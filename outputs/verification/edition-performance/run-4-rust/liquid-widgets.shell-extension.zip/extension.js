// <define:__LIQUID_EDITION__>
var define_LIQUID_EDITION_default = { backend: "rust", uuid: "liquid-widgets@local", schemaId: "org.gnome.shell.extensions.liquid-widgets", schemaPath: "/org/gnome/shell/extensions/liquid-widgets/", dataDirectory: "liquid-widgets", secretApplication: "org.local.LiquidWidgets", output: "dist", homepage: "https://github.com/NyongCho/gnome-widget" };

// src/extension.ts
import { Extension } from "resource:///org/gnome/shell/extensions/extension.js";
import "gi://Gio";

// src/dbus.ts
import Gio from "gi://Gio";
import GLib from "gi://GLib";

// generated/validators.js
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var require_formats = __commonJS({
  "node_modules/ajv-formats/dist/formats.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.formatNames = exports.fastFormats = exports.fullFormats = void 0;
    function fmtDef(validate, compare) {
      return { validate, compare };
    }
    exports.fullFormats = {
      // date: http://tools.ietf.org/html/rfc3339#section-5.6
      date: fmtDef(date, compareDate),
      // date-time: http://tools.ietf.org/html/rfc3339#section-5.6
      time: fmtDef(getTime(true), compareTime),
      "date-time": fmtDef(getDateTime(true), compareDateTime),
      "iso-time": fmtDef(getTime(), compareIsoTime),
      "iso-date-time": fmtDef(getDateTime(), compareIsoDateTime),
      // duration: https://tools.ietf.org/html/rfc3339#appendix-A
      duration: /^P(?!$)((\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+S)?)?|(\d+W)?)$/,
      uri,
      "uri-reference": /^(?:[a-z][a-z0-9+\-.]*:)?(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'"()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?(?:\?(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i,
      // uri-template: https://tools.ietf.org/html/rfc6570
      "uri-template": /^(?:(?:[^\x00-\x20"'<>%\\^`{|}]|%[0-9a-f]{2})|\{[+#./;?&=,!@|]?(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?(?:,(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?)*\})*$/i,
      // For the source: https://gist.github.com/dperini/729294
      // For test cases: https://mathiasbynens.be/demo/url-regex
      url: /^(?:https?|ftp):\/\/(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)(?:\.(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)*(?:\.(?:[a-z\u{00a1}-\u{ffff}]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/iu,
      email: /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i,
      hostname: /^(?=.{1,253}\.?$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[-0-9a-z]{0,61}[0-9a-z])?)*\.?$/i,
      // optimized https://www.safaribooksonline.com/library/view/regular-expressions-cookbook/9780596802837/ch07s16.html
      ipv4: /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/,
      ipv6: /^((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))$/i,
      regex,
      // uuid: http://tools.ietf.org/html/rfc4122
      uuid: /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i,
      // JSON-pointer: https://tools.ietf.org/html/rfc6901
      // uri fragment: https://tools.ietf.org/html/rfc3986#appendix-A
      "json-pointer": /^(?:\/(?:[^~/]|~0|~1)*)*$/,
      "json-pointer-uri-fragment": /^#(?:\/(?:[a-z0-9_\-.!$&'()*+,;:=@]|%[0-9a-f]{2}|~0|~1)*)*$/i,
      // relative JSON-pointer: http://tools.ietf.org/html/draft-luff-relative-json-pointer-00
      "relative-json-pointer": /^(?:0|[1-9][0-9]*)(?:#|(?:\/(?:[^~/]|~0|~1)*)*)$/,
      // the following formats are used by the openapi specification: https://spec.openapis.org/oas/v3.0.0#data-types
      // byte: https://github.com/miguelmota/is-base64
      byte,
      // signed 32 bit integer
      int32: { type: "number", validate: validateInt32 },
      // signed 64 bit integer
      int64: { type: "number", validate: validateInt64 },
      // C-type float
      float: { type: "number", validate: validateNumber },
      // C-type double
      double: { type: "number", validate: validateNumber },
      // hint to the UI to hide input strings
      password: true,
      // unchecked string payload
      binary: true
    };
    exports.fastFormats = {
      ...exports.fullFormats,
      date: fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\d$/, compareDate),
      time: fmtDef(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, compareTime),
      "date-time": fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\dt(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, compareDateTime),
      "iso-time": fmtDef(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, compareIsoTime),
      "iso-date-time": fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\d[t\s](?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, compareIsoDateTime),
      // uri: https://github.com/mafintosh/is-my-json-valid/blob/master/formats.js
      uri: /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/)?[^\s]*$/i,
      "uri-reference": /^(?:(?:[a-z][a-z0-9+\-.]*:)?\/?\/)?(?:[^\\\s#][^\s#]*)?(?:#[^\\\s]*)?$/i,
      // email (sources from jsen validator):
      // http://stackoverflow.com/questions/201323/using-a-regular-expression-to-validate-an-email-address#answer-8829363
      // http://www.w3.org/TR/html5/forms.html#valid-e-mail-address (search for 'wilful violation')
      email: /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i
    };
    exports.formatNames = Object.keys(exports.fullFormats);
    function isLeapYear(year) {
      return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    }
    var DATE = /^(\d\d\d\d)-(\d\d)-(\d\d)$/;
    var DAYS = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    function date(str) {
      const matches = DATE.exec(str);
      if (!matches)
        return false;
      const year = +matches[1];
      const month = +matches[2];
      const day = +matches[3];
      return month >= 1 && month <= 12 && day >= 1 && day <= (month === 2 && isLeapYear(year) ? 29 : DAYS[month]);
    }
    function compareDate(d1, d2) {
      if (!(d1 && d2))
        return void 0;
      if (d1 > d2)
        return 1;
      if (d1 < d2)
        return -1;
      return 0;
    }
    var TIME = /^(\d\d):(\d\d):(\d\d(?:\.\d+)?)(z|([+-])(\d\d)(?::?(\d\d))?)?$/i;
    function getTime(strictTimeZone) {
      return function time(str) {
        const matches = TIME.exec(str);
        if (!matches)
          return false;
        const hr = +matches[1];
        const min = +matches[2];
        const sec = +matches[3];
        const tz = matches[4];
        const tzSign = matches[5] === "-" ? -1 : 1;
        const tzH = +(matches[6] || 0);
        const tzM = +(matches[7] || 0);
        if (tzH > 23 || tzM > 59 || strictTimeZone && !tz)
          return false;
        if (hr <= 23 && min <= 59 && sec < 60)
          return true;
        const utcMin = min - tzM * tzSign;
        const utcHr = hr - tzH * tzSign - (utcMin < 0 ? 1 : 0);
        return (utcHr === 23 || utcHr === -1) && (utcMin === 59 || utcMin === -1) && sec < 61;
      };
    }
    function compareTime(s1, s2) {
      if (!(s1 && s2))
        return void 0;
      const t1 = (/* @__PURE__ */ new Date("2020-01-01T" + s1)).valueOf();
      const t2 = (/* @__PURE__ */ new Date("2020-01-01T" + s2)).valueOf();
      if (!(t1 && t2))
        return void 0;
      return t1 - t2;
    }
    function compareIsoTime(t1, t2) {
      if (!(t1 && t2))
        return void 0;
      const a1 = TIME.exec(t1);
      const a2 = TIME.exec(t2);
      if (!(a1 && a2))
        return void 0;
      t1 = a1[1] + a1[2] + a1[3];
      t2 = a2[1] + a2[2] + a2[3];
      if (t1 > t2)
        return 1;
      if (t1 < t2)
        return -1;
      return 0;
    }
    var DATE_TIME_SEPARATOR = /t|\s/i;
    function getDateTime(strictTimeZone) {
      const time = getTime(strictTimeZone);
      return function date_time(str) {
        const dateTime = str.split(DATE_TIME_SEPARATOR);
        return dateTime.length === 2 && date(dateTime[0]) && time(dateTime[1]);
      };
    }
    function compareDateTime(dt1, dt2) {
      if (!(dt1 && dt2))
        return void 0;
      const d1 = new Date(dt1).valueOf();
      const d2 = new Date(dt2).valueOf();
      if (!(d1 && d2))
        return void 0;
      return d1 - d2;
    }
    function compareIsoDateTime(dt1, dt2) {
      if (!(dt1 && dt2))
        return void 0;
      const [d1, t1] = dt1.split(DATE_TIME_SEPARATOR);
      const [d2, t2] = dt2.split(DATE_TIME_SEPARATOR);
      const res = compareDate(d1, d2);
      if (res === void 0)
        return void 0;
      return res || compareTime(t1, t2);
    }
    var NOT_URI_FRAGMENT = /\/|:/;
    var URI = /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)(?:\?(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
    function uri(str) {
      return NOT_URI_FRAGMENT.test(str) && URI.test(str);
    }
    var BYTE = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/gm;
    function byte(str) {
      BYTE.lastIndex = 0;
      return BYTE.test(str);
    }
    var MIN_INT32 = -(2 ** 31);
    var MAX_INT32 = 2 ** 31 - 1;
    function validateInt32(value) {
      return Number.isInteger(value) && value <= MAX_INT32 && value >= MIN_INT32;
    }
    function validateInt64(value) {
      return Number.isInteger(value);
    }
    function validateNumber() {
      return true;
    }
    var Z_ANCHOR = /[^\\]\\Z/;
    function regex(str) {
      if (Z_ANCHOR.test(str))
        return false;
      try {
        new RegExp(str);
        return true;
      } catch (e) {
        return false;
      }
    }
  }
});
var require_ucs2length = __commonJS({
  "node_modules/ajv/dist/runtime/ucs2length.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function ucs2length(str) {
      const len = str.length;
      let length = 0;
      let pos = 0;
      let value;
      while (pos < len) {
        length++;
        value = str.charCodeAt(pos++);
        if (value >= 55296 && value <= 56319 && pos < len) {
          value = str.charCodeAt(pos);
          if ((value & 64512) === 56320)
            pos++;
        }
      }
      return length;
    }
    exports.default = ucs2length;
    ucs2length.code = 'require("ajv/dist/runtime/ucs2length").default';
  }
});
var snapshot = validate20;
var formats0 = require_formats().fullFormats["date-time"];
var func1 = require_ucs2length().default;
var schema32 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/CalendarData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/CalendarData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
var pattern4 = new RegExp("^[0-9]{4}-(0[1-9]|1[0-2])$", "u");
var formats2 = require_formats().fullFormats.date;
function validate22(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate22.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.month === void 0 && (missing0 = "month") || data.timeZone === void 0 && (missing0 = "timeZone") || data.weekStart === void 0 && (missing0 = "weekStart") || data.events === void 0 && (missing0 = "events")) {
        validate22.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "month" || key0 === "timeZone" || key0 === "weekStart" || key0 === "events")) {
            validate22.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.month !== void 0) {
            let data0 = data.month;
            const _errs2 = errors2;
            if (errors2 === _errs2) {
              if (typeof data0 === "string") {
                if (func1(data0) > 7) {
                  validate22.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                  return false;
                } else {
                  if (!pattern4.test(data0)) {
                    validate22.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                    return false;
                  }
                }
              } else {
                validate22.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.timeZone !== void 0) {
              let data1 = data.timeZone;
              const _errs4 = errors2;
              if (errors2 === _errs4) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 255) {
                    validate22.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate22.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate22.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs4 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weekStart !== void 0) {
                let data2 = data.weekStart;
                const _errs6 = errors2;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate22.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors2 === _errs6) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 6 || isNaN(data2)) {
                      validate22.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate22.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs6 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.events !== void 0) {
                  let data3 = data.events;
                  const _errs8 = errors2;
                  if (errors2 === _errs8) {
                    if (Array.isArray(data3)) {
                      if (data3.length > 1e4) {
                        validate22.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/maxItems", keyword: "maxItems", params: { limit: 1e4 }, message: "must NOT have more than 10000 items" }];
                        return false;
                      } else {
                        var valid1 = true;
                        const len0 = data3.length;
                        for (let i0 = 0; i0 < len0; i0++) {
                          let data4 = data3[i0];
                          const _errs10 = errors2;
                          const _errs11 = errors2;
                          const _errs14 = errors2;
                          let valid4 = true;
                          const _errs15 = errors2;
                          if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                            if (data4.allDay !== void 0) {
                              if (true !== data4.allDay) {
                                const err0 = {};
                                if (vErrors === null) {
                                  vErrors = [err0];
                                } else {
                                  vErrors.push(err0);
                                }
                                errors2++;
                              }
                            }
                          }
                          var _valid0 = _errs15 === errors2;
                          errors2 = _errs14;
                          if (vErrors !== null) {
                            if (_errs14) {
                              vErrors.length = _errs14;
                            } else {
                              vErrors = null;
                            }
                          }
                          let ifClause0;
                          if (_valid0) {
                            const _errs17 = errors2;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data6 = data4.start;
                                const _errs18 = errors2;
                                if (errors2 === _errs18) {
                                  if (errors2 === _errs18) {
                                    if (typeof data6 === "string") {
                                      if (func1(data6) > 10) {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                        return false;
                                      } else {
                                        if (!formats2.validate(data6)) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid6 = _errs18 === errors2;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.end !== void 0) {
                                  let data7 = data4.end;
                                  const _errs20 = errors2;
                                  if (errors2 === _errs20) {
                                    if (errors2 === _errs20) {
                                      if (typeof data7 === "string") {
                                        if (func1(data7) > 10) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                          return false;
                                        } else {
                                          if (!formats2.validate(data7)) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid6 = _errs20 === errors2;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                            var _valid0 = _errs17 === errors2;
                            valid4 = _valid0;
                            if (valid4) {
                              var props0 = {};
                              props0.start = true;
                              props0.end = true;
                              props0.allDay = true;
                            }
                            ifClause0 = "then";
                          } else {
                            const _errs22 = errors2;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data8 = data4.start;
                                const _errs23 = errors2;
                                if (errors2 === _errs23) {
                                  if (errors2 === _errs23) {
                                    if (typeof data8 === "string") {
                                      if (func1(data8) > 64) {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                        return false;
                                      } else {
                                        if (!formats0.validate(data8)) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid7 = _errs23 === errors2;
                              } else {
                                var valid7 = true;
                              }
                              if (valid7) {
                                if (data4.end !== void 0) {
                                  let data9 = data4.end;
                                  const _errs25 = errors2;
                                  if (errors2 === _errs25) {
                                    if (errors2 === _errs25) {
                                      if (typeof data9 === "string") {
                                        if (func1(data9) > 64) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                          return false;
                                        } else {
                                          if (!formats0.validate(data9)) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid7 = _errs25 === errors2;
                                } else {
                                  var valid7 = true;
                                }
                              }
                            }
                            var _valid0 = _errs22 === errors2;
                            valid4 = _valid0;
                            if (valid4) {
                              if (props0 !== true) {
                                props0 = props0 || {};
                                props0.start = true;
                                props0.end = true;
                              }
                            }
                            ifClause0 = "else";
                          }
                          if (!valid4) {
                            const err1 = { instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/allOf/0/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
                            if (vErrors === null) {
                              vErrors = [err1];
                            } else {
                              vErrors.push(err1);
                            }
                            errors2++;
                            validate22.errors = vErrors;
                            return false;
                          }
                          if (errors2 === _errs11) {
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              let missing1;
                              if (data4.uid === void 0 && (missing1 = "uid") || data4.occurrenceKey === void 0 && (missing1 = "occurrenceKey") || data4.title === void 0 && (missing1 = "title") || data4.start === void 0 && (missing1 = "start") || data4.end === void 0 && (missing1 = "end") || data4.allDay === void 0 && (missing1 = "allDay")) {
                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                return false;
                              } else {
                                const _errs27 = errors2;
                                for (const key1 in data4) {
                                  if (!(key1 === "uid" || key1 === "occurrenceKey" || key1 === "title" || key1 === "start" || key1 === "end" || key1 === "allDay")) {
                                    validate22.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                    return false;
                                    break;
                                  }
                                }
                                if (_errs27 === errors2) {
                                  if (data4.uid !== void 0) {
                                    let data10 = data4.uid;
                                    const _errs28 = errors2;
                                    if (errors2 === _errs28) {
                                      if (typeof data10 === "string") {
                                        if (func1(data10) > 2048) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/maxLength", keyword: "maxLength", params: { limit: 2048 }, message: "must NOT have more than 2048 characters" }];
                                          return false;
                                        } else {
                                          if (func1(data10) < 1) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                    var valid8 = _errs28 === errors2;
                                  } else {
                                    var valid8 = true;
                                  }
                                  if (valid8) {
                                    if (data4.occurrenceKey !== void 0) {
                                      let data11 = data4.occurrenceKey;
                                      const _errs30 = errors2;
                                      if (errors2 === _errs30) {
                                        if (typeof data11 === "string") {
                                          if (func1(data11) > 64) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                            return false;
                                          } else {
                                            if (func1(data11) < 1) {
                                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                              return false;
                                            }
                                          }
                                        } else {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                          return false;
                                        }
                                      }
                                      var valid8 = _errs30 === errors2;
                                    } else {
                                      var valid8 = true;
                                    }
                                    if (valid8) {
                                      if (data4.title !== void 0) {
                                        let data12 = data4.title;
                                        const _errs32 = errors2;
                                        if (errors2 === _errs32) {
                                          if (typeof data12 === "string") {
                                            if (func1(data12) > 4096) {
                                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                                              return false;
                                            }
                                          } else {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                            return false;
                                          }
                                        }
                                        var valid8 = _errs32 === errors2;
                                      } else {
                                        var valid8 = true;
                                      }
                                      if (valid8) {
                                        if (data4.start !== void 0) {
                                          let data13 = data4.start;
                                          const _errs34 = errors2;
                                          if (errors2 === _errs34) {
                                            if (typeof data13 === "string") {
                                              if (func1(data13) > 64) {
                                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                return false;
                                              }
                                            } else {
                                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                              return false;
                                            }
                                          }
                                          var valid8 = _errs34 === errors2;
                                        } else {
                                          var valid8 = true;
                                        }
                                        if (valid8) {
                                          if (data4.end !== void 0) {
                                            let data14 = data4.end;
                                            const _errs36 = errors2;
                                            if (errors2 === _errs36) {
                                              if (typeof data14 === "string") {
                                                if (func1(data14) > 64) {
                                                  validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                }
                                              } else {
                                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                            var valid8 = _errs36 === errors2;
                                          } else {
                                            var valid8 = true;
                                          }
                                          if (valid8) {
                                            if (data4.allDay !== void 0) {
                                              const _errs38 = errors2;
                                              if (typeof data4.allDay !== "boolean") {
                                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/allDay", schemaPath: "#/$defs/CalendarEvent/properties/allDay/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                                                return false;
                                              }
                                              var valid8 = _errs38 === errors2;
                                            } else {
                                              var valid8 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            } else {
                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                              return false;
                            }
                          }
                          var valid1 = _errs10 === errors2;
                          if (!valid1) {
                            break;
                          }
                        }
                      }
                    } else {
                      validate22.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                      return false;
                    }
                  }
                  var valid0 = _errs8 === errors2;
                } else {
                  var valid0 = true;
                }
              }
            }
          }
        }
      }
    } else {
      validate22.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate22.errors = vErrors;
  return errors2 === 0;
}
validate22.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var pattern5 = new RegExp("^[A-Za-z0-9_-]+$", "u");
function validate21(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate21.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        const _errs6 = errors2;
        if (!validate22(data.data, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
          vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
          errors2 = vErrors.length;
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data2 = data.updatedAt;
          const _errs7 = errors2;
          if (errors2 === _errs7) {
            if (errors2 === _errs7) {
              if (typeof data2 === "string") {
                if (func1(data2) > 64) {
                  validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data2)) {
                    validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs7 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err1 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err1];
    } else {
      vErrors.push(err1);
    }
    errors2++;
    validate21.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs9 = errors2;
    const _errs10 = errors2;
    let valid4 = true;
    const _errs11 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data3 = data.status;
        if (!(data3 === "unconfigured" || data3 === "unavailable")) {
          const err2 = {};
          if (vErrors === null) {
            vErrors = [err2];
          } else {
            vErrors.push(err2);
          }
          errors2++;
        }
      }
    }
    var _valid1 = _errs11 === errors2;
    errors2 = _errs10;
    if (vErrors !== null) {
      if (_errs10) {
        vErrors.length = _errs10;
      } else {
        vErrors = null;
      }
    }
    if (_valid1) {
      const _errs13 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs14 = errors2;
          if (data.data !== null) {
            validate21.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid6 = _errs14 === errors2;
        } else {
          var valid6 = true;
        }
        if (valid6) {
          if (data.updatedAt !== void 0) {
            const _errs16 = errors2;
            if (data.updatedAt !== null) {
              validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid6 = _errs16 === errors2;
          } else {
            var valid6 = true;
          }
        }
      }
      var _valid1 = _errs13 === errors2;
      valid4 = _valid1;
      if (valid4) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid4) {
      const err3 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors2++;
      validate21.errors = vErrors;
      return false;
    }
    var valid0 = _errs9 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs18 = errors2;
      const _errs19 = errors2;
      let valid7 = true;
      const _errs20 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data6 = data.status;
          if (!(data6 === "ok" || data6 === "unconfigured" || data6 === "loading")) {
            const err4 = {};
            if (vErrors === null) {
              vErrors = [err4];
            } else {
              vErrors.push(err4);
            }
            errors2++;
          }
        }
      }
      var _valid2 = _errs20 === errors2;
      errors2 = _errs19;
      if (vErrors !== null) {
        if (_errs19) {
          vErrors.length = _errs19;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid2) {
        const _errs22 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate21.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid2 = _errs22 === errors2;
        valid7 = _valid2;
        if (valid7) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs25 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data8 = data.errorCode;
            if (!(data8 === "NETWORK_ERROR" || data8 === "INVALID_DATA" || data8 === "PAYLOAD_TOO_LARGE" || data8 === "EXPANSION_LIMIT" || data8 === "UNSUPPORTED_CALENDAR" || data8 === "UNKNOWN_TIME_ZONE" || data8 === "KEYRING_LOCKED" || data8 === "SECRET_DELETION_FAILED" || data8 === "AUTH_ERROR" || data8 === "RATE_LIMITED" || data8 === "NO_PLAYER" || data8 === "NO_INTERFACE" || data8 === "SERVICE_UNAVAILABLE" || data8 === "INTERNAL_ERROR")) {
              validate21.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema32.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid2 = _errs25 === errors2;
        valid7 = _valid2;
        if (valid7) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid7) {
        const err5 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err5];
        } else {
          vErrors.push(err5);
        }
        errors2++;
        validate21.errors = vErrors;
        return false;
      }
      var valid0 = _errs18 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.status === void 0 && (missing0 = "status") || data.sourceId === void 0 && (missing0 = "sourceId") || data.updatedAt === void 0 && (missing0 = "updatedAt") || data.data === void 0 && (missing0 = "data") || data.errorCode === void 0 && (missing0 = "errorCode")) {
        validate21.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs27 = errors2;
        for (const key0 in data) {
          if (!(key0 === "status" || key0 === "sourceId" || key0 === "updatedAt" || key0 === "data" || key0 === "errorCode")) {
            validate21.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs27 === errors2) {
          if (data.status !== void 0) {
            let data9 = data.status;
            const _errs28 = errors2;
            if (!(data9 === "loading" || data9 === "ok" || data9 === "stale" || data9 === "unconfigured" || data9 === "unavailable")) {
              validate21.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema32.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid11 = _errs28 === errors2;
          } else {
            var valid11 = true;
          }
          if (valid11) {
            if (data.sourceId !== void 0) {
              let data10 = data.sourceId;
              const _errs29 = errors2;
              const _errs30 = errors2;
              let valid12 = false;
              const _errs31 = errors2;
              if (errors2 === _errs31) {
                if (typeof data10 === "string") {
                  if (func1(data10) > 128) {
                    const err6 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err6];
                    } else {
                      vErrors.push(err6);
                    }
                    errors2++;
                  } else {
                    if (func1(data10) < 1) {
                      const err7 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err7];
                      } else {
                        vErrors.push(err7);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data10)) {
                        const err8 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err9 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err9];
                  } else {
                    vErrors.push(err9);
                  }
                  errors2++;
                }
              }
              var _valid3 = _errs31 === errors2;
              valid12 = valid12 || _valid3;
              const _errs33 = errors2;
              if (data10 !== null) {
                const err10 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err10];
                } else {
                  vErrors.push(err10);
                }
                errors2++;
              }
              var _valid3 = _errs33 === errors2;
              valid12 = valid12 || _valid3;
              if (!valid12) {
                const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err11];
                } else {
                  vErrors.push(err11);
                }
                errors2++;
                validate21.errors = vErrors;
                return false;
              } else {
                errors2 = _errs30;
                if (vErrors !== null) {
                  if (_errs30) {
                    vErrors.length = _errs30;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid11 = _errs29 === errors2;
            } else {
              var valid11 = true;
            }
            if (valid11) {
              if (data.updatedAt !== void 0) {
                let data11 = data.updatedAt;
                const _errs35 = errors2;
                const _errs36 = errors2;
                let valid13 = false;
                const _errs37 = errors2;
                if (errors2 === _errs37) {
                  if (errors2 === _errs37) {
                    if (typeof data11 === "string") {
                      if (func1(data11) > 64) {
                        const err12 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err12];
                        } else {
                          vErrors.push(err12);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data11)) {
                          const err13 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err13];
                          } else {
                            vErrors.push(err13);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err14 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err14];
                      } else {
                        vErrors.push(err14);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid4 = _errs37 === errors2;
                valid13 = valid13 || _valid4;
                const _errs39 = errors2;
                if (data11 !== null) {
                  const err15 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err15];
                  } else {
                    vErrors.push(err15);
                  }
                  errors2++;
                }
                var _valid4 = _errs39 === errors2;
                valid13 = valid13 || _valid4;
                if (!valid13) {
                  const err16 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err16];
                  } else {
                    vErrors.push(err16);
                  }
                  errors2++;
                  validate21.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs36;
                  if (vErrors !== null) {
                    if (_errs36) {
                      vErrors.length = _errs36;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid11 = _errs35 === errors2;
              } else {
                var valid11 = true;
              }
              if (valid11) {
                if (data.data !== void 0) {
                  let data12 = data.data;
                  const _errs41 = errors2;
                  const _errs42 = errors2;
                  let valid14 = false;
                  const _errs43 = errors2;
                  if (!validate22(data12, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
                    vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
                    errors2 = vErrors.length;
                  }
                  var _valid5 = _errs43 === errors2;
                  valid14 = valid14 || _valid5;
                  const _errs44 = errors2;
                  if (data12 !== null) {
                    const err17 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors2++;
                  }
                  var _valid5 = _errs44 === errors2;
                  valid14 = valid14 || _valid5;
                  if (!valid14) {
                    const err18 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err18];
                    } else {
                      vErrors.push(err18);
                    }
                    errors2++;
                    validate21.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs42;
                    if (vErrors !== null) {
                      if (_errs42) {
                        vErrors.length = _errs42;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid11 = _errs41 === errors2;
                } else {
                  var valid11 = true;
                }
                if (valid11) {
                  if (data.errorCode !== void 0) {
                    let data13 = data.errorCode;
                    const _errs46 = errors2;
                    const _errs47 = errors2;
                    let valid15 = false;
                    const _errs48 = errors2;
                    if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
                      const err19 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema32.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors2++;
                    }
                    var _valid6 = _errs48 === errors2;
                    valid15 = valid15 || _valid6;
                    const _errs49 = errors2;
                    if (data13 !== null) {
                      const err20 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err20];
                      } else {
                        vErrors.push(err20);
                      }
                      errors2++;
                    }
                    var _valid6 = _errs49 === errors2;
                    valid15 = valid15 || _valid6;
                    if (!valid15) {
                      const err21 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err21];
                      } else {
                        vErrors.push(err21);
                      }
                      errors2++;
                      validate21.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs47;
                      if (vErrors !== null) {
                        if (_errs47) {
                          vErrors.length = _errs47;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid11 = _errs46 === errors2;
                  } else {
                    var valid11 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate21.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate21.errors = vErrors;
  return errors2 === 0;
}
validate21.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema35 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/WeatherData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/WeatherData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
var pattern6 = new RegExp("^https://", "u");
function validate26(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate26.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.location === void 0 && (missing0 = "location") || data1.timeZone === void 0 && (missing0 = "timeZone") || data1.current === void 0 && (missing0 = "current") || data1.hourly === void 0 && (missing0 = "hourly") || data1.attributionUrl === void 0 && (missing0 = "attributionUrl")) {
              validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "location" || key0 === "timeZone" || key0 === "current" || key0 === "hourly" || key0 === "attributionUrl")) {
                  validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.location !== void 0) {
                  let data2 = data1.location;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 512) {
                        validate26.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                        return false;
                      }
                    } else {
                      validate26.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.timeZone !== void 0) {
                    let data3 = data1.timeZone;
                    const _errs12 = errors2;
                    if (errors2 === _errs12) {
                      if (typeof data3 === "string") {
                        if (func1(data3) > 255) {
                          validate26.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                          return false;
                        } else {
                          if (func1(data3) < 1) {
                            validate26.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          }
                        }
                      } else {
                        validate26.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.current !== void 0) {
                      let data4 = data1.current;
                      const _errs14 = errors2;
                      if (errors2 === _errs14) {
                        if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                          let missing1;
                          if (data4.temperatureC === void 0 && (missing1 = "temperatureC") || data4.code === void 0 && (missing1 = "code")) {
                            validate26.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                            return false;
                          } else {
                            const _errs16 = errors2;
                            for (const key1 in data4) {
                              if (!(key1 === "temperatureC" || key1 === "code")) {
                                validate26.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                return false;
                                break;
                              }
                            }
                            if (_errs16 === errors2) {
                              if (data4.temperatureC !== void 0) {
                                let data5 = data4.temperatureC;
                                const _errs17 = errors2;
                                const _errs18 = errors2;
                                let valid7 = false;
                                const _errs19 = errors2;
                                if (!(typeof data5 == "number" && isFinite(data5))) {
                                  const err1 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err1];
                                  } else {
                                    vErrors.push(err1);
                                  }
                                  errors2++;
                                }
                                var _valid1 = _errs19 === errors2;
                                valid7 = valid7 || _valid1;
                                const _errs21 = errors2;
                                if (data5 !== null) {
                                  const err2 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors2++;
                                }
                                var _valid1 = _errs21 === errors2;
                                valid7 = valid7 || _valid1;
                                if (!valid7) {
                                  const err3 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err3];
                                  } else {
                                    vErrors.push(err3);
                                  }
                                  errors2++;
                                  validate26.errors = vErrors;
                                  return false;
                                } else {
                                  errors2 = _errs18;
                                  if (vErrors !== null) {
                                    if (_errs18) {
                                      vErrors.length = _errs18;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid6 = _errs17 === errors2;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.code !== void 0) {
                                  let data6 = data4.code;
                                  const _errs23 = errors2;
                                  const _errs24 = errors2;
                                  let valid8 = false;
                                  const _errs25 = errors2;
                                  if (!(typeof data6 == "number" && (!(data6 % 1) && !isNaN(data6)) && isFinite(data6))) {
                                    const err4 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err4];
                                    } else {
                                      vErrors.push(err4);
                                    }
                                    errors2++;
                                  }
                                  if (errors2 === _errs25) {
                                    if (typeof data6 == "number" && isFinite(data6)) {
                                      if (data6 > 99 || isNaN(data6)) {
                                        const err5 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                        if (vErrors === null) {
                                          vErrors = [err5];
                                        } else {
                                          vErrors.push(err5);
                                        }
                                        errors2++;
                                      } else {
                                        if (data6 < 0 || isNaN(data6)) {
                                          const err6 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                          if (vErrors === null) {
                                            vErrors = [err6];
                                          } else {
                                            vErrors.push(err6);
                                          }
                                          errors2++;
                                        }
                                      }
                                    }
                                  }
                                  var _valid2 = _errs25 === errors2;
                                  valid8 = valid8 || _valid2;
                                  const _errs27 = errors2;
                                  if (data6 !== null) {
                                    const err7 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err7];
                                    } else {
                                      vErrors.push(err7);
                                    }
                                    errors2++;
                                  }
                                  var _valid2 = _errs27 === errors2;
                                  valid8 = valid8 || _valid2;
                                  if (!valid8) {
                                    const err8 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors2++;
                                    validate26.errors = vErrors;
                                    return false;
                                  } else {
                                    errors2 = _errs24;
                                    if (vErrors !== null) {
                                      if (_errs24) {
                                        vErrors.length = _errs24;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid6 = _errs23 === errors2;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                          }
                        } else {
                          validate26.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                          return false;
                        }
                      }
                      var valid5 = _errs14 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.hourly !== void 0) {
                        let data7 = data1.hourly;
                        const _errs29 = errors2;
                        if (errors2 === _errs29) {
                          if (Array.isArray(data7)) {
                            if (data7.length > 6) {
                              validate26.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" }];
                              return false;
                            } else {
                              var valid9 = true;
                              const len0 = data7.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data8 = data7[i0];
                                const _errs31 = errors2;
                                if (errors2 === _errs31) {
                                  if (data8 && typeof data8 == "object" && !Array.isArray(data8)) {
                                    let missing2;
                                    if (data8.at === void 0 && (missing2 = "at") || data8.temperatureC === void 0 && (missing2 = "temperatureC") || data8.precipitationProbability === void 0 && (missing2 = "precipitationProbability")) {
                                      validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
                                      return false;
                                    } else {
                                      const _errs33 = errors2;
                                      for (const key2 in data8) {
                                        if (!(key2 === "at" || key2 === "temperatureC" || key2 === "precipitationProbability")) {
                                          validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs33 === errors2) {
                                        if (data8.at !== void 0) {
                                          let data9 = data8.at;
                                          const _errs34 = errors2;
                                          if (errors2 === _errs34) {
                                            if (errors2 === _errs34) {
                                              if (typeof data9 === "string") {
                                                if (func1(data9) > 64) {
                                                  validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data9)) {
                                                    validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid10 = _errs34 === errors2;
                                        } else {
                                          var valid10 = true;
                                        }
                                        if (valid10) {
                                          if (data8.temperatureC !== void 0) {
                                            let data10 = data8.temperatureC;
                                            const _errs36 = errors2;
                                            const _errs37 = errors2;
                                            let valid11 = false;
                                            const _errs38 = errors2;
                                            if (!(typeof data10 == "number" && isFinite(data10))) {
                                              const err9 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                              if (vErrors === null) {
                                                vErrors = [err9];
                                              } else {
                                                vErrors.push(err9);
                                              }
                                              errors2++;
                                            }
                                            var _valid3 = _errs38 === errors2;
                                            valid11 = valid11 || _valid3;
                                            const _errs40 = errors2;
                                            if (data10 !== null) {
                                              const err10 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err10];
                                              } else {
                                                vErrors.push(err10);
                                              }
                                              errors2++;
                                            }
                                            var _valid3 = _errs40 === errors2;
                                            valid11 = valid11 || _valid3;
                                            if (!valid11) {
                                              const err11 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err11];
                                              } else {
                                                vErrors.push(err11);
                                              }
                                              errors2++;
                                              validate26.errors = vErrors;
                                              return false;
                                            } else {
                                              errors2 = _errs37;
                                              if (vErrors !== null) {
                                                if (_errs37) {
                                                  vErrors.length = _errs37;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid10 = _errs36 === errors2;
                                          } else {
                                            var valid10 = true;
                                          }
                                          if (valid10) {
                                            if (data8.precipitationProbability !== void 0) {
                                              let data11 = data8.precipitationProbability;
                                              const _errs42 = errors2;
                                              const _errs43 = errors2;
                                              let valid12 = false;
                                              const _errs44 = errors2;
                                              if (errors2 === _errs44) {
                                                if (typeof data11 == "number" && isFinite(data11)) {
                                                  if (data11 > 100 || isNaN(data11)) {
                                                    const err12 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                    if (vErrors === null) {
                                                      vErrors = [err12];
                                                    } else {
                                                      vErrors.push(err12);
                                                    }
                                                    errors2++;
                                                  } else {
                                                    if (data11 < 0 || isNaN(data11)) {
                                                      const err13 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                      if (vErrors === null) {
                                                        vErrors = [err13];
                                                      } else {
                                                        vErrors.push(err13);
                                                      }
                                                      errors2++;
                                                    }
                                                  }
                                                } else {
                                                  const err14 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                  if (vErrors === null) {
                                                    vErrors = [err14];
                                                  } else {
                                                    vErrors.push(err14);
                                                  }
                                                  errors2++;
                                                }
                                              }
                                              var _valid4 = _errs44 === errors2;
                                              valid12 = valid12 || _valid4;
                                              const _errs46 = errors2;
                                              if (data11 !== null) {
                                                const err15 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                if (vErrors === null) {
                                                  vErrors = [err15];
                                                } else {
                                                  vErrors.push(err15);
                                                }
                                                errors2++;
                                              }
                                              var _valid4 = _errs46 === errors2;
                                              valid12 = valid12 || _valid4;
                                              if (!valid12) {
                                                const err16 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                if (vErrors === null) {
                                                  vErrors = [err16];
                                                } else {
                                                  vErrors.push(err16);
                                                }
                                                errors2++;
                                                validate26.errors = vErrors;
                                                return false;
                                              } else {
                                                errors2 = _errs43;
                                                if (vErrors !== null) {
                                                  if (_errs43) {
                                                    vErrors.length = _errs43;
                                                  } else {
                                                    vErrors = null;
                                                  }
                                                }
                                              }
                                              var valid10 = _errs42 === errors2;
                                            } else {
                                              var valid10 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid9 = _errs31 === errors2;
                                if (!valid9) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate26.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs29 === errors2;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.attributionUrl !== void 0) {
                          let data12 = data1.attributionUrl;
                          const _errs48 = errors2;
                          if (errors2 === _errs48) {
                            if (typeof data12 === "string") {
                              if (func1(data12) > 512) {
                                validate26.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                                return false;
                              } else {
                                if (!pattern6.test(data12)) {
                                  validate26.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' }];
                                  return false;
                                }
                              }
                            } else {
                              validate26.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                              return false;
                            }
                          }
                          var valid5 = _errs48 === errors2;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data13 = data.updatedAt;
          const _errs50 = errors2;
          if (errors2 === _errs50) {
            if (errors2 === _errs50) {
              if (typeof data13 === "string") {
                if (func1(data13) > 64) {
                  validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data13)) {
                    validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs50 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err17 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err17];
    } else {
      vErrors.push(err17);
    }
    errors2++;
    validate26.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs52 = errors2;
    const _errs53 = errors2;
    let valid13 = true;
    const _errs54 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data14 = data.status;
        if (!(data14 === "unconfigured" || data14 === "unavailable")) {
          const err18 = {};
          if (vErrors === null) {
            vErrors = [err18];
          } else {
            vErrors.push(err18);
          }
          errors2++;
        }
      }
    }
    var _valid5 = _errs54 === errors2;
    errors2 = _errs53;
    if (vErrors !== null) {
      if (_errs53) {
        vErrors.length = _errs53;
      } else {
        vErrors = null;
      }
    }
    if (_valid5) {
      const _errs56 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs57 = errors2;
          if (data.data !== null) {
            validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid15 = _errs57 === errors2;
        } else {
          var valid15 = true;
        }
        if (valid15) {
          if (data.updatedAt !== void 0) {
            const _errs59 = errors2;
            if (data.updatedAt !== null) {
              validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid15 = _errs59 === errors2;
          } else {
            var valid15 = true;
          }
        }
      }
      var _valid5 = _errs56 === errors2;
      valid13 = _valid5;
      if (valid13) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid13) {
      const err19 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err19];
      } else {
        vErrors.push(err19);
      }
      errors2++;
      validate26.errors = vErrors;
      return false;
    }
    var valid0 = _errs52 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs61 = errors2;
      const _errs62 = errors2;
      let valid16 = true;
      const _errs63 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data17 = data.status;
          if (!(data17 === "ok" || data17 === "unconfigured" || data17 === "loading")) {
            const err20 = {};
            if (vErrors === null) {
              vErrors = [err20];
            } else {
              vErrors.push(err20);
            }
            errors2++;
          }
        }
      }
      var _valid6 = _errs63 === errors2;
      errors2 = _errs62;
      if (vErrors !== null) {
        if (_errs62) {
          vErrors.length = _errs62;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid6) {
        const _errs65 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate26.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid6 = _errs65 === errors2;
        valid16 = _valid6;
        if (valid16) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs68 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data19 = data.errorCode;
            if (!(data19 === "NETWORK_ERROR" || data19 === "INVALID_DATA" || data19 === "PAYLOAD_TOO_LARGE" || data19 === "EXPANSION_LIMIT" || data19 === "UNSUPPORTED_CALENDAR" || data19 === "UNKNOWN_TIME_ZONE" || data19 === "KEYRING_LOCKED" || data19 === "SECRET_DELETION_FAILED" || data19 === "AUTH_ERROR" || data19 === "RATE_LIMITED" || data19 === "NO_PLAYER" || data19 === "NO_INTERFACE" || data19 === "SERVICE_UNAVAILABLE" || data19 === "INTERNAL_ERROR")) {
              validate26.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema35.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid6 = _errs68 === errors2;
        valid16 = _valid6;
        if (valid16) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid16) {
        const err21 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err21];
        } else {
          vErrors.push(err21);
        }
        errors2++;
        validate26.errors = vErrors;
        return false;
      }
      var valid0 = _errs61 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing3;
      if (data.status === void 0 && (missing3 = "status") || data.sourceId === void 0 && (missing3 = "sourceId") || data.updatedAt === void 0 && (missing3 = "updatedAt") || data.data === void 0 && (missing3 = "data") || data.errorCode === void 0 && (missing3 = "errorCode")) {
        validate26.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" }];
        return false;
      } else {
        const _errs70 = errors2;
        for (const key3 in data) {
          if (!(key3 === "status" || key3 === "sourceId" || key3 === "updatedAt" || key3 === "data" || key3 === "errorCode")) {
            validate26.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs70 === errors2) {
          if (data.status !== void 0) {
            let data20 = data.status;
            const _errs71 = errors2;
            if (!(data20 === "loading" || data20 === "ok" || data20 === "stale" || data20 === "unconfigured" || data20 === "unavailable")) {
              validate26.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema35.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid20 = _errs71 === errors2;
          } else {
            var valid20 = true;
          }
          if (valid20) {
            if (data.sourceId !== void 0) {
              let data21 = data.sourceId;
              const _errs72 = errors2;
              const _errs73 = errors2;
              let valid21 = false;
              const _errs74 = errors2;
              if (errors2 === _errs74) {
                if (typeof data21 === "string") {
                  if (func1(data21) > 128) {
                    const err22 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err22];
                    } else {
                      vErrors.push(err22);
                    }
                    errors2++;
                  } else {
                    if (func1(data21) < 1) {
                      const err23 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err23];
                      } else {
                        vErrors.push(err23);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data21)) {
                        const err24 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err24];
                        } else {
                          vErrors.push(err24);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err25 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err25];
                  } else {
                    vErrors.push(err25);
                  }
                  errors2++;
                }
              }
              var _valid7 = _errs74 === errors2;
              valid21 = valid21 || _valid7;
              const _errs76 = errors2;
              if (data21 !== null) {
                const err26 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err26];
                } else {
                  vErrors.push(err26);
                }
                errors2++;
              }
              var _valid7 = _errs76 === errors2;
              valid21 = valid21 || _valid7;
              if (!valid21) {
                const err27 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err27];
                } else {
                  vErrors.push(err27);
                }
                errors2++;
                validate26.errors = vErrors;
                return false;
              } else {
                errors2 = _errs73;
                if (vErrors !== null) {
                  if (_errs73) {
                    vErrors.length = _errs73;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid20 = _errs72 === errors2;
            } else {
              var valid20 = true;
            }
            if (valid20) {
              if (data.updatedAt !== void 0) {
                let data22 = data.updatedAt;
                const _errs78 = errors2;
                const _errs79 = errors2;
                let valid22 = false;
                const _errs80 = errors2;
                if (errors2 === _errs80) {
                  if (errors2 === _errs80) {
                    if (typeof data22 === "string") {
                      if (func1(data22) > 64) {
                        const err28 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err28];
                        } else {
                          vErrors.push(err28);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data22)) {
                          const err29 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err29];
                          } else {
                            vErrors.push(err29);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err30 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err30];
                      } else {
                        vErrors.push(err30);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid8 = _errs80 === errors2;
                valid22 = valid22 || _valid8;
                const _errs82 = errors2;
                if (data22 !== null) {
                  const err31 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err31];
                  } else {
                    vErrors.push(err31);
                  }
                  errors2++;
                }
                var _valid8 = _errs82 === errors2;
                valid22 = valid22 || _valid8;
                if (!valid22) {
                  const err32 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err32];
                  } else {
                    vErrors.push(err32);
                  }
                  errors2++;
                  validate26.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs79;
                  if (vErrors !== null) {
                    if (_errs79) {
                      vErrors.length = _errs79;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid20 = _errs78 === errors2;
              } else {
                var valid20 = true;
              }
              if (valid20) {
                if (data.data !== void 0) {
                  let data23 = data.data;
                  const _errs84 = errors2;
                  const _errs85 = errors2;
                  let valid23 = false;
                  const _errs86 = errors2;
                  const _errs87 = errors2;
                  if (errors2 === _errs87) {
                    if (data23 && typeof data23 == "object" && !Array.isArray(data23)) {
                      let missing4;
                      if (data23.location === void 0 && (missing4 = "location") || data23.timeZone === void 0 && (missing4 = "timeZone") || data23.current === void 0 && (missing4 = "current") || data23.hourly === void 0 && (missing4 = "hourly") || data23.attributionUrl === void 0 && (missing4 = "attributionUrl")) {
                        const err33 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                        if (vErrors === null) {
                          vErrors = [err33];
                        } else {
                          vErrors.push(err33);
                        }
                        errors2++;
                      } else {
                        const _errs89 = errors2;
                        for (const key4 in data23) {
                          if (!(key4 === "location" || key4 === "timeZone" || key4 === "current" || key4 === "hourly" || key4 === "attributionUrl")) {
                            const err34 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err34];
                            } else {
                              vErrors.push(err34);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs89 === errors2) {
                          if (data23.location !== void 0) {
                            let data24 = data23.location;
                            const _errs90 = errors2;
                            if (errors2 === _errs90) {
                              if (typeof data24 === "string") {
                                if (func1(data24) > 512) {
                                  const err35 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors2++;
                                }
                              } else {
                                const err36 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err36];
                                } else {
                                  vErrors.push(err36);
                                }
                                errors2++;
                              }
                            }
                            var valid25 = _errs90 === errors2;
                          } else {
                            var valid25 = true;
                          }
                          if (valid25) {
                            if (data23.timeZone !== void 0) {
                              let data25 = data23.timeZone;
                              const _errs92 = errors2;
                              if (errors2 === _errs92) {
                                if (typeof data25 === "string") {
                                  if (func1(data25) > 255) {
                                    const err37 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err37];
                                    } else {
                                      vErrors.push(err37);
                                    }
                                    errors2++;
                                  } else {
                                    if (func1(data25) < 1) {
                                      const err38 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err38];
                                      } else {
                                        vErrors.push(err38);
                                      }
                                      errors2++;
                                    }
                                  }
                                } else {
                                  const err39 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err39];
                                  } else {
                                    vErrors.push(err39);
                                  }
                                  errors2++;
                                }
                              }
                              var valid25 = _errs92 === errors2;
                            } else {
                              var valid25 = true;
                            }
                            if (valid25) {
                              if (data23.current !== void 0) {
                                let data26 = data23.current;
                                const _errs94 = errors2;
                                if (errors2 === _errs94) {
                                  if (data26 && typeof data26 == "object" && !Array.isArray(data26)) {
                                    let missing5;
                                    if (data26.temperatureC === void 0 && (missing5 = "temperatureC") || data26.code === void 0 && (missing5 = "code")) {
                                      const err40 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing5 }, message: "must have required property '" + missing5 + "'" };
                                      if (vErrors === null) {
                                        vErrors = [err40];
                                      } else {
                                        vErrors.push(err40);
                                      }
                                      errors2++;
                                    } else {
                                      const _errs96 = errors2;
                                      for (const key5 in data26) {
                                        if (!(key5 === "temperatureC" || key5 === "code")) {
                                          const err41 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                                          if (vErrors === null) {
                                            vErrors = [err41];
                                          } else {
                                            vErrors.push(err41);
                                          }
                                          errors2++;
                                          break;
                                        }
                                      }
                                      if (_errs96 === errors2) {
                                        if (data26.temperatureC !== void 0) {
                                          let data27 = data26.temperatureC;
                                          const _errs97 = errors2;
                                          const _errs98 = errors2;
                                          let valid27 = false;
                                          const _errs99 = errors2;
                                          if (!(typeof data27 == "number" && isFinite(data27))) {
                                            const err42 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                            if (vErrors === null) {
                                              vErrors = [err42];
                                            } else {
                                              vErrors.push(err42);
                                            }
                                            errors2++;
                                          }
                                          var _valid10 = _errs99 === errors2;
                                          valid27 = valid27 || _valid10;
                                          const _errs101 = errors2;
                                          if (data27 !== null) {
                                            const err43 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                            if (vErrors === null) {
                                              vErrors = [err43];
                                            } else {
                                              vErrors.push(err43);
                                            }
                                            errors2++;
                                          }
                                          var _valid10 = _errs101 === errors2;
                                          valid27 = valid27 || _valid10;
                                          if (!valid27) {
                                            const err44 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                            if (vErrors === null) {
                                              vErrors = [err44];
                                            } else {
                                              vErrors.push(err44);
                                            }
                                            errors2++;
                                          } else {
                                            errors2 = _errs98;
                                            if (vErrors !== null) {
                                              if (_errs98) {
                                                vErrors.length = _errs98;
                                              } else {
                                                vErrors = null;
                                              }
                                            }
                                          }
                                          var valid26 = _errs97 === errors2;
                                        } else {
                                          var valid26 = true;
                                        }
                                        if (valid26) {
                                          if (data26.code !== void 0) {
                                            let data28 = data26.code;
                                            const _errs103 = errors2;
                                            const _errs104 = errors2;
                                            let valid28 = false;
                                            const _errs105 = errors2;
                                            if (!(typeof data28 == "number" && (!(data28 % 1) && !isNaN(data28)) && isFinite(data28))) {
                                              const err45 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                              if (vErrors === null) {
                                                vErrors = [err45];
                                              } else {
                                                vErrors.push(err45);
                                              }
                                              errors2++;
                                            }
                                            if (errors2 === _errs105) {
                                              if (typeof data28 == "number" && isFinite(data28)) {
                                                if (data28 > 99 || isNaN(data28)) {
                                                  const err46 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                                  if (vErrors === null) {
                                                    vErrors = [err46];
                                                  } else {
                                                    vErrors.push(err46);
                                                  }
                                                  errors2++;
                                                } else {
                                                  if (data28 < 0 || isNaN(data28)) {
                                                    const err47 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                    if (vErrors === null) {
                                                      vErrors = [err47];
                                                    } else {
                                                      vErrors.push(err47);
                                                    }
                                                    errors2++;
                                                  }
                                                }
                                              }
                                            }
                                            var _valid11 = _errs105 === errors2;
                                            valid28 = valid28 || _valid11;
                                            const _errs107 = errors2;
                                            if (data28 !== null) {
                                              const err48 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors2++;
                                            }
                                            var _valid11 = _errs107 === errors2;
                                            valid28 = valid28 || _valid11;
                                            if (!valid28) {
                                              const err49 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err49];
                                              } else {
                                                vErrors.push(err49);
                                              }
                                              errors2++;
                                            } else {
                                              errors2 = _errs104;
                                              if (vErrors !== null) {
                                                if (_errs104) {
                                                  vErrors.length = _errs104;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid26 = _errs103 === errors2;
                                          } else {
                                            var valid26 = true;
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    const err50 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                    if (vErrors === null) {
                                      vErrors = [err50];
                                    } else {
                                      vErrors.push(err50);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid25 = _errs94 === errors2;
                              } else {
                                var valid25 = true;
                              }
                              if (valid25) {
                                if (data23.hourly !== void 0) {
                                  let data29 = data23.hourly;
                                  const _errs109 = errors2;
                                  if (errors2 === _errs109) {
                                    if (Array.isArray(data29)) {
                                      if (data29.length > 6) {
                                        const err51 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" };
                                        if (vErrors === null) {
                                          vErrors = [err51];
                                        } else {
                                          vErrors.push(err51);
                                        }
                                        errors2++;
                                      } else {
                                        var valid29 = true;
                                        const len1 = data29.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data30 = data29[i1];
                                          const _errs111 = errors2;
                                          if (errors2 === _errs111) {
                                            if (data30 && typeof data30 == "object" && !Array.isArray(data30)) {
                                              let missing6;
                                              if (data30.at === void 0 && (missing6 = "at") || data30.temperatureC === void 0 && (missing6 = "temperatureC") || data30.precipitationProbability === void 0 && (missing6 = "precipitationProbability")) {
                                                const err52 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing6 }, message: "must have required property '" + missing6 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err52];
                                                } else {
                                                  vErrors.push(err52);
                                                }
                                                errors2++;
                                              } else {
                                                const _errs113 = errors2;
                                                for (const key6 in data30) {
                                                  if (!(key6 === "at" || key6 === "temperatureC" || key6 === "precipitationProbability")) {
                                                    const err53 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err53];
                                                    } else {
                                                      vErrors.push(err53);
                                                    }
                                                    errors2++;
                                                    break;
                                                  }
                                                }
                                                if (_errs113 === errors2) {
                                                  if (data30.at !== void 0) {
                                                    let data31 = data30.at;
                                                    const _errs114 = errors2;
                                                    if (errors2 === _errs114) {
                                                      if (errors2 === _errs114) {
                                                        if (typeof data31 === "string") {
                                                          if (func1(data31) > 64) {
                                                            const err54 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err54];
                                                            } else {
                                                              vErrors.push(err54);
                                                            }
                                                            errors2++;
                                                          } else {
                                                            if (!formats0.validate(data31)) {
                                                              const err55 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err55];
                                                              } else {
                                                                vErrors.push(err55);
                                                              }
                                                              errors2++;
                                                            }
                                                          }
                                                        } else {
                                                          const err56 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err56];
                                                          } else {
                                                            vErrors.push(err56);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                    }
                                                    var valid30 = _errs114 === errors2;
                                                  } else {
                                                    var valid30 = true;
                                                  }
                                                  if (valid30) {
                                                    if (data30.temperatureC !== void 0) {
                                                      let data32 = data30.temperatureC;
                                                      const _errs116 = errors2;
                                                      const _errs117 = errors2;
                                                      let valid31 = false;
                                                      const _errs118 = errors2;
                                                      if (!(typeof data32 == "number" && isFinite(data32))) {
                                                        const err57 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                        if (vErrors === null) {
                                                          vErrors = [err57];
                                                        } else {
                                                          vErrors.push(err57);
                                                        }
                                                        errors2++;
                                                      }
                                                      var _valid12 = _errs118 === errors2;
                                                      valid31 = valid31 || _valid12;
                                                      const _errs120 = errors2;
                                                      if (data32 !== null) {
                                                        const err58 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                        if (vErrors === null) {
                                                          vErrors = [err58];
                                                        } else {
                                                          vErrors.push(err58);
                                                        }
                                                        errors2++;
                                                      }
                                                      var _valid12 = _errs120 === errors2;
                                                      valid31 = valid31 || _valid12;
                                                      if (!valid31) {
                                                        const err59 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                        if (vErrors === null) {
                                                          vErrors = [err59];
                                                        } else {
                                                          vErrors.push(err59);
                                                        }
                                                        errors2++;
                                                      } else {
                                                        errors2 = _errs117;
                                                        if (vErrors !== null) {
                                                          if (_errs117) {
                                                            vErrors.length = _errs117;
                                                          } else {
                                                            vErrors = null;
                                                          }
                                                        }
                                                      }
                                                      var valid30 = _errs116 === errors2;
                                                    } else {
                                                      var valid30 = true;
                                                    }
                                                    if (valid30) {
                                                      if (data30.precipitationProbability !== void 0) {
                                                        let data33 = data30.precipitationProbability;
                                                        const _errs122 = errors2;
                                                        const _errs123 = errors2;
                                                        let valid32 = false;
                                                        const _errs124 = errors2;
                                                        if (errors2 === _errs124) {
                                                          if (typeof data33 == "number" && isFinite(data33)) {
                                                            if (data33 > 100 || isNaN(data33)) {
                                                              const err60 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                              if (vErrors === null) {
                                                                vErrors = [err60];
                                                              } else {
                                                                vErrors.push(err60);
                                                              }
                                                              errors2++;
                                                            } else {
                                                              if (data33 < 0 || isNaN(data33)) {
                                                                const err61 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                                if (vErrors === null) {
                                                                  vErrors = [err61];
                                                                } else {
                                                                  vErrors.push(err61);
                                                                }
                                                                errors2++;
                                                              }
                                                            }
                                                          } else {
                                                            const err62 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err62];
                                                            } else {
                                                              vErrors.push(err62);
                                                            }
                                                            errors2++;
                                                          }
                                                        }
                                                        var _valid13 = _errs124 === errors2;
                                                        valid32 = valid32 || _valid13;
                                                        const _errs126 = errors2;
                                                        if (data33 !== null) {
                                                          const err63 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                          if (vErrors === null) {
                                                            vErrors = [err63];
                                                          } else {
                                                            vErrors.push(err63);
                                                          }
                                                          errors2++;
                                                        }
                                                        var _valid13 = _errs126 === errors2;
                                                        valid32 = valid32 || _valid13;
                                                        if (!valid32) {
                                                          const err64 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                          if (vErrors === null) {
                                                            vErrors = [err64];
                                                          } else {
                                                            vErrors.push(err64);
                                                          }
                                                          errors2++;
                                                        } else {
                                                          errors2 = _errs123;
                                                          if (vErrors !== null) {
                                                            if (_errs123) {
                                                              vErrors.length = _errs123;
                                                            } else {
                                                              vErrors = null;
                                                            }
                                                          }
                                                        }
                                                        var valid30 = _errs122 === errors2;
                                                      } else {
                                                        var valid30 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err65 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err65];
                                              } else {
                                                vErrors.push(err65);
                                              }
                                              errors2++;
                                            }
                                          }
                                          var valid29 = _errs111 === errors2;
                                          if (!valid29) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err66 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err66];
                                      } else {
                                        vErrors.push(err66);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid25 = _errs109 === errors2;
                                } else {
                                  var valid25 = true;
                                }
                                if (valid25) {
                                  if (data23.attributionUrl !== void 0) {
                                    let data34 = data23.attributionUrl;
                                    const _errs128 = errors2;
                                    if (errors2 === _errs128) {
                                      if (typeof data34 === "string") {
                                        if (func1(data34) > 512) {
                                          const err67 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err67];
                                          } else {
                                            vErrors.push(err67);
                                          }
                                          errors2++;
                                        } else {
                                          if (!pattern6.test(data34)) {
                                            const err68 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' };
                                            if (vErrors === null) {
                                              vErrors = [err68];
                                            } else {
                                              vErrors.push(err68);
                                            }
                                            errors2++;
                                          }
                                        }
                                      } else {
                                        const err69 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err69];
                                        } else {
                                          vErrors.push(err69);
                                        }
                                        errors2++;
                                      }
                                    }
                                    var valid25 = _errs128 === errors2;
                                  } else {
                                    var valid25 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err70 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err70];
                      } else {
                        vErrors.push(err70);
                      }
                      errors2++;
                    }
                  }
                  var _valid9 = _errs86 === errors2;
                  valid23 = valid23 || _valid9;
                  const _errs130 = errors2;
                  if (data23 !== null) {
                    const err71 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err71];
                    } else {
                      vErrors.push(err71);
                    }
                    errors2++;
                  }
                  var _valid9 = _errs130 === errors2;
                  valid23 = valid23 || _valid9;
                  if (!valid23) {
                    const err72 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err72];
                    } else {
                      vErrors.push(err72);
                    }
                    errors2++;
                    validate26.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs85;
                    if (vErrors !== null) {
                      if (_errs85) {
                        vErrors.length = _errs85;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid20 = _errs84 === errors2;
                } else {
                  var valid20 = true;
                }
                if (valid20) {
                  if (data.errorCode !== void 0) {
                    let data35 = data.errorCode;
                    const _errs132 = errors2;
                    const _errs133 = errors2;
                    let valid33 = false;
                    const _errs134 = errors2;
                    if (!(data35 === "NETWORK_ERROR" || data35 === "INVALID_DATA" || data35 === "PAYLOAD_TOO_LARGE" || data35 === "EXPANSION_LIMIT" || data35 === "UNSUPPORTED_CALENDAR" || data35 === "UNKNOWN_TIME_ZONE" || data35 === "KEYRING_LOCKED" || data35 === "SECRET_DELETION_FAILED" || data35 === "AUTH_ERROR" || data35 === "RATE_LIMITED" || data35 === "NO_PLAYER" || data35 === "NO_INTERFACE" || data35 === "SERVICE_UNAVAILABLE" || data35 === "INTERNAL_ERROR")) {
                      const err73 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema35.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err73];
                      } else {
                        vErrors.push(err73);
                      }
                      errors2++;
                    }
                    var _valid14 = _errs134 === errors2;
                    valid33 = valid33 || _valid14;
                    const _errs135 = errors2;
                    if (data35 !== null) {
                      const err74 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err74];
                      } else {
                        vErrors.push(err74);
                      }
                      errors2++;
                    }
                    var _valid14 = _errs135 === errors2;
                    valid33 = valid33 || _valid14;
                    if (!valid33) {
                      const err75 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err75];
                      } else {
                        vErrors.push(err75);
                      }
                      errors2++;
                      validate26.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs133;
                      if (vErrors !== null) {
                        if (_errs133) {
                          vErrors.length = _errs133;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid20 = _errs132 === errors2;
                  } else {
                    var valid20 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate26.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate26.errors = vErrors;
  return errors2 === 0;
}
validate26.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema38 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/SystemData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/SystemData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
function validate28(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate28.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.cpuPercent === void 0 && (missing0 = "cpuPercent") || data1.memoryUsedBytes === void 0 && (missing0 = "memoryUsedBytes") || data1.memoryTotalBytes === void 0 && (missing0 = "memoryTotalBytes") || data1.temperatureC === void 0 && (missing0 = "temperatureC")) {
              validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "cpuPercent" || key0 === "memoryUsedBytes" || key0 === "memoryTotalBytes" || key0 === "temperatureC")) {
                  validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.cpuPercent !== void 0) {
                  let data2 = data1.cpuPercent;
                  const _errs10 = errors2;
                  const _errs11 = errors2;
                  let valid6 = false;
                  const _errs12 = errors2;
                  if (errors2 === _errs12) {
                    if (typeof data2 == "number" && isFinite(data2)) {
                      if (data2 > 100 || isNaN(data2)) {
                        const err1 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                        if (vErrors === null) {
                          vErrors = [err1];
                        } else {
                          vErrors.push(err1);
                        }
                        errors2++;
                      } else {
                        if (data2 < 0 || isNaN(data2)) {
                          const err2 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err2];
                          } else {
                            vErrors.push(err2);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err3 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors2++;
                    }
                  }
                  var _valid1 = _errs12 === errors2;
                  valid6 = valid6 || _valid1;
                  const _errs14 = errors2;
                  if (data2 !== null) {
                    const err4 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err4];
                    } else {
                      vErrors.push(err4);
                    }
                    errors2++;
                  }
                  var _valid1 = _errs14 === errors2;
                  valid6 = valid6 || _valid1;
                  if (!valid6) {
                    const err5 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err5];
                    } else {
                      vErrors.push(err5);
                    }
                    errors2++;
                    validate28.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs11;
                    if (vErrors !== null) {
                      if (_errs11) {
                        vErrors.length = _errs11;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.memoryUsedBytes !== void 0) {
                    let data3 = data1.memoryUsedBytes;
                    const _errs16 = errors2;
                    if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                      validate28.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                      return false;
                    }
                    if (errors2 === _errs16) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 > 9007199254740991 || isNaN(data3)) {
                          validate28.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                          return false;
                        } else {
                          if (data3 < 0 || isNaN(data3)) {
                            validate28.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                            return false;
                          }
                        }
                      }
                    }
                    var valid5 = _errs16 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.memoryTotalBytes !== void 0) {
                      let data4 = data1.memoryTotalBytes;
                      const _errs18 = errors2;
                      if (!(typeof data4 == "number" && (!(data4 % 1) && !isNaN(data4)) && isFinite(data4))) {
                        validate28.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                        return false;
                      }
                      if (errors2 === _errs18) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 > 9007199254740991 || isNaN(data4)) {
                            validate28.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                            return false;
                          } else {
                            if (data4 < 0 || isNaN(data4)) {
                              validate28.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                              return false;
                            }
                          }
                        }
                      }
                      var valid5 = _errs18 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.temperatureC !== void 0) {
                        let data5 = data1.temperatureC;
                        const _errs20 = errors2;
                        const _errs21 = errors2;
                        let valid7 = false;
                        const _errs22 = errors2;
                        if (!(typeof data5 == "number" && isFinite(data5))) {
                          const err6 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors2++;
                        }
                        var _valid2 = _errs22 === errors2;
                        valid7 = valid7 || _valid2;
                        const _errs24 = errors2;
                        if (data5 !== null) {
                          const err7 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                          if (vErrors === null) {
                            vErrors = [err7];
                          } else {
                            vErrors.push(err7);
                          }
                          errors2++;
                        }
                        var _valid2 = _errs24 === errors2;
                        valid7 = valid7 || _valid2;
                        if (!valid7) {
                          const err8 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                          if (vErrors === null) {
                            vErrors = [err8];
                          } else {
                            vErrors.push(err8);
                          }
                          errors2++;
                          validate28.errors = vErrors;
                          return false;
                        } else {
                          errors2 = _errs21;
                          if (vErrors !== null) {
                            if (_errs21) {
                              vErrors.length = _errs21;
                            } else {
                              vErrors = null;
                            }
                          }
                        }
                        var valid5 = _errs20 === errors2;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data6 = data.updatedAt;
          const _errs26 = errors2;
          if (errors2 === _errs26) {
            if (errors2 === _errs26) {
              if (typeof data6 === "string") {
                if (func1(data6) > 64) {
                  validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data6)) {
                    validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs26 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors2++;
    validate28.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs28 = errors2;
    const _errs29 = errors2;
    let valid8 = true;
    const _errs30 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data7 = data.status;
        if (!(data7 === "unconfigured" || data7 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors2++;
        }
      }
    }
    var _valid3 = _errs30 === errors2;
    errors2 = _errs29;
    if (vErrors !== null) {
      if (_errs29) {
        vErrors.length = _errs29;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs32 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs33 = errors2;
          if (data.data !== null) {
            validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid10 = _errs33 === errors2;
        } else {
          var valid10 = true;
        }
        if (valid10) {
          if (data.updatedAt !== void 0) {
            const _errs35 = errors2;
            if (data.updatedAt !== null) {
              validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid10 = _errs35 === errors2;
          } else {
            var valid10 = true;
          }
        }
      }
      var _valid3 = _errs32 === errors2;
      valid8 = _valid3;
      if (valid8) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid8) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors2++;
      validate28.errors = vErrors;
      return false;
    }
    var valid0 = _errs28 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs37 = errors2;
      const _errs38 = errors2;
      let valid11 = true;
      const _errs39 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data10 = data.status;
          if (!(data10 === "ok" || data10 === "unconfigured" || data10 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors2++;
          }
        }
      }
      var _valid4 = _errs39 === errors2;
      errors2 = _errs38;
      if (vErrors !== null) {
        if (_errs38) {
          vErrors.length = _errs38;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs41 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate28.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs41 === errors2;
        valid11 = _valid4;
        if (valid11) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs44 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data12 = data.errorCode;
            if (!(data12 === "NETWORK_ERROR" || data12 === "INVALID_DATA" || data12 === "PAYLOAD_TOO_LARGE" || data12 === "EXPANSION_LIMIT" || data12 === "UNSUPPORTED_CALENDAR" || data12 === "UNKNOWN_TIME_ZONE" || data12 === "KEYRING_LOCKED" || data12 === "SECRET_DELETION_FAILED" || data12 === "AUTH_ERROR" || data12 === "RATE_LIMITED" || data12 === "NO_PLAYER" || data12 === "NO_INTERFACE" || data12 === "SERVICE_UNAVAILABLE" || data12 === "INTERNAL_ERROR")) {
              validate28.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema38.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs44 === errors2;
        valid11 = _valid4;
        if (valid11) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid11) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors2++;
        validate28.errors = vErrors;
        return false;
      }
      var valid0 = _errs37 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate28.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs46 = errors2;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate28.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs46 === errors2) {
          if (data.status !== void 0) {
            let data13 = data.status;
            const _errs47 = errors2;
            if (!(data13 === "loading" || data13 === "ok" || data13 === "stale" || data13 === "unconfigured" || data13 === "unavailable")) {
              validate28.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema38.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid15 = _errs47 === errors2;
          } else {
            var valid15 = true;
          }
          if (valid15) {
            if (data.sourceId !== void 0) {
              let data14 = data.sourceId;
              const _errs48 = errors2;
              const _errs49 = errors2;
              let valid16 = false;
              const _errs50 = errors2;
              if (errors2 === _errs50) {
                if (typeof data14 === "string") {
                  if (func1(data14) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors2++;
                  } else {
                    if (func1(data14) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data14)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors2++;
                }
              }
              var _valid5 = _errs50 === errors2;
              valid16 = valid16 || _valid5;
              const _errs52 = errors2;
              if (data14 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors2++;
              }
              var _valid5 = _errs52 === errors2;
              valid16 = valid16 || _valid5;
              if (!valid16) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors2++;
                validate28.errors = vErrors;
                return false;
              } else {
                errors2 = _errs49;
                if (vErrors !== null) {
                  if (_errs49) {
                    vErrors.length = _errs49;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid15 = _errs48 === errors2;
            } else {
              var valid15 = true;
            }
            if (valid15) {
              if (data.updatedAt !== void 0) {
                let data15 = data.updatedAt;
                const _errs54 = errors2;
                const _errs55 = errors2;
                let valid17 = false;
                const _errs56 = errors2;
                if (errors2 === _errs56) {
                  if (errors2 === _errs56) {
                    if (typeof data15 === "string") {
                      if (func1(data15) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data15)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid6 = _errs56 === errors2;
                valid17 = valid17 || _valid6;
                const _errs58 = errors2;
                if (data15 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors2++;
                }
                var _valid6 = _errs58 === errors2;
                valid17 = valid17 || _valid6;
                if (!valid17) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors2++;
                  validate28.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs55;
                  if (vErrors !== null) {
                    if (_errs55) {
                      vErrors.length = _errs55;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid15 = _errs54 === errors2;
              } else {
                var valid15 = true;
              }
              if (valid15) {
                if (data.data !== void 0) {
                  let data16 = data.data;
                  const _errs60 = errors2;
                  const _errs61 = errors2;
                  let valid18 = false;
                  const _errs62 = errors2;
                  const _errs63 = errors2;
                  if (errors2 === _errs63) {
                    if (data16 && typeof data16 == "object" && !Array.isArray(data16)) {
                      let missing2;
                      if (data16.cpuPercent === void 0 && (missing2 = "cpuPercent") || data16.memoryUsedBytes === void 0 && (missing2 = "memoryUsedBytes") || data16.memoryTotalBytes === void 0 && (missing2 = "memoryTotalBytes") || data16.temperatureC === void 0 && (missing2 = "temperatureC")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors2++;
                      } else {
                        const _errs65 = errors2;
                        for (const key2 in data16) {
                          if (!(key2 === "cpuPercent" || key2 === "memoryUsedBytes" || key2 === "memoryTotalBytes" || key2 === "temperatureC")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs65 === errors2) {
                          if (data16.cpuPercent !== void 0) {
                            let data17 = data16.cpuPercent;
                            const _errs66 = errors2;
                            const _errs67 = errors2;
                            let valid21 = false;
                            const _errs68 = errors2;
                            if (errors2 === _errs68) {
                              if (typeof data17 == "number" && isFinite(data17)) {
                                if (data17 > 100 || isNaN(data17)) {
                                  const err27 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors2++;
                                } else {
                                  if (data17 < 0 || isNaN(data17)) {
                                    const err28 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors2++;
                              }
                            }
                            var _valid8 = _errs68 === errors2;
                            valid21 = valid21 || _valid8;
                            const _errs70 = errors2;
                            if (data17 !== null) {
                              const err30 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                              if (vErrors === null) {
                                vErrors = [err30];
                              } else {
                                vErrors.push(err30);
                              }
                              errors2++;
                            }
                            var _valid8 = _errs70 === errors2;
                            valid21 = valid21 || _valid8;
                            if (!valid21) {
                              const err31 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                              if (vErrors === null) {
                                vErrors = [err31];
                              } else {
                                vErrors.push(err31);
                              }
                              errors2++;
                            } else {
                              errors2 = _errs67;
                              if (vErrors !== null) {
                                if (_errs67) {
                                  vErrors.length = _errs67;
                                } else {
                                  vErrors = null;
                                }
                              }
                            }
                            var valid20 = _errs66 === errors2;
                          } else {
                            var valid20 = true;
                          }
                          if (valid20) {
                            if (data16.memoryUsedBytes !== void 0) {
                              let data18 = data16.memoryUsedBytes;
                              const _errs72 = errors2;
                              if (!(typeof data18 == "number" && (!(data18 % 1) && !isNaN(data18)) && isFinite(data18))) {
                                const err32 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors2++;
                              }
                              if (errors2 === _errs72) {
                                if (typeof data18 == "number" && isFinite(data18)) {
                                  if (data18 > 9007199254740991 || isNaN(data18)) {
                                    const err33 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                    if (vErrors === null) {
                                      vErrors = [err33];
                                    } else {
                                      vErrors.push(err33);
                                    }
                                    errors2++;
                                  } else {
                                    if (data18 < 0 || isNaN(data18)) {
                                      const err34 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors2++;
                                    }
                                  }
                                }
                              }
                              var valid20 = _errs72 === errors2;
                            } else {
                              var valid20 = true;
                            }
                            if (valid20) {
                              if (data16.memoryTotalBytes !== void 0) {
                                let data19 = data16.memoryTotalBytes;
                                const _errs74 = errors2;
                                if (!(typeof data19 == "number" && (!(data19 % 1) && !isNaN(data19)) && isFinite(data19))) {
                                  const err35 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors2++;
                                }
                                if (errors2 === _errs74) {
                                  if (typeof data19 == "number" && isFinite(data19)) {
                                    if (data19 > 9007199254740991 || isNaN(data19)) {
                                      const err36 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors2++;
                                    } else {
                                      if (data19 < 0 || isNaN(data19)) {
                                        const err37 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                        if (vErrors === null) {
                                          vErrors = [err37];
                                        } else {
                                          vErrors.push(err37);
                                        }
                                        errors2++;
                                      }
                                    }
                                  }
                                }
                                var valid20 = _errs74 === errors2;
                              } else {
                                var valid20 = true;
                              }
                              if (valid20) {
                                if (data16.temperatureC !== void 0) {
                                  let data20 = data16.temperatureC;
                                  const _errs76 = errors2;
                                  const _errs77 = errors2;
                                  let valid22 = false;
                                  const _errs78 = errors2;
                                  if (!(typeof data20 == "number" && isFinite(data20))) {
                                    const err38 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err38];
                                    } else {
                                      vErrors.push(err38);
                                    }
                                    errors2++;
                                  }
                                  var _valid9 = _errs78 === errors2;
                                  valid22 = valid22 || _valid9;
                                  const _errs80 = errors2;
                                  if (data20 !== null) {
                                    const err39 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err39];
                                    } else {
                                      vErrors.push(err39);
                                    }
                                    errors2++;
                                  }
                                  var _valid9 = _errs80 === errors2;
                                  valid22 = valid22 || _valid9;
                                  if (!valid22) {
                                    const err40 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err40];
                                    } else {
                                      vErrors.push(err40);
                                    }
                                    errors2++;
                                  } else {
                                    errors2 = _errs77;
                                    if (vErrors !== null) {
                                      if (_errs77) {
                                        vErrors.length = _errs77;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid20 = _errs76 === errors2;
                                } else {
                                  var valid20 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err41 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors2++;
                    }
                  }
                  var _valid7 = _errs62 === errors2;
                  valid18 = valid18 || _valid7;
                  const _errs82 = errors2;
                  if (data16 !== null) {
                    const err42 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err42];
                    } else {
                      vErrors.push(err42);
                    }
                    errors2++;
                  }
                  var _valid7 = _errs82 === errors2;
                  valid18 = valid18 || _valid7;
                  if (!valid18) {
                    const err43 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err43];
                    } else {
                      vErrors.push(err43);
                    }
                    errors2++;
                    validate28.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs61;
                    if (vErrors !== null) {
                      if (_errs61) {
                        vErrors.length = _errs61;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid15 = _errs60 === errors2;
                } else {
                  var valid15 = true;
                }
                if (valid15) {
                  if (data.errorCode !== void 0) {
                    let data21 = data.errorCode;
                    const _errs84 = errors2;
                    const _errs85 = errors2;
                    let valid23 = false;
                    const _errs86 = errors2;
                    if (!(data21 === "NETWORK_ERROR" || data21 === "INVALID_DATA" || data21 === "PAYLOAD_TOO_LARGE" || data21 === "EXPANSION_LIMIT" || data21 === "UNSUPPORTED_CALENDAR" || data21 === "UNKNOWN_TIME_ZONE" || data21 === "KEYRING_LOCKED" || data21 === "SECRET_DELETION_FAILED" || data21 === "AUTH_ERROR" || data21 === "RATE_LIMITED" || data21 === "NO_PLAYER" || data21 === "NO_INTERFACE" || data21 === "SERVICE_UNAVAILABLE" || data21 === "INTERNAL_ERROR")) {
                      const err44 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema38.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err44];
                      } else {
                        vErrors.push(err44);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs86 === errors2;
                    valid23 = valid23 || _valid10;
                    const _errs87 = errors2;
                    if (data21 !== null) {
                      const err45 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err45];
                      } else {
                        vErrors.push(err45);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs87 === errors2;
                    valid23 = valid23 || _valid10;
                    if (!valid23) {
                      const err46 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err46];
                      } else {
                        vErrors.push(err46);
                      }
                      errors2++;
                      validate28.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs85;
                      if (vErrors !== null) {
                        if (_errs85) {
                          vErrors.length = _errs85;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid15 = _errs84 === errors2;
                  } else {
                    var valid15 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate28.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate28.errors = vErrors;
  return errors2 === 0;
}
validate28.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema41 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/NetworkData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/NetworkData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
function validate30(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate30.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.interface === void 0 && (missing0 = "interface") || data1.rxBytesPerSec === void 0 && (missing0 = "rxBytesPerSec") || data1.txBytesPerSec === void 0 && (missing0 = "txBytesPerSec") || data1.history === void 0 && (missing0 = "history")) {
              validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "interface" || key0 === "rxBytesPerSec" || key0 === "txBytesPerSec" || key0 === "history")) {
                  validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.interface !== void 0) {
                  let data2 = data1.interface;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 64) {
                        validate30.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate30.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate30.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.rxBytesPerSec !== void 0) {
                    let data3 = data1.rxBytesPerSec;
                    const _errs12 = errors2;
                    const _errs13 = errors2;
                    let valid6 = false;
                    const _errs14 = errors2;
                    if (errors2 === _errs14) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 < 0 || isNaN(data3)) {
                          const err1 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err1];
                          } else {
                            vErrors.push(err1);
                          }
                          errors2++;
                        }
                      } else {
                        const err2 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err2];
                        } else {
                          vErrors.push(err2);
                        }
                        errors2++;
                      }
                    }
                    var _valid1 = _errs14 === errors2;
                    valid6 = valid6 || _valid1;
                    const _errs16 = errors2;
                    if (data3 !== null) {
                      const err3 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors2++;
                    }
                    var _valid1 = _errs16 === errors2;
                    valid6 = valid6 || _valid1;
                    if (!valid6) {
                      const err4 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err4];
                      } else {
                        vErrors.push(err4);
                      }
                      errors2++;
                      validate30.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs13;
                      if (vErrors !== null) {
                        if (_errs13) {
                          vErrors.length = _errs13;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.txBytesPerSec !== void 0) {
                      let data4 = data1.txBytesPerSec;
                      const _errs18 = errors2;
                      const _errs19 = errors2;
                      let valid7 = false;
                      const _errs20 = errors2;
                      if (errors2 === _errs20) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 < 0 || isNaN(data4)) {
                            const err5 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors2++;
                          }
                        } else {
                          const err6 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors2++;
                        }
                      }
                      var _valid2 = _errs20 === errors2;
                      valid7 = valid7 || _valid2;
                      const _errs22 = errors2;
                      if (data4 !== null) {
                        const err7 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                        if (vErrors === null) {
                          vErrors = [err7];
                        } else {
                          vErrors.push(err7);
                        }
                        errors2++;
                      }
                      var _valid2 = _errs22 === errors2;
                      valid7 = valid7 || _valid2;
                      if (!valid7) {
                        const err8 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors2++;
                        validate30.errors = vErrors;
                        return false;
                      } else {
                        errors2 = _errs19;
                        if (vErrors !== null) {
                          if (_errs19) {
                            vErrors.length = _errs19;
                          } else {
                            vErrors = null;
                          }
                        }
                      }
                      var valid5 = _errs18 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.history !== void 0) {
                        let data5 = data1.history;
                        const _errs24 = errors2;
                        if (errors2 === _errs24) {
                          if (Array.isArray(data5)) {
                            if (data5.length > 60) {
                              validate30.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" }];
                              return false;
                            } else {
                              var valid8 = true;
                              const len0 = data5.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data6 = data5[i0];
                                const _errs26 = errors2;
                                if (errors2 === _errs26) {
                                  if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
                                    let missing1;
                                    if (data6.at === void 0 && (missing1 = "at") || data6.rx === void 0 && (missing1 = "rx") || data6.tx === void 0 && (missing1 = "tx")) {
                                      validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                      return false;
                                    } else {
                                      const _errs28 = errors2;
                                      for (const key1 in data6) {
                                        if (!(key1 === "at" || key1 === "rx" || key1 === "tx")) {
                                          validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs28 === errors2) {
                                        if (data6.at !== void 0) {
                                          let data7 = data6.at;
                                          const _errs29 = errors2;
                                          if (errors2 === _errs29) {
                                            if (errors2 === _errs29) {
                                              if (typeof data7 === "string") {
                                                if (func1(data7) > 64) {
                                                  validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data7)) {
                                                    validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid9 = _errs29 === errors2;
                                        } else {
                                          var valid9 = true;
                                        }
                                        if (valid9) {
                                          if (data6.rx !== void 0) {
                                            let data8 = data6.rx;
                                            const _errs31 = errors2;
                                            if (errors2 === _errs31) {
                                              if (typeof data8 == "number" && isFinite(data8)) {
                                                if (data8 < 0 || isNaN(data8)) {
                                                  validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                  return false;
                                                }
                                              } else {
                                                validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                return false;
                                              }
                                            }
                                            var valid9 = _errs31 === errors2;
                                          } else {
                                            var valid9 = true;
                                          }
                                          if (valid9) {
                                            if (data6.tx !== void 0) {
                                              let data9 = data6.tx;
                                              const _errs33 = errors2;
                                              if (errors2 === _errs33) {
                                                if (typeof data9 == "number" && isFinite(data9)) {
                                                  if (data9 < 0 || isNaN(data9)) {
                                                    validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                    return false;
                                                  }
                                                } else {
                                                  validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                  return false;
                                                }
                                              }
                                              var valid9 = _errs33 === errors2;
                                            } else {
                                              var valid9 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid8 = _errs26 === errors2;
                                if (!valid8) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate30.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs24 === errors2;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data10 = data.updatedAt;
          const _errs35 = errors2;
          if (errors2 === _errs35) {
            if (errors2 === _errs35) {
              if (typeof data10 === "string") {
                if (func1(data10) > 64) {
                  validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data10)) {
                    validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs35 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors2++;
    validate30.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs37 = errors2;
    const _errs38 = errors2;
    let valid10 = true;
    const _errs39 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data11 = data.status;
        if (!(data11 === "unconfigured" || data11 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors2++;
        }
      }
    }
    var _valid3 = _errs39 === errors2;
    errors2 = _errs38;
    if (vErrors !== null) {
      if (_errs38) {
        vErrors.length = _errs38;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs41 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs42 = errors2;
          if (data.data !== null) {
            validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid12 = _errs42 === errors2;
        } else {
          var valid12 = true;
        }
        if (valid12) {
          if (data.updatedAt !== void 0) {
            const _errs44 = errors2;
            if (data.updatedAt !== null) {
              validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid12 = _errs44 === errors2;
          } else {
            var valid12 = true;
          }
        }
      }
      var _valid3 = _errs41 === errors2;
      valid10 = _valid3;
      if (valid10) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid10) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors2++;
      validate30.errors = vErrors;
      return false;
    }
    var valid0 = _errs37 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs46 = errors2;
      const _errs47 = errors2;
      let valid13 = true;
      const _errs48 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data14 = data.status;
          if (!(data14 === "ok" || data14 === "unconfigured" || data14 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors2++;
          }
        }
      }
      var _valid4 = _errs48 === errors2;
      errors2 = _errs47;
      if (vErrors !== null) {
        if (_errs47) {
          vErrors.length = _errs47;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs50 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate30.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs50 === errors2;
        valid13 = _valid4;
        if (valid13) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs53 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data16 = data.errorCode;
            if (!(data16 === "NETWORK_ERROR" || data16 === "INVALID_DATA" || data16 === "PAYLOAD_TOO_LARGE" || data16 === "EXPANSION_LIMIT" || data16 === "UNSUPPORTED_CALENDAR" || data16 === "UNKNOWN_TIME_ZONE" || data16 === "KEYRING_LOCKED" || data16 === "SECRET_DELETION_FAILED" || data16 === "AUTH_ERROR" || data16 === "RATE_LIMITED" || data16 === "NO_PLAYER" || data16 === "NO_INTERFACE" || data16 === "SERVICE_UNAVAILABLE" || data16 === "INTERNAL_ERROR")) {
              validate30.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema41.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs53 === errors2;
        valid13 = _valid4;
        if (valid13) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid13) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors2++;
        validate30.errors = vErrors;
        return false;
      }
      var valid0 = _errs46 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing2;
      if (data.status === void 0 && (missing2 = "status") || data.sourceId === void 0 && (missing2 = "sourceId") || data.updatedAt === void 0 && (missing2 = "updatedAt") || data.data === void 0 && (missing2 = "data") || data.errorCode === void 0 && (missing2 = "errorCode")) {
        validate30.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
        return false;
      } else {
        const _errs55 = errors2;
        for (const key2 in data) {
          if (!(key2 === "status" || key2 === "sourceId" || key2 === "updatedAt" || key2 === "data" || key2 === "errorCode")) {
            validate30.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs55 === errors2) {
          if (data.status !== void 0) {
            let data17 = data.status;
            const _errs56 = errors2;
            if (!(data17 === "loading" || data17 === "ok" || data17 === "stale" || data17 === "unconfigured" || data17 === "unavailable")) {
              validate30.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema41.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid17 = _errs56 === errors2;
          } else {
            var valid17 = true;
          }
          if (valid17) {
            if (data.sourceId !== void 0) {
              let data18 = data.sourceId;
              const _errs57 = errors2;
              const _errs58 = errors2;
              let valid18 = false;
              const _errs59 = errors2;
              if (errors2 === _errs59) {
                if (typeof data18 === "string") {
                  if (func1(data18) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors2++;
                  } else {
                    if (func1(data18) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data18)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors2++;
                }
              }
              var _valid5 = _errs59 === errors2;
              valid18 = valid18 || _valid5;
              const _errs61 = errors2;
              if (data18 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors2++;
              }
              var _valid5 = _errs61 === errors2;
              valid18 = valid18 || _valid5;
              if (!valid18) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors2++;
                validate30.errors = vErrors;
                return false;
              } else {
                errors2 = _errs58;
                if (vErrors !== null) {
                  if (_errs58) {
                    vErrors.length = _errs58;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid17 = _errs57 === errors2;
            } else {
              var valid17 = true;
            }
            if (valid17) {
              if (data.updatedAt !== void 0) {
                let data19 = data.updatedAt;
                const _errs63 = errors2;
                const _errs64 = errors2;
                let valid19 = false;
                const _errs65 = errors2;
                if (errors2 === _errs65) {
                  if (errors2 === _errs65) {
                    if (typeof data19 === "string") {
                      if (func1(data19) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data19)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid6 = _errs65 === errors2;
                valid19 = valid19 || _valid6;
                const _errs67 = errors2;
                if (data19 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors2++;
                }
                var _valid6 = _errs67 === errors2;
                valid19 = valid19 || _valid6;
                if (!valid19) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors2++;
                  validate30.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs64;
                  if (vErrors !== null) {
                    if (_errs64) {
                      vErrors.length = _errs64;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid17 = _errs63 === errors2;
              } else {
                var valid17 = true;
              }
              if (valid17) {
                if (data.data !== void 0) {
                  let data20 = data.data;
                  const _errs69 = errors2;
                  const _errs70 = errors2;
                  let valid20 = false;
                  const _errs71 = errors2;
                  const _errs72 = errors2;
                  if (errors2 === _errs72) {
                    if (data20 && typeof data20 == "object" && !Array.isArray(data20)) {
                      let missing3;
                      if (data20.interface === void 0 && (missing3 = "interface") || data20.rxBytesPerSec === void 0 && (missing3 = "rxBytesPerSec") || data20.txBytesPerSec === void 0 && (missing3 = "txBytesPerSec") || data20.history === void 0 && (missing3 = "history")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors2++;
                      } else {
                        const _errs74 = errors2;
                        for (const key3 in data20) {
                          if (!(key3 === "interface" || key3 === "rxBytesPerSec" || key3 === "txBytesPerSec" || key3 === "history")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs74 === errors2) {
                          if (data20.interface !== void 0) {
                            let data21 = data20.interface;
                            const _errs75 = errors2;
                            if (errors2 === _errs75) {
                              if (typeof data21 === "string") {
                                if (func1(data21) > 64) {
                                  const err27 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors2++;
                                } else {
                                  if (func1(data21) < 1) {
                                    const err28 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors2++;
                              }
                            }
                            var valid22 = _errs75 === errors2;
                          } else {
                            var valid22 = true;
                          }
                          if (valid22) {
                            if (data20.rxBytesPerSec !== void 0) {
                              let data22 = data20.rxBytesPerSec;
                              const _errs77 = errors2;
                              const _errs78 = errors2;
                              let valid23 = false;
                              const _errs79 = errors2;
                              if (errors2 === _errs79) {
                                if (typeof data22 == "number" && isFinite(data22)) {
                                  if (data22 < 0 || isNaN(data22)) {
                                    const err30 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err30];
                                    } else {
                                      vErrors.push(err30);
                                    }
                                    errors2++;
                                  }
                                } else {
                                  const err31 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err31];
                                  } else {
                                    vErrors.push(err31);
                                  }
                                  errors2++;
                                }
                              }
                              var _valid8 = _errs79 === errors2;
                              valid23 = valid23 || _valid8;
                              const _errs81 = errors2;
                              if (data22 !== null) {
                                const err32 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors2++;
                              }
                              var _valid8 = _errs81 === errors2;
                              valid23 = valid23 || _valid8;
                              if (!valid23) {
                                const err33 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err33];
                                } else {
                                  vErrors.push(err33);
                                }
                                errors2++;
                              } else {
                                errors2 = _errs78;
                                if (vErrors !== null) {
                                  if (_errs78) {
                                    vErrors.length = _errs78;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid22 = _errs77 === errors2;
                            } else {
                              var valid22 = true;
                            }
                            if (valid22) {
                              if (data20.txBytesPerSec !== void 0) {
                                let data23 = data20.txBytesPerSec;
                                const _errs83 = errors2;
                                const _errs84 = errors2;
                                let valid24 = false;
                                const _errs85 = errors2;
                                if (errors2 === _errs85) {
                                  if (typeof data23 == "number" && isFinite(data23)) {
                                    if (data23 < 0 || isNaN(data23)) {
                                      const err34 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors2++;
                                    }
                                  } else {
                                    const err35 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err35];
                                    } else {
                                      vErrors.push(err35);
                                    }
                                    errors2++;
                                  }
                                }
                                var _valid9 = _errs85 === errors2;
                                valid24 = valid24 || _valid9;
                                const _errs87 = errors2;
                                if (data23 !== null) {
                                  const err36 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err36];
                                  } else {
                                    vErrors.push(err36);
                                  }
                                  errors2++;
                                }
                                var _valid9 = _errs87 === errors2;
                                valid24 = valid24 || _valid9;
                                if (!valid24) {
                                  const err37 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err37];
                                  } else {
                                    vErrors.push(err37);
                                  }
                                  errors2++;
                                } else {
                                  errors2 = _errs84;
                                  if (vErrors !== null) {
                                    if (_errs84) {
                                      vErrors.length = _errs84;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid22 = _errs83 === errors2;
                              } else {
                                var valid22 = true;
                              }
                              if (valid22) {
                                if (data20.history !== void 0) {
                                  let data24 = data20.history;
                                  const _errs89 = errors2;
                                  if (errors2 === _errs89) {
                                    if (Array.isArray(data24)) {
                                      if (data24.length > 60) {
                                        const err38 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" };
                                        if (vErrors === null) {
                                          vErrors = [err38];
                                        } else {
                                          vErrors.push(err38);
                                        }
                                        errors2++;
                                      } else {
                                        var valid25 = true;
                                        const len1 = data24.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data25 = data24[i1];
                                          const _errs91 = errors2;
                                          if (errors2 === _errs91) {
                                            if (data25 && typeof data25 == "object" && !Array.isArray(data25)) {
                                              let missing4;
                                              if (data25.at === void 0 && (missing4 = "at") || data25.rx === void 0 && (missing4 = "rx") || data25.tx === void 0 && (missing4 = "tx")) {
                                                const err39 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err39];
                                                } else {
                                                  vErrors.push(err39);
                                                }
                                                errors2++;
                                              } else {
                                                const _errs93 = errors2;
                                                for (const key4 in data25) {
                                                  if (!(key4 === "at" || key4 === "rx" || key4 === "tx")) {
                                                    const err40 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err40];
                                                    } else {
                                                      vErrors.push(err40);
                                                    }
                                                    errors2++;
                                                    break;
                                                  }
                                                }
                                                if (_errs93 === errors2) {
                                                  if (data25.at !== void 0) {
                                                    let data26 = data25.at;
                                                    const _errs94 = errors2;
                                                    if (errors2 === _errs94) {
                                                      if (errors2 === _errs94) {
                                                        if (typeof data26 === "string") {
                                                          if (func1(data26) > 64) {
                                                            const err41 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err41];
                                                            } else {
                                                              vErrors.push(err41);
                                                            }
                                                            errors2++;
                                                          } else {
                                                            if (!formats0.validate(data26)) {
                                                              const err42 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err42];
                                                              } else {
                                                                vErrors.push(err42);
                                                              }
                                                              errors2++;
                                                            }
                                                          }
                                                        } else {
                                                          const err43 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err43];
                                                          } else {
                                                            vErrors.push(err43);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                    }
                                                    var valid26 = _errs94 === errors2;
                                                  } else {
                                                    var valid26 = true;
                                                  }
                                                  if (valid26) {
                                                    if (data25.rx !== void 0) {
                                                      let data27 = data25.rx;
                                                      const _errs96 = errors2;
                                                      if (errors2 === _errs96) {
                                                        if (typeof data27 == "number" && isFinite(data27)) {
                                                          if (data27 < 0 || isNaN(data27)) {
                                                            const err44 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                            if (vErrors === null) {
                                                              vErrors = [err44];
                                                            } else {
                                                              vErrors.push(err44);
                                                            }
                                                            errors2++;
                                                          }
                                                        } else {
                                                          const err45 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                          if (vErrors === null) {
                                                            vErrors = [err45];
                                                          } else {
                                                            vErrors.push(err45);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                      var valid26 = _errs96 === errors2;
                                                    } else {
                                                      var valid26 = true;
                                                    }
                                                    if (valid26) {
                                                      if (data25.tx !== void 0) {
                                                        let data28 = data25.tx;
                                                        const _errs98 = errors2;
                                                        if (errors2 === _errs98) {
                                                          if (typeof data28 == "number" && isFinite(data28)) {
                                                            if (data28 < 0 || isNaN(data28)) {
                                                              const err46 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                              if (vErrors === null) {
                                                                vErrors = [err46];
                                                              } else {
                                                                vErrors.push(err46);
                                                              }
                                                              errors2++;
                                                            }
                                                          } else {
                                                            const err47 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err47];
                                                            } else {
                                                              vErrors.push(err47);
                                                            }
                                                            errors2++;
                                                          }
                                                        }
                                                        var valid26 = _errs98 === errors2;
                                                      } else {
                                                        var valid26 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err48 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors2++;
                                            }
                                          }
                                          var valid25 = _errs91 === errors2;
                                          if (!valid25) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err49 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err49];
                                      } else {
                                        vErrors.push(err49);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid22 = _errs89 === errors2;
                                } else {
                                  var valid22 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err50 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err50];
                      } else {
                        vErrors.push(err50);
                      }
                      errors2++;
                    }
                  }
                  var _valid7 = _errs71 === errors2;
                  valid20 = valid20 || _valid7;
                  const _errs100 = errors2;
                  if (data20 !== null) {
                    const err51 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err51];
                    } else {
                      vErrors.push(err51);
                    }
                    errors2++;
                  }
                  var _valid7 = _errs100 === errors2;
                  valid20 = valid20 || _valid7;
                  if (!valid20) {
                    const err52 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err52];
                    } else {
                      vErrors.push(err52);
                    }
                    errors2++;
                    validate30.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs70;
                    if (vErrors !== null) {
                      if (_errs70) {
                        vErrors.length = _errs70;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid17 = _errs69 === errors2;
                } else {
                  var valid17 = true;
                }
                if (valid17) {
                  if (data.errorCode !== void 0) {
                    let data29 = data.errorCode;
                    const _errs102 = errors2;
                    const _errs103 = errors2;
                    let valid27 = false;
                    const _errs104 = errors2;
                    if (!(data29 === "NETWORK_ERROR" || data29 === "INVALID_DATA" || data29 === "PAYLOAD_TOO_LARGE" || data29 === "EXPANSION_LIMIT" || data29 === "UNSUPPORTED_CALENDAR" || data29 === "UNKNOWN_TIME_ZONE" || data29 === "KEYRING_LOCKED" || data29 === "SECRET_DELETION_FAILED" || data29 === "AUTH_ERROR" || data29 === "RATE_LIMITED" || data29 === "NO_PLAYER" || data29 === "NO_INTERFACE" || data29 === "SERVICE_UNAVAILABLE" || data29 === "INTERNAL_ERROR")) {
                      const err53 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema41.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err53];
                      } else {
                        vErrors.push(err53);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs104 === errors2;
                    valid27 = valid27 || _valid10;
                    const _errs105 = errors2;
                    if (data29 !== null) {
                      const err54 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err54];
                      } else {
                        vErrors.push(err54);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs105 === errors2;
                    valid27 = valid27 || _valid10;
                    if (!valid27) {
                      const err55 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err55];
                      } else {
                        vErrors.push(err55);
                      }
                      errors2++;
                      validate30.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs103;
                      if (vErrors !== null) {
                        if (_errs103) {
                          vErrors.length = _errs103;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid17 = _errs102 === errors2;
                  } else {
                    var valid17 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate30.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate30.errors = vErrors;
  return errors2 === 0;
}
validate30.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema44 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/MediaData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/MediaData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
var schema45 = { "type": "object", "additionalProperties": false, "required": ["player", "status", "title", "artist", "artUri"], "properties": { "player": { "type": "string", "maxLength": 255, "minLength": 1 }, "status": { "enum": ["playing", "paused", "stopped"] }, "title": { "type": "string", "maxLength": 4096 }, "artist": { "type": "string", "maxLength": 4096 }, "artUri": { "anyOf": [{ "type": "string", "maxLength": 4096, "pattern": "^file:///" }, { "type": "null" }] } } };
var pattern11 = new RegExp("^file:///", "u");
function validate32(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate32.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.player === void 0 && (missing0 = "player") || data1.status === void 0 && (missing0 = "status") || data1.title === void 0 && (missing0 = "title") || data1.artist === void 0 && (missing0 = "artist") || data1.artUri === void 0 && (missing0 = "artUri")) {
              validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "player" || key0 === "status" || key0 === "title" || key0 === "artist" || key0 === "artUri")) {
                  validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.player !== void 0) {
                  let data2 = data1.player;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 255) {
                        validate32.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate32.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate32.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.status !== void 0) {
                    let data3 = data1.status;
                    const _errs12 = errors2;
                    if (!(data3 === "playing" || data3 === "paused" || data3 === "stopped")) {
                      validate32.errors = [{ instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" }];
                      return false;
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.title !== void 0) {
                      let data4 = data1.title;
                      const _errs13 = errors2;
                      if (errors2 === _errs13) {
                        if (typeof data4 === "string") {
                          if (func1(data4) > 4096) {
                            validate32.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                            return false;
                          }
                        } else {
                          validate32.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                          return false;
                        }
                      }
                      var valid5 = _errs13 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.artist !== void 0) {
                        let data5 = data1.artist;
                        const _errs15 = errors2;
                        if (errors2 === _errs15) {
                          if (typeof data5 === "string") {
                            if (func1(data5) > 4096) {
                              validate32.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                              return false;
                            }
                          } else {
                            validate32.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                            return false;
                          }
                        }
                        var valid5 = _errs15 === errors2;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.artUri !== void 0) {
                          let data6 = data1.artUri;
                          const _errs17 = errors2;
                          const _errs18 = errors2;
                          let valid6 = false;
                          const _errs19 = errors2;
                          if (errors2 === _errs19) {
                            if (typeof data6 === "string") {
                              if (func1(data6) > 4096) {
                                const err1 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                if (vErrors === null) {
                                  vErrors = [err1];
                                } else {
                                  vErrors.push(err1);
                                }
                                errors2++;
                              } else {
                                if (!pattern11.test(data6)) {
                                  const err2 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors2++;
                                }
                              }
                            } else {
                              const err3 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err3];
                              } else {
                                vErrors.push(err3);
                              }
                              errors2++;
                            }
                          }
                          var _valid1 = _errs19 === errors2;
                          valid6 = valid6 || _valid1;
                          const _errs21 = errors2;
                          if (data6 !== null) {
                            const err4 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err4];
                            } else {
                              vErrors.push(err4);
                            }
                            errors2++;
                          }
                          var _valid1 = _errs21 === errors2;
                          valid6 = valid6 || _valid1;
                          if (!valid6) {
                            const err5 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors2++;
                            validate32.errors = vErrors;
                            return false;
                          } else {
                            errors2 = _errs18;
                            if (vErrors !== null) {
                              if (_errs18) {
                                vErrors.length = _errs18;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid5 = _errs17 === errors2;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data7 = data.updatedAt;
          const _errs23 = errors2;
          if (errors2 === _errs23) {
            if (errors2 === _errs23) {
              if (typeof data7 === "string") {
                if (func1(data7) > 64) {
                  validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data7)) {
                    validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs23 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err6 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err6];
    } else {
      vErrors.push(err6);
    }
    errors2++;
    validate32.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs25 = errors2;
    const _errs26 = errors2;
    let valid7 = true;
    const _errs27 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data8 = data.status;
        if (!(data8 === "unconfigured" || data8 === "unavailable")) {
          const err7 = {};
          if (vErrors === null) {
            vErrors = [err7];
          } else {
            vErrors.push(err7);
          }
          errors2++;
        }
      }
    }
    var _valid2 = _errs27 === errors2;
    errors2 = _errs26;
    if (vErrors !== null) {
      if (_errs26) {
        vErrors.length = _errs26;
      } else {
        vErrors = null;
      }
    }
    if (_valid2) {
      const _errs29 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs30 = errors2;
          if (data.data !== null) {
            validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid9 = _errs30 === errors2;
        } else {
          var valid9 = true;
        }
        if (valid9) {
          if (data.updatedAt !== void 0) {
            const _errs32 = errors2;
            if (data.updatedAt !== null) {
              validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid9 = _errs32 === errors2;
          } else {
            var valid9 = true;
          }
        }
      }
      var _valid2 = _errs29 === errors2;
      valid7 = _valid2;
      if (valid7) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid7) {
      const err8 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors2++;
      validate32.errors = vErrors;
      return false;
    }
    var valid0 = _errs25 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs34 = errors2;
      const _errs35 = errors2;
      let valid10 = true;
      const _errs36 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data11 = data.status;
          if (!(data11 === "ok" || data11 === "unconfigured" || data11 === "loading")) {
            const err9 = {};
            if (vErrors === null) {
              vErrors = [err9];
            } else {
              vErrors.push(err9);
            }
            errors2++;
          }
        }
      }
      var _valid3 = _errs36 === errors2;
      errors2 = _errs35;
      if (vErrors !== null) {
        if (_errs35) {
          vErrors.length = _errs35;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid3) {
        const _errs38 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate32.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid3 = _errs38 === errors2;
        valid10 = _valid3;
        if (valid10) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs41 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data13 = data.errorCode;
            if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
              validate32.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema44.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid3 = _errs41 === errors2;
        valid10 = _valid3;
        if (valid10) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid10) {
        const err10 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err10];
        } else {
          vErrors.push(err10);
        }
        errors2++;
        validate32.errors = vErrors;
        return false;
      }
      var valid0 = _errs34 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate32.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs43 = errors2;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate32.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs43 === errors2) {
          if (data.status !== void 0) {
            let data14 = data.status;
            const _errs44 = errors2;
            if (!(data14 === "loading" || data14 === "ok" || data14 === "stale" || data14 === "unconfigured" || data14 === "unavailable")) {
              validate32.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema44.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid14 = _errs44 === errors2;
          } else {
            var valid14 = true;
          }
          if (valid14) {
            if (data.sourceId !== void 0) {
              let data15 = data.sourceId;
              const _errs45 = errors2;
              const _errs46 = errors2;
              let valid15 = false;
              const _errs47 = errors2;
              if (errors2 === _errs47) {
                if (typeof data15 === "string") {
                  if (func1(data15) > 128) {
                    const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err11];
                    } else {
                      vErrors.push(err11);
                    }
                    errors2++;
                  } else {
                    if (func1(data15) < 1) {
                      const err12 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data15)) {
                        const err13 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err13];
                        } else {
                          vErrors.push(err13);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err14];
                  } else {
                    vErrors.push(err14);
                  }
                  errors2++;
                }
              }
              var _valid4 = _errs47 === errors2;
              valid15 = valid15 || _valid4;
              const _errs49 = errors2;
              if (data15 !== null) {
                const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err15];
                } else {
                  vErrors.push(err15);
                }
                errors2++;
              }
              var _valid4 = _errs49 === errors2;
              valid15 = valid15 || _valid4;
              if (!valid15) {
                const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err16];
                } else {
                  vErrors.push(err16);
                }
                errors2++;
                validate32.errors = vErrors;
                return false;
              } else {
                errors2 = _errs46;
                if (vErrors !== null) {
                  if (_errs46) {
                    vErrors.length = _errs46;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid14 = _errs45 === errors2;
            } else {
              var valid14 = true;
            }
            if (valid14) {
              if (data.updatedAt !== void 0) {
                let data16 = data.updatedAt;
                const _errs51 = errors2;
                const _errs52 = errors2;
                let valid16 = false;
                const _errs53 = errors2;
                if (errors2 === _errs53) {
                  if (errors2 === _errs53) {
                    if (typeof data16 === "string") {
                      if (func1(data16) > 64) {
                        const err17 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err17];
                        } else {
                          vErrors.push(err17);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data16)) {
                          const err18 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err18];
                          } else {
                            vErrors.push(err18);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err19 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid5 = _errs53 === errors2;
                valid16 = valid16 || _valid5;
                const _errs55 = errors2;
                if (data16 !== null) {
                  const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err20];
                  } else {
                    vErrors.push(err20);
                  }
                  errors2++;
                }
                var _valid5 = _errs55 === errors2;
                valid16 = valid16 || _valid5;
                if (!valid16) {
                  const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err21];
                  } else {
                    vErrors.push(err21);
                  }
                  errors2++;
                  validate32.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs52;
                  if (vErrors !== null) {
                    if (_errs52) {
                      vErrors.length = _errs52;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid14 = _errs51 === errors2;
              } else {
                var valid14 = true;
              }
              if (valid14) {
                if (data.data !== void 0) {
                  let data17 = data.data;
                  const _errs57 = errors2;
                  const _errs58 = errors2;
                  let valid17 = false;
                  const _errs59 = errors2;
                  const _errs60 = errors2;
                  if (errors2 === _errs60) {
                    if (data17 && typeof data17 == "object" && !Array.isArray(data17)) {
                      let missing2;
                      if (data17.player === void 0 && (missing2 = "player") || data17.status === void 0 && (missing2 = "status") || data17.title === void 0 && (missing2 = "title") || data17.artist === void 0 && (missing2 = "artist") || data17.artUri === void 0 && (missing2 = "artUri")) {
                        const err22 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err22];
                        } else {
                          vErrors.push(err22);
                        }
                        errors2++;
                      } else {
                        const _errs62 = errors2;
                        for (const key2 in data17) {
                          if (!(key2 === "player" || key2 === "status" || key2 === "title" || key2 === "artist" || key2 === "artUri")) {
                            const err23 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err23];
                            } else {
                              vErrors.push(err23);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs62 === errors2) {
                          if (data17.player !== void 0) {
                            let data18 = data17.player;
                            const _errs63 = errors2;
                            if (errors2 === _errs63) {
                              if (typeof data18 === "string") {
                                if (func1(data18) > 255) {
                                  const err24 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err24];
                                  } else {
                                    vErrors.push(err24);
                                  }
                                  errors2++;
                                } else {
                                  if (func1(data18) < 1) {
                                    const err25 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err25];
                                    } else {
                                      vErrors.push(err25);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err26 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err26];
                                } else {
                                  vErrors.push(err26);
                                }
                                errors2++;
                              }
                            }
                            var valid19 = _errs63 === errors2;
                          } else {
                            var valid19 = true;
                          }
                          if (valid19) {
                            if (data17.status !== void 0) {
                              let data19 = data17.status;
                              const _errs65 = errors2;
                              if (!(data19 === "playing" || data19 === "paused" || data19 === "stopped")) {
                                const err27 = { instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" };
                                if (vErrors === null) {
                                  vErrors = [err27];
                                } else {
                                  vErrors.push(err27);
                                }
                                errors2++;
                              }
                              var valid19 = _errs65 === errors2;
                            } else {
                              var valid19 = true;
                            }
                            if (valid19) {
                              if (data17.title !== void 0) {
                                let data20 = data17.title;
                                const _errs66 = errors2;
                                if (errors2 === _errs66) {
                                  if (typeof data20 === "string") {
                                    if (func1(data20) > 4096) {
                                      const err28 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err28];
                                      } else {
                                        vErrors.push(err28);
                                      }
                                      errors2++;
                                    }
                                  } else {
                                    const err29 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err29];
                                    } else {
                                      vErrors.push(err29);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid19 = _errs66 === errors2;
                              } else {
                                var valid19 = true;
                              }
                              if (valid19) {
                                if (data17.artist !== void 0) {
                                  let data21 = data17.artist;
                                  const _errs68 = errors2;
                                  if (errors2 === _errs68) {
                                    if (typeof data21 === "string") {
                                      if (func1(data21) > 4096) {
                                        const err30 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err30];
                                        } else {
                                          vErrors.push(err30);
                                        }
                                        errors2++;
                                      }
                                    } else {
                                      const err31 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err31];
                                      } else {
                                        vErrors.push(err31);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid19 = _errs68 === errors2;
                                } else {
                                  var valid19 = true;
                                }
                                if (valid19) {
                                  if (data17.artUri !== void 0) {
                                    let data22 = data17.artUri;
                                    const _errs70 = errors2;
                                    const _errs71 = errors2;
                                    let valid20 = false;
                                    const _errs72 = errors2;
                                    if (errors2 === _errs72) {
                                      if (typeof data22 === "string") {
                                        if (func1(data22) > 4096) {
                                          const err32 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err32];
                                          } else {
                                            vErrors.push(err32);
                                          }
                                          errors2++;
                                        } else {
                                          if (!pattern11.test(data22)) {
                                            const err33 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                            if (vErrors === null) {
                                              vErrors = [err33];
                                            } else {
                                              vErrors.push(err33);
                                            }
                                            errors2++;
                                          }
                                        }
                                      } else {
                                        const err34 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err34];
                                        } else {
                                          vErrors.push(err34);
                                        }
                                        errors2++;
                                      }
                                    }
                                    var _valid7 = _errs72 === errors2;
                                    valid20 = valid20 || _valid7;
                                    const _errs74 = errors2;
                                    if (data22 !== null) {
                                      const err35 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                      if (vErrors === null) {
                                        vErrors = [err35];
                                      } else {
                                        vErrors.push(err35);
                                      }
                                      errors2++;
                                    }
                                    var _valid7 = _errs74 === errors2;
                                    valid20 = valid20 || _valid7;
                                    if (!valid20) {
                                      const err36 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors2++;
                                    } else {
                                      errors2 = _errs71;
                                      if (vErrors !== null) {
                                        if (_errs71) {
                                          vErrors.length = _errs71;
                                        } else {
                                          vErrors = null;
                                        }
                                      }
                                    }
                                    var valid19 = _errs70 === errors2;
                                  } else {
                                    var valid19 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err37 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err37];
                      } else {
                        vErrors.push(err37);
                      }
                      errors2++;
                    }
                  }
                  var _valid6 = _errs59 === errors2;
                  valid17 = valid17 || _valid6;
                  const _errs76 = errors2;
                  if (data17 !== null) {
                    const err38 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err38];
                    } else {
                      vErrors.push(err38);
                    }
                    errors2++;
                  }
                  var _valid6 = _errs76 === errors2;
                  valid17 = valid17 || _valid6;
                  if (!valid17) {
                    const err39 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err39];
                    } else {
                      vErrors.push(err39);
                    }
                    errors2++;
                    validate32.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs58;
                    if (vErrors !== null) {
                      if (_errs58) {
                        vErrors.length = _errs58;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid14 = _errs57 === errors2;
                } else {
                  var valid14 = true;
                }
                if (valid14) {
                  if (data.errorCode !== void 0) {
                    let data23 = data.errorCode;
                    const _errs78 = errors2;
                    const _errs79 = errors2;
                    let valid21 = false;
                    const _errs80 = errors2;
                    if (!(data23 === "NETWORK_ERROR" || data23 === "INVALID_DATA" || data23 === "PAYLOAD_TOO_LARGE" || data23 === "EXPANSION_LIMIT" || data23 === "UNSUPPORTED_CALENDAR" || data23 === "UNKNOWN_TIME_ZONE" || data23 === "KEYRING_LOCKED" || data23 === "SECRET_DELETION_FAILED" || data23 === "AUTH_ERROR" || data23 === "RATE_LIMITED" || data23 === "NO_PLAYER" || data23 === "NO_INTERFACE" || data23 === "SERVICE_UNAVAILABLE" || data23 === "INTERNAL_ERROR")) {
                      const err40 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema44.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err40];
                      } else {
                        vErrors.push(err40);
                      }
                      errors2++;
                    }
                    var _valid8 = _errs80 === errors2;
                    valid21 = valid21 || _valid8;
                    const _errs81 = errors2;
                    if (data23 !== null) {
                      const err41 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors2++;
                    }
                    var _valid8 = _errs81 === errors2;
                    valid21 = valid21 || _valid8;
                    if (!valid21) {
                      const err42 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err42];
                      } else {
                        vErrors.push(err42);
                      }
                      errors2++;
                      validate32.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs79;
                      if (vErrors !== null) {
                        if (_errs79) {
                          vErrors.length = _errs79;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid14 = _errs78 === errors2;
                  } else {
                    var valid14 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate32.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate32.errors = vErrors;
  return errors2 === 0;
}
validate32.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate20(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate20.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.schemaVersion === void 0 && (missing0 = "schemaVersion") || data.generatedAt === void 0 && (missing0 = "generatedAt") || data.revisions === void 0 && (missing0 = "revisions") || data.calendar === void 0 && (missing0 = "calendar") || data.weather === void 0 && (missing0 = "weather") || data.system === void 0 && (missing0 = "system") || data.network === void 0 && (missing0 = "network") || data.media === void 0 && (missing0 = "media")) {
        validate20.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "schemaVersion" || key0 === "generatedAt" || key0 === "revisions" || key0 === "calendar" || key0 === "weather" || key0 === "system" || key0 === "network" || key0 === "media")) {
            validate20.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.schemaVersion !== void 0) {
            const _errs2 = errors2;
            if (1 !== data.schemaVersion) {
              validate20.errors = [{ instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.generatedAt !== void 0) {
              let data1 = data.generatedAt;
              const _errs3 = errors2;
              if (errors2 === _errs3) {
                if (errors2 === _errs3) {
                  if (typeof data1 === "string") {
                    if (func1(data1) > 64) {
                      validate20.errors = [{ instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                      return false;
                    } else {
                      if (!formats0.validate(data1)) {
                        validate20.errors = [{ instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                        return false;
                      }
                    }
                  } else {
                    validate20.errors = [{ instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
              }
              var valid0 = _errs3 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.revisions !== void 0) {
                let data2 = data.revisions;
                const _errs5 = errors2;
                if (errors2 === _errs5) {
                  if (data2 && typeof data2 == "object" && !Array.isArray(data2)) {
                    let missing1;
                    if (data2.calendar === void 0 && (missing1 = "calendar") || data2.weather === void 0 && (missing1 = "weather") || data2.system === void 0 && (missing1 = "system") || data2.network === void 0 && (missing1 = "network") || data2.media === void 0 && (missing1 = "media")) {
                      validate20.errors = [{ instancePath: instancePath + "/revisions", schemaPath: "#/properties/revisions/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                      return false;
                    } else {
                      const _errs7 = errors2;
                      for (const key1 in data2) {
                        if (!(key1 === "calendar" || key1 === "weather" || key1 === "system" || key1 === "network" || key1 === "media")) {
                          validate20.errors = [{ instancePath: instancePath + "/revisions", schemaPath: "#/properties/revisions/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                          return false;
                          break;
                        }
                      }
                      if (_errs7 === errors2) {
                        if (data2.calendar !== void 0) {
                          let data3 = data2.calendar;
                          const _errs8 = errors2;
                          if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                            validate20.errors = [{ instancePath: instancePath + "/revisions/calendar", schemaPath: "#/properties/revisions/properties/calendar/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                            return false;
                          }
                          if (errors2 === _errs8) {
                            if (typeof data3 == "number" && isFinite(data3)) {
                              if (data3 > 4294967295 || isNaN(data3)) {
                                validate20.errors = [{ instancePath: instancePath + "/revisions/calendar", schemaPath: "#/properties/revisions/properties/calendar/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                return false;
                              } else {
                                if (data3 < 0 || isNaN(data3)) {
                                  validate20.errors = [{ instancePath: instancePath + "/revisions/calendar", schemaPath: "#/properties/revisions/properties/calendar/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                  return false;
                                }
                              }
                            }
                          }
                          var valid1 = _errs8 === errors2;
                        } else {
                          var valid1 = true;
                        }
                        if (valid1) {
                          if (data2.weather !== void 0) {
                            let data4 = data2.weather;
                            const _errs10 = errors2;
                            if (!(typeof data4 == "number" && (!(data4 % 1) && !isNaN(data4)) && isFinite(data4))) {
                              validate20.errors = [{ instancePath: instancePath + "/revisions/weather", schemaPath: "#/properties/revisions/properties/weather/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                              return false;
                            }
                            if (errors2 === _errs10) {
                              if (typeof data4 == "number" && isFinite(data4)) {
                                if (data4 > 4294967295 || isNaN(data4)) {
                                  validate20.errors = [{ instancePath: instancePath + "/revisions/weather", schemaPath: "#/properties/revisions/properties/weather/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                  return false;
                                } else {
                                  if (data4 < 0 || isNaN(data4)) {
                                    validate20.errors = [{ instancePath: instancePath + "/revisions/weather", schemaPath: "#/properties/revisions/properties/weather/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                    return false;
                                  }
                                }
                              }
                            }
                            var valid1 = _errs10 === errors2;
                          } else {
                            var valid1 = true;
                          }
                          if (valid1) {
                            if (data2.system !== void 0) {
                              let data5 = data2.system;
                              const _errs12 = errors2;
                              if (!(typeof data5 == "number" && (!(data5 % 1) && !isNaN(data5)) && isFinite(data5))) {
                                validate20.errors = [{ instancePath: instancePath + "/revisions/system", schemaPath: "#/properties/revisions/properties/system/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                return false;
                              }
                              if (errors2 === _errs12) {
                                if (typeof data5 == "number" && isFinite(data5)) {
                                  if (data5 > 4294967295 || isNaN(data5)) {
                                    validate20.errors = [{ instancePath: instancePath + "/revisions/system", schemaPath: "#/properties/revisions/properties/system/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                    return false;
                                  } else {
                                    if (data5 < 0 || isNaN(data5)) {
                                      validate20.errors = [{ instancePath: instancePath + "/revisions/system", schemaPath: "#/properties/revisions/properties/system/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                      return false;
                                    }
                                  }
                                }
                              }
                              var valid1 = _errs12 === errors2;
                            } else {
                              var valid1 = true;
                            }
                            if (valid1) {
                              if (data2.network !== void 0) {
                                let data6 = data2.network;
                                const _errs14 = errors2;
                                if (!(typeof data6 == "number" && (!(data6 % 1) && !isNaN(data6)) && isFinite(data6))) {
                                  validate20.errors = [{ instancePath: instancePath + "/revisions/network", schemaPath: "#/properties/revisions/properties/network/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                  return false;
                                }
                                if (errors2 === _errs14) {
                                  if (typeof data6 == "number" && isFinite(data6)) {
                                    if (data6 > 4294967295 || isNaN(data6)) {
                                      validate20.errors = [{ instancePath: instancePath + "/revisions/network", schemaPath: "#/properties/revisions/properties/network/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                      return false;
                                    } else {
                                      if (data6 < 0 || isNaN(data6)) {
                                        validate20.errors = [{ instancePath: instancePath + "/revisions/network", schemaPath: "#/properties/revisions/properties/network/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                        return false;
                                      }
                                    }
                                  }
                                }
                                var valid1 = _errs14 === errors2;
                              } else {
                                var valid1 = true;
                              }
                              if (valid1) {
                                if (data2.media !== void 0) {
                                  let data7 = data2.media;
                                  const _errs16 = errors2;
                                  if (!(typeof data7 == "number" && (!(data7 % 1) && !isNaN(data7)) && isFinite(data7))) {
                                    validate20.errors = [{ instancePath: instancePath + "/revisions/media", schemaPath: "#/properties/revisions/properties/media/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                    return false;
                                  }
                                  if (errors2 === _errs16) {
                                    if (typeof data7 == "number" && isFinite(data7)) {
                                      if (data7 > 4294967295 || isNaN(data7)) {
                                        validate20.errors = [{ instancePath: instancePath + "/revisions/media", schemaPath: "#/properties/revisions/properties/media/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                        return false;
                                      } else {
                                        if (data7 < 0 || isNaN(data7)) {
                                          validate20.errors = [{ instancePath: instancePath + "/revisions/media", schemaPath: "#/properties/revisions/properties/media/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                          return false;
                                        }
                                      }
                                    }
                                  }
                                  var valid1 = _errs16 === errors2;
                                } else {
                                  var valid1 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    validate20.errors = [{ instancePath: instancePath + "/revisions", schemaPath: "#/properties/revisions/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                    return false;
                  }
                }
                var valid0 = _errs5 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.calendar !== void 0) {
                  const _errs18 = errors2;
                  if (!validate21(data.calendar, { instancePath: instancePath + "/calendar", parentData: data, parentDataProperty: "calendar", rootData, dynamicAnchors })) {
                    vErrors = vErrors === null ? validate21.errors : vErrors.concat(validate21.errors);
                    errors2 = vErrors.length;
                  }
                  var valid0 = _errs18 === errors2;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.weather !== void 0) {
                    const _errs19 = errors2;
                    if (!validate26(data.weather, { instancePath: instancePath + "/weather", parentData: data, parentDataProperty: "weather", rootData, dynamicAnchors })) {
                      vErrors = vErrors === null ? validate26.errors : vErrors.concat(validate26.errors);
                      errors2 = vErrors.length;
                    }
                    var valid0 = _errs19 === errors2;
                  } else {
                    var valid0 = true;
                  }
                  if (valid0) {
                    if (data.system !== void 0) {
                      const _errs20 = errors2;
                      if (!validate28(data.system, { instancePath: instancePath + "/system", parentData: data, parentDataProperty: "system", rootData, dynamicAnchors })) {
                        vErrors = vErrors === null ? validate28.errors : vErrors.concat(validate28.errors);
                        errors2 = vErrors.length;
                      }
                      var valid0 = _errs20 === errors2;
                    } else {
                      var valid0 = true;
                    }
                    if (valid0) {
                      if (data.network !== void 0) {
                        const _errs21 = errors2;
                        if (!validate30(data.network, { instancePath: instancePath + "/network", parentData: data, parentDataProperty: "network", rootData, dynamicAnchors })) {
                          vErrors = vErrors === null ? validate30.errors : vErrors.concat(validate30.errors);
                          errors2 = vErrors.length;
                        }
                        var valid0 = _errs21 === errors2;
                      } else {
                        var valid0 = true;
                      }
                      if (valid0) {
                        if (data.media !== void 0) {
                          const _errs22 = errors2;
                          if (!validate32(data.media, { instancePath: instancePath + "/media", parentData: data, parentDataProperty: "media", rootData, dynamicAnchors })) {
                            vErrors = vErrors === null ? validate32.errors : vErrors.concat(validate32.errors);
                            errors2 = vErrors.length;
                          }
                          var valid0 = _errs22 === errors2;
                        } else {
                          var valid0 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate20.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate20.errors = vErrors;
  return errors2 === 0;
}
validate20.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate34(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate34.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.calendarEnabled === void 0 && (missing0 = "calendarEnabled") || data.calendarSecretDeletionPending === void 0 && (missing0 = "calendarSecretDeletionPending") || data.weatherLocation === void 0 && (missing0 = "weatherLocation") || data.networkInterface === void 0 && (missing0 = "networkInterface")) {
        validate34.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "calendarEnabled" || key0 === "calendarSecretDeletionPending" || key0 === "weatherLocation" || key0 === "networkInterface")) {
            validate34.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.calendarEnabled !== void 0) {
            const _errs2 = errors2;
            if (typeof data.calendarEnabled !== "boolean") {
              validate34.errors = [{ instancePath: instancePath + "/calendarEnabled", schemaPath: "#/properties/calendarEnabled/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.calendarSecretDeletionPending !== void 0) {
              const _errs4 = errors2;
              if (typeof data.calendarSecretDeletionPending !== "boolean") {
                validate34.errors = [{ instancePath: instancePath + "/calendarSecretDeletionPending", schemaPath: "#/properties/calendarSecretDeletionPending/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                return false;
              }
              var valid0 = _errs4 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weatherLocation !== void 0) {
                let data2 = data.weatherLocation;
                const _errs6 = errors2;
                const _errs7 = errors2;
                let valid1 = false;
                const _errs8 = errors2;
                const _errs9 = errors2;
                if (errors2 === _errs9) {
                  if (data2 && typeof data2 == "object" && !Array.isArray(data2)) {
                    let missing1;
                    if (data2.id === void 0 && (missing1 = "id") || data2.label === void 0 && (missing1 = "label") || data2.latitude === void 0 && (missing1 = "latitude") || data2.longitude === void 0 && (missing1 = "longitude") || data2.timeZone === void 0 && (missing1 = "timeZone")) {
                      const err0 = { instancePath: instancePath + "/weatherLocation", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" };
                      if (vErrors === null) {
                        vErrors = [err0];
                      } else {
                        vErrors.push(err0);
                      }
                      errors2++;
                    } else {
                      const _errs11 = errors2;
                      for (const key1 in data2) {
                        if (!(key1 === "id" || key1 === "label" || key1 === "latitude" || key1 === "longitude" || key1 === "timeZone")) {
                          const err1 = { instancePath: instancePath + "/weatherLocation", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
                          if (vErrors === null) {
                            vErrors = [err1];
                          } else {
                            vErrors.push(err1);
                          }
                          errors2++;
                          break;
                        }
                      }
                      if (_errs11 === errors2) {
                        if (data2.id !== void 0) {
                          let data3 = data2.id;
                          const _errs12 = errors2;
                          if (errors2 === _errs12) {
                            if (typeof data3 === "string") {
                              if (func1(data3) > 128) {
                                const err2 = { instancePath: instancePath + "/weatherLocation/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                                if (vErrors === null) {
                                  vErrors = [err2];
                                } else {
                                  vErrors.push(err2);
                                }
                                errors2++;
                              } else {
                                if (func1(data3) < 1) {
                                  const err3 = { instancePath: instancePath + "/weatherLocation/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err3];
                                  } else {
                                    vErrors.push(err3);
                                  }
                                  errors2++;
                                }
                              }
                            } else {
                              const err4 = { instancePath: instancePath + "/weatherLocation/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err4];
                              } else {
                                vErrors.push(err4);
                              }
                              errors2++;
                            }
                          }
                          var valid3 = _errs12 === errors2;
                        } else {
                          var valid3 = true;
                        }
                        if (valid3) {
                          if (data2.label !== void 0) {
                            let data4 = data2.label;
                            const _errs14 = errors2;
                            if (errors2 === _errs14) {
                              if (typeof data4 === "string") {
                                if (func1(data4) > 512) {
                                  const err5 = { instancePath: instancePath + "/weatherLocation/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err5];
                                  } else {
                                    vErrors.push(err5);
                                  }
                                  errors2++;
                                } else {
                                  if (func1(data4) < 1) {
                                    const err6 = { instancePath: instancePath + "/weatherLocation/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err6];
                                    } else {
                                      vErrors.push(err6);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err7 = { instancePath: instancePath + "/weatherLocation/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err7];
                                } else {
                                  vErrors.push(err7);
                                }
                                errors2++;
                              }
                            }
                            var valid3 = _errs14 === errors2;
                          } else {
                            var valid3 = true;
                          }
                          if (valid3) {
                            if (data2.latitude !== void 0) {
                              let data5 = data2.latitude;
                              const _errs16 = errors2;
                              if (errors2 === _errs16) {
                                if (typeof data5 == "number" && isFinite(data5)) {
                                  if (data5 > 90 || isNaN(data5)) {
                                    const err8 = { instancePath: instancePath + "/weatherLocation/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors2++;
                                  } else {
                                    if (data5 < -90 || isNaN(data5)) {
                                      const err9 = { instancePath: instancePath + "/weatherLocation/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" };
                                      if (vErrors === null) {
                                        vErrors = [err9];
                                      } else {
                                        vErrors.push(err9);
                                      }
                                      errors2++;
                                    }
                                  }
                                } else {
                                  const err10 = { instancePath: instancePath + "/weatherLocation/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err10];
                                  } else {
                                    vErrors.push(err10);
                                  }
                                  errors2++;
                                }
                              }
                              var valid3 = _errs16 === errors2;
                            } else {
                              var valid3 = true;
                            }
                            if (valid3) {
                              if (data2.longitude !== void 0) {
                                let data6 = data2.longitude;
                                const _errs18 = errors2;
                                if (errors2 === _errs18) {
                                  if (typeof data6 == "number" && isFinite(data6)) {
                                    if (data6 > 180 || isNaN(data6)) {
                                      const err11 = { instancePath: instancePath + "/weatherLocation/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" };
                                      if (vErrors === null) {
                                        vErrors = [err11];
                                      } else {
                                        vErrors.push(err11);
                                      }
                                      errors2++;
                                    } else {
                                      if (data6 < -180 || isNaN(data6)) {
                                        const err12 = { instancePath: instancePath + "/weatherLocation/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" };
                                        if (vErrors === null) {
                                          vErrors = [err12];
                                        } else {
                                          vErrors.push(err12);
                                        }
                                        errors2++;
                                      }
                                    }
                                  } else {
                                    const err13 = { instancePath: instancePath + "/weatherLocation/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err13];
                                    } else {
                                      vErrors.push(err13);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid3 = _errs18 === errors2;
                              } else {
                                var valid3 = true;
                              }
                              if (valid3) {
                                if (data2.timeZone !== void 0) {
                                  let data7 = data2.timeZone;
                                  const _errs20 = errors2;
                                  if (errors2 === _errs20) {
                                    if (typeof data7 === "string") {
                                      if (func1(data7) > 255) {
                                        const err14 = { instancePath: instancePath + "/weatherLocation/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err14];
                                        } else {
                                          vErrors.push(err14);
                                        }
                                        errors2++;
                                      } else {
                                        if (func1(data7) < 1) {
                                          const err15 = { instancePath: instancePath + "/weatherLocation/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err15];
                                          } else {
                                            vErrors.push(err15);
                                          }
                                          errors2++;
                                        }
                                      }
                                    } else {
                                      const err16 = { instancePath: instancePath + "/weatherLocation/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err16];
                                      } else {
                                        vErrors.push(err16);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid3 = _errs20 === errors2;
                                } else {
                                  var valid3 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    const err17 = { instancePath: instancePath + "/weatherLocation", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors2++;
                  }
                }
                var _valid0 = _errs8 === errors2;
                valid1 = valid1 || _valid0;
                const _errs22 = errors2;
                if (data2 !== null) {
                  const err18 = { instancePath: instancePath + "/weatherLocation", schemaPath: "#/properties/weatherLocation/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err18];
                  } else {
                    vErrors.push(err18);
                  }
                  errors2++;
                }
                var _valid0 = _errs22 === errors2;
                valid1 = valid1 || _valid0;
                if (!valid1) {
                  const err19 = { instancePath: instancePath + "/weatherLocation", schemaPath: "#/properties/weatherLocation/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err19];
                  } else {
                    vErrors.push(err19);
                  }
                  errors2++;
                  validate34.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs7;
                  if (vErrors !== null) {
                    if (_errs7) {
                      vErrors.length = _errs7;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid0 = _errs6 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.networkInterface !== void 0) {
                  let data8 = data.networkInterface;
                  const _errs24 = errors2;
                  if (errors2 === _errs24) {
                    if (typeof data8 === "string") {
                      if (func1(data8) > 64) {
                        validate34.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                        return false;
                      } else {
                        if (func1(data8) < 1) {
                          validate34.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate34.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid0 = _errs24 === errors2;
                } else {
                  var valid0 = true;
                }
              }
            }
          }
        }
      }
    } else {
      validate34.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate34.errors = vErrors;
  return errors2 === 0;
}
validate34.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate35(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate35.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.month === void 0 && (missing0 = "month") || data.timeZone === void 0 && (missing0 = "timeZone") || data.weekStart === void 0 && (missing0 = "weekStart")) {
        validate35.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "month" || key0 === "timeZone" || key0 === "weekStart")) {
            validate35.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.month !== void 0) {
            let data0 = data.month;
            const _errs2 = errors2;
            if (errors2 === _errs2) {
              if (typeof data0 === "string") {
                if (func1(data0) > 7) {
                  validate35.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                  return false;
                } else {
                  if (!pattern4.test(data0)) {
                    validate35.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                    return false;
                  }
                }
              } else {
                validate35.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.timeZone !== void 0) {
              let data1 = data.timeZone;
              const _errs4 = errors2;
              if (errors2 === _errs4) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 255) {
                    validate35.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate35.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate35.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs4 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weekStart !== void 0) {
                let data2 = data.weekStart;
                const _errs6 = errors2;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate35.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors2 === _errs6) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 6 || isNaN(data2)) {
                      validate35.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate35.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs6 === errors2;
              } else {
                var valid0 = true;
              }
            }
          }
        }
      }
    } else {
      validate35.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate35.errors = vErrors;
  return errors2 === 0;
}
validate35.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate36(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate36.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs0 = errors2;
  let valid0 = false;
  const _errs1 = errors2;
  const _errs2 = errors2;
  if (errors2 === _errs2) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.id === void 0 && (missing0 = "id") || data.label === void 0 && (missing0 = "label") || data.latitude === void 0 && (missing0 = "latitude") || data.longitude === void 0 && (missing0 = "longitude") || data.timeZone === void 0 && (missing0 = "timeZone")) {
        const err0 = { instancePath, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" };
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      } else {
        const _errs4 = errors2;
        for (const key0 in data) {
          if (!(key0 === "id" || key0 === "label" || key0 === "latitude" || key0 === "longitude" || key0 === "timeZone")) {
            const err1 = { instancePath, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err1];
            } else {
              vErrors.push(err1);
            }
            errors2++;
            break;
          }
        }
        if (_errs4 === errors2) {
          if (data.id !== void 0) {
            let data0 = data.id;
            const _errs5 = errors2;
            if (errors2 === _errs5) {
              if (typeof data0 === "string") {
                if (func1(data0) > 128) {
                  const err2 = { instancePath: instancePath + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                  if (vErrors === null) {
                    vErrors = [err2];
                  } else {
                    vErrors.push(err2);
                  }
                  errors2++;
                } else {
                  if (func1(data0) < 1) {
                    const err3 = { instancePath: instancePath + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                    if (vErrors === null) {
                      vErrors = [err3];
                    } else {
                      vErrors.push(err3);
                    }
                    errors2++;
                  }
                }
              } else {
                const err4 = { instancePath: instancePath + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err4];
                } else {
                  vErrors.push(err4);
                }
                errors2++;
              }
            }
            var valid2 = _errs5 === errors2;
          } else {
            var valid2 = true;
          }
          if (valid2) {
            if (data.label !== void 0) {
              let data1 = data.label;
              const _errs7 = errors2;
              if (errors2 === _errs7) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 512) {
                    const err5 = { instancePath: instancePath + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                    if (vErrors === null) {
                      vErrors = [err5];
                    } else {
                      vErrors.push(err5);
                    }
                    errors2++;
                  } else {
                    if (func1(data1) < 1) {
                      const err6 = { instancePath: instancePath + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err6];
                      } else {
                        vErrors.push(err6);
                      }
                      errors2++;
                    }
                  }
                } else {
                  const err7 = { instancePath: instancePath + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err7];
                  } else {
                    vErrors.push(err7);
                  }
                  errors2++;
                }
              }
              var valid2 = _errs7 === errors2;
            } else {
              var valid2 = true;
            }
            if (valid2) {
              if (data.latitude !== void 0) {
                let data2 = data.latitude;
                const _errs9 = errors2;
                if (errors2 === _errs9) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 90 || isNaN(data2)) {
                      const err8 = { instancePath: instancePath + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" };
                      if (vErrors === null) {
                        vErrors = [err8];
                      } else {
                        vErrors.push(err8);
                      }
                      errors2++;
                    } else {
                      if (data2 < -90 || isNaN(data2)) {
                        const err9 = { instancePath: instancePath + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" };
                        if (vErrors === null) {
                          vErrors = [err9];
                        } else {
                          vErrors.push(err9);
                        }
                        errors2++;
                      }
                    }
                  } else {
                    const err10 = { instancePath: instancePath + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                    if (vErrors === null) {
                      vErrors = [err10];
                    } else {
                      vErrors.push(err10);
                    }
                    errors2++;
                  }
                }
                var valid2 = _errs9 === errors2;
              } else {
                var valid2 = true;
              }
              if (valid2) {
                if (data.longitude !== void 0) {
                  let data3 = data.longitude;
                  const _errs11 = errors2;
                  if (errors2 === _errs11) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 180 || isNaN(data3)) {
                        const err11 = { instancePath: instancePath + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" };
                        if (vErrors === null) {
                          vErrors = [err11];
                        } else {
                          vErrors.push(err11);
                        }
                        errors2++;
                      } else {
                        if (data3 < -180 || isNaN(data3)) {
                          const err12 = { instancePath: instancePath + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" };
                          if (vErrors === null) {
                            vErrors = [err12];
                          } else {
                            vErrors.push(err12);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err13 = { instancePath: instancePath + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                      if (vErrors === null) {
                        vErrors = [err13];
                      } else {
                        vErrors.push(err13);
                      }
                      errors2++;
                    }
                  }
                  var valid2 = _errs11 === errors2;
                } else {
                  var valid2 = true;
                }
                if (valid2) {
                  if (data.timeZone !== void 0) {
                    let data4 = data.timeZone;
                    const _errs13 = errors2;
                    if (errors2 === _errs13) {
                      if (typeof data4 === "string") {
                        if (func1(data4) > 255) {
                          const err14 = { instancePath: instancePath + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                          if (vErrors === null) {
                            vErrors = [err14];
                          } else {
                            vErrors.push(err14);
                          }
                          errors2++;
                        } else {
                          if (func1(data4) < 1) {
                            const err15 = { instancePath: instancePath + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err15];
                            } else {
                              vErrors.push(err15);
                            }
                            errors2++;
                          }
                        }
                      } else {
                        const err16 = { instancePath: instancePath + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors2++;
                      }
                    }
                    var valid2 = _errs13 === errors2;
                  } else {
                    var valid2 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      const err17 = { instancePath, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" };
      if (vErrors === null) {
        vErrors = [err17];
      } else {
        vErrors.push(err17);
      }
      errors2++;
    }
  }
  var _valid0 = _errs1 === errors2;
  valid0 = valid0 || _valid0;
  if (_valid0) {
    var props0 = true;
  }
  const _errs15 = errors2;
  if (data !== null) {
    const err18 = { instancePath, schemaPath: "#/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
    if (vErrors === null) {
      vErrors = [err18];
    } else {
      vErrors.push(err18);
    }
    errors2++;
  }
  var _valid0 = _errs15 === errors2;
  valid0 = valid0 || _valid0;
  if (!valid0) {
    const err19 = { instancePath, schemaPath: "#/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
    if (vErrors === null) {
      vErrors = [err19];
    } else {
      vErrors.push(err19);
    }
    errors2++;
    validate36.errors = vErrors;
    return false;
  } else {
    errors2 = _errs0;
    if (vErrors !== null) {
      if (_errs0) {
        vErrors.length = _errs0;
      } else {
        vErrors = null;
      }
    }
  }
  validate36.errors = vErrors;
  evaluated0.props = props0;
  return errors2 === 0;
}
validate36.evaluated = { "dynamicProps": true, "dynamicItems": false };
function validate37(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate37.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (Array.isArray(data)) {
      if (data.length > 20) {
        validate37.errors = [{ instancePath, schemaPath: "#/maxItems", keyword: "maxItems", params: { limit: 20 }, message: "must NOT have more than 20 items" }];
        return false;
      } else {
        var valid0 = true;
        const len0 = data.length;
        for (let i0 = 0; i0 < len0; i0++) {
          let data0 = data[i0];
          const _errs1 = errors2;
          const _errs2 = errors2;
          if (errors2 === _errs2) {
            if (data0 && typeof data0 == "object" && !Array.isArray(data0)) {
              let missing0;
              if (data0.id === void 0 && (missing0 = "id") || data0.label === void 0 && (missing0 = "label") || data0.latitude === void 0 && (missing0 = "latitude") || data0.longitude === void 0 && (missing0 = "longitude") || data0.timeZone === void 0 && (missing0 = "timeZone")) {
                validate37.errors = [{ instancePath: instancePath + "/" + i0, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
                return false;
              } else {
                const _errs4 = errors2;
                for (const key0 in data0) {
                  if (!(key0 === "id" || key0 === "label" || key0 === "latitude" || key0 === "longitude" || key0 === "timeZone")) {
                    validate37.errors = [{ instancePath: instancePath + "/" + i0, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                    return false;
                    break;
                  }
                }
                if (_errs4 === errors2) {
                  if (data0.id !== void 0) {
                    let data1 = data0.id;
                    const _errs5 = errors2;
                    if (errors2 === _errs5) {
                      if (typeof data1 === "string") {
                        if (func1(data1) > 128) {
                          validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" }];
                          return false;
                        } else {
                          if (func1(data1) < 1) {
                            validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          }
                        }
                      } else {
                        validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid2 = _errs5 === errors2;
                  } else {
                    var valid2 = true;
                  }
                  if (valid2) {
                    if (data0.label !== void 0) {
                      let data2 = data0.label;
                      const _errs7 = errors2;
                      if (errors2 === _errs7) {
                        if (typeof data2 === "string") {
                          if (func1(data2) > 512) {
                            validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                            return false;
                          } else {
                            if (func1(data2) < 1) {
                              validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                              return false;
                            }
                          }
                        } else {
                          validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                          return false;
                        }
                      }
                      var valid2 = _errs7 === errors2;
                    } else {
                      var valid2 = true;
                    }
                    if (valid2) {
                      if (data0.latitude !== void 0) {
                        let data3 = data0.latitude;
                        const _errs9 = errors2;
                        if (errors2 === _errs9) {
                          if (typeof data3 == "number" && isFinite(data3)) {
                            if (data3 > 90 || isNaN(data3)) {
                              validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" }];
                              return false;
                            } else {
                              if (data3 < -90 || isNaN(data3)) {
                                validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" }];
                                return false;
                              }
                            }
                          } else {
                            validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                            return false;
                          }
                        }
                        var valid2 = _errs9 === errors2;
                      } else {
                        var valid2 = true;
                      }
                      if (valid2) {
                        if (data0.longitude !== void 0) {
                          let data4 = data0.longitude;
                          const _errs11 = errors2;
                          if (errors2 === _errs11) {
                            if (typeof data4 == "number" && isFinite(data4)) {
                              if (data4 > 180 || isNaN(data4)) {
                                validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" }];
                                return false;
                              } else {
                                if (data4 < -180 || isNaN(data4)) {
                                  validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" }];
                                  return false;
                                }
                              }
                            } else {
                              validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                              return false;
                            }
                          }
                          var valid2 = _errs11 === errors2;
                        } else {
                          var valid2 = true;
                        }
                        if (valid2) {
                          if (data0.timeZone !== void 0) {
                            let data5 = data0.timeZone;
                            const _errs13 = errors2;
                            if (errors2 === _errs13) {
                              if (typeof data5 === "string") {
                                if (func1(data5) > 255) {
                                  validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                                  return false;
                                } else {
                                  if (func1(data5) < 1) {
                                    validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                    return false;
                                  }
                                }
                              } else {
                                validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                return false;
                              }
                            }
                            var valid2 = _errs13 === errors2;
                          } else {
                            var valid2 = true;
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              validate37.errors = [{ instancePath: instancePath + "/" + i0, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
              return false;
            }
          }
          var valid0 = _errs1 === errors2;
          if (!valid0) {
            break;
          }
        }
      }
    } else {
      validate37.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
      return false;
    }
  }
  validate37.errors = vErrors;
  return errors2 === 0;
}
validate37.evaluated = { "items": true, "dynamicProps": false, "dynamicItems": false };
var calendar = validate38;
function validate38(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate38.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        const _errs6 = errors2;
        if (!validate22(data.data, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
          vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
          errors2 = vErrors.length;
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data2 = data.updatedAt;
          const _errs7 = errors2;
          if (errors2 === _errs7) {
            if (errors2 === _errs7) {
              if (typeof data2 === "string") {
                if (func1(data2) > 64) {
                  validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data2)) {
                    validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs7 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err1 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err1];
    } else {
      vErrors.push(err1);
    }
    errors2++;
    validate38.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs9 = errors2;
    const _errs10 = errors2;
    let valid4 = true;
    const _errs11 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data3 = data.status;
        if (!(data3 === "unconfigured" || data3 === "unavailable")) {
          const err2 = {};
          if (vErrors === null) {
            vErrors = [err2];
          } else {
            vErrors.push(err2);
          }
          errors2++;
        }
      }
    }
    var _valid1 = _errs11 === errors2;
    errors2 = _errs10;
    if (vErrors !== null) {
      if (_errs10) {
        vErrors.length = _errs10;
      } else {
        vErrors = null;
      }
    }
    if (_valid1) {
      const _errs13 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs14 = errors2;
          if (data.data !== null) {
            validate38.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid6 = _errs14 === errors2;
        } else {
          var valid6 = true;
        }
        if (valid6) {
          if (data.updatedAt !== void 0) {
            const _errs16 = errors2;
            if (data.updatedAt !== null) {
              validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid6 = _errs16 === errors2;
          } else {
            var valid6 = true;
          }
        }
      }
      var _valid1 = _errs13 === errors2;
      valid4 = _valid1;
      if (valid4) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid4) {
      const err3 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors2++;
      validate38.errors = vErrors;
      return false;
    }
    var valid0 = _errs9 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs18 = errors2;
      const _errs19 = errors2;
      let valid7 = true;
      const _errs20 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data6 = data.status;
          if (!(data6 === "ok" || data6 === "unconfigured" || data6 === "loading")) {
            const err4 = {};
            if (vErrors === null) {
              vErrors = [err4];
            } else {
              vErrors.push(err4);
            }
            errors2++;
          }
        }
      }
      var _valid2 = _errs20 === errors2;
      errors2 = _errs19;
      if (vErrors !== null) {
        if (_errs19) {
          vErrors.length = _errs19;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid2) {
        const _errs22 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate38.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid2 = _errs22 === errors2;
        valid7 = _valid2;
        if (valid7) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs25 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data8 = data.errorCode;
            if (!(data8 === "NETWORK_ERROR" || data8 === "INVALID_DATA" || data8 === "PAYLOAD_TOO_LARGE" || data8 === "EXPANSION_LIMIT" || data8 === "UNSUPPORTED_CALENDAR" || data8 === "UNKNOWN_TIME_ZONE" || data8 === "KEYRING_LOCKED" || data8 === "SECRET_DELETION_FAILED" || data8 === "AUTH_ERROR" || data8 === "RATE_LIMITED" || data8 === "NO_PLAYER" || data8 === "NO_INTERFACE" || data8 === "SERVICE_UNAVAILABLE" || data8 === "INTERNAL_ERROR")) {
              validate38.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema32.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid2 = _errs25 === errors2;
        valid7 = _valid2;
        if (valid7) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid7) {
        const err5 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err5];
        } else {
          vErrors.push(err5);
        }
        errors2++;
        validate38.errors = vErrors;
        return false;
      }
      var valid0 = _errs18 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.status === void 0 && (missing0 = "status") || data.sourceId === void 0 && (missing0 = "sourceId") || data.updatedAt === void 0 && (missing0 = "updatedAt") || data.data === void 0 && (missing0 = "data") || data.errorCode === void 0 && (missing0 = "errorCode")) {
        validate38.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs27 = errors2;
        for (const key0 in data) {
          if (!(key0 === "status" || key0 === "sourceId" || key0 === "updatedAt" || key0 === "data" || key0 === "errorCode")) {
            validate38.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs27 === errors2) {
          if (data.status !== void 0) {
            let data9 = data.status;
            const _errs28 = errors2;
            if (!(data9 === "loading" || data9 === "ok" || data9 === "stale" || data9 === "unconfigured" || data9 === "unavailable")) {
              validate38.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema32.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid11 = _errs28 === errors2;
          } else {
            var valid11 = true;
          }
          if (valid11) {
            if (data.sourceId !== void 0) {
              let data10 = data.sourceId;
              const _errs29 = errors2;
              const _errs30 = errors2;
              let valid12 = false;
              const _errs31 = errors2;
              if (errors2 === _errs31) {
                if (typeof data10 === "string") {
                  if (func1(data10) > 128) {
                    const err6 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err6];
                    } else {
                      vErrors.push(err6);
                    }
                    errors2++;
                  } else {
                    if (func1(data10) < 1) {
                      const err7 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err7];
                      } else {
                        vErrors.push(err7);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data10)) {
                        const err8 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err9 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err9];
                  } else {
                    vErrors.push(err9);
                  }
                  errors2++;
                }
              }
              var _valid3 = _errs31 === errors2;
              valid12 = valid12 || _valid3;
              const _errs33 = errors2;
              if (data10 !== null) {
                const err10 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err10];
                } else {
                  vErrors.push(err10);
                }
                errors2++;
              }
              var _valid3 = _errs33 === errors2;
              valid12 = valid12 || _valid3;
              if (!valid12) {
                const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err11];
                } else {
                  vErrors.push(err11);
                }
                errors2++;
                validate38.errors = vErrors;
                return false;
              } else {
                errors2 = _errs30;
                if (vErrors !== null) {
                  if (_errs30) {
                    vErrors.length = _errs30;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid11 = _errs29 === errors2;
            } else {
              var valid11 = true;
            }
            if (valid11) {
              if (data.updatedAt !== void 0) {
                let data11 = data.updatedAt;
                const _errs35 = errors2;
                const _errs36 = errors2;
                let valid13 = false;
                const _errs37 = errors2;
                if (errors2 === _errs37) {
                  if (errors2 === _errs37) {
                    if (typeof data11 === "string") {
                      if (func1(data11) > 64) {
                        const err12 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err12];
                        } else {
                          vErrors.push(err12);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data11)) {
                          const err13 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err13];
                          } else {
                            vErrors.push(err13);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err14 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err14];
                      } else {
                        vErrors.push(err14);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid4 = _errs37 === errors2;
                valid13 = valid13 || _valid4;
                const _errs39 = errors2;
                if (data11 !== null) {
                  const err15 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err15];
                  } else {
                    vErrors.push(err15);
                  }
                  errors2++;
                }
                var _valid4 = _errs39 === errors2;
                valid13 = valid13 || _valid4;
                if (!valid13) {
                  const err16 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err16];
                  } else {
                    vErrors.push(err16);
                  }
                  errors2++;
                  validate38.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs36;
                  if (vErrors !== null) {
                    if (_errs36) {
                      vErrors.length = _errs36;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid11 = _errs35 === errors2;
              } else {
                var valid11 = true;
              }
              if (valid11) {
                if (data.data !== void 0) {
                  let data12 = data.data;
                  const _errs41 = errors2;
                  const _errs42 = errors2;
                  let valid14 = false;
                  const _errs43 = errors2;
                  if (!validate22(data12, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
                    vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
                    errors2 = vErrors.length;
                  }
                  var _valid5 = _errs43 === errors2;
                  valid14 = valid14 || _valid5;
                  const _errs44 = errors2;
                  if (data12 !== null) {
                    const err17 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors2++;
                  }
                  var _valid5 = _errs44 === errors2;
                  valid14 = valid14 || _valid5;
                  if (!valid14) {
                    const err18 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err18];
                    } else {
                      vErrors.push(err18);
                    }
                    errors2++;
                    validate38.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs42;
                    if (vErrors !== null) {
                      if (_errs42) {
                        vErrors.length = _errs42;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid11 = _errs41 === errors2;
                } else {
                  var valid11 = true;
                }
                if (valid11) {
                  if (data.errorCode !== void 0) {
                    let data13 = data.errorCode;
                    const _errs46 = errors2;
                    const _errs47 = errors2;
                    let valid15 = false;
                    const _errs48 = errors2;
                    if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
                      const err19 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema32.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors2++;
                    }
                    var _valid6 = _errs48 === errors2;
                    valid15 = valid15 || _valid6;
                    const _errs49 = errors2;
                    if (data13 !== null) {
                      const err20 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err20];
                      } else {
                        vErrors.push(err20);
                      }
                      errors2++;
                    }
                    var _valid6 = _errs49 === errors2;
                    valid15 = valid15 || _valid6;
                    if (!valid15) {
                      const err21 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err21];
                      } else {
                        vErrors.push(err21);
                      }
                      errors2++;
                      validate38.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs47;
                      if (vErrors !== null) {
                        if (_errs47) {
                          vErrors.length = _errs47;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid11 = _errs46 === errors2;
                  } else {
                    var valid11 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate38.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate38.errors = vErrors;
  return errors2 === 0;
}
validate38.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var weather = validate41;
function validate41(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate41.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.location === void 0 && (missing0 = "location") || data1.timeZone === void 0 && (missing0 = "timeZone") || data1.current === void 0 && (missing0 = "current") || data1.hourly === void 0 && (missing0 = "hourly") || data1.attributionUrl === void 0 && (missing0 = "attributionUrl")) {
              validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "location" || key0 === "timeZone" || key0 === "current" || key0 === "hourly" || key0 === "attributionUrl")) {
                  validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.location !== void 0) {
                  let data2 = data1.location;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 512) {
                        validate41.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                        return false;
                      }
                    } else {
                      validate41.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.timeZone !== void 0) {
                    let data3 = data1.timeZone;
                    const _errs12 = errors2;
                    if (errors2 === _errs12) {
                      if (typeof data3 === "string") {
                        if (func1(data3) > 255) {
                          validate41.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                          return false;
                        } else {
                          if (func1(data3) < 1) {
                            validate41.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          }
                        }
                      } else {
                        validate41.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.current !== void 0) {
                      let data4 = data1.current;
                      const _errs14 = errors2;
                      if (errors2 === _errs14) {
                        if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                          let missing1;
                          if (data4.temperatureC === void 0 && (missing1 = "temperatureC") || data4.code === void 0 && (missing1 = "code")) {
                            validate41.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                            return false;
                          } else {
                            const _errs16 = errors2;
                            for (const key1 in data4) {
                              if (!(key1 === "temperatureC" || key1 === "code")) {
                                validate41.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                return false;
                                break;
                              }
                            }
                            if (_errs16 === errors2) {
                              if (data4.temperatureC !== void 0) {
                                let data5 = data4.temperatureC;
                                const _errs17 = errors2;
                                const _errs18 = errors2;
                                let valid7 = false;
                                const _errs19 = errors2;
                                if (!(typeof data5 == "number" && isFinite(data5))) {
                                  const err1 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err1];
                                  } else {
                                    vErrors.push(err1);
                                  }
                                  errors2++;
                                }
                                var _valid1 = _errs19 === errors2;
                                valid7 = valid7 || _valid1;
                                const _errs21 = errors2;
                                if (data5 !== null) {
                                  const err2 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors2++;
                                }
                                var _valid1 = _errs21 === errors2;
                                valid7 = valid7 || _valid1;
                                if (!valid7) {
                                  const err3 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err3];
                                  } else {
                                    vErrors.push(err3);
                                  }
                                  errors2++;
                                  validate41.errors = vErrors;
                                  return false;
                                } else {
                                  errors2 = _errs18;
                                  if (vErrors !== null) {
                                    if (_errs18) {
                                      vErrors.length = _errs18;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid6 = _errs17 === errors2;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.code !== void 0) {
                                  let data6 = data4.code;
                                  const _errs23 = errors2;
                                  const _errs24 = errors2;
                                  let valid8 = false;
                                  const _errs25 = errors2;
                                  if (!(typeof data6 == "number" && (!(data6 % 1) && !isNaN(data6)) && isFinite(data6))) {
                                    const err4 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err4];
                                    } else {
                                      vErrors.push(err4);
                                    }
                                    errors2++;
                                  }
                                  if (errors2 === _errs25) {
                                    if (typeof data6 == "number" && isFinite(data6)) {
                                      if (data6 > 99 || isNaN(data6)) {
                                        const err5 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                        if (vErrors === null) {
                                          vErrors = [err5];
                                        } else {
                                          vErrors.push(err5);
                                        }
                                        errors2++;
                                      } else {
                                        if (data6 < 0 || isNaN(data6)) {
                                          const err6 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                          if (vErrors === null) {
                                            vErrors = [err6];
                                          } else {
                                            vErrors.push(err6);
                                          }
                                          errors2++;
                                        }
                                      }
                                    }
                                  }
                                  var _valid2 = _errs25 === errors2;
                                  valid8 = valid8 || _valid2;
                                  const _errs27 = errors2;
                                  if (data6 !== null) {
                                    const err7 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err7];
                                    } else {
                                      vErrors.push(err7);
                                    }
                                    errors2++;
                                  }
                                  var _valid2 = _errs27 === errors2;
                                  valid8 = valid8 || _valid2;
                                  if (!valid8) {
                                    const err8 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors2++;
                                    validate41.errors = vErrors;
                                    return false;
                                  } else {
                                    errors2 = _errs24;
                                    if (vErrors !== null) {
                                      if (_errs24) {
                                        vErrors.length = _errs24;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid6 = _errs23 === errors2;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                          }
                        } else {
                          validate41.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                          return false;
                        }
                      }
                      var valid5 = _errs14 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.hourly !== void 0) {
                        let data7 = data1.hourly;
                        const _errs29 = errors2;
                        if (errors2 === _errs29) {
                          if (Array.isArray(data7)) {
                            if (data7.length > 6) {
                              validate41.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" }];
                              return false;
                            } else {
                              var valid9 = true;
                              const len0 = data7.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data8 = data7[i0];
                                const _errs31 = errors2;
                                if (errors2 === _errs31) {
                                  if (data8 && typeof data8 == "object" && !Array.isArray(data8)) {
                                    let missing2;
                                    if (data8.at === void 0 && (missing2 = "at") || data8.temperatureC === void 0 && (missing2 = "temperatureC") || data8.precipitationProbability === void 0 && (missing2 = "precipitationProbability")) {
                                      validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
                                      return false;
                                    } else {
                                      const _errs33 = errors2;
                                      for (const key2 in data8) {
                                        if (!(key2 === "at" || key2 === "temperatureC" || key2 === "precipitationProbability")) {
                                          validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs33 === errors2) {
                                        if (data8.at !== void 0) {
                                          let data9 = data8.at;
                                          const _errs34 = errors2;
                                          if (errors2 === _errs34) {
                                            if (errors2 === _errs34) {
                                              if (typeof data9 === "string") {
                                                if (func1(data9) > 64) {
                                                  validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data9)) {
                                                    validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid10 = _errs34 === errors2;
                                        } else {
                                          var valid10 = true;
                                        }
                                        if (valid10) {
                                          if (data8.temperatureC !== void 0) {
                                            let data10 = data8.temperatureC;
                                            const _errs36 = errors2;
                                            const _errs37 = errors2;
                                            let valid11 = false;
                                            const _errs38 = errors2;
                                            if (!(typeof data10 == "number" && isFinite(data10))) {
                                              const err9 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                              if (vErrors === null) {
                                                vErrors = [err9];
                                              } else {
                                                vErrors.push(err9);
                                              }
                                              errors2++;
                                            }
                                            var _valid3 = _errs38 === errors2;
                                            valid11 = valid11 || _valid3;
                                            const _errs40 = errors2;
                                            if (data10 !== null) {
                                              const err10 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err10];
                                              } else {
                                                vErrors.push(err10);
                                              }
                                              errors2++;
                                            }
                                            var _valid3 = _errs40 === errors2;
                                            valid11 = valid11 || _valid3;
                                            if (!valid11) {
                                              const err11 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err11];
                                              } else {
                                                vErrors.push(err11);
                                              }
                                              errors2++;
                                              validate41.errors = vErrors;
                                              return false;
                                            } else {
                                              errors2 = _errs37;
                                              if (vErrors !== null) {
                                                if (_errs37) {
                                                  vErrors.length = _errs37;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid10 = _errs36 === errors2;
                                          } else {
                                            var valid10 = true;
                                          }
                                          if (valid10) {
                                            if (data8.precipitationProbability !== void 0) {
                                              let data11 = data8.precipitationProbability;
                                              const _errs42 = errors2;
                                              const _errs43 = errors2;
                                              let valid12 = false;
                                              const _errs44 = errors2;
                                              if (errors2 === _errs44) {
                                                if (typeof data11 == "number" && isFinite(data11)) {
                                                  if (data11 > 100 || isNaN(data11)) {
                                                    const err12 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                    if (vErrors === null) {
                                                      vErrors = [err12];
                                                    } else {
                                                      vErrors.push(err12);
                                                    }
                                                    errors2++;
                                                  } else {
                                                    if (data11 < 0 || isNaN(data11)) {
                                                      const err13 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                      if (vErrors === null) {
                                                        vErrors = [err13];
                                                      } else {
                                                        vErrors.push(err13);
                                                      }
                                                      errors2++;
                                                    }
                                                  }
                                                } else {
                                                  const err14 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                  if (vErrors === null) {
                                                    vErrors = [err14];
                                                  } else {
                                                    vErrors.push(err14);
                                                  }
                                                  errors2++;
                                                }
                                              }
                                              var _valid4 = _errs44 === errors2;
                                              valid12 = valid12 || _valid4;
                                              const _errs46 = errors2;
                                              if (data11 !== null) {
                                                const err15 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                if (vErrors === null) {
                                                  vErrors = [err15];
                                                } else {
                                                  vErrors.push(err15);
                                                }
                                                errors2++;
                                              }
                                              var _valid4 = _errs46 === errors2;
                                              valid12 = valid12 || _valid4;
                                              if (!valid12) {
                                                const err16 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                if (vErrors === null) {
                                                  vErrors = [err16];
                                                } else {
                                                  vErrors.push(err16);
                                                }
                                                errors2++;
                                                validate41.errors = vErrors;
                                                return false;
                                              } else {
                                                errors2 = _errs43;
                                                if (vErrors !== null) {
                                                  if (_errs43) {
                                                    vErrors.length = _errs43;
                                                  } else {
                                                    vErrors = null;
                                                  }
                                                }
                                              }
                                              var valid10 = _errs42 === errors2;
                                            } else {
                                              var valid10 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid9 = _errs31 === errors2;
                                if (!valid9) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate41.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs29 === errors2;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.attributionUrl !== void 0) {
                          let data12 = data1.attributionUrl;
                          const _errs48 = errors2;
                          if (errors2 === _errs48) {
                            if (typeof data12 === "string") {
                              if (func1(data12) > 512) {
                                validate41.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                                return false;
                              } else {
                                if (!pattern6.test(data12)) {
                                  validate41.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' }];
                                  return false;
                                }
                              }
                            } else {
                              validate41.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                              return false;
                            }
                          }
                          var valid5 = _errs48 === errors2;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data13 = data.updatedAt;
          const _errs50 = errors2;
          if (errors2 === _errs50) {
            if (errors2 === _errs50) {
              if (typeof data13 === "string") {
                if (func1(data13) > 64) {
                  validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data13)) {
                    validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs50 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err17 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err17];
    } else {
      vErrors.push(err17);
    }
    errors2++;
    validate41.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs52 = errors2;
    const _errs53 = errors2;
    let valid13 = true;
    const _errs54 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data14 = data.status;
        if (!(data14 === "unconfigured" || data14 === "unavailable")) {
          const err18 = {};
          if (vErrors === null) {
            vErrors = [err18];
          } else {
            vErrors.push(err18);
          }
          errors2++;
        }
      }
    }
    var _valid5 = _errs54 === errors2;
    errors2 = _errs53;
    if (vErrors !== null) {
      if (_errs53) {
        vErrors.length = _errs53;
      } else {
        vErrors = null;
      }
    }
    if (_valid5) {
      const _errs56 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs57 = errors2;
          if (data.data !== null) {
            validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid15 = _errs57 === errors2;
        } else {
          var valid15 = true;
        }
        if (valid15) {
          if (data.updatedAt !== void 0) {
            const _errs59 = errors2;
            if (data.updatedAt !== null) {
              validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid15 = _errs59 === errors2;
          } else {
            var valid15 = true;
          }
        }
      }
      var _valid5 = _errs56 === errors2;
      valid13 = _valid5;
      if (valid13) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid13) {
      const err19 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err19];
      } else {
        vErrors.push(err19);
      }
      errors2++;
      validate41.errors = vErrors;
      return false;
    }
    var valid0 = _errs52 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs61 = errors2;
      const _errs62 = errors2;
      let valid16 = true;
      const _errs63 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data17 = data.status;
          if (!(data17 === "ok" || data17 === "unconfigured" || data17 === "loading")) {
            const err20 = {};
            if (vErrors === null) {
              vErrors = [err20];
            } else {
              vErrors.push(err20);
            }
            errors2++;
          }
        }
      }
      var _valid6 = _errs63 === errors2;
      errors2 = _errs62;
      if (vErrors !== null) {
        if (_errs62) {
          vErrors.length = _errs62;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid6) {
        const _errs65 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate41.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid6 = _errs65 === errors2;
        valid16 = _valid6;
        if (valid16) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs68 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data19 = data.errorCode;
            if (!(data19 === "NETWORK_ERROR" || data19 === "INVALID_DATA" || data19 === "PAYLOAD_TOO_LARGE" || data19 === "EXPANSION_LIMIT" || data19 === "UNSUPPORTED_CALENDAR" || data19 === "UNKNOWN_TIME_ZONE" || data19 === "KEYRING_LOCKED" || data19 === "SECRET_DELETION_FAILED" || data19 === "AUTH_ERROR" || data19 === "RATE_LIMITED" || data19 === "NO_PLAYER" || data19 === "NO_INTERFACE" || data19 === "SERVICE_UNAVAILABLE" || data19 === "INTERNAL_ERROR")) {
              validate41.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema35.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid6 = _errs68 === errors2;
        valid16 = _valid6;
        if (valid16) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid16) {
        const err21 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err21];
        } else {
          vErrors.push(err21);
        }
        errors2++;
        validate41.errors = vErrors;
        return false;
      }
      var valid0 = _errs61 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing3;
      if (data.status === void 0 && (missing3 = "status") || data.sourceId === void 0 && (missing3 = "sourceId") || data.updatedAt === void 0 && (missing3 = "updatedAt") || data.data === void 0 && (missing3 = "data") || data.errorCode === void 0 && (missing3 = "errorCode")) {
        validate41.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" }];
        return false;
      } else {
        const _errs70 = errors2;
        for (const key3 in data) {
          if (!(key3 === "status" || key3 === "sourceId" || key3 === "updatedAt" || key3 === "data" || key3 === "errorCode")) {
            validate41.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs70 === errors2) {
          if (data.status !== void 0) {
            let data20 = data.status;
            const _errs71 = errors2;
            if (!(data20 === "loading" || data20 === "ok" || data20 === "stale" || data20 === "unconfigured" || data20 === "unavailable")) {
              validate41.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema35.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid20 = _errs71 === errors2;
          } else {
            var valid20 = true;
          }
          if (valid20) {
            if (data.sourceId !== void 0) {
              let data21 = data.sourceId;
              const _errs72 = errors2;
              const _errs73 = errors2;
              let valid21 = false;
              const _errs74 = errors2;
              if (errors2 === _errs74) {
                if (typeof data21 === "string") {
                  if (func1(data21) > 128) {
                    const err22 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err22];
                    } else {
                      vErrors.push(err22);
                    }
                    errors2++;
                  } else {
                    if (func1(data21) < 1) {
                      const err23 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err23];
                      } else {
                        vErrors.push(err23);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data21)) {
                        const err24 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err24];
                        } else {
                          vErrors.push(err24);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err25 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err25];
                  } else {
                    vErrors.push(err25);
                  }
                  errors2++;
                }
              }
              var _valid7 = _errs74 === errors2;
              valid21 = valid21 || _valid7;
              const _errs76 = errors2;
              if (data21 !== null) {
                const err26 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err26];
                } else {
                  vErrors.push(err26);
                }
                errors2++;
              }
              var _valid7 = _errs76 === errors2;
              valid21 = valid21 || _valid7;
              if (!valid21) {
                const err27 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err27];
                } else {
                  vErrors.push(err27);
                }
                errors2++;
                validate41.errors = vErrors;
                return false;
              } else {
                errors2 = _errs73;
                if (vErrors !== null) {
                  if (_errs73) {
                    vErrors.length = _errs73;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid20 = _errs72 === errors2;
            } else {
              var valid20 = true;
            }
            if (valid20) {
              if (data.updatedAt !== void 0) {
                let data22 = data.updatedAt;
                const _errs78 = errors2;
                const _errs79 = errors2;
                let valid22 = false;
                const _errs80 = errors2;
                if (errors2 === _errs80) {
                  if (errors2 === _errs80) {
                    if (typeof data22 === "string") {
                      if (func1(data22) > 64) {
                        const err28 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err28];
                        } else {
                          vErrors.push(err28);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data22)) {
                          const err29 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err29];
                          } else {
                            vErrors.push(err29);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err30 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err30];
                      } else {
                        vErrors.push(err30);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid8 = _errs80 === errors2;
                valid22 = valid22 || _valid8;
                const _errs82 = errors2;
                if (data22 !== null) {
                  const err31 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err31];
                  } else {
                    vErrors.push(err31);
                  }
                  errors2++;
                }
                var _valid8 = _errs82 === errors2;
                valid22 = valid22 || _valid8;
                if (!valid22) {
                  const err32 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err32];
                  } else {
                    vErrors.push(err32);
                  }
                  errors2++;
                  validate41.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs79;
                  if (vErrors !== null) {
                    if (_errs79) {
                      vErrors.length = _errs79;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid20 = _errs78 === errors2;
              } else {
                var valid20 = true;
              }
              if (valid20) {
                if (data.data !== void 0) {
                  let data23 = data.data;
                  const _errs84 = errors2;
                  const _errs85 = errors2;
                  let valid23 = false;
                  const _errs86 = errors2;
                  const _errs87 = errors2;
                  if (errors2 === _errs87) {
                    if (data23 && typeof data23 == "object" && !Array.isArray(data23)) {
                      let missing4;
                      if (data23.location === void 0 && (missing4 = "location") || data23.timeZone === void 0 && (missing4 = "timeZone") || data23.current === void 0 && (missing4 = "current") || data23.hourly === void 0 && (missing4 = "hourly") || data23.attributionUrl === void 0 && (missing4 = "attributionUrl")) {
                        const err33 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                        if (vErrors === null) {
                          vErrors = [err33];
                        } else {
                          vErrors.push(err33);
                        }
                        errors2++;
                      } else {
                        const _errs89 = errors2;
                        for (const key4 in data23) {
                          if (!(key4 === "location" || key4 === "timeZone" || key4 === "current" || key4 === "hourly" || key4 === "attributionUrl")) {
                            const err34 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err34];
                            } else {
                              vErrors.push(err34);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs89 === errors2) {
                          if (data23.location !== void 0) {
                            let data24 = data23.location;
                            const _errs90 = errors2;
                            if (errors2 === _errs90) {
                              if (typeof data24 === "string") {
                                if (func1(data24) > 512) {
                                  const err35 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors2++;
                                }
                              } else {
                                const err36 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err36];
                                } else {
                                  vErrors.push(err36);
                                }
                                errors2++;
                              }
                            }
                            var valid25 = _errs90 === errors2;
                          } else {
                            var valid25 = true;
                          }
                          if (valid25) {
                            if (data23.timeZone !== void 0) {
                              let data25 = data23.timeZone;
                              const _errs92 = errors2;
                              if (errors2 === _errs92) {
                                if (typeof data25 === "string") {
                                  if (func1(data25) > 255) {
                                    const err37 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err37];
                                    } else {
                                      vErrors.push(err37);
                                    }
                                    errors2++;
                                  } else {
                                    if (func1(data25) < 1) {
                                      const err38 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err38];
                                      } else {
                                        vErrors.push(err38);
                                      }
                                      errors2++;
                                    }
                                  }
                                } else {
                                  const err39 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err39];
                                  } else {
                                    vErrors.push(err39);
                                  }
                                  errors2++;
                                }
                              }
                              var valid25 = _errs92 === errors2;
                            } else {
                              var valid25 = true;
                            }
                            if (valid25) {
                              if (data23.current !== void 0) {
                                let data26 = data23.current;
                                const _errs94 = errors2;
                                if (errors2 === _errs94) {
                                  if (data26 && typeof data26 == "object" && !Array.isArray(data26)) {
                                    let missing5;
                                    if (data26.temperatureC === void 0 && (missing5 = "temperatureC") || data26.code === void 0 && (missing5 = "code")) {
                                      const err40 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing5 }, message: "must have required property '" + missing5 + "'" };
                                      if (vErrors === null) {
                                        vErrors = [err40];
                                      } else {
                                        vErrors.push(err40);
                                      }
                                      errors2++;
                                    } else {
                                      const _errs96 = errors2;
                                      for (const key5 in data26) {
                                        if (!(key5 === "temperatureC" || key5 === "code")) {
                                          const err41 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                                          if (vErrors === null) {
                                            vErrors = [err41];
                                          } else {
                                            vErrors.push(err41);
                                          }
                                          errors2++;
                                          break;
                                        }
                                      }
                                      if (_errs96 === errors2) {
                                        if (data26.temperatureC !== void 0) {
                                          let data27 = data26.temperatureC;
                                          const _errs97 = errors2;
                                          const _errs98 = errors2;
                                          let valid27 = false;
                                          const _errs99 = errors2;
                                          if (!(typeof data27 == "number" && isFinite(data27))) {
                                            const err42 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                            if (vErrors === null) {
                                              vErrors = [err42];
                                            } else {
                                              vErrors.push(err42);
                                            }
                                            errors2++;
                                          }
                                          var _valid10 = _errs99 === errors2;
                                          valid27 = valid27 || _valid10;
                                          const _errs101 = errors2;
                                          if (data27 !== null) {
                                            const err43 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                            if (vErrors === null) {
                                              vErrors = [err43];
                                            } else {
                                              vErrors.push(err43);
                                            }
                                            errors2++;
                                          }
                                          var _valid10 = _errs101 === errors2;
                                          valid27 = valid27 || _valid10;
                                          if (!valid27) {
                                            const err44 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                            if (vErrors === null) {
                                              vErrors = [err44];
                                            } else {
                                              vErrors.push(err44);
                                            }
                                            errors2++;
                                          } else {
                                            errors2 = _errs98;
                                            if (vErrors !== null) {
                                              if (_errs98) {
                                                vErrors.length = _errs98;
                                              } else {
                                                vErrors = null;
                                              }
                                            }
                                          }
                                          var valid26 = _errs97 === errors2;
                                        } else {
                                          var valid26 = true;
                                        }
                                        if (valid26) {
                                          if (data26.code !== void 0) {
                                            let data28 = data26.code;
                                            const _errs103 = errors2;
                                            const _errs104 = errors2;
                                            let valid28 = false;
                                            const _errs105 = errors2;
                                            if (!(typeof data28 == "number" && (!(data28 % 1) && !isNaN(data28)) && isFinite(data28))) {
                                              const err45 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                              if (vErrors === null) {
                                                vErrors = [err45];
                                              } else {
                                                vErrors.push(err45);
                                              }
                                              errors2++;
                                            }
                                            if (errors2 === _errs105) {
                                              if (typeof data28 == "number" && isFinite(data28)) {
                                                if (data28 > 99 || isNaN(data28)) {
                                                  const err46 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                                  if (vErrors === null) {
                                                    vErrors = [err46];
                                                  } else {
                                                    vErrors.push(err46);
                                                  }
                                                  errors2++;
                                                } else {
                                                  if (data28 < 0 || isNaN(data28)) {
                                                    const err47 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                    if (vErrors === null) {
                                                      vErrors = [err47];
                                                    } else {
                                                      vErrors.push(err47);
                                                    }
                                                    errors2++;
                                                  }
                                                }
                                              }
                                            }
                                            var _valid11 = _errs105 === errors2;
                                            valid28 = valid28 || _valid11;
                                            const _errs107 = errors2;
                                            if (data28 !== null) {
                                              const err48 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors2++;
                                            }
                                            var _valid11 = _errs107 === errors2;
                                            valid28 = valid28 || _valid11;
                                            if (!valid28) {
                                              const err49 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err49];
                                              } else {
                                                vErrors.push(err49);
                                              }
                                              errors2++;
                                            } else {
                                              errors2 = _errs104;
                                              if (vErrors !== null) {
                                                if (_errs104) {
                                                  vErrors.length = _errs104;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid26 = _errs103 === errors2;
                                          } else {
                                            var valid26 = true;
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    const err50 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                    if (vErrors === null) {
                                      vErrors = [err50];
                                    } else {
                                      vErrors.push(err50);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid25 = _errs94 === errors2;
                              } else {
                                var valid25 = true;
                              }
                              if (valid25) {
                                if (data23.hourly !== void 0) {
                                  let data29 = data23.hourly;
                                  const _errs109 = errors2;
                                  if (errors2 === _errs109) {
                                    if (Array.isArray(data29)) {
                                      if (data29.length > 6) {
                                        const err51 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" };
                                        if (vErrors === null) {
                                          vErrors = [err51];
                                        } else {
                                          vErrors.push(err51);
                                        }
                                        errors2++;
                                      } else {
                                        var valid29 = true;
                                        const len1 = data29.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data30 = data29[i1];
                                          const _errs111 = errors2;
                                          if (errors2 === _errs111) {
                                            if (data30 && typeof data30 == "object" && !Array.isArray(data30)) {
                                              let missing6;
                                              if (data30.at === void 0 && (missing6 = "at") || data30.temperatureC === void 0 && (missing6 = "temperatureC") || data30.precipitationProbability === void 0 && (missing6 = "precipitationProbability")) {
                                                const err52 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing6 }, message: "must have required property '" + missing6 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err52];
                                                } else {
                                                  vErrors.push(err52);
                                                }
                                                errors2++;
                                              } else {
                                                const _errs113 = errors2;
                                                for (const key6 in data30) {
                                                  if (!(key6 === "at" || key6 === "temperatureC" || key6 === "precipitationProbability")) {
                                                    const err53 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err53];
                                                    } else {
                                                      vErrors.push(err53);
                                                    }
                                                    errors2++;
                                                    break;
                                                  }
                                                }
                                                if (_errs113 === errors2) {
                                                  if (data30.at !== void 0) {
                                                    let data31 = data30.at;
                                                    const _errs114 = errors2;
                                                    if (errors2 === _errs114) {
                                                      if (errors2 === _errs114) {
                                                        if (typeof data31 === "string") {
                                                          if (func1(data31) > 64) {
                                                            const err54 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err54];
                                                            } else {
                                                              vErrors.push(err54);
                                                            }
                                                            errors2++;
                                                          } else {
                                                            if (!formats0.validate(data31)) {
                                                              const err55 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err55];
                                                              } else {
                                                                vErrors.push(err55);
                                                              }
                                                              errors2++;
                                                            }
                                                          }
                                                        } else {
                                                          const err56 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err56];
                                                          } else {
                                                            vErrors.push(err56);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                    }
                                                    var valid30 = _errs114 === errors2;
                                                  } else {
                                                    var valid30 = true;
                                                  }
                                                  if (valid30) {
                                                    if (data30.temperatureC !== void 0) {
                                                      let data32 = data30.temperatureC;
                                                      const _errs116 = errors2;
                                                      const _errs117 = errors2;
                                                      let valid31 = false;
                                                      const _errs118 = errors2;
                                                      if (!(typeof data32 == "number" && isFinite(data32))) {
                                                        const err57 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                        if (vErrors === null) {
                                                          vErrors = [err57];
                                                        } else {
                                                          vErrors.push(err57);
                                                        }
                                                        errors2++;
                                                      }
                                                      var _valid12 = _errs118 === errors2;
                                                      valid31 = valid31 || _valid12;
                                                      const _errs120 = errors2;
                                                      if (data32 !== null) {
                                                        const err58 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                        if (vErrors === null) {
                                                          vErrors = [err58];
                                                        } else {
                                                          vErrors.push(err58);
                                                        }
                                                        errors2++;
                                                      }
                                                      var _valid12 = _errs120 === errors2;
                                                      valid31 = valid31 || _valid12;
                                                      if (!valid31) {
                                                        const err59 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                        if (vErrors === null) {
                                                          vErrors = [err59];
                                                        } else {
                                                          vErrors.push(err59);
                                                        }
                                                        errors2++;
                                                      } else {
                                                        errors2 = _errs117;
                                                        if (vErrors !== null) {
                                                          if (_errs117) {
                                                            vErrors.length = _errs117;
                                                          } else {
                                                            vErrors = null;
                                                          }
                                                        }
                                                      }
                                                      var valid30 = _errs116 === errors2;
                                                    } else {
                                                      var valid30 = true;
                                                    }
                                                    if (valid30) {
                                                      if (data30.precipitationProbability !== void 0) {
                                                        let data33 = data30.precipitationProbability;
                                                        const _errs122 = errors2;
                                                        const _errs123 = errors2;
                                                        let valid32 = false;
                                                        const _errs124 = errors2;
                                                        if (errors2 === _errs124) {
                                                          if (typeof data33 == "number" && isFinite(data33)) {
                                                            if (data33 > 100 || isNaN(data33)) {
                                                              const err60 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                              if (vErrors === null) {
                                                                vErrors = [err60];
                                                              } else {
                                                                vErrors.push(err60);
                                                              }
                                                              errors2++;
                                                            } else {
                                                              if (data33 < 0 || isNaN(data33)) {
                                                                const err61 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                                if (vErrors === null) {
                                                                  vErrors = [err61];
                                                                } else {
                                                                  vErrors.push(err61);
                                                                }
                                                                errors2++;
                                                              }
                                                            }
                                                          } else {
                                                            const err62 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err62];
                                                            } else {
                                                              vErrors.push(err62);
                                                            }
                                                            errors2++;
                                                          }
                                                        }
                                                        var _valid13 = _errs124 === errors2;
                                                        valid32 = valid32 || _valid13;
                                                        const _errs126 = errors2;
                                                        if (data33 !== null) {
                                                          const err63 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                          if (vErrors === null) {
                                                            vErrors = [err63];
                                                          } else {
                                                            vErrors.push(err63);
                                                          }
                                                          errors2++;
                                                        }
                                                        var _valid13 = _errs126 === errors2;
                                                        valid32 = valid32 || _valid13;
                                                        if (!valid32) {
                                                          const err64 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                          if (vErrors === null) {
                                                            vErrors = [err64];
                                                          } else {
                                                            vErrors.push(err64);
                                                          }
                                                          errors2++;
                                                        } else {
                                                          errors2 = _errs123;
                                                          if (vErrors !== null) {
                                                            if (_errs123) {
                                                              vErrors.length = _errs123;
                                                            } else {
                                                              vErrors = null;
                                                            }
                                                          }
                                                        }
                                                        var valid30 = _errs122 === errors2;
                                                      } else {
                                                        var valid30 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err65 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err65];
                                              } else {
                                                vErrors.push(err65);
                                              }
                                              errors2++;
                                            }
                                          }
                                          var valid29 = _errs111 === errors2;
                                          if (!valid29) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err66 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err66];
                                      } else {
                                        vErrors.push(err66);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid25 = _errs109 === errors2;
                                } else {
                                  var valid25 = true;
                                }
                                if (valid25) {
                                  if (data23.attributionUrl !== void 0) {
                                    let data34 = data23.attributionUrl;
                                    const _errs128 = errors2;
                                    if (errors2 === _errs128) {
                                      if (typeof data34 === "string") {
                                        if (func1(data34) > 512) {
                                          const err67 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err67];
                                          } else {
                                            vErrors.push(err67);
                                          }
                                          errors2++;
                                        } else {
                                          if (!pattern6.test(data34)) {
                                            const err68 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' };
                                            if (vErrors === null) {
                                              vErrors = [err68];
                                            } else {
                                              vErrors.push(err68);
                                            }
                                            errors2++;
                                          }
                                        }
                                      } else {
                                        const err69 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err69];
                                        } else {
                                          vErrors.push(err69);
                                        }
                                        errors2++;
                                      }
                                    }
                                    var valid25 = _errs128 === errors2;
                                  } else {
                                    var valid25 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err70 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err70];
                      } else {
                        vErrors.push(err70);
                      }
                      errors2++;
                    }
                  }
                  var _valid9 = _errs86 === errors2;
                  valid23 = valid23 || _valid9;
                  const _errs130 = errors2;
                  if (data23 !== null) {
                    const err71 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err71];
                    } else {
                      vErrors.push(err71);
                    }
                    errors2++;
                  }
                  var _valid9 = _errs130 === errors2;
                  valid23 = valid23 || _valid9;
                  if (!valid23) {
                    const err72 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err72];
                    } else {
                      vErrors.push(err72);
                    }
                    errors2++;
                    validate41.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs85;
                    if (vErrors !== null) {
                      if (_errs85) {
                        vErrors.length = _errs85;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid20 = _errs84 === errors2;
                } else {
                  var valid20 = true;
                }
                if (valid20) {
                  if (data.errorCode !== void 0) {
                    let data35 = data.errorCode;
                    const _errs132 = errors2;
                    const _errs133 = errors2;
                    let valid33 = false;
                    const _errs134 = errors2;
                    if (!(data35 === "NETWORK_ERROR" || data35 === "INVALID_DATA" || data35 === "PAYLOAD_TOO_LARGE" || data35 === "EXPANSION_LIMIT" || data35 === "UNSUPPORTED_CALENDAR" || data35 === "UNKNOWN_TIME_ZONE" || data35 === "KEYRING_LOCKED" || data35 === "SECRET_DELETION_FAILED" || data35 === "AUTH_ERROR" || data35 === "RATE_LIMITED" || data35 === "NO_PLAYER" || data35 === "NO_INTERFACE" || data35 === "SERVICE_UNAVAILABLE" || data35 === "INTERNAL_ERROR")) {
                      const err73 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema35.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err73];
                      } else {
                        vErrors.push(err73);
                      }
                      errors2++;
                    }
                    var _valid14 = _errs134 === errors2;
                    valid33 = valid33 || _valid14;
                    const _errs135 = errors2;
                    if (data35 !== null) {
                      const err74 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err74];
                      } else {
                        vErrors.push(err74);
                      }
                      errors2++;
                    }
                    var _valid14 = _errs135 === errors2;
                    valid33 = valid33 || _valid14;
                    if (!valid33) {
                      const err75 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err75];
                      } else {
                        vErrors.push(err75);
                      }
                      errors2++;
                      validate41.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs133;
                      if (vErrors !== null) {
                        if (_errs133) {
                          vErrors.length = _errs133;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid20 = _errs132 === errors2;
                  } else {
                    var valid20 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate41.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate41.errors = vErrors;
  return errors2 === 0;
}
validate41.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var system = validate42;
function validate42(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate42.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.cpuPercent === void 0 && (missing0 = "cpuPercent") || data1.memoryUsedBytes === void 0 && (missing0 = "memoryUsedBytes") || data1.memoryTotalBytes === void 0 && (missing0 = "memoryTotalBytes") || data1.temperatureC === void 0 && (missing0 = "temperatureC")) {
              validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "cpuPercent" || key0 === "memoryUsedBytes" || key0 === "memoryTotalBytes" || key0 === "temperatureC")) {
                  validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.cpuPercent !== void 0) {
                  let data2 = data1.cpuPercent;
                  const _errs10 = errors2;
                  const _errs11 = errors2;
                  let valid6 = false;
                  const _errs12 = errors2;
                  if (errors2 === _errs12) {
                    if (typeof data2 == "number" && isFinite(data2)) {
                      if (data2 > 100 || isNaN(data2)) {
                        const err1 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                        if (vErrors === null) {
                          vErrors = [err1];
                        } else {
                          vErrors.push(err1);
                        }
                        errors2++;
                      } else {
                        if (data2 < 0 || isNaN(data2)) {
                          const err2 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err2];
                          } else {
                            vErrors.push(err2);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err3 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors2++;
                    }
                  }
                  var _valid1 = _errs12 === errors2;
                  valid6 = valid6 || _valid1;
                  const _errs14 = errors2;
                  if (data2 !== null) {
                    const err4 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err4];
                    } else {
                      vErrors.push(err4);
                    }
                    errors2++;
                  }
                  var _valid1 = _errs14 === errors2;
                  valid6 = valid6 || _valid1;
                  if (!valid6) {
                    const err5 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err5];
                    } else {
                      vErrors.push(err5);
                    }
                    errors2++;
                    validate42.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs11;
                    if (vErrors !== null) {
                      if (_errs11) {
                        vErrors.length = _errs11;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.memoryUsedBytes !== void 0) {
                    let data3 = data1.memoryUsedBytes;
                    const _errs16 = errors2;
                    if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                      validate42.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                      return false;
                    }
                    if (errors2 === _errs16) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 > 9007199254740991 || isNaN(data3)) {
                          validate42.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                          return false;
                        } else {
                          if (data3 < 0 || isNaN(data3)) {
                            validate42.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                            return false;
                          }
                        }
                      }
                    }
                    var valid5 = _errs16 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.memoryTotalBytes !== void 0) {
                      let data4 = data1.memoryTotalBytes;
                      const _errs18 = errors2;
                      if (!(typeof data4 == "number" && (!(data4 % 1) && !isNaN(data4)) && isFinite(data4))) {
                        validate42.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                        return false;
                      }
                      if (errors2 === _errs18) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 > 9007199254740991 || isNaN(data4)) {
                            validate42.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                            return false;
                          } else {
                            if (data4 < 0 || isNaN(data4)) {
                              validate42.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                              return false;
                            }
                          }
                        }
                      }
                      var valid5 = _errs18 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.temperatureC !== void 0) {
                        let data5 = data1.temperatureC;
                        const _errs20 = errors2;
                        const _errs21 = errors2;
                        let valid7 = false;
                        const _errs22 = errors2;
                        if (!(typeof data5 == "number" && isFinite(data5))) {
                          const err6 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors2++;
                        }
                        var _valid2 = _errs22 === errors2;
                        valid7 = valid7 || _valid2;
                        const _errs24 = errors2;
                        if (data5 !== null) {
                          const err7 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                          if (vErrors === null) {
                            vErrors = [err7];
                          } else {
                            vErrors.push(err7);
                          }
                          errors2++;
                        }
                        var _valid2 = _errs24 === errors2;
                        valid7 = valid7 || _valid2;
                        if (!valid7) {
                          const err8 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                          if (vErrors === null) {
                            vErrors = [err8];
                          } else {
                            vErrors.push(err8);
                          }
                          errors2++;
                          validate42.errors = vErrors;
                          return false;
                        } else {
                          errors2 = _errs21;
                          if (vErrors !== null) {
                            if (_errs21) {
                              vErrors.length = _errs21;
                            } else {
                              vErrors = null;
                            }
                          }
                        }
                        var valid5 = _errs20 === errors2;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data6 = data.updatedAt;
          const _errs26 = errors2;
          if (errors2 === _errs26) {
            if (errors2 === _errs26) {
              if (typeof data6 === "string") {
                if (func1(data6) > 64) {
                  validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data6)) {
                    validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs26 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors2++;
    validate42.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs28 = errors2;
    const _errs29 = errors2;
    let valid8 = true;
    const _errs30 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data7 = data.status;
        if (!(data7 === "unconfigured" || data7 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors2++;
        }
      }
    }
    var _valid3 = _errs30 === errors2;
    errors2 = _errs29;
    if (vErrors !== null) {
      if (_errs29) {
        vErrors.length = _errs29;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs32 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs33 = errors2;
          if (data.data !== null) {
            validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid10 = _errs33 === errors2;
        } else {
          var valid10 = true;
        }
        if (valid10) {
          if (data.updatedAt !== void 0) {
            const _errs35 = errors2;
            if (data.updatedAt !== null) {
              validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid10 = _errs35 === errors2;
          } else {
            var valid10 = true;
          }
        }
      }
      var _valid3 = _errs32 === errors2;
      valid8 = _valid3;
      if (valid8) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid8) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors2++;
      validate42.errors = vErrors;
      return false;
    }
    var valid0 = _errs28 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs37 = errors2;
      const _errs38 = errors2;
      let valid11 = true;
      const _errs39 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data10 = data.status;
          if (!(data10 === "ok" || data10 === "unconfigured" || data10 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors2++;
          }
        }
      }
      var _valid4 = _errs39 === errors2;
      errors2 = _errs38;
      if (vErrors !== null) {
        if (_errs38) {
          vErrors.length = _errs38;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs41 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate42.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs41 === errors2;
        valid11 = _valid4;
        if (valid11) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs44 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data12 = data.errorCode;
            if (!(data12 === "NETWORK_ERROR" || data12 === "INVALID_DATA" || data12 === "PAYLOAD_TOO_LARGE" || data12 === "EXPANSION_LIMIT" || data12 === "UNSUPPORTED_CALENDAR" || data12 === "UNKNOWN_TIME_ZONE" || data12 === "KEYRING_LOCKED" || data12 === "SECRET_DELETION_FAILED" || data12 === "AUTH_ERROR" || data12 === "RATE_LIMITED" || data12 === "NO_PLAYER" || data12 === "NO_INTERFACE" || data12 === "SERVICE_UNAVAILABLE" || data12 === "INTERNAL_ERROR")) {
              validate42.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema38.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs44 === errors2;
        valid11 = _valid4;
        if (valid11) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid11) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors2++;
        validate42.errors = vErrors;
        return false;
      }
      var valid0 = _errs37 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate42.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs46 = errors2;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate42.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs46 === errors2) {
          if (data.status !== void 0) {
            let data13 = data.status;
            const _errs47 = errors2;
            if (!(data13 === "loading" || data13 === "ok" || data13 === "stale" || data13 === "unconfigured" || data13 === "unavailable")) {
              validate42.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema38.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid15 = _errs47 === errors2;
          } else {
            var valid15 = true;
          }
          if (valid15) {
            if (data.sourceId !== void 0) {
              let data14 = data.sourceId;
              const _errs48 = errors2;
              const _errs49 = errors2;
              let valid16 = false;
              const _errs50 = errors2;
              if (errors2 === _errs50) {
                if (typeof data14 === "string") {
                  if (func1(data14) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors2++;
                  } else {
                    if (func1(data14) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data14)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors2++;
                }
              }
              var _valid5 = _errs50 === errors2;
              valid16 = valid16 || _valid5;
              const _errs52 = errors2;
              if (data14 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors2++;
              }
              var _valid5 = _errs52 === errors2;
              valid16 = valid16 || _valid5;
              if (!valid16) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors2++;
                validate42.errors = vErrors;
                return false;
              } else {
                errors2 = _errs49;
                if (vErrors !== null) {
                  if (_errs49) {
                    vErrors.length = _errs49;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid15 = _errs48 === errors2;
            } else {
              var valid15 = true;
            }
            if (valid15) {
              if (data.updatedAt !== void 0) {
                let data15 = data.updatedAt;
                const _errs54 = errors2;
                const _errs55 = errors2;
                let valid17 = false;
                const _errs56 = errors2;
                if (errors2 === _errs56) {
                  if (errors2 === _errs56) {
                    if (typeof data15 === "string") {
                      if (func1(data15) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data15)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid6 = _errs56 === errors2;
                valid17 = valid17 || _valid6;
                const _errs58 = errors2;
                if (data15 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors2++;
                }
                var _valid6 = _errs58 === errors2;
                valid17 = valid17 || _valid6;
                if (!valid17) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors2++;
                  validate42.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs55;
                  if (vErrors !== null) {
                    if (_errs55) {
                      vErrors.length = _errs55;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid15 = _errs54 === errors2;
              } else {
                var valid15 = true;
              }
              if (valid15) {
                if (data.data !== void 0) {
                  let data16 = data.data;
                  const _errs60 = errors2;
                  const _errs61 = errors2;
                  let valid18 = false;
                  const _errs62 = errors2;
                  const _errs63 = errors2;
                  if (errors2 === _errs63) {
                    if (data16 && typeof data16 == "object" && !Array.isArray(data16)) {
                      let missing2;
                      if (data16.cpuPercent === void 0 && (missing2 = "cpuPercent") || data16.memoryUsedBytes === void 0 && (missing2 = "memoryUsedBytes") || data16.memoryTotalBytes === void 0 && (missing2 = "memoryTotalBytes") || data16.temperatureC === void 0 && (missing2 = "temperatureC")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors2++;
                      } else {
                        const _errs65 = errors2;
                        for (const key2 in data16) {
                          if (!(key2 === "cpuPercent" || key2 === "memoryUsedBytes" || key2 === "memoryTotalBytes" || key2 === "temperatureC")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs65 === errors2) {
                          if (data16.cpuPercent !== void 0) {
                            let data17 = data16.cpuPercent;
                            const _errs66 = errors2;
                            const _errs67 = errors2;
                            let valid21 = false;
                            const _errs68 = errors2;
                            if (errors2 === _errs68) {
                              if (typeof data17 == "number" && isFinite(data17)) {
                                if (data17 > 100 || isNaN(data17)) {
                                  const err27 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors2++;
                                } else {
                                  if (data17 < 0 || isNaN(data17)) {
                                    const err28 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors2++;
                              }
                            }
                            var _valid8 = _errs68 === errors2;
                            valid21 = valid21 || _valid8;
                            const _errs70 = errors2;
                            if (data17 !== null) {
                              const err30 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                              if (vErrors === null) {
                                vErrors = [err30];
                              } else {
                                vErrors.push(err30);
                              }
                              errors2++;
                            }
                            var _valid8 = _errs70 === errors2;
                            valid21 = valid21 || _valid8;
                            if (!valid21) {
                              const err31 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                              if (vErrors === null) {
                                vErrors = [err31];
                              } else {
                                vErrors.push(err31);
                              }
                              errors2++;
                            } else {
                              errors2 = _errs67;
                              if (vErrors !== null) {
                                if (_errs67) {
                                  vErrors.length = _errs67;
                                } else {
                                  vErrors = null;
                                }
                              }
                            }
                            var valid20 = _errs66 === errors2;
                          } else {
                            var valid20 = true;
                          }
                          if (valid20) {
                            if (data16.memoryUsedBytes !== void 0) {
                              let data18 = data16.memoryUsedBytes;
                              const _errs72 = errors2;
                              if (!(typeof data18 == "number" && (!(data18 % 1) && !isNaN(data18)) && isFinite(data18))) {
                                const err32 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors2++;
                              }
                              if (errors2 === _errs72) {
                                if (typeof data18 == "number" && isFinite(data18)) {
                                  if (data18 > 9007199254740991 || isNaN(data18)) {
                                    const err33 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                    if (vErrors === null) {
                                      vErrors = [err33];
                                    } else {
                                      vErrors.push(err33);
                                    }
                                    errors2++;
                                  } else {
                                    if (data18 < 0 || isNaN(data18)) {
                                      const err34 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors2++;
                                    }
                                  }
                                }
                              }
                              var valid20 = _errs72 === errors2;
                            } else {
                              var valid20 = true;
                            }
                            if (valid20) {
                              if (data16.memoryTotalBytes !== void 0) {
                                let data19 = data16.memoryTotalBytes;
                                const _errs74 = errors2;
                                if (!(typeof data19 == "number" && (!(data19 % 1) && !isNaN(data19)) && isFinite(data19))) {
                                  const err35 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors2++;
                                }
                                if (errors2 === _errs74) {
                                  if (typeof data19 == "number" && isFinite(data19)) {
                                    if (data19 > 9007199254740991 || isNaN(data19)) {
                                      const err36 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors2++;
                                    } else {
                                      if (data19 < 0 || isNaN(data19)) {
                                        const err37 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                        if (vErrors === null) {
                                          vErrors = [err37];
                                        } else {
                                          vErrors.push(err37);
                                        }
                                        errors2++;
                                      }
                                    }
                                  }
                                }
                                var valid20 = _errs74 === errors2;
                              } else {
                                var valid20 = true;
                              }
                              if (valid20) {
                                if (data16.temperatureC !== void 0) {
                                  let data20 = data16.temperatureC;
                                  const _errs76 = errors2;
                                  const _errs77 = errors2;
                                  let valid22 = false;
                                  const _errs78 = errors2;
                                  if (!(typeof data20 == "number" && isFinite(data20))) {
                                    const err38 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err38];
                                    } else {
                                      vErrors.push(err38);
                                    }
                                    errors2++;
                                  }
                                  var _valid9 = _errs78 === errors2;
                                  valid22 = valid22 || _valid9;
                                  const _errs80 = errors2;
                                  if (data20 !== null) {
                                    const err39 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err39];
                                    } else {
                                      vErrors.push(err39);
                                    }
                                    errors2++;
                                  }
                                  var _valid9 = _errs80 === errors2;
                                  valid22 = valid22 || _valid9;
                                  if (!valid22) {
                                    const err40 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err40];
                                    } else {
                                      vErrors.push(err40);
                                    }
                                    errors2++;
                                  } else {
                                    errors2 = _errs77;
                                    if (vErrors !== null) {
                                      if (_errs77) {
                                        vErrors.length = _errs77;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid20 = _errs76 === errors2;
                                } else {
                                  var valid20 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err41 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors2++;
                    }
                  }
                  var _valid7 = _errs62 === errors2;
                  valid18 = valid18 || _valid7;
                  const _errs82 = errors2;
                  if (data16 !== null) {
                    const err42 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err42];
                    } else {
                      vErrors.push(err42);
                    }
                    errors2++;
                  }
                  var _valid7 = _errs82 === errors2;
                  valid18 = valid18 || _valid7;
                  if (!valid18) {
                    const err43 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err43];
                    } else {
                      vErrors.push(err43);
                    }
                    errors2++;
                    validate42.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs61;
                    if (vErrors !== null) {
                      if (_errs61) {
                        vErrors.length = _errs61;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid15 = _errs60 === errors2;
                } else {
                  var valid15 = true;
                }
                if (valid15) {
                  if (data.errorCode !== void 0) {
                    let data21 = data.errorCode;
                    const _errs84 = errors2;
                    const _errs85 = errors2;
                    let valid23 = false;
                    const _errs86 = errors2;
                    if (!(data21 === "NETWORK_ERROR" || data21 === "INVALID_DATA" || data21 === "PAYLOAD_TOO_LARGE" || data21 === "EXPANSION_LIMIT" || data21 === "UNSUPPORTED_CALENDAR" || data21 === "UNKNOWN_TIME_ZONE" || data21 === "KEYRING_LOCKED" || data21 === "SECRET_DELETION_FAILED" || data21 === "AUTH_ERROR" || data21 === "RATE_LIMITED" || data21 === "NO_PLAYER" || data21 === "NO_INTERFACE" || data21 === "SERVICE_UNAVAILABLE" || data21 === "INTERNAL_ERROR")) {
                      const err44 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema38.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err44];
                      } else {
                        vErrors.push(err44);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs86 === errors2;
                    valid23 = valid23 || _valid10;
                    const _errs87 = errors2;
                    if (data21 !== null) {
                      const err45 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err45];
                      } else {
                        vErrors.push(err45);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs87 === errors2;
                    valid23 = valid23 || _valid10;
                    if (!valid23) {
                      const err46 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err46];
                      } else {
                        vErrors.push(err46);
                      }
                      errors2++;
                      validate42.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs85;
                      if (vErrors !== null) {
                        if (_errs85) {
                          vErrors.length = _errs85;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid15 = _errs84 === errors2;
                  } else {
                    var valid15 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate42.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate42.errors = vErrors;
  return errors2 === 0;
}
validate42.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var network = validate43;
function validate43(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate43.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.interface === void 0 && (missing0 = "interface") || data1.rxBytesPerSec === void 0 && (missing0 = "rxBytesPerSec") || data1.txBytesPerSec === void 0 && (missing0 = "txBytesPerSec") || data1.history === void 0 && (missing0 = "history")) {
              validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "interface" || key0 === "rxBytesPerSec" || key0 === "txBytesPerSec" || key0 === "history")) {
                  validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.interface !== void 0) {
                  let data2 = data1.interface;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 64) {
                        validate43.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate43.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate43.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.rxBytesPerSec !== void 0) {
                    let data3 = data1.rxBytesPerSec;
                    const _errs12 = errors2;
                    const _errs13 = errors2;
                    let valid6 = false;
                    const _errs14 = errors2;
                    if (errors2 === _errs14) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 < 0 || isNaN(data3)) {
                          const err1 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err1];
                          } else {
                            vErrors.push(err1);
                          }
                          errors2++;
                        }
                      } else {
                        const err2 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err2];
                        } else {
                          vErrors.push(err2);
                        }
                        errors2++;
                      }
                    }
                    var _valid1 = _errs14 === errors2;
                    valid6 = valid6 || _valid1;
                    const _errs16 = errors2;
                    if (data3 !== null) {
                      const err3 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors2++;
                    }
                    var _valid1 = _errs16 === errors2;
                    valid6 = valid6 || _valid1;
                    if (!valid6) {
                      const err4 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err4];
                      } else {
                        vErrors.push(err4);
                      }
                      errors2++;
                      validate43.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs13;
                      if (vErrors !== null) {
                        if (_errs13) {
                          vErrors.length = _errs13;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.txBytesPerSec !== void 0) {
                      let data4 = data1.txBytesPerSec;
                      const _errs18 = errors2;
                      const _errs19 = errors2;
                      let valid7 = false;
                      const _errs20 = errors2;
                      if (errors2 === _errs20) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 < 0 || isNaN(data4)) {
                            const err5 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors2++;
                          }
                        } else {
                          const err6 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors2++;
                        }
                      }
                      var _valid2 = _errs20 === errors2;
                      valid7 = valid7 || _valid2;
                      const _errs22 = errors2;
                      if (data4 !== null) {
                        const err7 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                        if (vErrors === null) {
                          vErrors = [err7];
                        } else {
                          vErrors.push(err7);
                        }
                        errors2++;
                      }
                      var _valid2 = _errs22 === errors2;
                      valid7 = valid7 || _valid2;
                      if (!valid7) {
                        const err8 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors2++;
                        validate43.errors = vErrors;
                        return false;
                      } else {
                        errors2 = _errs19;
                        if (vErrors !== null) {
                          if (_errs19) {
                            vErrors.length = _errs19;
                          } else {
                            vErrors = null;
                          }
                        }
                      }
                      var valid5 = _errs18 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.history !== void 0) {
                        let data5 = data1.history;
                        const _errs24 = errors2;
                        if (errors2 === _errs24) {
                          if (Array.isArray(data5)) {
                            if (data5.length > 60) {
                              validate43.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" }];
                              return false;
                            } else {
                              var valid8 = true;
                              const len0 = data5.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data6 = data5[i0];
                                const _errs26 = errors2;
                                if (errors2 === _errs26) {
                                  if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
                                    let missing1;
                                    if (data6.at === void 0 && (missing1 = "at") || data6.rx === void 0 && (missing1 = "rx") || data6.tx === void 0 && (missing1 = "tx")) {
                                      validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                      return false;
                                    } else {
                                      const _errs28 = errors2;
                                      for (const key1 in data6) {
                                        if (!(key1 === "at" || key1 === "rx" || key1 === "tx")) {
                                          validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs28 === errors2) {
                                        if (data6.at !== void 0) {
                                          let data7 = data6.at;
                                          const _errs29 = errors2;
                                          if (errors2 === _errs29) {
                                            if (errors2 === _errs29) {
                                              if (typeof data7 === "string") {
                                                if (func1(data7) > 64) {
                                                  validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data7)) {
                                                    validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid9 = _errs29 === errors2;
                                        } else {
                                          var valid9 = true;
                                        }
                                        if (valid9) {
                                          if (data6.rx !== void 0) {
                                            let data8 = data6.rx;
                                            const _errs31 = errors2;
                                            if (errors2 === _errs31) {
                                              if (typeof data8 == "number" && isFinite(data8)) {
                                                if (data8 < 0 || isNaN(data8)) {
                                                  validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                  return false;
                                                }
                                              } else {
                                                validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                return false;
                                              }
                                            }
                                            var valid9 = _errs31 === errors2;
                                          } else {
                                            var valid9 = true;
                                          }
                                          if (valid9) {
                                            if (data6.tx !== void 0) {
                                              let data9 = data6.tx;
                                              const _errs33 = errors2;
                                              if (errors2 === _errs33) {
                                                if (typeof data9 == "number" && isFinite(data9)) {
                                                  if (data9 < 0 || isNaN(data9)) {
                                                    validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                    return false;
                                                  }
                                                } else {
                                                  validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                  return false;
                                                }
                                              }
                                              var valid9 = _errs33 === errors2;
                                            } else {
                                              var valid9 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid8 = _errs26 === errors2;
                                if (!valid8) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate43.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs24 === errors2;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data10 = data.updatedAt;
          const _errs35 = errors2;
          if (errors2 === _errs35) {
            if (errors2 === _errs35) {
              if (typeof data10 === "string") {
                if (func1(data10) > 64) {
                  validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data10)) {
                    validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs35 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors2++;
    validate43.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs37 = errors2;
    const _errs38 = errors2;
    let valid10 = true;
    const _errs39 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data11 = data.status;
        if (!(data11 === "unconfigured" || data11 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors2++;
        }
      }
    }
    var _valid3 = _errs39 === errors2;
    errors2 = _errs38;
    if (vErrors !== null) {
      if (_errs38) {
        vErrors.length = _errs38;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs41 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs42 = errors2;
          if (data.data !== null) {
            validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid12 = _errs42 === errors2;
        } else {
          var valid12 = true;
        }
        if (valid12) {
          if (data.updatedAt !== void 0) {
            const _errs44 = errors2;
            if (data.updatedAt !== null) {
              validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid12 = _errs44 === errors2;
          } else {
            var valid12 = true;
          }
        }
      }
      var _valid3 = _errs41 === errors2;
      valid10 = _valid3;
      if (valid10) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid10) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors2++;
      validate43.errors = vErrors;
      return false;
    }
    var valid0 = _errs37 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs46 = errors2;
      const _errs47 = errors2;
      let valid13 = true;
      const _errs48 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data14 = data.status;
          if (!(data14 === "ok" || data14 === "unconfigured" || data14 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors2++;
          }
        }
      }
      var _valid4 = _errs48 === errors2;
      errors2 = _errs47;
      if (vErrors !== null) {
        if (_errs47) {
          vErrors.length = _errs47;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs50 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate43.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs50 === errors2;
        valid13 = _valid4;
        if (valid13) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs53 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data16 = data.errorCode;
            if (!(data16 === "NETWORK_ERROR" || data16 === "INVALID_DATA" || data16 === "PAYLOAD_TOO_LARGE" || data16 === "EXPANSION_LIMIT" || data16 === "UNSUPPORTED_CALENDAR" || data16 === "UNKNOWN_TIME_ZONE" || data16 === "KEYRING_LOCKED" || data16 === "SECRET_DELETION_FAILED" || data16 === "AUTH_ERROR" || data16 === "RATE_LIMITED" || data16 === "NO_PLAYER" || data16 === "NO_INTERFACE" || data16 === "SERVICE_UNAVAILABLE" || data16 === "INTERNAL_ERROR")) {
              validate43.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema41.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs53 === errors2;
        valid13 = _valid4;
        if (valid13) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid13) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors2++;
        validate43.errors = vErrors;
        return false;
      }
      var valid0 = _errs46 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing2;
      if (data.status === void 0 && (missing2 = "status") || data.sourceId === void 0 && (missing2 = "sourceId") || data.updatedAt === void 0 && (missing2 = "updatedAt") || data.data === void 0 && (missing2 = "data") || data.errorCode === void 0 && (missing2 = "errorCode")) {
        validate43.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
        return false;
      } else {
        const _errs55 = errors2;
        for (const key2 in data) {
          if (!(key2 === "status" || key2 === "sourceId" || key2 === "updatedAt" || key2 === "data" || key2 === "errorCode")) {
            validate43.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs55 === errors2) {
          if (data.status !== void 0) {
            let data17 = data.status;
            const _errs56 = errors2;
            if (!(data17 === "loading" || data17 === "ok" || data17 === "stale" || data17 === "unconfigured" || data17 === "unavailable")) {
              validate43.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema41.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid17 = _errs56 === errors2;
          } else {
            var valid17 = true;
          }
          if (valid17) {
            if (data.sourceId !== void 0) {
              let data18 = data.sourceId;
              const _errs57 = errors2;
              const _errs58 = errors2;
              let valid18 = false;
              const _errs59 = errors2;
              if (errors2 === _errs59) {
                if (typeof data18 === "string") {
                  if (func1(data18) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors2++;
                  } else {
                    if (func1(data18) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data18)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors2++;
                }
              }
              var _valid5 = _errs59 === errors2;
              valid18 = valid18 || _valid5;
              const _errs61 = errors2;
              if (data18 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors2++;
              }
              var _valid5 = _errs61 === errors2;
              valid18 = valid18 || _valid5;
              if (!valid18) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors2++;
                validate43.errors = vErrors;
                return false;
              } else {
                errors2 = _errs58;
                if (vErrors !== null) {
                  if (_errs58) {
                    vErrors.length = _errs58;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid17 = _errs57 === errors2;
            } else {
              var valid17 = true;
            }
            if (valid17) {
              if (data.updatedAt !== void 0) {
                let data19 = data.updatedAt;
                const _errs63 = errors2;
                const _errs64 = errors2;
                let valid19 = false;
                const _errs65 = errors2;
                if (errors2 === _errs65) {
                  if (errors2 === _errs65) {
                    if (typeof data19 === "string") {
                      if (func1(data19) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data19)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid6 = _errs65 === errors2;
                valid19 = valid19 || _valid6;
                const _errs67 = errors2;
                if (data19 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors2++;
                }
                var _valid6 = _errs67 === errors2;
                valid19 = valid19 || _valid6;
                if (!valid19) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors2++;
                  validate43.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs64;
                  if (vErrors !== null) {
                    if (_errs64) {
                      vErrors.length = _errs64;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid17 = _errs63 === errors2;
              } else {
                var valid17 = true;
              }
              if (valid17) {
                if (data.data !== void 0) {
                  let data20 = data.data;
                  const _errs69 = errors2;
                  const _errs70 = errors2;
                  let valid20 = false;
                  const _errs71 = errors2;
                  const _errs72 = errors2;
                  if (errors2 === _errs72) {
                    if (data20 && typeof data20 == "object" && !Array.isArray(data20)) {
                      let missing3;
                      if (data20.interface === void 0 && (missing3 = "interface") || data20.rxBytesPerSec === void 0 && (missing3 = "rxBytesPerSec") || data20.txBytesPerSec === void 0 && (missing3 = "txBytesPerSec") || data20.history === void 0 && (missing3 = "history")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors2++;
                      } else {
                        const _errs74 = errors2;
                        for (const key3 in data20) {
                          if (!(key3 === "interface" || key3 === "rxBytesPerSec" || key3 === "txBytesPerSec" || key3 === "history")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs74 === errors2) {
                          if (data20.interface !== void 0) {
                            let data21 = data20.interface;
                            const _errs75 = errors2;
                            if (errors2 === _errs75) {
                              if (typeof data21 === "string") {
                                if (func1(data21) > 64) {
                                  const err27 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors2++;
                                } else {
                                  if (func1(data21) < 1) {
                                    const err28 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors2++;
                              }
                            }
                            var valid22 = _errs75 === errors2;
                          } else {
                            var valid22 = true;
                          }
                          if (valid22) {
                            if (data20.rxBytesPerSec !== void 0) {
                              let data22 = data20.rxBytesPerSec;
                              const _errs77 = errors2;
                              const _errs78 = errors2;
                              let valid23 = false;
                              const _errs79 = errors2;
                              if (errors2 === _errs79) {
                                if (typeof data22 == "number" && isFinite(data22)) {
                                  if (data22 < 0 || isNaN(data22)) {
                                    const err30 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err30];
                                    } else {
                                      vErrors.push(err30);
                                    }
                                    errors2++;
                                  }
                                } else {
                                  const err31 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err31];
                                  } else {
                                    vErrors.push(err31);
                                  }
                                  errors2++;
                                }
                              }
                              var _valid8 = _errs79 === errors2;
                              valid23 = valid23 || _valid8;
                              const _errs81 = errors2;
                              if (data22 !== null) {
                                const err32 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors2++;
                              }
                              var _valid8 = _errs81 === errors2;
                              valid23 = valid23 || _valid8;
                              if (!valid23) {
                                const err33 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err33];
                                } else {
                                  vErrors.push(err33);
                                }
                                errors2++;
                              } else {
                                errors2 = _errs78;
                                if (vErrors !== null) {
                                  if (_errs78) {
                                    vErrors.length = _errs78;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid22 = _errs77 === errors2;
                            } else {
                              var valid22 = true;
                            }
                            if (valid22) {
                              if (data20.txBytesPerSec !== void 0) {
                                let data23 = data20.txBytesPerSec;
                                const _errs83 = errors2;
                                const _errs84 = errors2;
                                let valid24 = false;
                                const _errs85 = errors2;
                                if (errors2 === _errs85) {
                                  if (typeof data23 == "number" && isFinite(data23)) {
                                    if (data23 < 0 || isNaN(data23)) {
                                      const err34 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors2++;
                                    }
                                  } else {
                                    const err35 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err35];
                                    } else {
                                      vErrors.push(err35);
                                    }
                                    errors2++;
                                  }
                                }
                                var _valid9 = _errs85 === errors2;
                                valid24 = valid24 || _valid9;
                                const _errs87 = errors2;
                                if (data23 !== null) {
                                  const err36 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err36];
                                  } else {
                                    vErrors.push(err36);
                                  }
                                  errors2++;
                                }
                                var _valid9 = _errs87 === errors2;
                                valid24 = valid24 || _valid9;
                                if (!valid24) {
                                  const err37 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err37];
                                  } else {
                                    vErrors.push(err37);
                                  }
                                  errors2++;
                                } else {
                                  errors2 = _errs84;
                                  if (vErrors !== null) {
                                    if (_errs84) {
                                      vErrors.length = _errs84;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid22 = _errs83 === errors2;
                              } else {
                                var valid22 = true;
                              }
                              if (valid22) {
                                if (data20.history !== void 0) {
                                  let data24 = data20.history;
                                  const _errs89 = errors2;
                                  if (errors2 === _errs89) {
                                    if (Array.isArray(data24)) {
                                      if (data24.length > 60) {
                                        const err38 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" };
                                        if (vErrors === null) {
                                          vErrors = [err38];
                                        } else {
                                          vErrors.push(err38);
                                        }
                                        errors2++;
                                      } else {
                                        var valid25 = true;
                                        const len1 = data24.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data25 = data24[i1];
                                          const _errs91 = errors2;
                                          if (errors2 === _errs91) {
                                            if (data25 && typeof data25 == "object" && !Array.isArray(data25)) {
                                              let missing4;
                                              if (data25.at === void 0 && (missing4 = "at") || data25.rx === void 0 && (missing4 = "rx") || data25.tx === void 0 && (missing4 = "tx")) {
                                                const err39 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err39];
                                                } else {
                                                  vErrors.push(err39);
                                                }
                                                errors2++;
                                              } else {
                                                const _errs93 = errors2;
                                                for (const key4 in data25) {
                                                  if (!(key4 === "at" || key4 === "rx" || key4 === "tx")) {
                                                    const err40 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err40];
                                                    } else {
                                                      vErrors.push(err40);
                                                    }
                                                    errors2++;
                                                    break;
                                                  }
                                                }
                                                if (_errs93 === errors2) {
                                                  if (data25.at !== void 0) {
                                                    let data26 = data25.at;
                                                    const _errs94 = errors2;
                                                    if (errors2 === _errs94) {
                                                      if (errors2 === _errs94) {
                                                        if (typeof data26 === "string") {
                                                          if (func1(data26) > 64) {
                                                            const err41 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err41];
                                                            } else {
                                                              vErrors.push(err41);
                                                            }
                                                            errors2++;
                                                          } else {
                                                            if (!formats0.validate(data26)) {
                                                              const err42 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err42];
                                                              } else {
                                                                vErrors.push(err42);
                                                              }
                                                              errors2++;
                                                            }
                                                          }
                                                        } else {
                                                          const err43 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err43];
                                                          } else {
                                                            vErrors.push(err43);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                    }
                                                    var valid26 = _errs94 === errors2;
                                                  } else {
                                                    var valid26 = true;
                                                  }
                                                  if (valid26) {
                                                    if (data25.rx !== void 0) {
                                                      let data27 = data25.rx;
                                                      const _errs96 = errors2;
                                                      if (errors2 === _errs96) {
                                                        if (typeof data27 == "number" && isFinite(data27)) {
                                                          if (data27 < 0 || isNaN(data27)) {
                                                            const err44 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                            if (vErrors === null) {
                                                              vErrors = [err44];
                                                            } else {
                                                              vErrors.push(err44);
                                                            }
                                                            errors2++;
                                                          }
                                                        } else {
                                                          const err45 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                          if (vErrors === null) {
                                                            vErrors = [err45];
                                                          } else {
                                                            vErrors.push(err45);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                      var valid26 = _errs96 === errors2;
                                                    } else {
                                                      var valid26 = true;
                                                    }
                                                    if (valid26) {
                                                      if (data25.tx !== void 0) {
                                                        let data28 = data25.tx;
                                                        const _errs98 = errors2;
                                                        if (errors2 === _errs98) {
                                                          if (typeof data28 == "number" && isFinite(data28)) {
                                                            if (data28 < 0 || isNaN(data28)) {
                                                              const err46 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                              if (vErrors === null) {
                                                                vErrors = [err46];
                                                              } else {
                                                                vErrors.push(err46);
                                                              }
                                                              errors2++;
                                                            }
                                                          } else {
                                                            const err47 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err47];
                                                            } else {
                                                              vErrors.push(err47);
                                                            }
                                                            errors2++;
                                                          }
                                                        }
                                                        var valid26 = _errs98 === errors2;
                                                      } else {
                                                        var valid26 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err48 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors2++;
                                            }
                                          }
                                          var valid25 = _errs91 === errors2;
                                          if (!valid25) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err49 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err49];
                                      } else {
                                        vErrors.push(err49);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid22 = _errs89 === errors2;
                                } else {
                                  var valid22 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err50 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err50];
                      } else {
                        vErrors.push(err50);
                      }
                      errors2++;
                    }
                  }
                  var _valid7 = _errs71 === errors2;
                  valid20 = valid20 || _valid7;
                  const _errs100 = errors2;
                  if (data20 !== null) {
                    const err51 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err51];
                    } else {
                      vErrors.push(err51);
                    }
                    errors2++;
                  }
                  var _valid7 = _errs100 === errors2;
                  valid20 = valid20 || _valid7;
                  if (!valid20) {
                    const err52 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err52];
                    } else {
                      vErrors.push(err52);
                    }
                    errors2++;
                    validate43.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs70;
                    if (vErrors !== null) {
                      if (_errs70) {
                        vErrors.length = _errs70;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid17 = _errs69 === errors2;
                } else {
                  var valid17 = true;
                }
                if (valid17) {
                  if (data.errorCode !== void 0) {
                    let data29 = data.errorCode;
                    const _errs102 = errors2;
                    const _errs103 = errors2;
                    let valid27 = false;
                    const _errs104 = errors2;
                    if (!(data29 === "NETWORK_ERROR" || data29 === "INVALID_DATA" || data29 === "PAYLOAD_TOO_LARGE" || data29 === "EXPANSION_LIMIT" || data29 === "UNSUPPORTED_CALENDAR" || data29 === "UNKNOWN_TIME_ZONE" || data29 === "KEYRING_LOCKED" || data29 === "SECRET_DELETION_FAILED" || data29 === "AUTH_ERROR" || data29 === "RATE_LIMITED" || data29 === "NO_PLAYER" || data29 === "NO_INTERFACE" || data29 === "SERVICE_UNAVAILABLE" || data29 === "INTERNAL_ERROR")) {
                      const err53 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema41.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err53];
                      } else {
                        vErrors.push(err53);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs104 === errors2;
                    valid27 = valid27 || _valid10;
                    const _errs105 = errors2;
                    if (data29 !== null) {
                      const err54 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err54];
                      } else {
                        vErrors.push(err54);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs105 === errors2;
                    valid27 = valid27 || _valid10;
                    if (!valid27) {
                      const err55 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err55];
                      } else {
                        vErrors.push(err55);
                      }
                      errors2++;
                      validate43.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs103;
                      if (vErrors !== null) {
                        if (_errs103) {
                          vErrors.length = _errs103;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid17 = _errs102 === errors2;
                  } else {
                    var valid17 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate43.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate43.errors = vErrors;
  return errors2 === 0;
}
validate43.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var media = validate44;
function validate44(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate44.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.player === void 0 && (missing0 = "player") || data1.status === void 0 && (missing0 = "status") || data1.title === void 0 && (missing0 = "title") || data1.artist === void 0 && (missing0 = "artist") || data1.artUri === void 0 && (missing0 = "artUri")) {
              validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "player" || key0 === "status" || key0 === "title" || key0 === "artist" || key0 === "artUri")) {
                  validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.player !== void 0) {
                  let data2 = data1.player;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 255) {
                        validate44.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate44.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate44.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.status !== void 0) {
                    let data3 = data1.status;
                    const _errs12 = errors2;
                    if (!(data3 === "playing" || data3 === "paused" || data3 === "stopped")) {
                      validate44.errors = [{ instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" }];
                      return false;
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.title !== void 0) {
                      let data4 = data1.title;
                      const _errs13 = errors2;
                      if (errors2 === _errs13) {
                        if (typeof data4 === "string") {
                          if (func1(data4) > 4096) {
                            validate44.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                            return false;
                          }
                        } else {
                          validate44.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                          return false;
                        }
                      }
                      var valid5 = _errs13 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.artist !== void 0) {
                        let data5 = data1.artist;
                        const _errs15 = errors2;
                        if (errors2 === _errs15) {
                          if (typeof data5 === "string") {
                            if (func1(data5) > 4096) {
                              validate44.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                              return false;
                            }
                          } else {
                            validate44.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                            return false;
                          }
                        }
                        var valid5 = _errs15 === errors2;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.artUri !== void 0) {
                          let data6 = data1.artUri;
                          const _errs17 = errors2;
                          const _errs18 = errors2;
                          let valid6 = false;
                          const _errs19 = errors2;
                          if (errors2 === _errs19) {
                            if (typeof data6 === "string") {
                              if (func1(data6) > 4096) {
                                const err1 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                if (vErrors === null) {
                                  vErrors = [err1];
                                } else {
                                  vErrors.push(err1);
                                }
                                errors2++;
                              } else {
                                if (!pattern11.test(data6)) {
                                  const err2 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors2++;
                                }
                              }
                            } else {
                              const err3 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err3];
                              } else {
                                vErrors.push(err3);
                              }
                              errors2++;
                            }
                          }
                          var _valid1 = _errs19 === errors2;
                          valid6 = valid6 || _valid1;
                          const _errs21 = errors2;
                          if (data6 !== null) {
                            const err4 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err4];
                            } else {
                              vErrors.push(err4);
                            }
                            errors2++;
                          }
                          var _valid1 = _errs21 === errors2;
                          valid6 = valid6 || _valid1;
                          if (!valid6) {
                            const err5 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors2++;
                            validate44.errors = vErrors;
                            return false;
                          } else {
                            errors2 = _errs18;
                            if (vErrors !== null) {
                              if (_errs18) {
                                vErrors.length = _errs18;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid5 = _errs17 === errors2;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data7 = data.updatedAt;
          const _errs23 = errors2;
          if (errors2 === _errs23) {
            if (errors2 === _errs23) {
              if (typeof data7 === "string") {
                if (func1(data7) > 64) {
                  validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data7)) {
                    validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs23 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err6 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err6];
    } else {
      vErrors.push(err6);
    }
    errors2++;
    validate44.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs25 = errors2;
    const _errs26 = errors2;
    let valid7 = true;
    const _errs27 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data8 = data.status;
        if (!(data8 === "unconfigured" || data8 === "unavailable")) {
          const err7 = {};
          if (vErrors === null) {
            vErrors = [err7];
          } else {
            vErrors.push(err7);
          }
          errors2++;
        }
      }
    }
    var _valid2 = _errs27 === errors2;
    errors2 = _errs26;
    if (vErrors !== null) {
      if (_errs26) {
        vErrors.length = _errs26;
      } else {
        vErrors = null;
      }
    }
    if (_valid2) {
      const _errs29 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs30 = errors2;
          if (data.data !== null) {
            validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid9 = _errs30 === errors2;
        } else {
          var valid9 = true;
        }
        if (valid9) {
          if (data.updatedAt !== void 0) {
            const _errs32 = errors2;
            if (data.updatedAt !== null) {
              validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid9 = _errs32 === errors2;
          } else {
            var valid9 = true;
          }
        }
      }
      var _valid2 = _errs29 === errors2;
      valid7 = _valid2;
      if (valid7) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid7) {
      const err8 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors2++;
      validate44.errors = vErrors;
      return false;
    }
    var valid0 = _errs25 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs34 = errors2;
      const _errs35 = errors2;
      let valid10 = true;
      const _errs36 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data11 = data.status;
          if (!(data11 === "ok" || data11 === "unconfigured" || data11 === "loading")) {
            const err9 = {};
            if (vErrors === null) {
              vErrors = [err9];
            } else {
              vErrors.push(err9);
            }
            errors2++;
          }
        }
      }
      var _valid3 = _errs36 === errors2;
      errors2 = _errs35;
      if (vErrors !== null) {
        if (_errs35) {
          vErrors.length = _errs35;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid3) {
        const _errs38 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate44.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid3 = _errs38 === errors2;
        valid10 = _valid3;
        if (valid10) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs41 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data13 = data.errorCode;
            if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
              validate44.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema44.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid3 = _errs41 === errors2;
        valid10 = _valid3;
        if (valid10) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid10) {
        const err10 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err10];
        } else {
          vErrors.push(err10);
        }
        errors2++;
        validate44.errors = vErrors;
        return false;
      }
      var valid0 = _errs34 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate44.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs43 = errors2;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate44.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs43 === errors2) {
          if (data.status !== void 0) {
            let data14 = data.status;
            const _errs44 = errors2;
            if (!(data14 === "loading" || data14 === "ok" || data14 === "stale" || data14 === "unconfigured" || data14 === "unavailable")) {
              validate44.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema44.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid14 = _errs44 === errors2;
          } else {
            var valid14 = true;
          }
          if (valid14) {
            if (data.sourceId !== void 0) {
              let data15 = data.sourceId;
              const _errs45 = errors2;
              const _errs46 = errors2;
              let valid15 = false;
              const _errs47 = errors2;
              if (errors2 === _errs47) {
                if (typeof data15 === "string") {
                  if (func1(data15) > 128) {
                    const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err11];
                    } else {
                      vErrors.push(err11);
                    }
                    errors2++;
                  } else {
                    if (func1(data15) < 1) {
                      const err12 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data15)) {
                        const err13 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err13];
                        } else {
                          vErrors.push(err13);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err14];
                  } else {
                    vErrors.push(err14);
                  }
                  errors2++;
                }
              }
              var _valid4 = _errs47 === errors2;
              valid15 = valid15 || _valid4;
              const _errs49 = errors2;
              if (data15 !== null) {
                const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err15];
                } else {
                  vErrors.push(err15);
                }
                errors2++;
              }
              var _valid4 = _errs49 === errors2;
              valid15 = valid15 || _valid4;
              if (!valid15) {
                const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err16];
                } else {
                  vErrors.push(err16);
                }
                errors2++;
                validate44.errors = vErrors;
                return false;
              } else {
                errors2 = _errs46;
                if (vErrors !== null) {
                  if (_errs46) {
                    vErrors.length = _errs46;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid14 = _errs45 === errors2;
            } else {
              var valid14 = true;
            }
            if (valid14) {
              if (data.updatedAt !== void 0) {
                let data16 = data.updatedAt;
                const _errs51 = errors2;
                const _errs52 = errors2;
                let valid16 = false;
                const _errs53 = errors2;
                if (errors2 === _errs53) {
                  if (errors2 === _errs53) {
                    if (typeof data16 === "string") {
                      if (func1(data16) > 64) {
                        const err17 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err17];
                        } else {
                          vErrors.push(err17);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data16)) {
                          const err18 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err18];
                          } else {
                            vErrors.push(err18);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err19 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid5 = _errs53 === errors2;
                valid16 = valid16 || _valid5;
                const _errs55 = errors2;
                if (data16 !== null) {
                  const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err20];
                  } else {
                    vErrors.push(err20);
                  }
                  errors2++;
                }
                var _valid5 = _errs55 === errors2;
                valid16 = valid16 || _valid5;
                if (!valid16) {
                  const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err21];
                  } else {
                    vErrors.push(err21);
                  }
                  errors2++;
                  validate44.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs52;
                  if (vErrors !== null) {
                    if (_errs52) {
                      vErrors.length = _errs52;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid14 = _errs51 === errors2;
              } else {
                var valid14 = true;
              }
              if (valid14) {
                if (data.data !== void 0) {
                  let data17 = data.data;
                  const _errs57 = errors2;
                  const _errs58 = errors2;
                  let valid17 = false;
                  const _errs59 = errors2;
                  const _errs60 = errors2;
                  if (errors2 === _errs60) {
                    if (data17 && typeof data17 == "object" && !Array.isArray(data17)) {
                      let missing2;
                      if (data17.player === void 0 && (missing2 = "player") || data17.status === void 0 && (missing2 = "status") || data17.title === void 0 && (missing2 = "title") || data17.artist === void 0 && (missing2 = "artist") || data17.artUri === void 0 && (missing2 = "artUri")) {
                        const err22 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err22];
                        } else {
                          vErrors.push(err22);
                        }
                        errors2++;
                      } else {
                        const _errs62 = errors2;
                        for (const key2 in data17) {
                          if (!(key2 === "player" || key2 === "status" || key2 === "title" || key2 === "artist" || key2 === "artUri")) {
                            const err23 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err23];
                            } else {
                              vErrors.push(err23);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs62 === errors2) {
                          if (data17.player !== void 0) {
                            let data18 = data17.player;
                            const _errs63 = errors2;
                            if (errors2 === _errs63) {
                              if (typeof data18 === "string") {
                                if (func1(data18) > 255) {
                                  const err24 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err24];
                                  } else {
                                    vErrors.push(err24);
                                  }
                                  errors2++;
                                } else {
                                  if (func1(data18) < 1) {
                                    const err25 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err25];
                                    } else {
                                      vErrors.push(err25);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err26 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err26];
                                } else {
                                  vErrors.push(err26);
                                }
                                errors2++;
                              }
                            }
                            var valid19 = _errs63 === errors2;
                          } else {
                            var valid19 = true;
                          }
                          if (valid19) {
                            if (data17.status !== void 0) {
                              let data19 = data17.status;
                              const _errs65 = errors2;
                              if (!(data19 === "playing" || data19 === "paused" || data19 === "stopped")) {
                                const err27 = { instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" };
                                if (vErrors === null) {
                                  vErrors = [err27];
                                } else {
                                  vErrors.push(err27);
                                }
                                errors2++;
                              }
                              var valid19 = _errs65 === errors2;
                            } else {
                              var valid19 = true;
                            }
                            if (valid19) {
                              if (data17.title !== void 0) {
                                let data20 = data17.title;
                                const _errs66 = errors2;
                                if (errors2 === _errs66) {
                                  if (typeof data20 === "string") {
                                    if (func1(data20) > 4096) {
                                      const err28 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err28];
                                      } else {
                                        vErrors.push(err28);
                                      }
                                      errors2++;
                                    }
                                  } else {
                                    const err29 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err29];
                                    } else {
                                      vErrors.push(err29);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid19 = _errs66 === errors2;
                              } else {
                                var valid19 = true;
                              }
                              if (valid19) {
                                if (data17.artist !== void 0) {
                                  let data21 = data17.artist;
                                  const _errs68 = errors2;
                                  if (errors2 === _errs68) {
                                    if (typeof data21 === "string") {
                                      if (func1(data21) > 4096) {
                                        const err30 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err30];
                                        } else {
                                          vErrors.push(err30);
                                        }
                                        errors2++;
                                      }
                                    } else {
                                      const err31 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err31];
                                      } else {
                                        vErrors.push(err31);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid19 = _errs68 === errors2;
                                } else {
                                  var valid19 = true;
                                }
                                if (valid19) {
                                  if (data17.artUri !== void 0) {
                                    let data22 = data17.artUri;
                                    const _errs70 = errors2;
                                    const _errs71 = errors2;
                                    let valid20 = false;
                                    const _errs72 = errors2;
                                    if (errors2 === _errs72) {
                                      if (typeof data22 === "string") {
                                        if (func1(data22) > 4096) {
                                          const err32 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err32];
                                          } else {
                                            vErrors.push(err32);
                                          }
                                          errors2++;
                                        } else {
                                          if (!pattern11.test(data22)) {
                                            const err33 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                            if (vErrors === null) {
                                              vErrors = [err33];
                                            } else {
                                              vErrors.push(err33);
                                            }
                                            errors2++;
                                          }
                                        }
                                      } else {
                                        const err34 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err34];
                                        } else {
                                          vErrors.push(err34);
                                        }
                                        errors2++;
                                      }
                                    }
                                    var _valid7 = _errs72 === errors2;
                                    valid20 = valid20 || _valid7;
                                    const _errs74 = errors2;
                                    if (data22 !== null) {
                                      const err35 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                      if (vErrors === null) {
                                        vErrors = [err35];
                                      } else {
                                        vErrors.push(err35);
                                      }
                                      errors2++;
                                    }
                                    var _valid7 = _errs74 === errors2;
                                    valid20 = valid20 || _valid7;
                                    if (!valid20) {
                                      const err36 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors2++;
                                    } else {
                                      errors2 = _errs71;
                                      if (vErrors !== null) {
                                        if (_errs71) {
                                          vErrors.length = _errs71;
                                        } else {
                                          vErrors = null;
                                        }
                                      }
                                    }
                                    var valid19 = _errs70 === errors2;
                                  } else {
                                    var valid19 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err37 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err37];
                      } else {
                        vErrors.push(err37);
                      }
                      errors2++;
                    }
                  }
                  var _valid6 = _errs59 === errors2;
                  valid17 = valid17 || _valid6;
                  const _errs76 = errors2;
                  if (data17 !== null) {
                    const err38 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err38];
                    } else {
                      vErrors.push(err38);
                    }
                    errors2++;
                  }
                  var _valid6 = _errs76 === errors2;
                  valid17 = valid17 || _valid6;
                  if (!valid17) {
                    const err39 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err39];
                    } else {
                      vErrors.push(err39);
                    }
                    errors2++;
                    validate44.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs58;
                    if (vErrors !== null) {
                      if (_errs58) {
                        vErrors.length = _errs58;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid14 = _errs57 === errors2;
                } else {
                  var valid14 = true;
                }
                if (valid14) {
                  if (data.errorCode !== void 0) {
                    let data23 = data.errorCode;
                    const _errs78 = errors2;
                    const _errs79 = errors2;
                    let valid21 = false;
                    const _errs80 = errors2;
                    if (!(data23 === "NETWORK_ERROR" || data23 === "INVALID_DATA" || data23 === "PAYLOAD_TOO_LARGE" || data23 === "EXPANSION_LIMIT" || data23 === "UNSUPPORTED_CALENDAR" || data23 === "UNKNOWN_TIME_ZONE" || data23 === "KEYRING_LOCKED" || data23 === "SECRET_DELETION_FAILED" || data23 === "AUTH_ERROR" || data23 === "RATE_LIMITED" || data23 === "NO_PLAYER" || data23 === "NO_INTERFACE" || data23 === "SERVICE_UNAVAILABLE" || data23 === "INTERNAL_ERROR")) {
                      const err40 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema44.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err40];
                      } else {
                        vErrors.push(err40);
                      }
                      errors2++;
                    }
                    var _valid8 = _errs80 === errors2;
                    valid21 = valid21 || _valid8;
                    const _errs81 = errors2;
                    if (data23 !== null) {
                      const err41 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors2++;
                    }
                    var _valid8 = _errs81 === errors2;
                    valid21 = valid21 || _valid8;
                    if (!valid21) {
                      const err42 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err42];
                      } else {
                        vErrors.push(err42);
                      }
                      errors2++;
                      validate44.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs79;
                      if (vErrors !== null) {
                        if (_errs79) {
                          vErrors.length = _errs79;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid14 = _errs78 === errors2;
                  } else {
                    var valid14 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate44.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate44.errors = vErrors;
  return errors2 === 0;
}
validate44.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate46(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate46.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.jobId === void 0 && (missing0 = "jobId") || data.sourceId === void 0 && (missing0 = "sourceId") || data.generation === void 0 && (missing0 = "generation") || data.context === void 0 && (missing0 = "context") || data.now === void 0 && (missing0 = "now")) {
        validate46.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "version" || key0 === "jobId" || key0 === "sourceId" || key0 === "generation" || key0 === "context" || key0 === "now")) {
            validate46.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.version !== void 0) {
            const _errs2 = errors2;
            if (1 !== data.version) {
              validate46.errors = [{ instancePath: instancePath + "/version", schemaPath: "#/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.jobId !== void 0) {
              let data1 = data.jobId;
              const _errs3 = errors2;
              if (errors2 === _errs3) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 128) {
                    validate46.errors = [{ instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate46.errors = [{ instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate46.errors = [{ instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs3 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.sourceId !== void 0) {
                let data2 = data.sourceId;
                const _errs5 = errors2;
                if (errors2 === _errs5) {
                  if (typeof data2 === "string") {
                    if (func1(data2) > 128) {
                      validate46.errors = [{ instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" }];
                      return false;
                    } else {
                      if (func1(data2) < 1) {
                        validate46.errors = [{ instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                        return false;
                      }
                    }
                  } else {
                    validate46.errors = [{ instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
                var valid0 = _errs5 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.generation !== void 0) {
                  let data3 = data.generation;
                  const _errs7 = errors2;
                  if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                    validate46.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                    return false;
                  }
                  if (errors2 === _errs7) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 4294967295 || isNaN(data3)) {
                        validate46.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                        return false;
                      } else {
                        if (data3 < 0 || isNaN(data3)) {
                          validate46.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                          return false;
                        }
                      }
                    }
                  }
                  var valid0 = _errs7 === errors2;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.context !== void 0) {
                    let data4 = data.context;
                    const _errs9 = errors2;
                    const _errs10 = errors2;
                    if (errors2 === _errs10) {
                      if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                        let missing1;
                        if (data4.month === void 0 && (missing1 = "month") || data4.timeZone === void 0 && (missing1 = "timeZone") || data4.weekStart === void 0 && (missing1 = "weekStart")) {
                          validate46.errors = [{ instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                          return false;
                        } else {
                          const _errs12 = errors2;
                          for (const key1 in data4) {
                            if (!(key1 === "month" || key1 === "timeZone" || key1 === "weekStart")) {
                              validate46.errors = [{ instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                              return false;
                              break;
                            }
                          }
                          if (_errs12 === errors2) {
                            if (data4.month !== void 0) {
                              let data5 = data4.month;
                              const _errs13 = errors2;
                              if (errors2 === _errs13) {
                                if (typeof data5 === "string") {
                                  if (func1(data5) > 7) {
                                    validate46.errors = [{ instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                                    return false;
                                  } else {
                                    if (!pattern4.test(data5)) {
                                      validate46.errors = [{ instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                                      return false;
                                    }
                                  }
                                } else {
                                  validate46.errors = [{ instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                  return false;
                                }
                              }
                              var valid2 = _errs13 === errors2;
                            } else {
                              var valid2 = true;
                            }
                            if (valid2) {
                              if (data4.timeZone !== void 0) {
                                let data6 = data4.timeZone;
                                const _errs15 = errors2;
                                if (errors2 === _errs15) {
                                  if (typeof data6 === "string") {
                                    if (func1(data6) > 255) {
                                      validate46.errors = [{ instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                                      return false;
                                    } else {
                                      if (func1(data6) < 1) {
                                        validate46.errors = [{ instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                        return false;
                                      }
                                    }
                                  } else {
                                    validate46.errors = [{ instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                    return false;
                                  }
                                }
                                var valid2 = _errs15 === errors2;
                              } else {
                                var valid2 = true;
                              }
                              if (valid2) {
                                if (data4.weekStart !== void 0) {
                                  let data7 = data4.weekStart;
                                  const _errs17 = errors2;
                                  if (!(typeof data7 == "number" && (!(data7 % 1) && !isNaN(data7)) && isFinite(data7))) {
                                    validate46.errors = [{ instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                    return false;
                                  }
                                  if (errors2 === _errs17) {
                                    if (typeof data7 == "number" && isFinite(data7)) {
                                      if (data7 > 6 || isNaN(data7)) {
                                        validate46.errors = [{ instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                                        return false;
                                      } else {
                                        if (data7 < 0 || isNaN(data7)) {
                                          validate46.errors = [{ instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                          return false;
                                        }
                                      }
                                    }
                                  }
                                  var valid2 = _errs17 === errors2;
                                } else {
                                  var valid2 = true;
                                }
                              }
                            }
                          }
                        }
                      } else {
                        validate46.errors = [{ instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                        return false;
                      }
                    }
                    var valid0 = _errs9 === errors2;
                  } else {
                    var valid0 = true;
                  }
                  if (valid0) {
                    if (data.now !== void 0) {
                      let data8 = data.now;
                      const _errs19 = errors2;
                      if (errors2 === _errs19) {
                        if (errors2 === _errs19) {
                          if (typeof data8 === "string") {
                            if (func1(data8) > 64) {
                              validate46.errors = [{ instancePath: instancePath + "/now", schemaPath: "#/properties/now/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                              return false;
                            } else {
                              if (!formats0.validate(data8)) {
                                validate46.errors = [{ instancePath: instancePath + "/now", schemaPath: "#/properties/now/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                return false;
                              }
                            }
                          } else {
                            validate46.errors = [{ instancePath: instancePath + "/now", schemaPath: "#/properties/now/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                            return false;
                          }
                        }
                      }
                      var valid0 = _errs19 === errors2;
                    } else {
                      var valid0 = true;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate46.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate46.errors = vErrors;
  return errors2 === 0;
}
validate46.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema70 = { "type": "object", "additionalProperties": false, "required": ["version", "state"], "properties": { "version": { "const": 1 }, "state": { "enum": ["ready", "busy"] } } };
function validate47(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate47.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.state === void 0 && (missing0 = "state")) {
        validate47.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "version" || key0 === "state")) {
            validate47.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.version !== void 0) {
            const _errs2 = errors2;
            if (1 !== data.version) {
              validate47.errors = [{ instancePath: instancePath + "/version", schemaPath: "#/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.state !== void 0) {
              let data1 = data.state;
              const _errs3 = errors2;
              if (!(data1 === "ready" || data1 === "busy")) {
                validate47.errors = [{ instancePath: instancePath + "/state", schemaPath: "#/properties/state/enum", keyword: "enum", params: { allowedValues: schema70.properties.state.enum }, message: "must be equal to one of the allowed values" }];
                return false;
              }
              var valid0 = _errs3 === errors2;
            } else {
              var valid0 = true;
            }
          }
        }
      }
    } else {
      validate47.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate47.errors = vErrors;
  return errors2 === 0;
}
validate47.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema71 = { "oneOf": [{ "type": "object", "additionalProperties": false, "required": ["version", "jobId", "sourceId", "generation", "ok", "data"], "properties": { "version": { "const": 1 }, "jobId": { "type": "string", "minLength": 1, "maxLength": 128 }, "sourceId": { "type": "string", "minLength": 1, "maxLength": 128 }, "generation": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "ok": { "const": true }, "data": { "$ref": "urn:liquid-widgets:snapshot:v1#/$defs/CalendarData" } } }, { "type": "object", "additionalProperties": false, "required": ["version", "jobId", "sourceId", "generation", "ok", "errorCode"], "properties": { "version": { "const": 1 }, "jobId": { "type": "string", "minLength": 1, "maxLength": 128 }, "sourceId": { "type": "string", "minLength": 1, "maxLength": 128 }, "generation": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "ok": { "const": false }, "errorCode": { "enum": ["INVALID_DATA", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT"] } } }] };
function validate49(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate49.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.month === void 0 && (missing0 = "month") || data.timeZone === void 0 && (missing0 = "timeZone") || data.weekStart === void 0 && (missing0 = "weekStart") || data.events === void 0 && (missing0 = "events")) {
        validate49.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "month" || key0 === "timeZone" || key0 === "weekStart" || key0 === "events")) {
            validate49.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.month !== void 0) {
            let data0 = data.month;
            const _errs2 = errors2;
            if (errors2 === _errs2) {
              if (typeof data0 === "string") {
                if (func1(data0) > 7) {
                  validate49.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                  return false;
                } else {
                  if (!pattern4.test(data0)) {
                    validate49.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                    return false;
                  }
                }
              } else {
                validate49.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.timeZone !== void 0) {
              let data1 = data.timeZone;
              const _errs4 = errors2;
              if (errors2 === _errs4) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 255) {
                    validate49.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate49.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate49.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs4 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weekStart !== void 0) {
                let data2 = data.weekStart;
                const _errs6 = errors2;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate49.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors2 === _errs6) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 6 || isNaN(data2)) {
                      validate49.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate49.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs6 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.events !== void 0) {
                  let data3 = data.events;
                  const _errs8 = errors2;
                  if (errors2 === _errs8) {
                    if (Array.isArray(data3)) {
                      if (data3.length > 1e4) {
                        validate49.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/maxItems", keyword: "maxItems", params: { limit: 1e4 }, message: "must NOT have more than 10000 items" }];
                        return false;
                      } else {
                        var valid1 = true;
                        const len0 = data3.length;
                        for (let i0 = 0; i0 < len0; i0++) {
                          let data4 = data3[i0];
                          const _errs10 = errors2;
                          const _errs11 = errors2;
                          const _errs14 = errors2;
                          let valid4 = true;
                          const _errs15 = errors2;
                          if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                            if (data4.allDay !== void 0) {
                              if (true !== data4.allDay) {
                                const err0 = {};
                                if (vErrors === null) {
                                  vErrors = [err0];
                                } else {
                                  vErrors.push(err0);
                                }
                                errors2++;
                              }
                            }
                          }
                          var _valid0 = _errs15 === errors2;
                          errors2 = _errs14;
                          if (vErrors !== null) {
                            if (_errs14) {
                              vErrors.length = _errs14;
                            } else {
                              vErrors = null;
                            }
                          }
                          let ifClause0;
                          if (_valid0) {
                            const _errs17 = errors2;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data6 = data4.start;
                                const _errs18 = errors2;
                                if (errors2 === _errs18) {
                                  if (errors2 === _errs18) {
                                    if (typeof data6 === "string") {
                                      if (func1(data6) > 10) {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                        return false;
                                      } else {
                                        if (!formats2.validate(data6)) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid6 = _errs18 === errors2;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.end !== void 0) {
                                  let data7 = data4.end;
                                  const _errs20 = errors2;
                                  if (errors2 === _errs20) {
                                    if (errors2 === _errs20) {
                                      if (typeof data7 === "string") {
                                        if (func1(data7) > 10) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                          return false;
                                        } else {
                                          if (!formats2.validate(data7)) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid6 = _errs20 === errors2;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                            var _valid0 = _errs17 === errors2;
                            valid4 = _valid0;
                            if (valid4) {
                              var props0 = {};
                              props0.start = true;
                              props0.end = true;
                              props0.allDay = true;
                            }
                            ifClause0 = "then";
                          } else {
                            const _errs22 = errors2;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data8 = data4.start;
                                const _errs23 = errors2;
                                if (errors2 === _errs23) {
                                  if (errors2 === _errs23) {
                                    if (typeof data8 === "string") {
                                      if (func1(data8) > 64) {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                        return false;
                                      } else {
                                        if (!formats0.validate(data8)) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid7 = _errs23 === errors2;
                              } else {
                                var valid7 = true;
                              }
                              if (valid7) {
                                if (data4.end !== void 0) {
                                  let data9 = data4.end;
                                  const _errs25 = errors2;
                                  if (errors2 === _errs25) {
                                    if (errors2 === _errs25) {
                                      if (typeof data9 === "string") {
                                        if (func1(data9) > 64) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                          return false;
                                        } else {
                                          if (!formats0.validate(data9)) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid7 = _errs25 === errors2;
                                } else {
                                  var valid7 = true;
                                }
                              }
                            }
                            var _valid0 = _errs22 === errors2;
                            valid4 = _valid0;
                            if (valid4) {
                              if (props0 !== true) {
                                props0 = props0 || {};
                                props0.start = true;
                                props0.end = true;
                              }
                            }
                            ifClause0 = "else";
                          }
                          if (!valid4) {
                            const err1 = { instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/allOf/0/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
                            if (vErrors === null) {
                              vErrors = [err1];
                            } else {
                              vErrors.push(err1);
                            }
                            errors2++;
                            validate49.errors = vErrors;
                            return false;
                          }
                          if (errors2 === _errs11) {
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              let missing1;
                              if (data4.uid === void 0 && (missing1 = "uid") || data4.occurrenceKey === void 0 && (missing1 = "occurrenceKey") || data4.title === void 0 && (missing1 = "title") || data4.start === void 0 && (missing1 = "start") || data4.end === void 0 && (missing1 = "end") || data4.allDay === void 0 && (missing1 = "allDay")) {
                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                return false;
                              } else {
                                const _errs27 = errors2;
                                for (const key1 in data4) {
                                  if (!(key1 === "uid" || key1 === "occurrenceKey" || key1 === "title" || key1 === "start" || key1 === "end" || key1 === "allDay")) {
                                    validate49.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                    return false;
                                    break;
                                  }
                                }
                                if (_errs27 === errors2) {
                                  if (data4.uid !== void 0) {
                                    let data10 = data4.uid;
                                    const _errs28 = errors2;
                                    if (errors2 === _errs28) {
                                      if (typeof data10 === "string") {
                                        if (func1(data10) > 2048) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/maxLength", keyword: "maxLength", params: { limit: 2048 }, message: "must NOT have more than 2048 characters" }];
                                          return false;
                                        } else {
                                          if (func1(data10) < 1) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                    var valid8 = _errs28 === errors2;
                                  } else {
                                    var valid8 = true;
                                  }
                                  if (valid8) {
                                    if (data4.occurrenceKey !== void 0) {
                                      let data11 = data4.occurrenceKey;
                                      const _errs30 = errors2;
                                      if (errors2 === _errs30) {
                                        if (typeof data11 === "string") {
                                          if (func1(data11) > 64) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                            return false;
                                          } else {
                                            if (func1(data11) < 1) {
                                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                              return false;
                                            }
                                          }
                                        } else {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                          return false;
                                        }
                                      }
                                      var valid8 = _errs30 === errors2;
                                    } else {
                                      var valid8 = true;
                                    }
                                    if (valid8) {
                                      if (data4.title !== void 0) {
                                        let data12 = data4.title;
                                        const _errs32 = errors2;
                                        if (errors2 === _errs32) {
                                          if (typeof data12 === "string") {
                                            if (func1(data12) > 4096) {
                                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                                              return false;
                                            }
                                          } else {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                            return false;
                                          }
                                        }
                                        var valid8 = _errs32 === errors2;
                                      } else {
                                        var valid8 = true;
                                      }
                                      if (valid8) {
                                        if (data4.start !== void 0) {
                                          let data13 = data4.start;
                                          const _errs34 = errors2;
                                          if (errors2 === _errs34) {
                                            if (typeof data13 === "string") {
                                              if (func1(data13) > 64) {
                                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                return false;
                                              }
                                            } else {
                                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                              return false;
                                            }
                                          }
                                          var valid8 = _errs34 === errors2;
                                        } else {
                                          var valid8 = true;
                                        }
                                        if (valid8) {
                                          if (data4.end !== void 0) {
                                            let data14 = data4.end;
                                            const _errs36 = errors2;
                                            if (errors2 === _errs36) {
                                              if (typeof data14 === "string") {
                                                if (func1(data14) > 64) {
                                                  validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                }
                                              } else {
                                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                            var valid8 = _errs36 === errors2;
                                          } else {
                                            var valid8 = true;
                                          }
                                          if (valid8) {
                                            if (data4.allDay !== void 0) {
                                              const _errs38 = errors2;
                                              if (typeof data4.allDay !== "boolean") {
                                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/allDay", schemaPath: "#/$defs/CalendarEvent/properties/allDay/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                                                return false;
                                              }
                                              var valid8 = _errs38 === errors2;
                                            } else {
                                              var valid8 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            } else {
                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                              return false;
                            }
                          }
                          var valid1 = _errs10 === errors2;
                          if (!valid1) {
                            break;
                          }
                        }
                      }
                    } else {
                      validate49.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                      return false;
                    }
                  }
                  var valid0 = _errs8 === errors2;
                } else {
                  var valid0 = true;
                }
              }
            }
          }
        }
      }
    } else {
      validate49.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate49.errors = vErrors;
  return errors2 === 0;
}
validate49.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate48(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate48.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs0 = errors2;
  let valid0 = false;
  let passing0 = null;
  const _errs1 = errors2;
  if (errors2 === _errs1) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.jobId === void 0 && (missing0 = "jobId") || data.sourceId === void 0 && (missing0 = "sourceId") || data.generation === void 0 && (missing0 = "generation") || data.ok === void 0 && (missing0 = "ok") || data.data === void 0 && (missing0 = "data")) {
        const err0 = { instancePath, schemaPath: "#/oneOf/0/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" };
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      } else {
        const _errs3 = errors2;
        for (const key0 in data) {
          if (!(key0 === "version" || key0 === "jobId" || key0 === "sourceId" || key0 === "generation" || key0 === "ok" || key0 === "data")) {
            const err1 = { instancePath, schemaPath: "#/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err1];
            } else {
              vErrors.push(err1);
            }
            errors2++;
            break;
          }
        }
        if (_errs3 === errors2) {
          if (data.version !== void 0) {
            const _errs4 = errors2;
            if (1 !== data.version) {
              const err2 = { instancePath: instancePath + "/version", schemaPath: "#/oneOf/0/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" };
              if (vErrors === null) {
                vErrors = [err2];
              } else {
                vErrors.push(err2);
              }
              errors2++;
            }
            var valid1 = _errs4 === errors2;
          } else {
            var valid1 = true;
          }
          if (valid1) {
            if (data.jobId !== void 0) {
              let data1 = data.jobId;
              const _errs5 = errors2;
              if (errors2 === _errs5) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 128) {
                    const err3 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/0/properties/jobId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err3];
                    } else {
                      vErrors.push(err3);
                    }
                    errors2++;
                  } else {
                    if (func1(data1) < 1) {
                      const err4 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/0/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err4];
                      } else {
                        vErrors.push(err4);
                      }
                      errors2++;
                    }
                  }
                } else {
                  const err5 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/0/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err5];
                  } else {
                    vErrors.push(err5);
                  }
                  errors2++;
                }
              }
              var valid1 = _errs5 === errors2;
            } else {
              var valid1 = true;
            }
            if (valid1) {
              if (data.sourceId !== void 0) {
                let data2 = data.sourceId;
                const _errs7 = errors2;
                if (errors2 === _errs7) {
                  if (typeof data2 === "string") {
                    if (func1(data2) > 128) {
                      const err6 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/0/properties/sourceId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                      if (vErrors === null) {
                        vErrors = [err6];
                      } else {
                        vErrors.push(err6);
                      }
                      errors2++;
                    } else {
                      if (func1(data2) < 1) {
                        const err7 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/0/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err7];
                        } else {
                          vErrors.push(err7);
                        }
                        errors2++;
                      }
                    }
                  } else {
                    const err8 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/0/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err8];
                    } else {
                      vErrors.push(err8);
                    }
                    errors2++;
                  }
                }
                var valid1 = _errs7 === errors2;
              } else {
                var valid1 = true;
              }
              if (valid1) {
                if (data.generation !== void 0) {
                  let data3 = data.generation;
                  const _errs9 = errors2;
                  if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                    const err9 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/0/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                    if (vErrors === null) {
                      vErrors = [err9];
                    } else {
                      vErrors.push(err9);
                    }
                    errors2++;
                  }
                  if (errors2 === _errs9) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 4294967295 || isNaN(data3)) {
                        const err10 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/0/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" };
                        if (vErrors === null) {
                          vErrors = [err10];
                        } else {
                          vErrors.push(err10);
                        }
                        errors2++;
                      } else {
                        if (data3 < 0 || isNaN(data3)) {
                          const err11 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/0/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err11];
                          } else {
                            vErrors.push(err11);
                          }
                          errors2++;
                        }
                      }
                    }
                  }
                  var valid1 = _errs9 === errors2;
                } else {
                  var valid1 = true;
                }
                if (valid1) {
                  if (data.ok !== void 0) {
                    const _errs11 = errors2;
                    if (true !== data.ok) {
                      const err12 = { instancePath: instancePath + "/ok", schemaPath: "#/oneOf/0/properties/ok/const", keyword: "const", params: { allowedValue: true }, message: "must be equal to constant" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors2++;
                    }
                    var valid1 = _errs11 === errors2;
                  } else {
                    var valid1 = true;
                  }
                  if (valid1) {
                    if (data.data !== void 0) {
                      const _errs12 = errors2;
                      if (!validate49(data.data, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
                        vErrors = vErrors === null ? validate49.errors : vErrors.concat(validate49.errors);
                        errors2 = vErrors.length;
                      }
                      var valid1 = _errs12 === errors2;
                    } else {
                      var valid1 = true;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      const err13 = { instancePath, schemaPath: "#/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
      if (vErrors === null) {
        vErrors = [err13];
      } else {
        vErrors.push(err13);
      }
      errors2++;
    }
  }
  var _valid0 = _errs1 === errors2;
  if (_valid0) {
    valid0 = true;
    passing0 = 0;
    var props0 = true;
  }
  const _errs13 = errors2;
  if (errors2 === _errs13) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.version === void 0 && (missing1 = "version") || data.jobId === void 0 && (missing1 = "jobId") || data.sourceId === void 0 && (missing1 = "sourceId") || data.generation === void 0 && (missing1 = "generation") || data.ok === void 0 && (missing1 = "ok") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        const err14 = { instancePath, schemaPath: "#/oneOf/1/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" };
        if (vErrors === null) {
          vErrors = [err14];
        } else {
          vErrors.push(err14);
        }
        errors2++;
      } else {
        const _errs15 = errors2;
        for (const key1 in data) {
          if (!(key1 === "version" || key1 === "jobId" || key1 === "sourceId" || key1 === "generation" || key1 === "ok" || key1 === "errorCode")) {
            const err15 = { instancePath, schemaPath: "#/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err15];
            } else {
              vErrors.push(err15);
            }
            errors2++;
            break;
          }
        }
        if (_errs15 === errors2) {
          if (data.version !== void 0) {
            const _errs16 = errors2;
            if (1 !== data.version) {
              const err16 = { instancePath: instancePath + "/version", schemaPath: "#/oneOf/1/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" };
              if (vErrors === null) {
                vErrors = [err16];
              } else {
                vErrors.push(err16);
              }
              errors2++;
            }
            var valid2 = _errs16 === errors2;
          } else {
            var valid2 = true;
          }
          if (valid2) {
            if (data.jobId !== void 0) {
              let data7 = data.jobId;
              const _errs17 = errors2;
              if (errors2 === _errs17) {
                if (typeof data7 === "string") {
                  if (func1(data7) > 128) {
                    const err17 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/1/properties/jobId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors2++;
                  } else {
                    if (func1(data7) < 1) {
                      const err18 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/1/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err18];
                      } else {
                        vErrors.push(err18);
                      }
                      errors2++;
                    }
                  }
                } else {
                  const err19 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/1/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err19];
                  } else {
                    vErrors.push(err19);
                  }
                  errors2++;
                }
              }
              var valid2 = _errs17 === errors2;
            } else {
              var valid2 = true;
            }
            if (valid2) {
              if (data.sourceId !== void 0) {
                let data8 = data.sourceId;
                const _errs19 = errors2;
                if (errors2 === _errs19) {
                  if (typeof data8 === "string") {
                    if (func1(data8) > 128) {
                      const err20 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/1/properties/sourceId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                      if (vErrors === null) {
                        vErrors = [err20];
                      } else {
                        vErrors.push(err20);
                      }
                      errors2++;
                    } else {
                      if (func1(data8) < 1) {
                        const err21 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/1/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err21];
                        } else {
                          vErrors.push(err21);
                        }
                        errors2++;
                      }
                    }
                  } else {
                    const err22 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/1/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err22];
                    } else {
                      vErrors.push(err22);
                    }
                    errors2++;
                  }
                }
                var valid2 = _errs19 === errors2;
              } else {
                var valid2 = true;
              }
              if (valid2) {
                if (data.generation !== void 0) {
                  let data9 = data.generation;
                  const _errs21 = errors2;
                  if (!(typeof data9 == "number" && (!(data9 % 1) && !isNaN(data9)) && isFinite(data9))) {
                    const err23 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/1/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                    if (vErrors === null) {
                      vErrors = [err23];
                    } else {
                      vErrors.push(err23);
                    }
                    errors2++;
                  }
                  if (errors2 === _errs21) {
                    if (typeof data9 == "number" && isFinite(data9)) {
                      if (data9 > 4294967295 || isNaN(data9)) {
                        const err24 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/1/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" };
                        if (vErrors === null) {
                          vErrors = [err24];
                        } else {
                          vErrors.push(err24);
                        }
                        errors2++;
                      } else {
                        if (data9 < 0 || isNaN(data9)) {
                          const err25 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/1/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err25];
                          } else {
                            vErrors.push(err25);
                          }
                          errors2++;
                        }
                      }
                    }
                  }
                  var valid2 = _errs21 === errors2;
                } else {
                  var valid2 = true;
                }
                if (valid2) {
                  if (data.ok !== void 0) {
                    const _errs23 = errors2;
                    if (false !== data.ok) {
                      const err26 = { instancePath: instancePath + "/ok", schemaPath: "#/oneOf/1/properties/ok/const", keyword: "const", params: { allowedValue: false }, message: "must be equal to constant" };
                      if (vErrors === null) {
                        vErrors = [err26];
                      } else {
                        vErrors.push(err26);
                      }
                      errors2++;
                    }
                    var valid2 = _errs23 === errors2;
                  } else {
                    var valid2 = true;
                  }
                  if (valid2) {
                    if (data.errorCode !== void 0) {
                      let data11 = data.errorCode;
                      const _errs24 = errors2;
                      if (!(data11 === "INVALID_DATA" || data11 === "UNSUPPORTED_CALENDAR" || data11 === "UNKNOWN_TIME_ZONE" || data11 === "PAYLOAD_TOO_LARGE" || data11 === "EXPANSION_LIMIT")) {
                        const err27 = { instancePath: instancePath + "/errorCode", schemaPath: "#/oneOf/1/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema71.oneOf[1].properties.errorCode.enum }, message: "must be equal to one of the allowed values" };
                        if (vErrors === null) {
                          vErrors = [err27];
                        } else {
                          vErrors.push(err27);
                        }
                        errors2++;
                      }
                      var valid2 = _errs24 === errors2;
                    } else {
                      var valid2 = true;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      const err28 = { instancePath, schemaPath: "#/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
      if (vErrors === null) {
        vErrors = [err28];
      } else {
        vErrors.push(err28);
      }
      errors2++;
    }
  }
  var _valid0 = _errs13 === errors2;
  if (_valid0 && valid0) {
    valid0 = false;
    passing0 = [passing0, 1];
  } else {
    if (_valid0) {
      valid0 = true;
      passing0 = 1;
      if (props0 !== true) {
        props0 = true;
      }
    }
  }
  if (!valid0) {
    const err29 = { instancePath, schemaPath: "#/oneOf", keyword: "oneOf", params: { passingSchemas: passing0 }, message: "must match exactly one schema in oneOf" };
    if (vErrors === null) {
      vErrors = [err29];
    } else {
      vErrors.push(err29);
    }
    errors2++;
    validate48.errors = vErrors;
    return false;
  } else {
    errors2 = _errs0;
    if (vErrors !== null) {
      if (_errs0) {
        vErrors.length = _errs0;
      } else {
        vErrors = null;
      }
    }
  }
  validate48.errors = vErrors;
  evaluated0.props = props0;
  return errors2 === 0;
}
validate48.evaluated = { "dynamicProps": true, "dynamicItems": false };
var formats76 = /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
var pattern26 = new RegExp("^[^/\\s\\x00-\\x1f]+$", "u");
function validate51(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate51.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.schemaVersion === void 0 && (missing0 = "schemaVersion") || data.revision === void 0 && (missing0 = "revision") || data.calendar === void 0 && (missing0 = "calendar") || data.weather === void 0 && (missing0 = "weather") || data.networkInterface === void 0 && (missing0 = "networkInterface")) {
        validate51.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "schemaVersion" || key0 === "revision" || key0 === "calendar" || key0 === "weather" || key0 === "networkInterface")) {
            validate51.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.schemaVersion !== void 0) {
            const _errs2 = errors2;
            if (1 !== data.schemaVersion) {
              validate51.errors = [{ instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.revision !== void 0) {
              let data1 = data.revision;
              const _errs3 = errors2;
              if (errors2 === _errs3) {
                if (errors2 === _errs3) {
                  if (typeof data1 === "string") {
                    if (!formats76.test(data1)) {
                      validate51.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' }];
                      return false;
                    }
                  } else {
                    validate51.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
              }
              var valid0 = _errs3 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.calendar !== void 0) {
                let data2 = data.calendar;
                const _errs5 = errors2;
                if (errors2 === _errs5) {
                  if (data2 && typeof data2 == "object" && !Array.isArray(data2)) {
                    let missing1;
                    if (data2.sourceId === void 0 && (missing1 = "sourceId") || data2.enabled === void 0 && (missing1 = "enabled") || data2.deletionPending === void 0 && (missing1 = "deletionPending")) {
                      validate51.errors = [{ instancePath: instancePath + "/calendar", schemaPath: "#/properties/calendar/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                      return false;
                    } else {
                      const _errs7 = errors2;
                      for (const key1 in data2) {
                        if (!(key1 === "sourceId" || key1 === "enabled" || key1 === "deletionPending")) {
                          validate51.errors = [{ instancePath: instancePath + "/calendar", schemaPath: "#/properties/calendar/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                          return false;
                          break;
                        }
                      }
                      if (_errs7 === errors2) {
                        if (data2.sourceId !== void 0) {
                          let data3 = data2.sourceId;
                          const _errs8 = errors2;
                          const _errs9 = errors2;
                          let valid2 = false;
                          const _errs10 = errors2;
                          if (errors2 === _errs10) {
                            if (errors2 === _errs10) {
                              if (typeof data3 === "string") {
                                if (!formats76.test(data3)) {
                                  const err0 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf/0/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' };
                                  if (vErrors === null) {
                                    vErrors = [err0];
                                  } else {
                                    vErrors.push(err0);
                                  }
                                  errors2++;
                                }
                              } else {
                                const err1 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err1];
                                } else {
                                  vErrors.push(err1);
                                }
                                errors2++;
                              }
                            }
                          }
                          var _valid0 = _errs10 === errors2;
                          valid2 = valid2 || _valid0;
                          const _errs12 = errors2;
                          if (data3 !== null) {
                            const err2 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err2];
                            } else {
                              vErrors.push(err2);
                            }
                            errors2++;
                          }
                          var _valid0 = _errs12 === errors2;
                          valid2 = valid2 || _valid0;
                          if (!valid2) {
                            const err3 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err3];
                            } else {
                              vErrors.push(err3);
                            }
                            errors2++;
                            validate51.errors = vErrors;
                            return false;
                          } else {
                            errors2 = _errs9;
                            if (vErrors !== null) {
                              if (_errs9) {
                                vErrors.length = _errs9;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid1 = _errs8 === errors2;
                        } else {
                          var valid1 = true;
                        }
                        if (valid1) {
                          if (data2.enabled !== void 0) {
                            const _errs14 = errors2;
                            if (typeof data2.enabled !== "boolean") {
                              validate51.errors = [{ instancePath: instancePath + "/calendar/enabled", schemaPath: "#/properties/calendar/properties/enabled/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                              return false;
                            }
                            var valid1 = _errs14 === errors2;
                          } else {
                            var valid1 = true;
                          }
                          if (valid1) {
                            if (data2.deletionPending !== void 0) {
                              const _errs16 = errors2;
                              if (typeof data2.deletionPending !== "boolean") {
                                validate51.errors = [{ instancePath: instancePath + "/calendar/deletionPending", schemaPath: "#/properties/calendar/properties/deletionPending/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                                return false;
                              }
                              var valid1 = _errs16 === errors2;
                            } else {
                              var valid1 = true;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    validate51.errors = [{ instancePath: instancePath + "/calendar", schemaPath: "#/properties/calendar/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                    return false;
                  }
                }
                var valid0 = _errs5 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.weather !== void 0) {
                  let data6 = data.weather;
                  const _errs18 = errors2;
                  if (errors2 === _errs18) {
                    if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
                      let missing2;
                      if (data6.sourceId === void 0 && (missing2 = "sourceId") || data6.location === void 0 && (missing2 = "location")) {
                        validate51.errors = [{ instancePath: instancePath + "/weather", schemaPath: "#/properties/weather/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
                        return false;
                      } else {
                        const _errs20 = errors2;
                        for (const key2 in data6) {
                          if (!(key2 === "sourceId" || key2 === "location")) {
                            validate51.errors = [{ instancePath: instancePath + "/weather", schemaPath: "#/properties/weather/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
                            return false;
                            break;
                          }
                        }
                        if (_errs20 === errors2) {
                          if (data6.sourceId !== void 0) {
                            let data7 = data6.sourceId;
                            const _errs21 = errors2;
                            const _errs22 = errors2;
                            let valid4 = false;
                            const _errs23 = errors2;
                            if (errors2 === _errs23) {
                              if (errors2 === _errs23) {
                                if (typeof data7 === "string") {
                                  if (!formats76.test(data7)) {
                                    const err4 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf/0/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' };
                                    if (vErrors === null) {
                                      vErrors = [err4];
                                    } else {
                                      vErrors.push(err4);
                                    }
                                    errors2++;
                                  }
                                } else {
                                  const err5 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err5];
                                  } else {
                                    vErrors.push(err5);
                                  }
                                  errors2++;
                                }
                              }
                            }
                            var _valid1 = _errs23 === errors2;
                            valid4 = valid4 || _valid1;
                            const _errs25 = errors2;
                            if (data7 !== null) {
                              const err6 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                              if (vErrors === null) {
                                vErrors = [err6];
                              } else {
                                vErrors.push(err6);
                              }
                              errors2++;
                            }
                            var _valid1 = _errs25 === errors2;
                            valid4 = valid4 || _valid1;
                            if (!valid4) {
                              const err7 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                              if (vErrors === null) {
                                vErrors = [err7];
                              } else {
                                vErrors.push(err7);
                              }
                              errors2++;
                              validate51.errors = vErrors;
                              return false;
                            } else {
                              errors2 = _errs22;
                              if (vErrors !== null) {
                                if (_errs22) {
                                  vErrors.length = _errs22;
                                } else {
                                  vErrors = null;
                                }
                              }
                            }
                            var valid3 = _errs21 === errors2;
                          } else {
                            var valid3 = true;
                          }
                          if (valid3) {
                            if (data6.location !== void 0) {
                              let data8 = data6.location;
                              const _errs27 = errors2;
                              const _errs28 = errors2;
                              let valid5 = false;
                              const _errs29 = errors2;
                              const _errs30 = errors2;
                              if (errors2 === _errs30) {
                                if (data8 && typeof data8 == "object" && !Array.isArray(data8)) {
                                  let missing3;
                                  if (data8.id === void 0 && (missing3 = "id") || data8.label === void 0 && (missing3 = "label") || data8.latitude === void 0 && (missing3 = "latitude") || data8.longitude === void 0 && (missing3 = "longitude") || data8.timeZone === void 0 && (missing3 = "timeZone")) {
                                    const err8 = { instancePath: instancePath + "/weather/location", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors2++;
                                  } else {
                                    const _errs32 = errors2;
                                    for (const key3 in data8) {
                                      if (!(key3 === "id" || key3 === "label" || key3 === "latitude" || key3 === "longitude" || key3 === "timeZone")) {
                                        const err9 = { instancePath: instancePath + "/weather/location", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                                        if (vErrors === null) {
                                          vErrors = [err9];
                                        } else {
                                          vErrors.push(err9);
                                        }
                                        errors2++;
                                        break;
                                      }
                                    }
                                    if (_errs32 === errors2) {
                                      if (data8.id !== void 0) {
                                        let data9 = data8.id;
                                        const _errs33 = errors2;
                                        if (errors2 === _errs33) {
                                          if (typeof data9 === "string") {
                                            if (func1(data9) > 128) {
                                              const err10 = { instancePath: instancePath + "/weather/location/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                                              if (vErrors === null) {
                                                vErrors = [err10];
                                              } else {
                                                vErrors.push(err10);
                                              }
                                              errors2++;
                                            } else {
                                              if (func1(data9) < 1) {
                                                const err11 = { instancePath: instancePath + "/weather/location/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                                if (vErrors === null) {
                                                  vErrors = [err11];
                                                } else {
                                                  vErrors.push(err11);
                                                }
                                                errors2++;
                                              }
                                            }
                                          } else {
                                            const err12 = { instancePath: instancePath + "/weather/location/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                            if (vErrors === null) {
                                              vErrors = [err12];
                                            } else {
                                              vErrors.push(err12);
                                            }
                                            errors2++;
                                          }
                                        }
                                        var valid7 = _errs33 === errors2;
                                      } else {
                                        var valid7 = true;
                                      }
                                      if (valid7) {
                                        if (data8.label !== void 0) {
                                          let data10 = data8.label;
                                          const _errs35 = errors2;
                                          if (errors2 === _errs35) {
                                            if (typeof data10 === "string") {
                                              if (func1(data10) > 512) {
                                                const err13 = { instancePath: instancePath + "/weather/location/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                                if (vErrors === null) {
                                                  vErrors = [err13];
                                                } else {
                                                  vErrors.push(err13);
                                                }
                                                errors2++;
                                              } else {
                                                if (func1(data10) < 1) {
                                                  const err14 = { instancePath: instancePath + "/weather/location/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                                  if (vErrors === null) {
                                                    vErrors = [err14];
                                                  } else {
                                                    vErrors.push(err14);
                                                  }
                                                  errors2++;
                                                }
                                              }
                                            } else {
                                              const err15 = { instancePath: instancePath + "/weather/location/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                              if (vErrors === null) {
                                                vErrors = [err15];
                                              } else {
                                                vErrors.push(err15);
                                              }
                                              errors2++;
                                            }
                                          }
                                          var valid7 = _errs35 === errors2;
                                        } else {
                                          var valid7 = true;
                                        }
                                        if (valid7) {
                                          if (data8.latitude !== void 0) {
                                            let data11 = data8.latitude;
                                            const _errs37 = errors2;
                                            if (errors2 === _errs37) {
                                              if (typeof data11 == "number" && isFinite(data11)) {
                                                if (data11 > 90 || isNaN(data11)) {
                                                  const err16 = { instancePath: instancePath + "/weather/location/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" };
                                                  if (vErrors === null) {
                                                    vErrors = [err16];
                                                  } else {
                                                    vErrors.push(err16);
                                                  }
                                                  errors2++;
                                                } else {
                                                  if (data11 < -90 || isNaN(data11)) {
                                                    const err17 = { instancePath: instancePath + "/weather/location/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" };
                                                    if (vErrors === null) {
                                                      vErrors = [err17];
                                                    } else {
                                                      vErrors.push(err17);
                                                    }
                                                    errors2++;
                                                  }
                                                }
                                              } else {
                                                const err18 = { instancePath: instancePath + "/weather/location/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                if (vErrors === null) {
                                                  vErrors = [err18];
                                                } else {
                                                  vErrors.push(err18);
                                                }
                                                errors2++;
                                              }
                                            }
                                            var valid7 = _errs37 === errors2;
                                          } else {
                                            var valid7 = true;
                                          }
                                          if (valid7) {
                                            if (data8.longitude !== void 0) {
                                              let data12 = data8.longitude;
                                              const _errs39 = errors2;
                                              if (errors2 === _errs39) {
                                                if (typeof data12 == "number" && isFinite(data12)) {
                                                  if (data12 > 180 || isNaN(data12)) {
                                                    const err19 = { instancePath: instancePath + "/weather/location/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" };
                                                    if (vErrors === null) {
                                                      vErrors = [err19];
                                                    } else {
                                                      vErrors.push(err19);
                                                    }
                                                    errors2++;
                                                  } else {
                                                    if (data12 < -180 || isNaN(data12)) {
                                                      const err20 = { instancePath: instancePath + "/weather/location/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" };
                                                      if (vErrors === null) {
                                                        vErrors = [err20];
                                                      } else {
                                                        vErrors.push(err20);
                                                      }
                                                      errors2++;
                                                    }
                                                  }
                                                } else {
                                                  const err21 = { instancePath: instancePath + "/weather/location/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                  if (vErrors === null) {
                                                    vErrors = [err21];
                                                  } else {
                                                    vErrors.push(err21);
                                                  }
                                                  errors2++;
                                                }
                                              }
                                              var valid7 = _errs39 === errors2;
                                            } else {
                                              var valid7 = true;
                                            }
                                            if (valid7) {
                                              if (data8.timeZone !== void 0) {
                                                let data13 = data8.timeZone;
                                                const _errs41 = errors2;
                                                if (errors2 === _errs41) {
                                                  if (typeof data13 === "string") {
                                                    if (func1(data13) > 255) {
                                                      const err22 = { instancePath: instancePath + "/weather/location/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                                      if (vErrors === null) {
                                                        vErrors = [err22];
                                                      } else {
                                                        vErrors.push(err22);
                                                      }
                                                      errors2++;
                                                    } else {
                                                      if (func1(data13) < 1) {
                                                        const err23 = { instancePath: instancePath + "/weather/location/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                                        if (vErrors === null) {
                                                          vErrors = [err23];
                                                        } else {
                                                          vErrors.push(err23);
                                                        }
                                                        errors2++;
                                                      }
                                                    }
                                                  } else {
                                                    const err24 = { instancePath: instancePath + "/weather/location/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                    if (vErrors === null) {
                                                      vErrors = [err24];
                                                    } else {
                                                      vErrors.push(err24);
                                                    }
                                                    errors2++;
                                                  }
                                                }
                                                var valid7 = _errs41 === errors2;
                                              } else {
                                                var valid7 = true;
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                } else {
                                  const err25 = { instancePath: instancePath + "/weather/location", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                  if (vErrors === null) {
                                    vErrors = [err25];
                                  } else {
                                    vErrors.push(err25);
                                  }
                                  errors2++;
                                }
                              }
                              var _valid2 = _errs29 === errors2;
                              valid5 = valid5 || _valid2;
                              const _errs43 = errors2;
                              if (data8 !== null) {
                                const err26 = { instancePath: instancePath + "/weather/location", schemaPath: "#/properties/weather/properties/location/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err26];
                                } else {
                                  vErrors.push(err26);
                                }
                                errors2++;
                              }
                              var _valid2 = _errs43 === errors2;
                              valid5 = valid5 || _valid2;
                              if (!valid5) {
                                const err27 = { instancePath: instancePath + "/weather/location", schemaPath: "#/properties/weather/properties/location/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err27];
                                } else {
                                  vErrors.push(err27);
                                }
                                errors2++;
                                validate51.errors = vErrors;
                                return false;
                              } else {
                                errors2 = _errs28;
                                if (vErrors !== null) {
                                  if (_errs28) {
                                    vErrors.length = _errs28;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid3 = _errs27 === errors2;
                            } else {
                              var valid3 = true;
                            }
                          }
                        }
                      }
                    } else {
                      validate51.errors = [{ instancePath: instancePath + "/weather", schemaPath: "#/properties/weather/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                      return false;
                    }
                  }
                  var valid0 = _errs18 === errors2;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.networkInterface !== void 0) {
                    let data14 = data.networkInterface;
                    const _errs45 = errors2;
                    if (errors2 === _errs45) {
                      if (typeof data14 === "string") {
                        if (func1(data14) > 64) {
                          validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                          return false;
                        } else {
                          if (func1(data14) < 1) {
                            validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          } else {
                            if (!pattern26.test(data14)) {
                              validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/pattern", keyword: "pattern", params: { pattern: "^[^/\\s\\x00-\\x1f]+$" }, message: 'must match pattern "^[^/\\s\\x00-\\x1f]+$"' }];
                              return false;
                            }
                          }
                        }
                      } else {
                        validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid0 = _errs45 === errors2;
                  } else {
                    var valid0 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate51.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate51.errors = vErrors;
  return errors2 === 0;
}
validate51.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema76 = { "$schema": "https://json-schema.org/draft/2020-12/schema", "$id": "urn:liquid-widgets:calendar-status:v1", "type": "object", "additionalProperties": false, "properties": { "version": { "const": 1 }, "instanceId": { "type": "string", "format": "uuid" }, "revision": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "generation": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "context": { "anyOf": [{ "$ref": "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext" }, { "type": "null" }] }, "hasData": { "type": "boolean" }, "eventCount": { "type": "integer", "minimum": 0, "maximum": 1e4 }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "required": ["version", "instanceId", "revision", "generation", "context", "hasData", "eventCount", "sourceId", "status", "updatedAt", "errorCode"] };
var func169 = Object.prototype.hasOwnProperty;
function validate52(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate52.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.instanceId === void 0 && (missing0 = "instanceId") || data.revision === void 0 && (missing0 = "revision") || data.generation === void 0 && (missing0 = "generation") || data.context === void 0 && (missing0 = "context") || data.hasData === void 0 && (missing0 = "hasData") || data.eventCount === void 0 && (missing0 = "eventCount") || data.sourceId === void 0 && (missing0 = "sourceId") || data.status === void 0 && (missing0 = "status") || data.updatedAt === void 0 && (missing0 = "updatedAt") || data.errorCode === void 0 && (missing0 = "errorCode")) {
        validate52.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!func169.call(schema76.properties, key0)) {
            validate52.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.version !== void 0) {
            const _errs2 = errors2;
            if (1 !== data.version) {
              validate52.errors = [{ instancePath: instancePath + "/version", schemaPath: "#/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.instanceId !== void 0) {
              let data1 = data.instanceId;
              const _errs3 = errors2;
              if (errors2 === _errs3) {
                if (errors2 === _errs3) {
                  if (typeof data1 === "string") {
                    if (!formats76.test(data1)) {
                      validate52.errors = [{ instancePath: instancePath + "/instanceId", schemaPath: "#/properties/instanceId/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' }];
                      return false;
                    }
                  } else {
                    validate52.errors = [{ instancePath: instancePath + "/instanceId", schemaPath: "#/properties/instanceId/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
              }
              var valid0 = _errs3 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.revision !== void 0) {
                let data2 = data.revision;
                const _errs5 = errors2;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate52.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors2 === _errs5) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 4294967295 || isNaN(data2)) {
                      validate52.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate52.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs5 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.generation !== void 0) {
                  let data3 = data.generation;
                  const _errs7 = errors2;
                  if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                    validate52.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                    return false;
                  }
                  if (errors2 === _errs7) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 4294967295 || isNaN(data3)) {
                        validate52.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                        return false;
                      } else {
                        if (data3 < 0 || isNaN(data3)) {
                          validate52.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                          return false;
                        }
                      }
                    }
                  }
                  var valid0 = _errs7 === errors2;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.context !== void 0) {
                    let data4 = data.context;
                    const _errs9 = errors2;
                    const _errs10 = errors2;
                    let valid1 = false;
                    const _errs11 = errors2;
                    const _errs12 = errors2;
                    if (errors2 === _errs12) {
                      if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                        let missing1;
                        if (data4.month === void 0 && (missing1 = "month") || data4.timeZone === void 0 && (missing1 = "timeZone") || data4.weekStart === void 0 && (missing1 = "weekStart")) {
                          const err0 = { instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" };
                          if (vErrors === null) {
                            vErrors = [err0];
                          } else {
                            vErrors.push(err0);
                          }
                          errors2++;
                        } else {
                          const _errs14 = errors2;
                          for (const key1 in data4) {
                            if (!(key1 === "month" || key1 === "timeZone" || key1 === "weekStart")) {
                              const err1 = { instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
                              if (vErrors === null) {
                                vErrors = [err1];
                              } else {
                                vErrors.push(err1);
                              }
                              errors2++;
                              break;
                            }
                          }
                          if (_errs14 === errors2) {
                            if (data4.month !== void 0) {
                              let data5 = data4.month;
                              const _errs15 = errors2;
                              if (errors2 === _errs15) {
                                if (typeof data5 === "string") {
                                  if (func1(data5) > 7) {
                                    const err2 = { instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err2];
                                    } else {
                                      vErrors.push(err2);
                                    }
                                    errors2++;
                                  } else {
                                    if (!pattern4.test(data5)) {
                                      const err3 = { instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' };
                                      if (vErrors === null) {
                                        vErrors = [err3];
                                      } else {
                                        vErrors.push(err3);
                                      }
                                      errors2++;
                                    }
                                  }
                                } else {
                                  const err4 = { instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err4];
                                  } else {
                                    vErrors.push(err4);
                                  }
                                  errors2++;
                                }
                              }
                              var valid3 = _errs15 === errors2;
                            } else {
                              var valid3 = true;
                            }
                            if (valid3) {
                              if (data4.timeZone !== void 0) {
                                let data6 = data4.timeZone;
                                const _errs17 = errors2;
                                if (errors2 === _errs17) {
                                  if (typeof data6 === "string") {
                                    if (func1(data6) > 255) {
                                      const err5 = { instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err5];
                                      } else {
                                        vErrors.push(err5);
                                      }
                                      errors2++;
                                    } else {
                                      if (func1(data6) < 1) {
                                        const err6 = { instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err6];
                                        } else {
                                          vErrors.push(err6);
                                        }
                                        errors2++;
                                      }
                                    }
                                  } else {
                                    const err7 = { instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err7];
                                    } else {
                                      vErrors.push(err7);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid3 = _errs17 === errors2;
                              } else {
                                var valid3 = true;
                              }
                              if (valid3) {
                                if (data4.weekStart !== void 0) {
                                  let data7 = data4.weekStart;
                                  const _errs19 = errors2;
                                  if (!(typeof data7 == "number" && (!(data7 % 1) && !isNaN(data7)) && isFinite(data7))) {
                                    const err8 = { instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors2++;
                                  }
                                  if (errors2 === _errs19) {
                                    if (typeof data7 == "number" && isFinite(data7)) {
                                      if (data7 > 6 || isNaN(data7)) {
                                        const err9 = { instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" };
                                        if (vErrors === null) {
                                          vErrors = [err9];
                                        } else {
                                          vErrors.push(err9);
                                        }
                                        errors2++;
                                      } else {
                                        if (data7 < 0 || isNaN(data7)) {
                                          const err10 = { instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                          if (vErrors === null) {
                                            vErrors = [err10];
                                          } else {
                                            vErrors.push(err10);
                                          }
                                          errors2++;
                                        }
                                      }
                                    }
                                  }
                                  var valid3 = _errs19 === errors2;
                                } else {
                                  var valid3 = true;
                                }
                              }
                            }
                          }
                        }
                      } else {
                        const err11 = { instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err11];
                        } else {
                          vErrors.push(err11);
                        }
                        errors2++;
                      }
                    }
                    var _valid0 = _errs11 === errors2;
                    valid1 = valid1 || _valid0;
                    const _errs21 = errors2;
                    if (data4 !== null) {
                      const err12 = { instancePath: instancePath + "/context", schemaPath: "#/properties/context/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors2++;
                    }
                    var _valid0 = _errs21 === errors2;
                    valid1 = valid1 || _valid0;
                    if (!valid1) {
                      const err13 = { instancePath: instancePath + "/context", schemaPath: "#/properties/context/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err13];
                      } else {
                        vErrors.push(err13);
                      }
                      errors2++;
                      validate52.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs10;
                      if (vErrors !== null) {
                        if (_errs10) {
                          vErrors.length = _errs10;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid0 = _errs9 === errors2;
                  } else {
                    var valid0 = true;
                  }
                  if (valid0) {
                    if (data.hasData !== void 0) {
                      const _errs23 = errors2;
                      if (typeof data.hasData !== "boolean") {
                        validate52.errors = [{ instancePath: instancePath + "/hasData", schemaPath: "#/properties/hasData/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                        return false;
                      }
                      var valid0 = _errs23 === errors2;
                    } else {
                      var valid0 = true;
                    }
                    if (valid0) {
                      if (data.eventCount !== void 0) {
                        let data9 = data.eventCount;
                        const _errs25 = errors2;
                        if (!(typeof data9 == "number" && (!(data9 % 1) && !isNaN(data9)) && isFinite(data9))) {
                          validate52.errors = [{ instancePath: instancePath + "/eventCount", schemaPath: "#/properties/eventCount/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                          return false;
                        }
                        if (errors2 === _errs25) {
                          if (typeof data9 == "number" && isFinite(data9)) {
                            if (data9 > 1e4 || isNaN(data9)) {
                              validate52.errors = [{ instancePath: instancePath + "/eventCount", schemaPath: "#/properties/eventCount/maximum", keyword: "maximum", params: { comparison: "<=", limit: 1e4 }, message: "must be <= 10000" }];
                              return false;
                            } else {
                              if (data9 < 0 || isNaN(data9)) {
                                validate52.errors = [{ instancePath: instancePath + "/eventCount", schemaPath: "#/properties/eventCount/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                return false;
                              }
                            }
                          }
                        }
                        var valid0 = _errs25 === errors2;
                      } else {
                        var valid0 = true;
                      }
                      if (valid0) {
                        if (data.sourceId !== void 0) {
                          let data10 = data.sourceId;
                          const _errs27 = errors2;
                          const _errs28 = errors2;
                          let valid4 = false;
                          const _errs29 = errors2;
                          if (errors2 === _errs29) {
                            if (typeof data10 === "string") {
                              if (func1(data10) > 128) {
                                const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                                if (vErrors === null) {
                                  vErrors = [err14];
                                } else {
                                  vErrors.push(err14);
                                }
                                errors2++;
                              } else {
                                if (func1(data10) < 1) {
                                  const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err15];
                                  } else {
                                    vErrors.push(err15);
                                  }
                                  errors2++;
                                } else {
                                  if (!pattern5.test(data10)) {
                                    const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                                    if (vErrors === null) {
                                      vErrors = [err16];
                                    } else {
                                      vErrors.push(err16);
                                    }
                                    errors2++;
                                  }
                                }
                              }
                            } else {
                              const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err17];
                              } else {
                                vErrors.push(err17);
                              }
                              errors2++;
                            }
                          }
                          var _valid1 = _errs29 === errors2;
                          valid4 = valid4 || _valid1;
                          const _errs31 = errors2;
                          if (data10 !== null) {
                            const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err18];
                            } else {
                              vErrors.push(err18);
                            }
                            errors2++;
                          }
                          var _valid1 = _errs31 === errors2;
                          valid4 = valid4 || _valid1;
                          if (!valid4) {
                            const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err19];
                            } else {
                              vErrors.push(err19);
                            }
                            errors2++;
                            validate52.errors = vErrors;
                            return false;
                          } else {
                            errors2 = _errs28;
                            if (vErrors !== null) {
                              if (_errs28) {
                                vErrors.length = _errs28;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid0 = _errs27 === errors2;
                        } else {
                          var valid0 = true;
                        }
                        if (valid0) {
                          if (data.status !== void 0) {
                            let data11 = data.status;
                            const _errs33 = errors2;
                            if (!(data11 === "loading" || data11 === "ok" || data11 === "stale" || data11 === "unconfigured" || data11 === "unavailable")) {
                              validate52.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema76.properties.status.enum }, message: "must be equal to one of the allowed values" }];
                              return false;
                            }
                            var valid0 = _errs33 === errors2;
                          } else {
                            var valid0 = true;
                          }
                          if (valid0) {
                            if (data.updatedAt !== void 0) {
                              let data12 = data.updatedAt;
                              const _errs34 = errors2;
                              const _errs35 = errors2;
                              let valid5 = false;
                              const _errs36 = errors2;
                              if (errors2 === _errs36) {
                                if (errors2 === _errs36) {
                                  if (typeof data12 === "string") {
                                    if (func1(data12) > 64) {
                                      const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err20];
                                      } else {
                                        vErrors.push(err20);
                                      }
                                      errors2++;
                                    } else {
                                      if (!formats0.validate(data12)) {
                                        const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                        if (vErrors === null) {
                                          vErrors = [err21];
                                        } else {
                                          vErrors.push(err21);
                                        }
                                        errors2++;
                                      }
                                    }
                                  } else {
                                    const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err22];
                                    } else {
                                      vErrors.push(err22);
                                    }
                                    errors2++;
                                  }
                                }
                              }
                              var _valid2 = _errs36 === errors2;
                              valid5 = valid5 || _valid2;
                              const _errs38 = errors2;
                              if (data12 !== null) {
                                const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err23];
                                } else {
                                  vErrors.push(err23);
                                }
                                errors2++;
                              }
                              var _valid2 = _errs38 === errors2;
                              valid5 = valid5 || _valid2;
                              if (!valid5) {
                                const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err24];
                                } else {
                                  vErrors.push(err24);
                                }
                                errors2++;
                                validate52.errors = vErrors;
                                return false;
                              } else {
                                errors2 = _errs35;
                                if (vErrors !== null) {
                                  if (_errs35) {
                                    vErrors.length = _errs35;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid0 = _errs34 === errors2;
                            } else {
                              var valid0 = true;
                            }
                            if (valid0) {
                              if (data.errorCode !== void 0) {
                                let data13 = data.errorCode;
                                const _errs40 = errors2;
                                const _errs41 = errors2;
                                let valid6 = false;
                                const _errs42 = errors2;
                                if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
                                  const err25 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema76.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                                  if (vErrors === null) {
                                    vErrors = [err25];
                                  } else {
                                    vErrors.push(err25);
                                  }
                                  errors2++;
                                }
                                var _valid3 = _errs42 === errors2;
                                valid6 = valid6 || _valid3;
                                const _errs43 = errors2;
                                if (data13 !== null) {
                                  const err26 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err26];
                                  } else {
                                    vErrors.push(err26);
                                  }
                                  errors2++;
                                }
                                var _valid3 = _errs43 === errors2;
                                valid6 = valid6 || _valid3;
                                if (!valid6) {
                                  const err27 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors2++;
                                  validate52.errors = vErrors;
                                  return false;
                                } else {
                                  errors2 = _errs41;
                                  if (vErrors !== null) {
                                    if (_errs41) {
                                      vErrors.length = _errs41;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid0 = _errs40 === errors2;
                              } else {
                                var valid0 = true;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate52.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate52.errors = vErrors;
  return errors2 === 0;
}
validate52.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };

// src/shared/validation.ts
var MAX_PAYLOAD_BYTES = 512 * 1024;
var ValidationError = class extends Error {
  constructor() {
    super("Invalid protocol payload");
    this.name = "ValidationError";
  }
};
function parse(input, validate) {
  if (new TextEncoder().encode(input).length > MAX_PAYLOAD_BYTES) throw new ValidationError();
  let value;
  try {
    value = JSON.parse(input);
  } catch {
    throw new ValidationError();
  }
  if (!validate(value)) throw new ValidationError();
  return value;
}
function parseSnapshot(input) {
  return parse(input, snapshot);
}
var providerValidators = { calendar, weather, system, network, media };
function parseProviderState(name, input) {
  if (!Object.hasOwn(providerValidators, name)) throw new ValidationError();
  return parse(input, providerValidators[name]);
}

// src/shared/providerStore.ts
var PROVIDERS = ["calendar", "weather", "system", "network", "media"];
var ProviderStore = class {
  states = {
    calendar: { status: "unconfigured", sourceId: null, updatedAt: null, data: null, errorCode: null },
    weather: { status: "unconfigured", sourceId: null, updatedAt: null, data: null, errorCode: null },
    system: { status: "unavailable", sourceId: null, updatedAt: null, data: null, errorCode: "SERVICE_UNAVAILABLE" },
    network: { status: "unavailable", sourceId: null, updatedAt: null, data: null, errorCode: "SERVICE_UNAVAILABLE" },
    media: { status: "unavailable", sourceId: null, updatedAt: null, data: null, errorCode: "SERVICE_UNAVAILABLE" }
  };
  revisions = /* @__PURE__ */ new Map();
  acceptSnapshot(snapshot2) {
    for (const name of PROVIDERS) this.applyChange(name, snapshot2.revisions[name], snapshot2[name]);
  }
  applyChange(name, revision, state) {
    if (!PROVIDERS.includes(name) || !Number.isInteger(revision) || revision < 0 || revision > 4294967295) throw new ValidationError();
    if (revision <= (this.revisions.get(name) ?? -1)) return false;
    this.states[name] = state;
    this.revisions.set(name, revision);
    return true;
  }
  markRefreshing(name) {
    const state = this.states[name];
    if (state.status !== "unconfigured") this.states[name] = { ...state, status: "loading", errorCode: null };
  }
  // Retain values for the disconnected UI; revision ownership never crosses owners.
  resetOwner() {
    this.revisions.clear();
  }
  get(name) {
    return this.states[name];
  }
};

// src/shared/dataClient.ts
var Cancellation = class {
  cancelled = false;
  listeners = /* @__PURE__ */ new Set();
  onCancel(callback) {
    if (this.cancelled) callback();
    else this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }
  cancel() {
    this.cancelled = true;
    for (const callback of this.listeners) callback();
    this.listeners.clear();
  }
};
var DataClient = class {
  constructor(wire, store, changed, connection) {
    this.wire = wire;
    this.store = store;
    this.changed = changed;
    this.connection = connection;
  }
  wire;
  store;
  changed;
  connection;
  desiredContext = null;
  appliedContext = null;
  contextPump = null;
  providers = [];
  resumePending = false;
  resumeRetries = /* @__PURE__ */ new Map();
  generation = 0;
  retryCancel = null;
  retryDelay = 1e3;
  owner = null;
  unwatch = null;
  unsignal = null;
  token = null;
  cancel = new Cancellation();
  setCalendarContext(context, day) {
    const json = JSON.stringify(context);
    this.desiredContext = { json, day, key: json + day };
    void this.syncContext().catch(() => {
    });
  }
  syncContext() {
    if (this.contextPump) return this.contextPump;
    if (!this.owner || !this.desiredContext || this.appliedContext?.key === this.desiredContext.key) return Promise.resolve();
    const owner = this.owner, generation = this.generation;
    const current = () => owner === this.owner && generation === this.generation;
    const pump = (async () => {
      while (current() && this.desiredContext && this.appliedContext?.key !== this.desiredContext.key) {
        const desired = this.desiredContext, previous = this.appliedContext;
        await this.wire.call(owner, "SetCalendarContext", [desired.json], this.cancel);
        if (!current()) return;
        if (previous && previous.day !== desired.day && this.token) {
          await this.wire.call(owner, "Refresh", ["calendar"], this.cancel).catch(() => {
          });
          if (!current()) return;
        }
        this.appliedContext = desired;
      }
    })();
    this.contextPump = pump;
    void pump.finally(() => {
      if (this.contextPump === pump) this.contextPump = null;
    }).catch(() => {
    });
    return pump;
  }
  refreshAfterResume() {
    this.resumePending = true;
    if (!this.owner || !this.token) return;
    this.resumePending = false;
    const owner = this.owner, generation = this.generation;
    const current = () => this.owner === owner && this.generation === generation;
    for (const name of this.providers.filter((p) => (p === "calendar" || p === "weather") && this.store.get(p).status !== "unconfigured")) {
      this.resumeRetries.get(name)?.();
      this.resumeRetries.delete(name);
      this.store.markRefreshing(name);
      this.changed(name);
      const source = this.store.get(name).sourceId;
      const relevant = () => current() && this.store.get(name).sourceId === source && this.store.get(name).status === "loading";
      const refresh = async () => {
        try {
          await this.wire.call(owner, "Refresh", [name], this.cancel);
        } catch {
          if (relevant()) this.resumeRetries.set(name, this.wire.schedule(6e4, () => {
            this.resumeRetries.delete(name);
            if (relevant()) void refresh();
          }));
        }
      };
      void refresh();
    }
  }
  start(providers) {
    this.stop();
    if (!providers.length || providers.some((p) => !PROVIDERS.includes(p))) throw new Error("Invalid providers");
    this.providers = [...new Set(providers)];
    this.unwatch = this.wire.watchOwner((owner) => {
      this.retryDelay = 1e3;
      void this.connect(owner, [...new Set(providers)]);
    });
  }
  release(owner, token) {
    void this.wire.call(owner, "Unsubscribe", [token], null).catch(() => {
    });
  }
  disconnect() {
    this.retryCancel?.();
    this.retryCancel = null;
    for (const cancel of this.resumeRetries.values()) cancel();
    this.resumeRetries.clear();
    this.appliedContext = null;
    this.contextPump = null;
    this.generation++;
    this.cancel.cancel();
    this.cancel = new Cancellation();
    this.unsignal?.();
    this.unsignal = null;
    if (this.owner && this.token) this.release(this.owner, this.token);
    this.token = null;
    this.owner = null;
    this.store.resetOwner();
  }
  stop() {
    this.resumePending = false;
    this.providers = [];
    this.retryDelay = 1e3;
    this.unwatch?.();
    this.unwatch = null;
    this.disconnect();
    this.connection("disconnected");
  }
  async connect(owner, providers) {
    if (owner && owner === this.owner) return;
    this.disconnect();
    this.owner = owner;
    if (!owner) {
      this.connection("disconnected");
      return;
    }
    const generation = this.generation;
    const current = () => generation === this.generation && owner === this.owner;
    this.connection("connecting");
    this.unsignal = this.wire.watchChanges(owner, (name, revision, payload) => {
      if (!current()) return;
      try {
        const provider = name;
        if (this.store.applyChange(provider, revision, parseProviderState(provider, payload))) {
          this.resumeRetries.get(provider)?.();
          this.resumeRetries.delete(provider);
          this.changed(provider);
        }
      } catch {
        this.connection("invalid-data");
      }
    });
    try {
      if (this.desiredContext) {
        await this.syncContext();
        if (!current()) return;
      }
      const [token] = await this.wire.call(owner, "Subscribe", [providers], null);
      if (typeof token !== "string" || !token || token.length > 128) throw new Error("Invalid subscription");
      if (!current()) {
        this.release(owner, token);
        return;
      }
      this.token = token;
      const [raw] = await this.wire.call(owner, "GetSnapshot", [], this.cancel);
      if (!current()) return;
      if (typeof raw !== "string") throw new Error("Invalid snapshot");
      this.store.acceptSnapshot(parseSnapshot(raw));
      this.retryDelay = 1e3;
      this.changed();
      this.connection("connected");
      if (this.resumePending) this.refreshAfterResume();
    } catch {
      if (current()) {
        this.disconnect();
        this.connection("unavailable");
        const retryGeneration = this.generation;
        const delay = this.retryDelay;
        this.retryDelay = Math.min(3e4, delay * 2);
        this.retryCancel = this.wire.schedule(delay, () => {
          this.retryCancel = null;
          if (this.generation === retryGeneration) void this.connect(owner, providers);
        });
      }
    }
  }
};

// src/dbus.ts
var BUS_NAME = "org.local.LiquidWidgets";
var PATH = "/org/local/LiquidWidgets";
var IFACE = "org.local.LiquidWidgets1";
var signatures = { Subscribe: "(as)", Unsubscribe: "(s)", Refresh: "(s)", SetCalendarContext: "(s)", SetCalendarSecret: "(s)", SearchLocations: "(s)", SetWeatherLocation: "(s)", SetNetworkInterface: "(s)" };
var SessionTransport = class {
  constructor(bus = Gio.DBus.session) {
    this.bus = bus;
  }
  bus;
  schedule(delay, callback) {
    const id = GLib.timeout_add(GLib.PRIORITY_DEFAULT, delay, () => {
      callback();
      return GLib.SOURCE_REMOVE;
    });
    return () => {
      GLib.source_remove(id);
    };
  }
  watchOwner(callback) {
    const id = Gio.bus_watch_name_on_connection(
      this.bus,
      BUS_NAME,
      Gio.BusNameWatcherFlags.NONE,
      (_bus, _name, owner) => callback(owner),
      () => callback(null)
    );
    return () => Gio.bus_unwatch_name(id);
  }
  watchChanges(owner, callback) {
    const id = this.bus.signal_subscribe(
      owner,
      IFACE,
      "ProviderChanged",
      PATH,
      null,
      Gio.DBusSignalFlags.NONE,
      (_bus, _sender, _path, _interface, _signal, parameters) => {
        const [name, revision, payload] = parameters.deep_unpack();
        callback(name, revision, payload);
      }
    );
    return () => this.bus.signal_unsubscribe(id);
  }
  call(owner, method, args, cancel) {
    const cancellable = new Gio.Cancellable();
    const off = cancel?.onCancel(() => cancellable.cancel());
    return new Promise((resolve, reject) => {
      const signature = signatures[method];
      const parameters = signature ? new GLib.Variant(signature, args) : null;
      this.bus.call(
        owner,
        PATH,
        IFACE,
        method,
        parameters,
        null,
        Gio.DBusCallFlags.NO_AUTO_START,
        1e4,
        cancellable,
        (bus, result) => {
          off?.();
          try {
            resolve(bus.call_finish(result).deep_unpack());
          } catch {
            reject(new Error("Service call failed"));
          }
        }
      );
    });
  }
};

// src/data/runtime.ts
import GLib12 from "gi://GLib";
import Gio13 from "gi://Gio";

// src/calendar/statusBridge.ts
import Gio3 from "gi://Gio";
import GLib3 from "gi://GLib";

// src/data/async.ts
import Gio2 from "gi://Gio";
import GLib2 from "gi://GLib";
function gioAsync(start, finish) {
  return new Promise((resolve, reject) => start((_source, result) => {
    try {
      resolve(finish(result));
    } catch (error) {
      reject(error);
    }
  }));
}

// src/calendar/protocol.ts
var CONTROL_LIMIT = 16 * 1024;
var INPUT_LIMIT = 5 * 1024 * 1024;
var REPLY_LIMIT = 512 * 1024;

// src/calendar/workerClient.ts
import Gio6 from "gi://Gio";
import GLib6 from "gi://GLib";

// src/data/busLease.ts
import Gio4 from "gi://Gio";
import GLib4 from "gi://GLib";

// src/calendar/streams.ts
import "gi://Gio";
import GLib5 from "gi://GLib";
function closeStream(stream) {
  return new Promise((resolve) => stream.close_async(GLib5.PRIORITY_DEFAULT, null, (source, result) => {
    try {
      source.close_finish(result);
    } catch {
    }
    resolve();
  }));
}

// src/data/providers/mediaArt.ts
var ART_MAX_BYTES = 8 * 1024 * 1024;

// src/data/mpris.ts
import Gio7 from "gi://Gio";
import GLib7 from "gi://GLib";

// src/data/artworkFiles.ts
import Gio9 from "gi://Gio";
import GLib9 from "gi://GLib";

// src/data/files.ts
import Gio8 from "gi://Gio";
import GLib8 from "gi://GLib";

// editions.json
var editions_default = {
  rust: {
    backend: "rust",
    uuid: "liquid-widgets@local",
    schemaId: "org.gnome.shell.extensions.liquid-widgets",
    schemaPath: "/org/gnome/shell/extensions/liquid-widgets/",
    dataDirectory: "liquid-widgets",
    secretApplication: "org.local.LiquidWidgets",
    output: "dist",
    homepage: "https://github.com/NyongCho/gnome-widget"
  },
  gjs: {
    backend: "gjs",
    uuid: "liquid-widgets@nyongcho.github.io",
    schemaId: "org.gnome.shell.extensions.liquid-widgets-public",
    schemaPath: "/org/gnome/shell/extensions/liquid-widgets-public/",
    dataDirectory: "liquid-widgets-public",
    secretApplication: "io.github.NyongCho.LiquidWidgets",
    output: "dist-gjs",
    homepage: "https://github.com/NyongCho/gnome-widget"
  }
};

// src/edition.ts
function getEdition(name) {
  if (name !== "rust" && name !== "gjs") throw new Error("Unknown edition");
  return editions_default[name];
}
var EDITION = typeof define_LIQUID_EDITION_default === "undefined" ? getEdition("rust") : define_LIQUID_EDITION_default;

// src/data/http.ts
import Soup from "gi://Soup?version=3.0";
import "gi://Gio";

// src/data/secrets.ts
import Gio11 from "gi://Gio";
import GLib10 from "gi://GLib";

// src/data/linux.ts
import Gio12 from "gi://Gio";
import GLib11 from "gi://GLib";

// src/data/providers/system.ts
var U64 = (1n << 64n) - 1n;
var SAFE = BigInt(Number.MAX_SAFE_INTEGER);

// src/data/providers/weather.ts
var LIMITS = { maxBytes: 256 * 1024, timeoutMs: 15e3 };

// src/backend/rust.ts
var RustWidgetSession = class {
  client;
  destroyed = false;
  constructor(transport, options) {
    this.client = new DataClient(transport, options.store, options.changed, options.connection);
  }
  start(providers) {
    if (!this.destroyed) this.client.start(providers);
  }
  stop() {
    if (!this.destroyed) this.client.stop();
  }
  setCalendarContext(context, day) {
    if (!this.destroyed) this.client.setCalendarContext(context, day);
  }
  refreshAfterResume() {
    if (!this.destroyed) this.client.refreshAfterResume();
  }
  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.client.stop();
  }
};

// src/backend/factory.ts
function createWidgetDataSession(options) {
  if (false)
    return createLocalWidgetSession(options);
  return new RustWidgetSession(new SessionTransport(), options);
}

// src/platform/desktopLayer.ts
import Clutter from "gi://Clutter";
import Meta from "gi://Meta";
import * as Main from "resource:///org/gnome/shell/ui/main.js";
var DesktopLayerAdapter = class {
  actor = new Clutter.Actor({ reactive: false, name: "liquid-widgets-layer" });
  restacked;
  sessionChanged;
  overviewShowing;
  overviewHidden;
  constructor() {
    global.window_group.add_child(this.actor);
    this.restacked = global.display.connect("restacked", () => this.restack());
    this.sessionChanged = Main.sessionMode.connect("updated", () => this.updateVisibility());
    this.overviewShowing = Main.overview.connect("showing", () => this.actor.hide());
    this.overviewHidden = Main.overview.connect("hidden", () => this.updateVisibility());
    this.restack();
    this.updateVisibility();
  }
  restack() {
    const children = global.window_group.get_children();
    const desktop = children.filter((actor) => {
      if (!(actor instanceof Meta.WindowActor)) return false;
      const win = actor.meta_window;
      return win?.get_window_type() === Meta.WindowType.DESKTOP || win?.get_gtk_application_id() === "com.rastersoft.ding";
    });
    const topDesktop = children.filter((child) => desktop.includes(child)).at(-1);
    if (topDesktop) global.window_group.set_child_above_sibling(this.actor, topDesktop);
    else {
      const firstWindow = children.find((child) => child instanceof Meta.WindowActor);
      if (firstWindow) global.window_group.set_child_below_sibling(this.actor, firstWindow);
      else global.window_group.set_child_above_sibling(this.actor, null);
    }
  }
  updateVisibility() {
    this.actor.visible = !Main.sessionMode.isLocked && !Main.overview.visible;
  }
  destroy() {
    global.display.disconnect(this.restacked);
    Main.sessionMode.disconnect(this.sessionChanged);
    Main.overview.disconnect(this.overviewShowing);
    Main.overview.disconnect(this.overviewHidden);
    this.actor.destroy();
  }
};

// src/widgets/host.ts
import Clutter11 from "gi://Clutter";
import Gio16 from "gi://Gio";
import St7 from "gi://St";
import Pango3 from "gi://Pango";
import GLib15 from "gi://GLib";

// src/shared/i18n.ts
var messages = {
  "\uC704\uC82F \uB3D9\uAE30\uD654": "Widget synchronization",
  "\uC124\uC815\uCC3D \uC5F0\uACB0 \uD655\uC778": "Connection check in settings",
  "\uC5F0\uACB0 \uC815\uBCF4 \uC800\uC7A5\uB428 \xB7 \uC0C1\uD0DC \uD655\uC778 \uC911": "Connection saved \xB7 Checking status",
  "\uC5F0\uACB0 \uD655\uC778 \uC644\uB8CC \xB7 \uC77C\uC815 {count}\uAC1C": "Connection verified \xB7 {count} events",
  "\uC5F0\uACB0\uC744 \uD655\uC778\uD558\uB294 \uC911\u2026": "Verifying the connection\u2026",
  "\uC5F0\uACB0 \uD655\uC778 \uC911 \xB7 \uB9C8\uC9C0\uB9C9 \uB370\uC774\uD130 \uD45C\uC2DC": "Verifying connection \xB7 Showing last data",
  "{message} \xB7 \uB9C8\uC9C0\uB9C9 \uD655\uC778 \uB370\uC774\uD130 \uD45C\uC2DC": "{message} \xB7 Showing last verified data",
  "\uC124\uC815\uC744 \uC77D\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.": "Could not read settings. Please try again shortly.",
  "\uC67C\uCABD \uC5F4": "Left column",
  "\uC624\uB978\uCABD \uC5F4": "Right column",
  "\uC67C\uCABD \uC5F4\uB85C \uC774\uB3D9": "Move to left column",
  "\uC624\uB978\uCABD \uC5F4\uB85C \uC774\uB3D9": "Move to right column",
  "\uAC01 \uC5F4 \uC548\uC5D0\uC11C \uC21C\uC11C\uB97C \uBC14\uAFB8\uAC70\uB098 \uBC18\uB300\uCABD \uC5F4\uB85C \uC62E\uAE38 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uC74C\uC545\uC740 \uC7AC\uC0DD \uC911\uC77C \uB54C\uB9CC \uD45C\uC2DC\uB429\uB2C8\uB2E4.": "Reorder cards within each column or move them to the other column. Music appears only while playing.",
  "\uC704\uB85C \uC774\uB3D9": "Move up",
  "\uC544\uB798\uB85C \uC774\uB3D9": "Move down",
  "\uC704\xB7\uC544\uB798 \uBC84\uD2BC\uC73C\uB85C \uC21C\uC11C\uB97C \uBC14\uAFC9\uB2C8\uB2E4. \uCE74\uB4DC\uB294 \uC67C\uCABD\uBD80\uD130 \uD55C \uC904\uC5D0 \uB450 \uAC1C\uC529 \uBC30\uCE58\uB429\uB2C8\uB2E4. \uC74C\uC545\uC740 \uC7AC\uC0DD \uC911\uC77C \uB54C\uB9CC \uD45C\uC2DC\uB429\uB2C8\uB2E4.": "Use the up/down buttons to reorder. Cards fill each row from left to right, two per row. Music appears only while playing.",
  "\uC704\uC82F": "Widgets",
  "\uB370\uC774\uD130": "Data",
  "\uC5B8\uC5B4 / Language": "\uC5B8\uC5B4 / Language",
  "\uD45C\uC2DC \uC5B8\uC5B4": "Display language",
  "\uC704\uC82F\uACFC \uC124\uC815\uC5D0 \uBC14\uB85C \uC801\uC6A9\uB429\uB2C8\uB2E4.": "Applies immediately to widgets and settings.",
  "\uD45C\uC2DC\uD560 \uCE74\uB4DC": "Visible cards",
  "\uC74C\uC545\uC740 \uC7AC\uC0DD \uC911\uC77C \uB54C\uB9CC \uD45C\uC2DC\uB429\uB2C8\uB2E4.": "Music appears only while playing.",
  "\uB0A0\uC9DC\uC640 \uC2DC\uACC4": "Date and clock",
  "\uC6D4\uAC04 \uB2EC\uB825": "Monthly calendar",
  "\uB2E4\uAC00\uC624\uB294 \uC77C\uC815": "Upcoming events",
  "\uC2DC\uACC4": "Clock",
  "\uC2DC\uACC4 \uC2A4\uD0C0\uC77C": "Clock style",
  "\uC120\uD0DD\uD55C \uC2A4\uD0C0\uC77C\uC774 \uBC14\uB85C \uC801\uC6A9\uB429\uB2C8\uB2E4.": "The selected style applies immediately.",
  "\uD070 \uB514\uC9C0\uD138": "Large digital",
  "\uC0AC\uAC01 \uB208\uAE08": "Square dial",
  "\uD074\uB798\uC2DD \uC6D0\uD615": "Classic round",
  "\uBBF8\uB2C8\uBA40 \uC544\uB0A0\uB85C\uADF8": "Minimal analog",
  "\uB0A0\uC528": "Weather",
  "\uB124\uD2B8\uC6CC\uD06C": "Network",
  "CPU \xB7 \uBA54\uBAA8\uB9AC \xB7 \uC628\uB3C4": "CPU \xB7 Memory \xB7 Temperature",
  "\uC74C\uC545": "Music",
  "\uC720\uB9AC\uC640 \uD06C\uAE30": "Glass and size",
  "\uC720\uB9AC \uB18D\uB3C4": "Glass tint",
  "\uC720\uB9AC \uB18D\uB3C4\uB97C \uB192\uC774\uBA74 \uBC30\uACBD\uC774 \uB354 \uCC28\uBD84\uD574\uC9D1\uB2C8\uB2E4. \uAE00\uC790 \uB300\uBE44\uB294 \uC790\uB3D9\uC73C\uB85C \uC720\uC9C0\uD569\uB2C8\uB2E4.": "Increase glass tint for a calmer backdrop. Text contrast is maintained automatically.",
  "\uC804\uCCB4 \uD06C\uAE30": "Scale",
  "\uAD74\uC808 \uAC15\uB3C4": "Refraction strength",
  "\uC800\uC804\uB825 \uBAA8\uB4DC": "Low power mode",
  "\uAD74\uC808 \uB300\uC2E0 \uBC18\uD22C\uBA85 \uBC30\uACBD\uC744 \uC0AC\uC6A9\uD569\uB2C8\uB2E4.": "Uses a translucent background instead of refraction.",
  "\uD654\uBA74\uACFC \uC704\uCE58": "Display and position",
  "\uC120\uD0DD\uD55C \uD654\uBA74\uC774 \uC5C6\uC73C\uBA74 \uC8FC \uBAA8\uB2C8\uD130\uC5D0 \uD45C\uC2DC\uD569\uB2C8\uB2E4. \uC5EC\uBC31\uC740 \uC791\uC5C5 \uC601\uC5ED\uC5D0 \uB9DE\uAC8C \uC81C\uD55C\uB429\uB2C8\uB2E4.": "Uses the primary monitor if the selected display is unavailable. Margins stay within the work area.",
  "\uBAA8\uB2C8\uD130": "Monitor",
  "\uC8FC \uBAA8\uB2C8\uD130 (\uC790\uB3D9)": "Primary monitor (automatic)",
  "{monitor} \xB7 \uC5F0\uACB0 \uC548 \uB428 (\uC8FC \uBAA8\uB2C8\uD130\uC5D0 \uD45C\uC2DC)": "{monitor} \xB7 Disconnected (using primary)",
  "\uAE30\uC900 \uC704\uCE58": "Corner",
  "\uC624\uB978\uCABD \uC704": "Top right",
  "\uC67C\uCABD \uC704": "Top left",
  "\uAC00\uB85C \uC5EC\uBC31": "Horizontal margin",
  "\uC138\uB85C \uC5EC\uBC31": "Vertical margin",
  "\uB17C\uB9AC \uD53D\uC140": "Logical pixels",
  "\uC790\uB3D9\uC740 \uAE30\uBCF8 \uACBD\uB85C\uC758 \uBB3C\uB9AC \uC778\uD130\uD398\uC774\uC2A4 \uD558\uB098\uB97C \uC0AC\uC6A9\uD569\uB2C8\uB2E4. Tailscale \uD2B8\uB798\uD53D\uC740 tailscale0\uC744 \uC9C1\uC811 \uC120\uD0DD\uD558\uC138\uC694.": "Automatic uses the physical interface for the default route. Select tailscale0 to show Tailscale traffic.",
  "\uB124\uD2B8\uC6CC\uD06C \uC778\uD130\uD398\uC774\uC2A4": "Network interface",
  "\uC778\uD130\uD398\uC774\uC2A4 \uC801\uC6A9": "Apply interface",
  "\uC800\uC7A5": "Save",
  "\uD604\uC7AC \uC124\uC815\uC744 \uD655\uC778\uD558\uB294 \uC911\u2026": "Loading current settings\u2026",
  "\uC790\uB3D9 (\uAE30\uBCF8 \uACBD\uB85C)": "Automatic (default route)",
  "\uC790\uB3D9": "Automatic",
  "\uC0AC\uC6A9 \uC911: {value}": "In use: {value}",
  "\uB370\uC774\uD130 \uC11C\uBE44\uC2A4\uB97C \uC2DC\uC791\uD55C \uB4A4 \uB2E4\uC2DC \uC5F4\uC5B4 \uC8FC\uC138\uC694.": "Start the data service, then reopen settings.",
  "\uC800\uC7A5\uD558\uB294 \uC911\u2026": "Saving\u2026",
  "\uC800\uC7A5\uD588\uC5B4\uC694. \uC0C8 \uC778\uD130\uD398\uC774\uC2A4\uC758 \uCCAB \uC18D\uB3C4\uB97C \uCE21\uC815\uD569\uB2C8\uB2E4.": "Saved. Measuring the new interface\u2019s initial speed.",
  "\uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.": "Could not save. Please try again.",
  "Google Calendar": "Google Calendar",
  "\uC77D\uAE30 \uC804\uC6A9\uC73C\uB85C \uC5F0\uACB0\uD569\uB2C8\uB2E4. Google Calendar \uC124\uC815 \u2192 \uCE98\uB9B0\uB354 \uD1B5\uD569 \u2192 iCal \uD615\uC2DD\uC758 \uBE44\uACF5\uAC1C \uC8FC\uC18C\uB97C \uC785\uB825\uD558\uC138\uC694.": "Read-only connection. Enter the secret iCal address from Google Calendar settings \u2192 Integrate calendar.",
  "\uC5F0\uACB0 \uC0C1\uD0DC": "Connection status",
  "\uD655\uC778 \uC911\u2026": "Checking\u2026",
  "\uBE44\uACF5\uAC1C iCal \uC8FC\uC18C": "Private iCal address",
  "\uCE98\uB9B0\uB354 \uC5F0\uACB0 \uAD00\uB9AC": "Calendar connection",
  "\uC5F0\uACB0": "Connect",
  "\uC5F0\uACB0 \uD574\uC81C": "Disconnect",
  "\uC8FC\uC18C\uB294 \uC800\uC7A5 \uD6C4 \uB2E4\uC2DC \uD45C\uC2DC\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.": "The address is not shown again after saving.",
  "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C": "Delete connection details",
  "\uCC98\uB9AC \uC911\u2026": "Working\u2026",
  "\uC5F0\uACB0 \uC815\uBCF4\uB97C \uC800\uC7A5\uD588\uC5B4\uC694. \uB3D9\uAE30\uD654 \uACB0\uACFC\uB294 \uC704 \uC5F0\uACB0 \uC0C1\uD0DC\uC5D0 \uD45C\uC2DC\uB429\uB2C8\uB2E4.": "Connection saved. Sync results appear in the connection status above.",
  "\uC77C\uC815\uACFC \uC5F0\uACB0 \uC815\uBCF4\uB97C \uC0AD\uC81C\uD588\uC5B4\uC694.": "Events and connection details deleted.",
  "\uCC98\uB9AC\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC8FC\uC18C \uD615\uC2DD\uACFC \uD0A4\uB9C1 \uC7A0\uAE08\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.": "Could not complete. Check the address format and unlock the keyring.",
  "\uB0A0\uC528 \uC9C0\uC5ED": "Weather location",
  "\uC120\uD0DD\uD55C \uB3C4\uC2DC\uC758 \uD604\uC7AC \uB0A0\uC528\uC640 \uC55E\uC73C\uB85C 6\uC2DC\uAC04 \uC608\uBCF4\uB97C \uD45C\uC2DC\uD569\uB2C8\uB2E4.": "Shows current weather and the next six hours for your city.",
  "\uC120\uD0DD\uD55C \uC9C0\uC5ED": "Selected location",
  "\uD574\uC81C": "Clear",
  "\uB3C4\uC2DC \uC774\uB984": "City name",
  "\uAC80\uC0C9": "Search",
  "\uB450 \uAE00\uC790 \uC774\uC0C1 \uC785\uB825\uD574 \uAC80\uC0C9\uD558\uC138\uC694.": "Enter at least two characters to search.",
  "\uAC80\uC0C9 \uACB0\uACFC": "Search results",
  "\uC9C0\uC5ED\uC744 \uC120\uD0DD\uD558\uC9C0 \uC54A\uC558\uC5B4\uC694.": "No location selected.",
  "\uC9C0\uC5ED\uC744 \uC800\uC7A5\uD558\uB294 \uC911\u2026": "Saving location\u2026",
  "\uC9C0\uC5ED\uC744 \uC120\uD0DD\uD588\uC5B4\uC694. \uB0A0\uC528 \uB3D9\uAE30\uD654\uB97C \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694.": "Location saved. Waiting for weather to sync.",
  "\uC9C0\uC5ED\uC744 \uD574\uC81C\uD588\uC5B4\uC694.": "Location cleared.",
  "\uC9C0\uC5ED\uC744 \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.": "Could not save location. Please try again.",
  "\uB450 \uAE00\uC790 \uC774\uC0C1 \uC785\uB825\uD574 \uC8FC\uC138\uC694.": "Enter at least two characters.",
  "\uB3C4\uC2DC\uB97C \uCC3E\uB294 \uC911\u2026": "Searching for cities\u2026",
  "\uC120\uD0DD": "Select",
  "\uD45C\uC2DC\uD560 \uB3C4\uC2DC\uB97C \uC120\uD0DD\uD558\uC138\uC694.": "Select a city to display.",
  "\uAC80\uC0C9 \uACB0\uACFC\uAC00 \uC5C6\uC5B4\uC694.": "No results found.",
  "\uAC80\uC0C9\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uAE30\uC874 \uC120\uD0DD\uC740 \uC720\uC9C0\uB429\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.": "Search failed. Your previous selection is saved. Please try again shortly.",
  "\uB0A0\uC528 \uB370\uC774\uD130": "Weather data",
  "\uBB34\uB8CC API\uB294 \uAC1C\uC778 \uBE44\uC0C1\uC5C5\uC6A9\uC73C\uB85C \uC0AC\uC6A9\uD569\uB2C8\uB2E4. \uB370\uC774\uD130: CC BY 4.0.": "The free API is for personal, non-commercial use. Data: CC BY 4.0.",
  "\uCD9C\uCC98": "Sources",
  "\uC624\uB298": "Today",
  "\uB2EC\uB825": "Calendar",
  "\uC2DC\uC2A4\uD15C": "System",
  "\uC9C0\uAE08 \uC7AC\uC0DD \uC911": "Now playing",
  "\uC704\uC82F \uC124\uC815": "Widget settings",
  "\uBE0C\uB77C\uC6B0\uC800\uB97C \uC5F4 \uC218 \uC5C6\uC5B4\uC694": "Could not open the browser",
  "\uAD74\uC808 \uBD88\uAC00 \xB7 \uBC18\uD22C\uBA85": "Translucent mode",
  "{date} \xB7 \uC77C\uC815 \uC788\uC74C": "{date} \xB7 Has events",
  "\u2193 \uB2E4\uC6B4\uB85C\uB4DC": "\u2193 Download",
  "\u2191 \uC5C5\uB85C\uB4DC": "\u2191 Upload",
  "\uD45C\uC2DC\uD560 \uB3C4\uC2DC\uB97C \uC120\uD0DD\uD558\uC138\uC694": "Select a city to display",
  "\uC124\uC815\uC5D0\uC11C \uCE98\uB9B0\uB354\uB97C \uC5F0\uACB0\uD558\uC138\uC694": "Connect a calendar",
  "\uC5F0\uACB0\uB418\uBA74 \uC815\uBCF4\uB97C \uD45C\uC2DC\uD574\uC694": "Waiting for connection",
  "\uC608\uC815\uB41C \uC77C\uC815 \uC5C6\uC74C": "No upcoming events",
  "\uC81C\uBAA9 \uC5C6\uB294 \uC77C\uC815": "Untitled event",
  "\uC885\uC77C": "All day",
  "\uB0A0\uC528 \uC2DC\uAC04\uB300\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694": "Check the weather time zone",
  "\uB0A0\uC528 \uC815\uBCF4 \uC5C6\uC74C": "Weather unavailable",
  "\uB9D1\uC74C": "Clear",
  "\uAD6C\uB984 \uC870\uAE08": "Partly cloudy",
  "\uD750\uB9BC": "Overcast",
  "\uC548\uAC1C": "Fog",
  "\uC774\uC2AC\uBE44": "Drizzle",
  "\uBE44": "Rain",
  "\uB208": "Snow",
  "\uB1CC\uC6B0": "Thunderstorm",
  "\uCD5C\uADFC 60\uCD08 \uB124\uD2B8\uC6CC\uD06C \uC18D\uB3C4 \xB7 \uC2E4\uC120 \uB2E4\uC6B4\uB85C\uB4DC, \uC810\uC120 \uC5C5\uB85C\uB4DC": "Network speed over the last 60 seconds \xB7 Solid: download, dashed: upload",
  "\uCE21\uC815 \uC911": "Measuring\u2026",
  "CPU \uCE21\uC815 \uC911": "Measuring CPU\u2026",
  "CPU \uC628\uB3C4 \uC13C\uC11C \uC5C6\uC74C": "CPU temperature sensor unavailable",
  "CPU \uC628\uB3C4  {value}\xB0C": "CPU temperature  {value}\xB0C",
  "\uC81C\uBAA9 \uC5C6\uB294 \uACE1": "Untitled track",
  "\uC544\uD2F0\uC2A4\uD2B8 \uC815\uBCF4 \uC5C6\uC74C": "Unknown artist",
  "\uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694": "Check your connection",
  "\uB370\uC774\uD130\uB97C \uC77D\uC744 \uC218 \uC5C6\uC5B4\uC694": "Could not read the data",
  "\uB370\uC774\uD130\uAC00 \uB108\uBB34 \uCEE4\uC694": "Data is too large",
  "\uC77C\uC815\uC774 \uB108\uBB34 \uB9CE\uC544\uC694": "Too many events",
  "\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uC77C\uC815 \uD615\uC2DD": "Unsupported calendar format",
  "\uC2DC\uAC04\uB300\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694": "Check the time zone",
  "\uD0A4\uB9C1 \uC7A0\uAE08\uC744 \uD574\uC81C\uD574 \uC8FC\uC138\uC694": "Unlock the keyring",
  "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C\uB97C \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694": "Retry deleting connection details",
  "\uCE98\uB9B0\uB354 \uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694": "Check the calendar connection",
  "\uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4": "Retrying shortly",
  "\uC7AC\uC0DD \uC911\uC778 \uC74C\uC545 \uC5C6\uC74C": "No music playing",
  "\uB124\uD2B8\uC6CC\uD06C\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694": "Check the network",
  "\uB370\uC774\uD130\uB97C \uAE30\uB2E4\uB9AC\uB294 \uC911": "Waiting for data",
  "\uB2E4\uC2DC \uC5F0\uACB0\uD558\uB294 \uC911": "Reconnecting",
  "\uB370\uC774\uD130 \uC11C\uBE44\uC2A4 \uC5F0\uACB0 \uB300\uAE30": "Waiting for the data service",
  "\uC5F0\uACB0 \uB04A\uAE40 \xB7 \uB9C8\uC9C0\uB9C9 \uB370\uC774\uD130": "Disconnected \xB7 Last available data",
  "\uC124\uC815\uC774 \uD544\uC694\uD574\uC694": "Setup required",
  "\uC5C5\uB370\uC774\uD2B8 \uC911\u2026": "Updating\u2026",
  "\uB370\uC774\uD130\uB97C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC5B4\uC694": "Data unavailable",
  "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C\uAC00 \uB0A8\uC544 \uC788\uC5B4\uC694. \uD0A4\uB9C1\uC744 \uD574\uC81C\uD558\uACE0 \uB2E4\uC2DC \uC0AD\uC81C\uD574 \uC8FC\uC138\uC694.": "Connection details still need deletion. Unlock the keyring and delete them again.",
  "\uC5F0\uACB0\uD558\uC9C0 \uC54A\uC74C": "Not connected",
  "\uC5F0\uACB0 \uC815\uBCF4 \uC800\uC7A5\uB428 \xB7 \uB370\uC774\uD130 \uC11C\uBE44\uC2A4 \uC5F0\uACB0 \uB300\uAE30": "Connection saved \xB7 Waiting for the data service",
  "\uB3D9\uAE30\uD654 \uC644\uB8CC \xB7 \uD45C\uC2DC \uBC94\uC704\uC758 \uC77C\uC815 {count}\uAC1C": "Synced \xB7 Events in range: {count}",
  "\uC77C\uC815\uC744 \uBD88\uB7EC\uC624\uB294 \uC911\u2026": "Loading events\u2026",
  "\uC77C\uC815 \uAC31\uC2E0 \uC911 \xB7 \uB9C8\uC9C0\uB9C9 \uB3D9\uAE30\uD654 \uB370\uC774\uD130 \uD45C\uC2DC": "Refreshing events \xB7 Showing last synced data",
  "{message} \xB7 \uB9C8\uC9C0\uB9C9 \uB3D9\uAE30\uD654 \uB370\uC774\uD130 \uD45C\uC2DC": "{message} \xB7 Showing last synced data"
};
function language(value) {
  return value === "en" ? "en" : "ko";
}
function localeFor(value) {
  return value === "en" ? "en-US" : "ko-KR";
}
function translate(value, message, values = {}) {
  const template = value === "en" ? messages[message] : message;
  return template.replace(/\{(\w+)\}/g, (original, key) => String(values[key] ?? original));
}

// src/widgets/card.ts
import St from "gi://St";
import Clutter5 from "gi://Clutter";
import Pango from "gi://Pango";

// src/effects/background.ts
import Clutter4 from "gi://Clutter";
import GLib13 from "gi://GLib";

// src/effects/glass.ts
import Clutter2 from "gi://Clutter";
import Cogl from "gi://Cogl";
import GObject from "gi://GObject";
import Graphene from "gi://Graphene";

// shaders/glass.glsl
var glass_default = "uniform float lw_width;\nuniform float lw_height;\nuniform float lw_padding;\nuniform float lw_strength;\nuniform float lw_opacity;\nuniform float lw_tint;\nuniform float lw_dark;\n\nvec3 lw_linear(vec3 c) {\n    return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), c));\n}\nvec3 lw_srgb(vec3 c) {\n    return mix(c * 12.92, 1.055 * pow(max(c, vec3(0.0)), vec3(1.0 / 2.4)) - 0.055,\n               step(vec3(0.0031308), c));\n}\nvec3 lw_material(vec3 color) {\n    float density = clamp((lw_tint - 0.05) / 0.75, 0.0, 1.0);\n    // Retain wallpaper hue; lift dark backgrounds for dark text, and limit\n    // bright backgrounds for light text. Blur alone cannot fix white-on-white.\n    color = mix(color, vec3(lw_dark > 0.5 ? 0.16 : 0.96), 0.025 + density * 0.10);\n    vec3 linear = lw_linear(clamp(color, 0.0, 1.0));\n    float luma = dot(linear, vec3(0.2126, 0.7152, 0.0722));\n    float low = lw_dark > 0.5 ? 0.018 : 0.28 + density * 0.14;\n    float high = lw_dark > 0.5 ? 0.125 - density * 0.035 : 0.95;\n    if (luma > high) linear *= high / max(luma, 0.0001);\n    if (luma < low) linear = mix(linear, vec3(1.0), (low - luma) / max(1.0 - luma, 0.0001));\n    return lw_srgb(linear);\n}\nvec4 lw_glass(sampler2D background, vec2 uv) {\n    vec2 size = vec2(lw_width, lw_height);\n    vec2 halfCard = size * 0.5 - vec2(lw_padding);\n    vec2 p = uv * size - size * 0.5;\n    float radius = min(28.0, min(halfCard.x, halfCard.y));\n    vec2 q = abs(p) - halfCard + vec2(radius);\n    float distance = length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - radius;\n    float coverage = 1.0 - smoothstep(-0.65, 0.65, distance);\n    vec2 outward = q.x > q.y ? vec2(sign(p.x), 0.0) : vec2(0.0, sign(p.y));\n    if (q.x > 0.0 && q.y > 0.0) outward = normalize(q) * sign(p);\n\n    // A flat center with a rounded 20px bevel. The bounded slope keeps the\n    // grazing edge finite; this is a single-boundary screen-space lens.\n    float t = clamp(-distance / 20.0, 0.0, 1.0);\n    float slope = 0.65 * (1.0 - t) / sqrt(max(0.01, 1.0 - (1.0 - t) * (1.0 - t)));\n    vec3 normal = normalize(vec3(outward * slope, 1.0));\n    vec3 ray = refract(vec3(0.0, 0.0, -1.0), normal, 1.0 / 1.45);\n    vec2 offset = ray.xy / max(-ray.z, 0.2) * lw_strength;\n    offset *= min(1.0, 20.0 / max(length(offset), 0.0001));\n    vec2 refracted = uv + offset / size;\n    vec3 color = texture2D(cogl_sampler1, refracted).rgb;\n    // A trace of the original at the rim makes the lens readable without\n    // bringing fine wallpaper detail back into the content area.\n    float edge = 1.0 - smoothstep(0.0, 5.0, -distance);\n    color = mix(color, texture2D(background, refracted).rgb, edge * 0.08);\n    color = lw_material(color);\n\n    float facing = dot(outward, normalize(vec2(-0.65, -1.0)));\n    float rim = 1.0 - smoothstep(0.25, 1.35, abs(distance));\n    float fresnel = pow(1.0 - normal.z, 3.0);\n    float highlight = rim * (0.075 + 0.27 * max(facing, 0.0) + 0.10 * max(-facing, 0.0)) + fresnel * edge * 0.035;\n    color = mix(color, vec3(1.0), highlight);\n    color *= 1.0 - (1.0 - smoothstep(0.0, 3.0, -distance)) * max(-facing, 0.0) * 0.07;\n\n    float shadow = exp(-pow(max(distance, 0.0) / 3.5, 2.0)) * 0.10 * (1.0 - coverage);\n    float alpha = (coverage + shadow) * lw_opacity;\n    return vec4(color * coverage * lw_opacity, alpha);\n}\n";

// shaders/blur.glsl
var blur_default = "uniform float lw_step_x;\nuniform float lw_step_y;\nuniform float lw_sigma;\n\n// Separable Gaussian in input texels. Widening the blur adds samples instead\n// of leaving holes. Read every tap: the downsampled output can lie between\n// input texel centers, where paired-tap offsets would no longer be exact.\nvec4 lw_blur(sampler2D source, vec2 uv) {\n    vec2 stepSize = vec2(lw_step_x, lw_step_y);\n    float radius = ceil(3.0 * lw_sigma);\n    vec4 color = texture2D(source, uv);\n    float total = 1.0;\n    for (float tap = 1.0; tap <= radius; tap += 1.0) {\n        float weight = exp(-0.5 * pow(tap / lw_sigma, 2.0));\n        vec2 offset = stepSize * tap;\n        color += (texture2D(source, uv + offset) + texture2D(source, uv - offset)) * weight;\n        total += 2.0 * weight;\n    }\n    return color / total;\n}\n";

// src/effects/glass.ts
var sharedGlass = null;
var sharedBlur = null;
function snippet(blur) {
  if (blur && sharedBlur) return sharedBlur;
  if (!blur && sharedGlass) return sharedGlass;
  const result = Cogl.Snippet.new(Cogl.SnippetHook.FRAGMENT, blur ? blur_default : glass_default, null);
  result.set_replace(blur ? "cogl_color_out = lw_blur(cogl_sampler0, cogl_tex_coord0_in.xy);" : "cogl_color_out = lw_glass(cogl_sampler0, cogl_tex_coord0_in.xy);");
  if (blur) sharedBlur = result;
  else sharedGlass = result;
  return result;
}
function buffer(context, pixelWidth, pixelHeight, width, height) {
  const texture = Cogl.Texture2D.new_with_size(context, pixelWidth, pixelHeight);
  texture.set_components(Cogl.TextureComponents.RGBA);
  texture.allocate();
  const framebuffer = Cogl.Offscreen.new_with_texture(texture);
  framebuffer.allocate();
  framebuffer.set_viewport(0, 0, pixelWidth, pixelHeight);
  framebuffer.set_modelview_matrix(new Graphene.Matrix().init_identity());
  framebuffer.orthographic(0, 0, width, height, -1, 1);
  return { texture, framebuffer, pixelWidth, pixelHeight };
}
function bind(pipeline, layer, texture) {
  pipeline.set_layer_texture(layer, texture);
  pipeline.set_layer_filters(layer, Cogl.PipelineFilter.LINEAR, Cogl.PipelineFilter.LINEAR);
  pipeline.set_layer_wrap_mode(layer, Cogl.PipelineWrapMode.CLAMP_TO_EDGE);
}
function uniforms(pipeline, values) {
  for (const [name, value] of Object.entries(values))
    pipeline.set_uniform_1f(pipeline.get_uniform_location(name), value);
}
function rectangle(pipeline, width, height) {
  const node = Clutter2.PipelineNode.new(pipeline);
  const box = new Clutter2.ActorBox();
  box.init(0, 0, width, height);
  node.add_rectangle(box);
  return node;
}
var GlassEffect = GObject.registerClass({ GTypeName: "LiquidWidgetsGlassEffect50", Signals: { failed: {} } }, class GlassEffect2 extends Clutter2.Effect {
  failed = false;
  target = null;
  dirty = true;
  strength = 16;
  tint = 0.24;
  dark = true;
  // Maximum 20px refraction + 18px blur support + filtering/AA headroom.
  padding = 40;
  inputPaints = 0;
  blurPaints = 0;
  outputPaints = 0;
  setStrength(value) {
    const strength = Math.max(0, Math.min(20, Number.isFinite(value) ? value : 0));
    if (strength === this.strength) return;
    this.strength = strength;
    this.queue_repaint();
  }
  setMaterial(opacity, dark) {
    const tint = Math.max(0.05, Math.min(0.8, Number.isFinite(opacity) ? opacity : 0.24));
    if (tint === this.tint && dark === this.dark) return;
    this.tint = tint;
    this.dark = dark;
    this.queue_repaint();
  }
  invalidate() {
    this.dirty = true;
    this.queue_repaint();
  }
  release() {
    this.target = null;
    this.dirty = true;
  }
  get textureBytes() {
    return this.target ? [this.target.source, this.target.horizontal, this.target.blurred].reduce((sum, item) => sum + item.pixelWidth * item.pixelHeight * 4, 0) : 0;
  }
  ensureTarget(context, width, height, scale) {
    const pixelWidth = Math.max(1, Math.ceil(width * scale));
    const pixelHeight = Math.max(1, Math.ceil(height * scale));
    if (this.target?.source.pixelWidth === pixelWidth && this.target.source.pixelHeight === pixelHeight && this.target.width === width && this.target.height === height) return this.target;
    this.target = null;
    const source = buffer(context, pixelWidth, pixelHeight, width, height);
    const halfWidth = Math.max(1, Math.ceil(pixelWidth / 2));
    const halfHeight = Math.max(1, Math.ceil(pixelHeight / 2));
    const horizontal = buffer(context, halfWidth, halfHeight, width, height);
    const blurred = buffer(context, halfWidth, halfHeight, width, height);
    const copy = Cogl.Pipeline.new(context);
    const horizontalPass = Cogl.Pipeline.new(context);
    const verticalPass = Cogl.Pipeline.new(context);
    bind(horizontalPass, 0, source.texture);
    bind(verticalPass, 0, horizontal.texture);
    horizontalPass.add_snippet(snippet(true));
    verticalPass.add_snippet(snippet(true));
    uniforms(horizontalPass, { lw_step_x: 1 / pixelWidth, lw_step_y: 0, lw_sigma: 6 * pixelWidth / width });
    uniforms(verticalPass, { lw_step_x: 0, lw_step_y: 1 / halfHeight, lw_sigma: 6 * halfHeight / height });
    const composite = Cogl.Pipeline.new(context);
    bind(composite, 0, source.texture);
    bind(composite, 1, blurred.texture);
    composite.add_snippet(snippet(false));
    this.target = { source, horizontal, blurred, copy, horizontalPass, verticalPass, composite, width, height };
    this.dirty = true;
    return this.target;
  }
  vfunc_paint(node, context, flags) {
    if (this.failed) return;
    const actor = this.get_actor();
    if (!actor || actor.width <= 0 || actor.height <= 0) return;
    if (flags & Clutter2.EffectPaintFlags.BYPASS_EFFECT) {
      node.add_child(Clutter2.ActorNode.new(actor, -1));
      return;
    }
    try {
      const target = this.ensureTarget(context.get_framebuffer().get_context(), actor.width, actor.height, actor.get_resource_scale());
      if (this.dirty || flags & Clutter2.EffectPaintFlags.ACTOR_DIRTY) {
        const input = Clutter2.LayerNode.new_to_framebuffer(target.source.framebuffer, target.copy);
        input.add_child(Clutter2.ActorNode.new(actor, 255));
        node.add_child(input);
        const horizontal = Clutter2.LayerNode.new_to_framebuffer(target.horizontal.framebuffer, target.copy);
        horizontal.add_child(rectangle(target.horizontalPass, actor.width, actor.height));
        node.add_child(horizontal);
        const vertical = Clutter2.LayerNode.new_to_framebuffer(target.blurred.framebuffer, target.copy);
        vertical.add_child(rectangle(target.verticalPass, actor.width, actor.height));
        node.add_child(vertical);
        this.inputPaints++;
        this.blurPaints += 2;
        this.dirty = false;
      }
      uniforms(target.composite, {
        lw_width: actor.width,
        lw_height: actor.height,
        lw_padding: this.padding,
        lw_strength: this.strength,
        lw_opacity: actor.get_paint_opacity() / 255,
        lw_tint: this.tint,
        lw_dark: this.dark ? 1 : 0
      });
      node.add_child(rectangle(target.composite, actor.width, actor.height));
      this.outputPaints++;
    } catch {
      this.failed = true;
      this.release();
      this.emit("failed");
      console.warn("Liquid Widgets: refraction unavailable; using translucent cards");
    }
  }
});

// src/platform/gnome50.ts
import Clutter3 from "gi://Clutter";
import * as Background from "resource:///org/gnome/shell/ui/background.js";
import * as Main2 from "resource:///org/gnome/shell/ui/main.js";
var WallpaperClone = class {
  constructor(container, monitorIndex, padding, invalidate) {
    this.monitorIndex = monitorIndex;
    this.padding = padding;
    this.invalidate = invalidate;
    container.add_child(this.wallpaper);
    this.manager = new Background.BackgroundManager({ container: this.wallpaper, monitorIndex, controlPosition: false, vignette: false });
    const update = () => {
      this.position();
      this.invalidate();
    };
    this.changed = this.manager.connect("changed", update);
    this.loaded = this.manager.connect("loaded", update);
    this.monitorsChanged = Main2.layoutManager.connect("monitors-changed", update);
  }
  monitorIndex;
  padding;
  invalidate;
  manager;
  wallpaper = new Clutter3.Actor();
  changed;
  loaded;
  monitorsChanged;
  rect = { x: 0, y: 0, width: 1, height: 1 };
  position() {
    const monitor = Main2.layoutManager.monitors[this.monitorIndex];
    if (!monitor || !this.manager.backgroundActor) return;
    this.wallpaper.set_position(monitor.x - this.rect.x + this.padding, monitor.y - this.rect.y + this.padding);
    this.wallpaper.set_size(monitor.width, monitor.height);
  }
  setGeometry(rect) {
    if (rect.x === this.rect.x && rect.y === this.rect.y && rect.width === this.rect.width && rect.height === this.rect.height) return;
    this.rect = { ...rect };
    this.position();
    this.invalidate();
  }
  destroy() {
    Main2.layoutManager.disconnect(this.monitorsChanged);
    this.manager.disconnect(this.changed);
    this.manager.disconnect(this.loaded);
    this.manager.destroy();
    this.wallpaper.destroy();
  }
};

// src/effects/background.ts
var GlassSurface = class {
  actor = new Clutter4.Actor();
  source = new Clutter4.Actor({ clip_to_allocation: true });
  effect = new GlassEffect();
  wallpaper;
  fallbackIdle = 0;
  constructor(monitorIndex, onFallback = () => {
  }) {
    this.actor.add_child(this.source);
    this.source.add_effect(this.effect);
    this.effect.connect("failed", () => {
      this.fallbackIdle = GLib13.idle_add(GLib13.PRIORITY_DEFAULT_IDLE, () => {
        this.fallbackIdle = 0;
        this.source.hide();
        onFallback();
        return GLib13.SOURCE_REMOVE;
      });
    });
    this.wallpaper = new WallpaperClone(this.source, monitorIndex, this.effect.padding, () => this.effect.invalidate());
  }
  // GNOME resource scale is authoritative (125% currently allocates at 2x).
  // Keep the logical scale argument for the shared surface interface.
  setGeometry(rect, _scale, worldRect = rect) {
    this.actor.set_position(rect.x, rect.y);
    this.actor.set_size(rect.width, rect.height);
    const p = this.effect.padding;
    this.source.set_position(-p, -p);
    this.source.set_size(rect.width + 2 * p, rect.height + 2 * p);
    this.wallpaper.setGeometry(worldRect);
  }
  get fallback() {
    return this.effect.failed;
  }
  setEnabled(enabled) {
    this.source.visible = enabled && !this.fallback;
    if (!enabled) this.effect.release();
  }
  setStrength(value) {
    this.effect.setStrength(value);
  }
  setMaterial(opacity, dark) {
    this.effect.setMaterial(opacity, dark);
  }
  get diagnostics() {
    return { inputPaints: this.effect.inputPaints, blurPaints: this.effect.blurPaints, outputPaints: this.effect.outputPaints, textureBytes: this.effect.textureBytes };
  }
  destroy() {
    if (this.fallbackIdle) GLib13.Source.remove(this.fallbackIdle);
    this.fallbackIdle = 0;
    this.wallpaper.destroy();
    this.source.remove_effect(this.effect);
    this.effect.release();
    this.actor.destroy();
  }
};

// src/widgets/card.ts
function label(text2, styleClass = "liquid-caption") {
  const actor = new St.Label({ text: text2, style_class: styleClass, x_expand: true });
  actor.clutter_text.ellipsize = Pango.EllipsizeMode.END;
  return actor;
}
var GlassCard = class {
  constructor(id, monitor, title, action) {
    this.id = id;
    this.surface = new GlassSurface(monitor, () => this.applyAppearance());
    this.title = label(title, "liquid-title");
    const heading = new St.BoxLayout({ x_expand: true });
    heading.add_child(this.title);
    this.mode.x_expand = false;
    this.mode.x_align = Clutter5.ActorAlign.END;
    this.mode.hide();
    heading.add_child(this.mode);
    this.status.hide();
    this.status.connect("notify::text", () => {
      this.status.visible = Boolean(this.status.get_text());
    });
    this.content.add_child(heading);
    this.content.add_child(this.body);
    this.content.add_child(this.status);
    this.button = new St.Button({ child: this.content, reactive: true, can_focus: true, track_hover: true, style_class: "liquid-card", accessible_name: title });
    this.button.connect("clicked", action);
    this.surface.actor.add_child(this.button);
  }
  id;
  scale = 1;
  opacity = 0.24;
  lowPower = false;
  dark = true;
  surface;
  button;
  content = new St.BoxLayout({ orientation: Clutter5.Orientation.VERTICAL, style_class: "liquid-content", x_expand: true, y_expand: true, x_align: Clutter5.ActorAlign.FILL, y_align: Clutter5.ActorAlign.FILL });
  body = new St.BoxLayout({ orientation: Clutter5.Orientation.VERTICAL, style_class: "liquid-body" });
  title;
  status = label("", "liquid-status");
  mode = label("", "liquid-status");
  setGeometry(local, world, scale) {
    this.surface.setGeometry(local, scale, world);
    this.scale = scale;
    this.button.set_size(local.width, local.height);
  }
  setStyle(strength, opacity, lowPower, dark, scale = this.scale) {
    this.scale = scale;
    this.opacity = opacity;
    this.lowPower = lowPower;
    this.dark = dark;
    this.surface.setStrength(strength);
    this.surface.setEnabled(!lowPower);
    this.applyAppearance();
  }
  applyAppearance() {
    this.mode.visible = this.surface.fallback;
    this.surface.setMaterial(this.opacity, this.dark);
    const alpha = this.lowPower || this.surface.fallback ? 0.96 : 0;
    const color = this.dark ? "12,24,42" : "248,250,253";
    this.button.set_style(`font-size:${14 * this.scale}px;background-color:rgba(${color},${alpha});`);
  }
  clear() {
    this.body.destroy_all_children();
  }
  destroy() {
    this.surface.destroy();
  }
};

// src/widgets/clock.ts
import Cairo from "cairo";
import Clutter6 from "gi://Clutter";
import GLib14 from "gi://GLib";
import Pango2 from "gi://Pango";
import St2 from "gi://St";

// src/shared/clockValues.ts
function millisecondsToNextMinute(nowMs) {
  return 6e4 - (nowMs % 6e4 + 6e4) % 6e4;
}
function millisecondsToNextSecond(nowMs) {
  return Math.ceil(1e3 - (nowMs % 1e3 + 1e3) % 1e3);
}
function clockStyle(value) {
  return value === "square" || value === "classic" || value === "minimal" ? value : "digital";
}
function clockFaceValues(now, zone, hour12, locale) {
  const options = { timeZone: zone, hour: "2-digit", minute: "2-digit", second: "2-digit" };
  const wall = new Intl.DateTimeFormat("en-GB", { ...options, hourCycle: "h23" }).formatToParts(now);
  const get = (parts, type) => parts.find((part) => part.type === type)?.value ?? "";
  const hours = Number(get(wall, "hour")), minutes = Number(get(wall, "minute")), seconds = Number(get(wall, "second"));
  const display = new Intl.DateTimeFormat(locale, { ...options, ...hour12 ? { hour12: true } : { hourCycle: "h23" } }).formatToParts(now);
  const date = new Intl.DateTimeFormat(locale, { timeZone: zone, month: "short", day: "numeric", weekday: "long" }).format(now);
  return {
    digits: `${get(display, "hour")}:${get(display, "minute")}`,
    dayPeriod: get(display, "dayPeriod"),
    date,
    hourAngle: (hours % 12 + minutes / 60 + seconds / 3600) * 30,
    minuteAngle: (minutes + seconds / 60) * 6,
    secondAngle: seconds * 6
  };
}
function clockValues(now, zone, hour12, locale) {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(now);
  const get = (type) => parts.find((p) => p.type === type).value;
  const format = (options) => new Intl.DateTimeFormat(locale, { timeZone: zone, ...options }).format(now);
  return {
    today: `${get("year")}-${get("month")}-${get("day")}`,
    day: String(Number(get("day"))),
    date: format({ year: "numeric", month: "long", day: "numeric" }),
    weekday: format({ weekday: "long" }),
    month: format({ month: "long" }),
    time: format({ hour: "2-digit", minute: "2-digit", ...hour12 ? { hour12: true } : { hourCycle: "h23" } })
  };
}

// src/widgets/clock.ts
function slot(child) {
  const box = new St2.Widget({ layout_manager: new Clutter6.BinLayout() });
  child.x_align = Clutter6.ActorAlign.CENTER;
  child.y_align = Clutter6.ActorAlign.CENTER;
  box.add_child(child);
  return box;
}
function text(name) {
  const actor = new St2.Label({ name });
  actor.clutter_text.ellipsize = Pango2.EllipsizeMode.NONE;
  return actor;
}
var ClockFace = class {
  constructor(card, readNow) {
    this.card = card;
    this.readNow = readNow;
    this.actor.add_child(this.dial);
    this.dial.add_child(this.area);
    for (const number of this.numbers) this.dial.add_child(number.box);
    for (const box of [this.digitsBox, this.periodBox]) this.dial.add_child(box);
    this.dateBox.x_expand = true;
    this.dateBox.y_expand = true;
    this.dateBox.x_align = Clutter6.ActorAlign.CENTER;
    this.dateBox.y_align = Clutter6.ActorAlign.END;
    this.actor.add_child(this.dateBox);
    const heading = card.title.get_parent();
    heading?.remove_child(card.mode);
    heading?.hide();
    card.mode.x_align = Clutter6.ActorAlign.CENTER;
    card.mode.y_align = Clutter6.ActorAlign.CENTER;
    this.dateBox.add_child(card.mode);
    card.mode.connect("notify::visible", () => {
      this.date.visible = !card.mode.visible;
    });
    card.content.set_style("spacing:0;");
    card.body.y_expand = true;
    card.body.add_child(this.actor);
    const attrs = new Pango2.AttrList();
    attrs.insert(Pango2.attr_font_features_new("tnum=1"));
    attrs.insert(Pango2.attr_stretch_new(Pango2.Stretch.CONDENSED));
    this.digits.clutter_text.set_attributes(attrs);
    this.area.connect("repaint", () => this.paint());
    this.actor.connect("notify::mapped", () => this.schedule());
    this.actor.connect("destroy", () => this.stop());
  }
  card;
  readNow;
  actor = new St2.Widget({ name: "liquid-clock-face", layout_manager: new Clutter6.BinLayout(), y_expand: true });
  dial = new St2.Widget({ layout_manager: new Clutter6.FixedLayout(), x_expand: true, y_expand: true, y_align: Clutter6.ActorAlign.START });
  area = new St2.DrawingArea({ name: "liquid-clock-dial" });
  digits = text("liquid-clock-digits");
  date = text("liquid-clock-date");
  period = text("liquid-clock-period");
  digitsBox = slot(this.digits);
  dateBox = slot(this.date);
  periodBox = slot(this.period);
  numbers = Array.from({ length: 12 }, (_, i) => {
    const label2 = text("liquid-clock-hour");
    label2.set_text(String(i + 1));
    return { label: label2, box: slot(label2) };
  });
  options = null;
  values = clockFaceValues(Date.now(), "UTC", false, "en-US");
  unit = 1;
  offset = 0;
  timer = 0;
  update(options) {
    this.options = options;
    this.actor.name = `liquid-clock-${options.style}`;
    this.unit = Math.min(options.scale, Math.max(1, options.width) / 196);
    this.offset = (options.width - 196 * this.unit) / 2;
    const u = this.unit, x = this.offset;
    this.actor.set_size(options.width, 184 * u);
    this.dial.set_size(options.width, 166 * u);
    this.area.set_size(options.width, 166 * u);
    const place = (box, px, y, w, h) => {
      box.set_position(x + px * u, y * u);
      box.set_size(w * u, h * u);
    };
    place(this.digitsBox, 8, 41, 180, 84);
    place(this.periodBox, 8, 126, 180, 22);
    this.dateBox.set_size(196 * u, 18 * u);
    this.digits.set_style(`font-family:"Noto Sans Display";font-size:${62 * u}px;font-weight:600;`);
    this.date.set_style(`font-size:${13 * u}px;font-weight:500;`);
    this.period.set_style(`font-size:${12 * u}px;font-weight:500;`);
    this.digitsBox.visible = options.style === "digital";
    this.periodBox.visible = options.style === "digital" && options.hour12;
    this.date.visible = !this.card.mode.visible;
    for (let i = 0; i < 12; i++) {
      const number = this.numbers[i], n = i + 1, a = n / 12 * Math.PI * 2 - Math.PI / 2;
      number.box.visible = options.style === "classic" || options.style === "square" && n % 3 === 0;
      let px = 98 + Math.cos(a) * 57 - 12, py = 82 + Math.sin(a) * 57 - 12;
      if (options.style === "square") {
        const points = { 12: [86, 17], 3: [154, 70], 6: [86, 120], 9: [24, 70] };
        [px, py] = points[n] ?? [0, 0];
      }
      place(number.box, px, py, 24, 24);
      number.label.set_style(`font-size:${(options.style === "square" ? 17 : 15) * u}px;font-weight:500;`);
    }
    this.refresh();
    const natural = this.digits.get_preferred_width(-1)[1], available = 180 * u;
    if (natural > available) this.digits.set_style(`font-family:"Noto Sans Display";font-size:${Math.max(1, 62 * u * (available - 2) / natural)}px;font-weight:600;`);
    this.schedule();
  }
  refresh() {
    if (!this.options) return;
    const { zone, hour12, locale } = this.options;
    this.values = clockFaceValues(this.readNow(), zone, hour12, locale);
    this.digits.set_text(this.values.digits);
    this.period.set_text(this.values.dayPeriod);
    this.date.set_text(this.values.date);
    this.card.button.accessible_name = `${this.values.date} \xB7 ${this.values.dayPeriod} ${this.values.digits}`.trim();
    this.area.queue_repaint();
  }
  stop() {
    if (this.timer) {
      GLib14.Source.remove(this.timer);
      this.timer = 0;
    }
  }
  schedule() {
    this.stop();
    if (!this.options || this.options.style === "digital" || this.options.lowPower || !this.actor.mapped) return;
    this.refresh();
    this.timer = GLib14.timeout_add(GLib14.PRIORITY_DEFAULT, millisecondsToNextSecond(this.readNow()), () => {
      this.timer = 0;
      this.schedule();
      return GLib14.SOURCE_REMOVE;
    });
  }
  paint() {
    if (!this.options) return;
    const cr = this.area.get_context(), u = this.unit, cx = this.offset + 98 * u, cy = 82 * u;
    const { style, lowPower } = this.options;
    try {
      const ink = this.area.get_theme_node().get_foreground_color();
      const color = (alpha = 1) => cr.setSourceRGBA(ink.red / 255, ink.green / 255, ink.blue / 255, alpha);
      const line = (x1, y1, x2, y2, width, alpha = 1) => {
        color(alpha);
        cr.setLineWidth(width * u);
        cr.moveTo(x1, y1);
        cr.lineTo(x2, y2);
        cr.stroke();
      };
      cr.setLineCap(Cairo.LineCap.ROUND);
      if (style === "classic" || style === "minimal") {
        color(0.055);
        cr.arc(cx, cy, 79 * u, 0, Math.PI * 2);
        cr.fill();
      }
      for (let i = 0; i < 60; i++) {
        const a = i / 60 * Math.PI * 2 - Math.PI / 2, major = i % 5 === 0, dx = Math.cos(a), dy = Math.sin(a);
        if (style === "minimal" && !major) continue;
        const square = style === "digital" || style === "square";
        const outer = square ? Math.min(88 / Math.max(Math.abs(dx), 1e-4), 74 / Math.max(Math.abs(dy), 1e-4)) : 76;
        const length = square ? major ? style === "digital" ? 8 : 14 : 4 : style === "minimal" ? 12 : major ? 8 : 3;
        line(
          cx + dx * (outer - length) * u,
          cy + dy * (outer - length) * u,
          cx + dx * outer * u,
          cy + dy * outer * u,
          style === "minimal" ? 3 : major ? 2.2 : 1.3,
          major ? 0.9 : 0.38
        );
      }
      if (style !== "digital") {
        const hand = (degrees, length, width) => {
          const a = degrees * Math.PI / 180 - Math.PI / 2;
          line(cx - Math.cos(a) * 6 * u, cy - Math.sin(a) * 6 * u, cx + Math.cos(a) * length * u, cy + Math.sin(a) * length * u, width);
        };
        hand(this.values.hourAngle, 43, 5.5);
        hand(this.values.minuteAngle, 62, 3.7);
        if (!lowPower) {
          const dark = ink.red > 128, a = this.values.secondAngle * Math.PI / 180 - Math.PI / 2;
          cr.setSourceRGBA(dark ? 1 : 0.8, dark ? 0.65 : 0.3, dark ? 0.3 : 0.055, 1);
          cr.setLineWidth(1.4 * u);
          cr.moveTo(cx - Math.cos(a) * 10 * u, cy - Math.sin(a) * 10 * u);
          cr.lineTo(cx + Math.cos(a) * 67 * u, cy + Math.sin(a) * 67 * u);
          cr.stroke();
        }
        cr.arc(cx, cy, 3.2 * u, 0, Math.PI * 2);
        cr.fill();
      }
    } finally {
      cr.$dispose();
    }
  }
};

// src/widgets/live.ts
import Clutter8 from "gi://Clutter";
import St4 from "gi://St";

// src/shared/liveData.ts
function requestedProviders(visible) {
  return PROVIDERS.filter((name) => visible.includes(name) || name === "calendar" && visible.includes("agenda"));
}
function rateLabel(bytes, language2 = "ko") {
  if (bytes === null) return translate(language2, "\uCE21\uC815 \uC911");
  const units = ["B/s", "KiB/s", "MiB/s", "GiB/s"];
  let unit = 0;
  while (bytes >= 1024 && unit < units.length - 1) {
    bytes /= 1024;
    unit++;
  }
  return `${unit ? bytes.toFixed(1) : Math.round(bytes)} ${units[unit]}`;
}

// src/widgets/artwork.ts
import Clutter7 from "gi://Clutter";
import Cogl2 from "gi://Cogl";
import Gio15 from "gi://Gio";

// src/widgets/artworkDecode.ts
import Gio14 from "gi://Gio";
import GdkPixbuf from "gi://GdkPixbuf";
async function loadArtworkPixbuf(uri, width, height, cancel) {
  if (!uri.startsWith("file:///")) throw new Error("INVALID_DATA");
  const file = Gio14.File.new_for_uri(uri), stream = await gioAsync((cb) => file.read_async(0, cancel, cb), (r) => file.read_finish(r));
  try {
    return await gioAsync((cb) => GdkPixbuf.Pixbuf.new_from_stream_at_scale_async(stream, width, height, true, cancel, cb), (r) => GdkPixbuf.Pixbuf.new_from_stream_finish(r));
  } finally {
    await closeStream(stream);
  }
}

// src/widgets/artwork.ts
import St3 from "gi://St";
function mediaArtwork(uri, scale, resourceScale) {
  const height = Math.round(44 * scale), density = Math.max(1, Math.ceil(resourceScale));
  const frame = new St3.Widget({
    width: height,
    height,
    y_align: Clutter7.ActorAlign.CENTER,
    layout_manager: new Clutter7.BinLayout(),
    content_gravity: Clutter7.ContentGravity.RESIZE_ASPECT
  });
  const fallback = new St3.Icon({
    icon_name: "audio-x-generic-symbolic",
    icon_size: height,
    x_align: Clutter7.ActorAlign.CENTER,
    y_align: Clutter7.ActorAlign.CENTER
  });
  frame.add_child(fallback);
  if (!uri?.startsWith("file:///")) return frame;
  const cancellable = new Gio15.Cancellable();
  let alive = true;
  frame.connect("destroy", () => {
    alive = false;
    cancellable.cancel();
  });
  void loadArtworkPixbuf(uri, Math.round(78 * scale) * density, height * density, cancellable).then((pixbuf) => {
    if (!alive) return;
    try {
      const width = pixbuf.get_width(), pixelsHigh = pixbuf.get_height();
      const content = new St3.ImageContent({ preferred_width: width / density, preferred_height: pixelsHigh / density });
      content.set_data(
        frame.get_context().get_backend().get_cogl_context(),
        pixbuf.get_pixels(),
        pixbuf.get_has_alpha() ? Cogl2.PixelFormat.RGBA_8888 : Cogl2.PixelFormat.RGB_888,
        width,
        pixelsHigh,
        pixbuf.get_rowstride()
      );
      frame.width = width / density;
      frame.content = content;
      fallback.hide();
    } catch {
    }
  }, () => {
  });
  return frame;
}

// src/widgets/live.ts
function renderNetwork(card, data, scale, language2) {
  card.title.set_text(`${translate(language2, "\uB124\uD2B8\uC6CC\uD06C")} \xB7 ${data.interface}`);
  card.body.add_child(label(`\u2193 ${rateLabel(data.rxBytesPerSec, language2)}`, "liquid-network-rate"));
  card.body.add_child(label(`\u2191 ${rateLabel(data.txBytesPerSec, language2)}`, "liquid-caption"));
  const graph = new St4.DrawingArea({ style_class: "liquid-network-graph", height: 40 * scale, x_expand: true, accessible_name: translate(language2, "\uCD5C\uADFC 60\uCD08 \uB124\uD2B8\uC6CC\uD06C \uC18D\uB3C4 \xB7 \uC2E4\uC120 \uB2E4\uC6B4\uB85C\uB4DC, \uC810\uC120 \uC5C5\uB85C\uB4DC") });
  graph.connect("repaint", () => {
    const cr = graph.get_context();
    try {
      const [width, height] = graph.get_surface_size();
      const samples = data.history;
      if (samples.length < 2) return;
      const maximum = Math.max(1, ...samples.flatMap((s) => [s.rx, s.tx]));
      const end = Date.parse(samples.at(-1).at);
      const ink = graph.get_theme_node().get_foreground_color();
      for (const key of ["rx", "tx"]) {
        cr.setSourceRGBA(ink.red / 255, ink.green / 255, ink.blue / 255, 1);
        cr.setLineWidth(1.5 * scale);
        cr.setDash(key === "tx" ? [3 * scale, 3 * scale] : [], 0);
        samples.forEach((sample, i) => {
          const x = Math.max(0, Math.min(1, (Date.parse(sample.at) - end + 6e4) / 6e4)) * width;
          const y = height - 2 - sample[key] / maximum * (height - 4);
          if (i === 0) cr.moveTo(x, y);
          else cr.lineTo(x, y);
        });
        cr.stroke();
      }
    } finally {
      cr.$dispose();
    }
  });
  card.body.add_child(graph);
}
function renderMedia(card, data, scale, language2) {
  const row = new St4.BoxLayout({ style_class: "liquid-media-row", x_expand: true });
  const icon = mediaArtwork(data.artUri, scale, card.button.get_resource_scale());
  row.add_child(icon);
  const details = new St4.BoxLayout({ orientation: Clutter8.Orientation.VERTICAL, x_expand: true, y_align: Clutter8.ActorAlign.CENTER });
  details.add_child(label(data.title || translate(language2, "\uC81C\uBAA9 \uC5C6\uB294 \uACE1"), "liquid-media-title"));
  details.add_child(label(data.artist || translate(language2, "\uC544\uD2F0\uC2A4\uD2B8 \uC815\uBCF4 \uC5C6\uC74C"), "liquid-caption"));
  row.add_child(details);
  card.body.add_child(row);
}

// src/widgets/system.ts
import Cairo2 from "cairo";
import Clutter9 from "gi://Clutter";
import St5 from "gi://St";
function gauge(name, percent, scale, language2) {
  const ratio = percent === null ? null : Math.max(0, Math.min(100, percent)) / 100;
  const value = ratio === null ? "\u2014" : `${Math.round(ratio * 100)}%`;
  const column = new St5.BoxLayout({
    orientation: Clutter9.Orientation.VERTICAL,
    style_class: "liquid-system-gauge",
    x_expand: true
  });
  const frame = new St5.Widget({
    width: 80 * scale,
    height: 80 * scale,
    x_align: Clutter9.ActorAlign.CENTER,
    layout_manager: new Clutter9.BinLayout()
  });
  const ring = new St5.DrawingArea({
    width: 80 * scale,
    height: 80 * scale,
    accessible_name: `${name} ${ratio === null ? translate(language2, "\uCE21\uC815 \uC911") : value}`
  });
  ring.connect("repaint", () => {
    const cr = ring.get_context();
    try {
      const [width, height] = ring.get_surface_size(), size = Math.min(width, height);
      const stroke = size * 7 / 80, radius = (size - stroke) / 2 - 1 * scale;
      const ink = ring.get_theme_node().get_foreground_color();
      cr.setLineWidth(stroke);
      cr.setLineCap(Cairo2.LineCap.ROUND);
      cr.setSourceRGBA(ink.red / 255, ink.green / 255, ink.blue / 255, 0.18);
      cr.arc(width / 2, height / 2, radius, 0, 2 * Math.PI);
      cr.stroke();
      if (ratio !== null && ratio > 0) {
        cr.setSourceRGBA(ink.red / 255, ink.green / 255, ink.blue / 255, 1);
        cr.arc(width / 2, height / 2, radius, -Math.PI / 2, -Math.PI / 2 + 2 * Math.PI * ratio);
        cr.stroke();
      }
    } finally {
      cr.$dispose();
    }
  });
  const number = label(value, "liquid-system-percent");
  number.x_expand = false;
  number.x_align = Clutter9.ActorAlign.CENTER;
  number.y_align = Clutter9.ActorAlign.CENTER;
  frame.add_child(ring);
  frame.add_child(number);
  column.add_child(frame);
  const caption = label(name, "liquid-system-name");
  caption.x_align = Clutter9.ActorAlign.CENTER;
  column.add_child(caption);
  return column;
}
function renderSystem(card, data, scale, language2) {
  const row = new St5.BoxLayout({ style_class: "liquid-system-row", x_expand: true });
  row.add_child(gauge("CPU", data.cpuPercent, scale, language2));
  row.add_child(gauge("RAM", data.memoryTotalBytes > 0 ? data.memoryUsedBytes / data.memoryTotalBytes * 100 : null, scale, language2));
  card.body.add_child(row);
  card.body.add_child(label(`RAM  ${(data.memoryUsedBytes / 2 ** 30).toFixed(1)} / ${(data.memoryTotalBytes / 2 ** 30).toFixed(1)} GiB`, "liquid-caption"));
  card.body.add_child(label(data.temperatureC === null ? translate(language2, "CPU \uC628\uB3C4 \uC13C\uC11C \uC5C6\uC74C") : translate(language2, "CPU \uC628\uB3C4  {value}\xB0C", { value: Math.round(data.temperatureC) }), "liquid-caption"));
}

// src/widgets/weather.ts
import St6 from "gi://St";
import Clutter10 from "gi://Clutter";

// src/shared/weatherFormat.ts
function weatherView(data, locale, hour12, language2 = "ko") {
  let format;
  try {
    format = new Intl.DateTimeFormat(locale, { timeZone: data.timeZone, hour: "2-digit", hourCycle: hour12 ? "h12" : "h23" });
  } catch {
    return null;
  }
  const code = data.current.code;
  let description = "\uB0A0\uC528 \uC815\uBCF4 \uC5C6\uC74C", icon = "weather-severe-alert-symbolic";
  if (code === 0) {
    description = "\uB9D1\uC74C";
    icon = "weather-clear-symbolic";
  } else if (code === 1 || code === 2) {
    description = "\uAD6C\uB984 \uC870\uAE08";
    icon = "weather-few-clouds-symbolic";
  } else if (code === 3) {
    description = "\uD750\uB9BC";
    icon = "weather-overcast-symbolic";
  } else if (code === 45 || code === 48) {
    description = "\uC548\uAC1C";
    icon = "weather-fog-symbolic";
  } else if (code !== null && [51, 53, 55, 56, 57].includes(code)) {
    description = "\uC774\uC2AC\uBE44";
    icon = "weather-showers-scattered-symbolic";
  } else if (code !== null && [61, 63, 65, 66, 67, 80, 81, 82].includes(code)) {
    description = "\uBE44";
    icon = "weather-showers-symbolic";
  } else if (code !== null && [71, 73, 75, 77, 85, 86].includes(code)) {
    description = "\uB208";
    icon = "weather-snow-symbolic";
  } else if (code !== null && [95, 96, 99].includes(code)) {
    description = "\uB1CC\uC6B0";
    icon = "weather-storm-symbolic";
  }
  const temperature = (value) => value === null ? "\u2014\xB0" : `${Math.round(value)}\xB0`;
  return { temperature: temperature(data.current.temperatureC), description: translate(language2, description), icon, hours: data.hourly.map((hour) => ({ time: format.format(Date.parse(hour.at)), temperature: temperature(hour.temperatureC), rain: hour.precipitationProbability === null ? "\u2014" : `${Math.round(hour.precipitationProbability)}%` })) };
}

// src/widgets/weather.ts
function renderWeather(card, data, scale, locale, hour12, language2) {
  card.title.set_text(data.location);
  const view = weatherView(data, locale, hour12, language2);
  if (!view) {
    card.body.add_child(label(translate(language2, "\uB0A0\uC528 \uC2DC\uAC04\uB300\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694")));
    return;
  }
  const current = new St6.BoxLayout({ x_expand: true });
  current.add_child(label(view.temperature, "liquid-big"));
  current.add_child(new St6.Icon({ icon_name: view.icon, icon_size: Math.round(32 * scale), y_align: Clutter10.ActorAlign.CENTER }));
  card.body.add_child(current);
  card.body.add_child(label(view.description));
  const hours = new St6.BoxLayout({ x_expand: true });
  for (const hour of view.hours) {
    const column = new St6.BoxLayout({ orientation: Clutter10.Orientation.VERTICAL, width: Math.max(1, (card.button.width - 36 * scale) / 6) });
    column.add_child(label(hour.time, "liquid-weather-hour"));
    column.add_child(label(hour.temperature, "liquid-weather-temperature"));
    column.add_child(label(hour.rain, "liquid-weather-rain"));
    hours.add_child(column);
  }
  card.body.add_child(hours);
  card.body.add_child(label("Open-Meteo", "liquid-weather-attribution"));
}

// src/shared/cardState.ts
var errors = { NETWORK_ERROR: "\uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694", INVALID_DATA: "\uB370\uC774\uD130\uB97C \uC77D\uC744 \uC218 \uC5C6\uC5B4\uC694", PAYLOAD_TOO_LARGE: "\uB370\uC774\uD130\uAC00 \uB108\uBB34 \uCEE4\uC694", EXPANSION_LIMIT: "\uC77C\uC815\uC774 \uB108\uBB34 \uB9CE\uC544\uC694", UNSUPPORTED_CALENDAR: "\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uC77C\uC815 \uD615\uC2DD", UNKNOWN_TIME_ZONE: "\uC2DC\uAC04\uB300\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694", KEYRING_LOCKED: "\uD0A4\uB9C1 \uC7A0\uAE08\uC744 \uD574\uC81C\uD574 \uC8FC\uC138\uC694", SECRET_DELETION_FAILED: "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C\uB97C \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694", AUTH_ERROR: "\uCE98\uB9B0\uB354 \uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694", RATE_LIMITED: "\uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4", NO_PLAYER: "\uC7AC\uC0DD \uC911\uC778 \uC74C\uC545 \uC5C6\uC74C", NO_INTERFACE: "\uB124\uD2B8\uC6CC\uD06C\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694", SERVICE_UNAVAILABLE: "\uB370\uC774\uD130\uB97C \uAE30\uB2E4\uB9AC\uB294 \uC911", INTERNAL_ERROR: "\uB2E4\uC2DC \uC5F0\uACB0\uD558\uB294 \uC911" };
function cardState(state, connected, language2 = "ko") {
  if (!connected) return { kind: state.data === null ? "disconnected" : "stale", data: state.data, updatedAt: state.updatedAt, message: translate(language2, state.data === null ? "\uB370\uC774\uD130 \uC11C\uBE44\uC2A4 \uC5F0\uACB0 \uB300\uAE30" : "\uC5F0\uACB0 \uB04A\uAE40 \xB7 \uB9C8\uC9C0\uB9C9 \uB370\uC774\uD130") };
  if (state.status === "unconfigured") return { kind: "unconfigured", data: null, updatedAt: null, message: translate(language2, "\uC124\uC815\uC774 \uD544\uC694\uD574\uC694") };
  if (state.status === "loading") return { kind: state.data === null ? "loading" : "stale", data: state.data, updatedAt: state.updatedAt, message: translate(language2, "\uC5C5\uB370\uC774\uD2B8 \uC911\u2026") };
  if (state.status === "ok" && state.data !== null) return { kind: "ready", data: state.data, updatedAt: state.updatedAt, message: "" };
  return { kind: state.data === null ? "unavailable" : "stale", data: state.data, updatedAt: state.updatedAt, message: translate(language2, errors[state.errorCode ?? ""] ?? "\uB370\uC774\uD130\uB97C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC5B4\uC694") };
}

// src/shared/calendarFormat.ts
function monthGrid(month, weekStart) {
  if (!/^\d{4}-\d{2}$/.test(month) || weekStart < 0 || weekStart > 6) throw new Error("Invalid calendar context");
  const [year, m] = month.split("-").map(Number);
  const first = new Date(Date.UTC(year, m - 1, 1));
  const offset = (first.getUTCDay() - weekStart + 7) % 7;
  const length = Math.ceil((offset + new Date(Date.UTC(year, m, 0)).getUTCDate()) / 7) * 7;
  return Array.from({ length }, (_, index) => {
    const date = new Date(Date.UTC(year, m - 1, index - offset + 1));
    return { iso: date.toISOString().slice(0, 10), day: date.getUTCDate(), inMonth: date.getUTCMonth() === m - 1 };
  });
}
function eventDays(events, days, timeZone) {
  const format = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" });
  const iso = (time) => {
    const parts = format.formatToParts(time);
    return ["year", "month", "day"].map((type) => parts.find((part) => part.type === type).value).join("-");
  };
  const result = /* @__PURE__ */ new Set();
  for (const event of events) {
    const start = event.allDay ? event.start : iso(Date.parse(event.start));
    const end = event.allDay ? event.end : iso(Math.max(Date.parse(event.start), Date.parse(event.end) - 1));
    for (const day of days) if (day.iso >= start && (event.allDay ? day.iso < end : day.iso <= end)) result.add(day.iso);
  }
  return result;
}

// src/shared/agenda.ts
function selectAgenda(events, nowMs, today, timeZone = "UTC") {
  let formatter;
  const localStart = (event) => {
    if (event.allDay) return `${event.start}T00:00:00`;
    formatter ??= new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" });
    const parts = formatter.formatToParts(Date.parse(event.start));
    const part = (name) => parts.find((p) => p.type === name).value;
    return `${part("year")}-${part("month")}-${part("day")}T${part("hour")}:${part("minute")}:${part("second")}`;
  };
  const limit = /* @__PURE__ */ new Date(`${today}T00:00:00Z`);
  limit.setUTCDate(limit.getUTCDate() + 30);
  const horizon = limit.toISOString().slice(0, 10);
  const ongoing = (e) => e.allDay ? e.start <= today : Date.parse(e.start) <= nowMs;
  return events.filter((e) => (e.allDay ? e.end > today : Date.parse(e.end) > nowMs) && (ongoing(e) || localStart(e).slice(0, 10) < horizon)).sort((a, b) => Number(ongoing(b)) - Number(ongoing(a)) || (a.allDay || b.allDay ? localStart(a).localeCompare(localStart(b)) : Date.parse(a.start) - Date.parse(b.start)) || a.uid.localeCompare(b.uid) || a.occurrenceKey.localeCompare(b.occurrenceKey)).slice(0, 3);
}
function formatAgendaWhen(event, timeZone, locale, hour12, language2 = "ko") {
  const at = event.allDay ? Date.parse(`${event.start}T12:00:00Z`) : Date.parse(event.start);
  const date = new Intl.DateTimeFormat(locale, { timeZone: event.allDay ? "UTC" : timeZone, month: "short", day: "numeric", weekday: "short" }).format(at);
  const time = event.allDay ? translate(language2, "\uC885\uC77C") : new Intl.DateTimeFormat(locale, { timeZone, hour: "2-digit", minute: "2-digit", hourCycle: hour12 ? "h12" : "h23" }).format(at);
  return `${date} \xB7 ${time}`;
}

// src/shared/cards.ts
var CARD_IDS = ["clock", "calendar", "weather", "agenda", "network", "system", "media"];
var DEFAULT_CARD_COLUMNS = { left: ["clock", "calendar", "agenda"], right: ["weather", "system", "network", "media"] };
var sides = ["left", "right"];
function normalizeCardColumns(columns) {
  const result = { left: [], right: [] }, known = new Set(CARD_IDS), seen = /* @__PURE__ */ new Set();
  for (const side of sides) for (const id of columns[side]) {
    if (known.has(id) && !seen.has(id)) {
      result[side].push(id);
      seen.add(id);
    }
  }
  for (const side of sides) for (const id of DEFAULT_CARD_COLUMNS[side]) if (!seen.has(id)) {
    result[side].push(id);
    seen.add(id);
  }
  return result;
}
function visibleCardColumns(columns, visible) {
  const result = normalizeCardColumns(columns), enabled = new Set(visible);
  return { left: result.left.filter((id) => enabled.has(id)), right: result.right.filter((id) => enabled.has(id)) };
}

// src/shared/layout.ts
var heights = { clock: 142, calendar: 252, weather: 230, agenda: 210, network: 210, system: 174, media: 174 };
function computeLayout(config, area, visible, measuredHeights = {}) {
  const scale = Math.max(0.75, Math.min(1.5, Number.isFinite(config.scale) ? config.scale : 1));
  const marginX = Math.min(Math.max(0, config.offsetX), Math.max(0, area.width * 0.08));
  const marginY = Math.min(Math.max(0, config.offsetY), Math.max(0, area.height * 0.08));
  const availableWidth = Math.max(1, area.width - 2 * marginX);
  const gap = 14 * scale, toolbarHeight = Math.min(40 * scale, Math.max(1, area.height / 3));
  const columns = availableWidth >= 478 * scale ? 2 : 1;
  const width = columns === 2 ? 478 * scale : Math.min(320 * scale, availableWidth);
  const cardWidth = (width - (columns - 1) * gap) / columns;
  const lists = visibleCardColumns(config.cardColumns ?? DEFAULT_CARD_COLUMNS, visible);
  const naturalHeight = (id) => {
    const measured = measuredHeights[id];
    return measured !== void 0 && Number.isFinite(measured) && measured > 0 ? measured : heights[id] * scale;
  };
  const clockHeight = Math.max(naturalHeight("clock"), visible.includes("weather") ? naturalHeight("weather") : 230 * scale);
  const cards = [];
  const stacks = columns === 2 ? [lists.left, lists.right] : [[...lists.left, ...lists.right]];
  const stackHeights = stacks.map((ids, column) => {
    let y = 0;
    for (const id of ids) {
      const height2 = id === "clock" ? clockHeight : naturalHeight(id);
      cards.push({ id, rect: { x: column * (cardWidth + gap), y, width: cardWidth, height: height2 } });
      y += height2 + gap;
    }
    return ids.length ? y - gap : 0;
  });
  const contentHeight = Math.max(...stackHeights);
  const height = Math.min(toolbarHeight + contentHeight, Math.max(toolbarHeight + 1, area.height - 2 * marginY));
  return {
    cards,
    columns,
    overflow: contentHeight > height - toolbarHeight,
    contentHeight,
    toolbarHeight,
    viewport: { x: config.anchor === "top-right" ? area.x + area.width - marginX - width : area.x + marginX, y: area.y + marginY, width, height }
  };
}
function selectMonitor(selected, monitors) {
  const found = monitors.findIndex((m) => m.id === selected);
  return found >= 0 ? found : monitors.length ? Math.max(0, monitors.findIndex((m) => m.primary)) : -1;
}

// src/widgets/host.ts
var TITLES = { clock: "\uC624\uB298", calendar: "\uB2EC\uB825", weather: "\uB0A0\uC528", agenda: "\uB2E4\uAC00\uC624\uB294 \uC77C\uC815", network: "\uB124\uD2B8\uC6CC\uD06C", system: "\uC2DC\uC2A4\uD15C", media: "\uC9C0\uAE08 \uC7AC\uC0DD \uC911" };
var WidgetHost = class {
  constructor(settings2, preferences) {
    this.settings = settings2;
    this.preferences = preferences;
    const name = label("LIQUID", "liquid-brand");
    name.clutter_text.ellipsize = Pango3.EllipsizeMode.NONE;
    name.x_expand = false;
    name.y_align = Clutter11.ActorAlign.CENTER;
    this.toolbar.add_child(name);
    this.toolbar.add_child(new St7.Widget({ x_expand: true }));
    this.settingsButton = new St7.Button({ child: new St7.Icon({ icon_name: "emblem-system-symbolic", icon_size: 15 }), style_class: "liquid-settings", y_align: Clutter11.ActorAlign.CENTER, can_focus: true, reactive: true, accessible_name: this.t("\uC704\uC82F \uC124\uC815") });
    this.settingsButton.connect("clicked", preferences);
    this.toolbar.add_child(this.settingsButton);
    this.actor.add_child(this.toolbar);
    this.actor.add_child(this.scroll);
    this.content.add_child(this.canvas);
    this.scroll.set_child(this.content);
    this.scroll.set_policy(St7.PolicyType.NEVER, St7.PolicyType.AUTOMATIC);
    this.adjustmentSignal = this.scroll.vadjustment.connect("notify::value", () => this.placeCards());
    this.schemeSignal = this.scheme.connect("notify::color-scheme", () => this.refreshAppearance());
    this.refreshAppearance();
  }
  settings;
  preferences;
  actor = new St7.Widget({ name: "liquid-widgets-host", style_class: "liquid-widgets" });
  scheme = St7.Settings.get();
  schemeSignal;
  get dark() {
    return this.scheme.color_scheme === St7.SystemColorScheme.PREFER_DARK;
  }
  toolbar = new St7.BoxLayout({ style_class: "liquid-toolbar" });
  scroll = new St7.ScrollView({ overlay_scrollbars: true, reactive: false });
  content = new St7.BoxLayout({ orientation: Clutter11.Orientation.VERTICAL });
  canvas = new St7.Widget({ layout_manager: new Clutter11.FixedLayout() });
  cards = /* @__PURE__ */ new Map();
  current = null;
  config = null;
  area = null;
  monitor = -1;
  scale = 1;
  connected = false;
  states = /* @__PURE__ */ new Map();
  adjustmentSignal;
  now = Date.now();
  zone = "UTC";
  hour12 = false;
  weekStart = 1;
  recordedAt = GLib15.get_monotonic_time();
  clockFaces = /* @__PURE__ */ new WeakMap();
  settingsButton;
  get language() {
    return language(this.settings.get_string("language"));
  }
  get locale() {
    return localeFor(this.language);
  }
  t(message, values) {
    return translate(this.language, message, values);
  }
  refreshAppearance() {
    this.actor.set_style_class_name(`liquid-widgets ${this.dark ? "liquid-dark" : "liquid-light"}`);
    this.placeCards();
    this.renderAll();
    this.reflow();
  }
  get visibleCards() {
    const columns = visibleCardColumns(this.cardColumns, this.settings.get_strv("visible"));
    return [...columns.left, ...columns.right].filter((id) => id !== "media" || this.states.get("media")?.data?.status === "playing");
  }
  get cardColumns() {
    const raw = this.settings.get_value("card-columns").deep_unpack();
    return normalizeCardColumns({ left: raw[0] ?? [], right: raw[1] ?? [] });
  }
  layout(config, area, monitor) {
    config = { ...config, cardColumns: this.cardColumns };
    this.config = config;
    this.area = { ...area };
    this.scale = config.scale;
    if (this.monitor !== monitor) {
      for (const card of this.cards.values()) card.destroy();
      this.cards.clear();
      this.monitor = monitor;
    }
    const wanted = this.visibleCards;
    for (const [id, card] of this.cards) if (!wanted.includes(id)) {
      card.destroy();
      this.cards.delete(id);
    }
    for (const id of wanted) if (!this.cards.has(id)) {
      const card = new GlassCard(id, monitor, TITLES[id] ? this.t(TITLES[id]) : id, () => {
        if (id === "calendar" || id === "agenda") Gio16.AppInfo.launch_default_for_uri_async("https://calendar.google.com/", null, null, (_object, result) => {
          try {
            Gio16.AppInfo.launch_default_for_uri_finish(result);
          } catch {
            card.status.set_text(this.t("\uBE0C\uB77C\uC6B0\uC800\uB97C \uC5F4 \uC218 \uC5C6\uC5B4\uC694"));
            this.reflow();
          }
        });
        else this.preferences();
      });
      this.cards.set(id, card);
      this.canvas.add_child(card.surface.actor);
      card.button.connect("key-focus-in", () => this.reveal(id));
    }
    wanted.forEach((id, index) => this.canvas.set_child_at_index(this.cards.get(id).surface.actor, index));
    for (const { id, rect } of computeLayout(config, area, wanted).cards) {
      const card = this.cards.get(id);
      card.button.set_width(rect.width);
      card.setStyle(this.settings.get_double("strength"), this.settings.get_double("opacity"), this.settings.get_boolean("low-power"), this.dark, this.scale);
    }
    this.renderAll();
    this.reflow();
  }
  reflow() {
    if (!this.config || !this.area) return;
    const wanted = this.visibleCards.filter((id) => this.cards.has(id));
    const measured = Object.fromEntries(wanted.map((id) => {
      const card = this.cards.get(id);
      return [id, Math.ceil(card.content.get_preferred_height(card.button.width)[1])];
    }));
    this.current = computeLayout(this.config, this.area, wanted, measured);
    const { viewport, toolbarHeight, contentHeight } = this.current;
    this.actor.set_position(viewport.x, viewport.y);
    this.actor.set_size(viewport.width, viewport.height);
    this.toolbar.set_size(viewport.width, toolbarHeight - 8);
    this.scroll.set_position(0, toolbarHeight);
    this.scroll.set_size(viewport.width, viewport.height - toolbarHeight);
    this.canvas.set_size(viewport.width, contentHeight);
    this.placeCards();
  }
  reveal(id) {
    const item = this.current?.cards.find((c) => c.id === id);
    if (!item || !this.current) return;
    const adjustment = this.scroll.vadjustment;
    const visible = this.current.viewport.height - this.current.toolbarHeight;
    if (item.rect.y < adjustment.value) adjustment.value = item.rect.y;
    else if (item.rect.y + item.rect.height > adjustment.value + visible) adjustment.value = item.rect.y + item.rect.height - visible;
  }
  placeCards() {
    if (!this.current) return;
    const { viewport, toolbarHeight } = this.current;
    for (const { id, rect } of this.current.cards) {
      const card = this.cards.get(id);
      card.setGeometry(rect, { ...rect, x: viewport.x + rect.x, y: viewport.y + toolbarHeight + rect.y - this.scroll.vadjustment.value }, this.scale);
      card.setStyle(this.settings.get_double("strength"), this.settings.get_double("opacity"), this.settings.get_boolean("low-power"), this.dark);
    }
  }
  update(snapshot2) {
    for (const name of ["calendar", "weather", "system", "network", "media"]) this.updateProvider(name, snapshot2[name]);
  }
  updateProvider(name, state) {
    this.states.set(name, state);
    for (const id of name === "calendar" ? ["calendar", "agenda"] : [name]) this.render(id);
    this.reflow();
  }
  setConnected(value) {
    this.connected = value;
    this.renderAll();
    this.reflow();
  }
  tick(now, zone, hour12, _systemLocale, weekStart) {
    this.now = now;
    this.recordedAt = GLib15.get_monotonic_time();
    this.zone = zone;
    this.hour12 = hour12;
    this.weekStart = weekStart;
    for (const id of ["clock", "calendar", "agenda"]) this.render(id);
    this.reflow();
  }
  renderAll() {
    this.settingsButton.accessible_name = this.t("\uC704\uC82F \uC124\uC815");
    for (const id of this.cards.keys()) this.render(id);
  }
  render(id) {
    const card = this.cards.get(id);
    if (!card) return;
    card.mode.set_text(this.t("\uAD74\uC808 \uBD88\uAC00 \xB7 \uBC18\uD22C\uBA85"));
    const clock = clockValues(this.now, this.zone, this.hour12, this.locale);
    if (id === "clock") {
      card.title.set_text(`${clock.weekday} \xB7 ${clock.date}`);
      let face = this.clockFaces.get(card);
      if (!face) {
        face = new ClockFace(card, () => this.now + (GLib15.get_monotonic_time() - this.recordedAt) / 1e3);
        this.clockFaces.set(card, face);
      }
      face.update({ style: clockStyle(this.settings.get_string("clock-style")), zone: this.zone, hour12: this.hour12, locale: this.locale, scale: this.scale, width: Math.max(1, card.button.width - 36 * this.scale), lowPower: this.settings.get_boolean("low-power") });
      card.status.set_text("");
      return;
    }
    card.clear();
    card.title.set_text(TITLES[id] ? this.t(TITLES[id]) : id);
    card.button.accessible_name = TITLES[id] ? this.t(TITLES[id]) : id;
    const provider = id === "agenda" ? "calendar" : id;
    let state = this.states.get(provider) ?? { status: "unconfigured", sourceId: null, updatedAt: null, data: null, errorCode: null };
    const calendar2 = provider === "calendar" ? state.data : null;
    if (calendar2 && (calendar2.month !== clock.today.slice(0, 7) || calendar2.timeZone !== this.zone || calendar2.weekStart !== this.weekStart)) {
      state = { ...state, status: "loading", data: null, updatedAt: null, errorCode: null };
    }
    const view = cardState(state, this.connected, this.language);
    const success = view.updatedAt ? new Intl.DateTimeFormat(this.locale, { timeZone: this.zone, hour: "2-digit", minute: "2-digit", hourCycle: this.hour12 ? "h12" : "h23" }).format(Date.parse(view.updatedAt)) : "";
    card.status.set_text(`${view.message}${view.kind === "stale" && success ? ` \xB7 ${success}` : ""}`);
    if (id === "calendar") {
      card.title.set_text(new Intl.DateTimeFormat(this.locale, { timeZone: this.zone, year: "numeric", month: "long" }).format(this.now));
      const grid = new St7.BoxLayout({ orientation: Clutter11.Orientation.VERTICAL, style_class: "liquid-calendar-grid" });
      const days = monthGrid(clock.today.slice(0, 7), this.weekStart);
      const dots = eventDays(view.data?.events ?? [], days, this.zone);
      for (let row = 0; row < 1 + days.length / 7; row++) {
        const line = new St7.BoxLayout({ x_expand: true });
        for (let column = 0; column < 7; column++) {
          const day = days[(row - 1) * 7 + column];
          const text2 = row === 0 ? new Intl.DateTimeFormat(this.locale, { weekday: "narrow", timeZone: "UTC" }).format(Date.UTC(2026, 10, 1 + (this.weekStart + column) % 7)) : String(day.day);
          const item = label(text2, "liquid-calendar-day");
          item.x_expand = false;
          item.x_align = Clutter11.ActorAlign.CENTER;
          item.y_align = Clutter11.ActorAlign.CENTER;
          const cell = new St7.Widget({ style_class: "liquid-calendar-cell", layout_manager: new Clutter11.BinLayout(), width: 27 * this.scale, height: 23 * this.scale, x_expand: true });
          if (day?.iso === clock.today) cell.add_style_class_name("liquid-calendar-today");
          else if (day && !day.inMonth) item.add_style_class_name("liquid-calendar-muted");
          cell.add_child(item);
          if (day && dots.has(day.iso)) {
            const dot = new St7.Widget({ style_class: day.iso === clock.today ? "liquid-event-dot today" : "liquid-event-dot", width: 3 * this.scale, height: 3 * this.scale, x_align: Clutter11.ActorAlign.CENTER, y_align: Clutter11.ActorAlign.END, y_expand: true });
            cell.add_child(dot);
            item.accessible_name = this.t("{date} \xB7 \uC77C\uC815 \uC788\uC74C", { date: day.iso });
          }
          line.add_child(cell);
        }
        grid.add_child(line);
      }
      card.body.add_child(grid);
      return;
    }
    if (view.data === null) {
      if (id === "network") {
        const row = new St7.BoxLayout({ x_expand: true });
        for (const title of [this.t("\u2193 \uB2E4\uC6B4\uB85C\uB4DC"), this.t("\u2191 \uC5C5\uB85C\uB4DC")]) {
          const column = new St7.BoxLayout({ orientation: Clutter11.Orientation.VERTICAL, x_expand: true });
          column.add_child(label(title));
          column.add_child(label("\u2014", "liquid-value"));
          row.add_child(column);
        }
        card.body.add_child(row);
      } else if (id === "weather") card.body.add_child(label("\u2014\xB0", "liquid-big"));
      else if (id === "system") card.body.add_child(label("\u2014 %", "liquid-value"));
      const prompt = this.t(view.kind === "unconfigured" ? id === "weather" ? "\uD45C\uC2DC\uD560 \uB3C4\uC2DC\uB97C \uC120\uD0DD\uD558\uC138\uC694" : "\uC124\uC815\uC5D0\uC11C \uCE98\uB9B0\uB354\uB97C \uC5F0\uACB0\uD558\uC138\uC694" : "\uC5F0\uACB0\uB418\uBA74 \uC815\uBCF4\uB97C \uD45C\uC2DC\uD574\uC694");
      card.body.add_child(label(prompt));
      return;
    }
    if (id === "agenda") {
      const data = view.data;
      const events = selectAgenda(data.events, this.now, clock.today, this.zone);
      if (!events.length) card.body.add_child(label(this.t("\uC608\uC815\uB41C \uC77C\uC815 \uC5C6\uC74C")));
      for (const event of events) {
        card.body.add_child(label(event.title || this.t("\uC81C\uBAA9 \uC5C6\uB294 \uC77C\uC815"), "liquid-agenda-title"));
        card.body.add_child(label(formatAgendaWhen(event, this.zone, this.locale, this.hour12, this.language), "liquid-agenda-time"));
      }
    } else if (id === "weather") {
      const data = view.data;
      if (!data) return;
      renderWeather(card, data, this.scale, this.locale, this.hour12, this.language);
    } else if (id === "system") renderSystem(card, view.data, this.scale, this.language);
    else if (id === "network") renderNetwork(card, view.data, this.scale, this.language);
    else if (id === "media") renderMedia(card, view.data, this.scale, this.language);
  }
  get diagnostics() {
    return { cards: this.cards.size, layout: this.current, scroll: this.scroll.vadjustment.value };
  }
  destroy() {
    this.scheme.disconnect(this.schemeSignal);
    this.scroll.vadjustment.disconnect(this.adjustmentSignal);
    for (const card of this.cards.values()) card.destroy();
    this.cards.clear();
    this.actor.destroy();
  }
};

// src/clock.ts
import Gio17 from "gi://Gio";
import GLib16 from "gi://GLib";
import GnomeDesktop from "gi://GnomeDesktop?version=4.0";
import Shell from "gi://Shell";
import * as LoginManager from "resource:///org/gnome/shell/misc/loginManager.js";
var ClockController = class {
  timer = 0;
  clock = new GnomeDesktop.WallClock();
  settings = new Gio17.Settings({ schema_id: "org.gnome.desktop.interface" });
  login = LoginManager.getLoginManager();
  signals = [];
  callback = null;
  get timeZone() {
    return this.clock.get_timezone().get_identifier();
  }
  get hour12() {
    return this.settings.get_string("clock-format") === "12h";
  }
  get locale() {
    const raw = (GLib16.get_language_names()[0] ?? "en_US").split(".")[0].split("@")[0];
    return raw === "C" || raw === "POSIX" ? "en-US" : raw.replaceAll("_", "-");
  }
  get weekStart() {
    return Shell.util_get_week_start();
  }
  start(onTick, onResume = () => {
  }) {
    this.callback = onTick;
    this.signals.push({ object: this.clock, id: this.clock.connect("notify::clock", () => this.tick()) });
    this.signals.push({ object: this.clock, id: this.clock.connect("notify::timezone", () => this.tick()) });
    this.signals.push({ object: this.settings, id: this.settings.connect("changed::clock-format", () => this.tick()) });
    this.signals.push({ object: this.login, id: this.login.connect("prepare-for-sleep", (_object, sleeping) => {
      if (!sleeping) {
        this.tick();
        onResume();
      }
    }) });
    this.tick();
  }
  tick() {
    if (this.timer) {
      GLib16.source_remove(this.timer);
      this.timer = 0;
    }
    this.callback?.(Date.now());
    this.timer = GLib16.timeout_add(GLib16.PRIORITY_DEFAULT, millisecondsToNextMinute(Date.now()), () => {
      this.timer = 0;
      this.tick();
      return GLib16.SOURCE_REMOVE;
    });
  }
  destroy() {
    if (this.timer) GLib16.source_remove(this.timer);
    this.timer = 0;
    for (const { object, id } of this.signals) object.disconnect(id);
    this.signals = [];
    this.callback = null;
    this.clock.run_dispose();
  }
};

// src/layout.ts
import * as Main3 from "resource:///org/gnome/shell/ui/main.js";
function desktopWorkarea(selected) {
  const manager = global.backend.get_monitor_manager();
  const hardware = manager.get_monitors() ?? [];
  const index = selectMonitor(selected, Main3.layoutManager.monitors.map((m) => ({ id: hardware.find((h) => manager.get_monitor_for_connector(h.get_connector()) === m.index)?.get_connector() ?? String(m.index), primary: m.index === Main3.layoutManager.primaryIndex })));
  if (index < 0) return null;
  const monitor = Main3.layoutManager.monitors[index];
  const area = global.workspace_manager.get_active_workspace().get_work_area_for_monitor(monitor.index);
  return { index: monitor.index, area: { x: area.x, y: area.y, width: area.width, height: area.height } };
}
function watchDesktopLayout(callback) {
  const monitors = Main3.layoutManager.connect("monitors-changed", callback);
  const workarea = global.display.connect("workareas-changed", callback);
  return () => {
    Main3.layoutManager.disconnect(monitors);
    global.display.disconnect(workarea);
  };
}

// src/cardSettings.ts
import GLib17 from "gi://GLib";
function saveCardColumns(settings2, columns) {
  const normalized = normalizeCardColumns(columns), next = [normalized.left, normalized.right];
  if (JSON.stringify(settings2.get_value("card-columns").deep_unpack()) !== JSON.stringify(next)) settings2.set_value("card-columns", new GLib17.Variant("aas", next));
}
function initializeCardColumns(settings2) {
  const raw = settings2.get_value("card-columns").deep_unpack();
  const columns = normalizeCardColumns({ left: raw[0] ?? [], right: raw[1] ?? [] });
  saveCardColumns(settings2, columns);
  return columns;
}

// src/extension.ts
var LiquidWidgets = class extends Extension {
  layer = null;
  host = null;
  clock = null;
  client = null;
  settings = null;
  settingsChanged = 0;
  subscribed = "";
  unwatch = null;
  enable() {
    this.settings = this.getSettings();
    initializeCardColumns(this.settings);
    this.layer = new DesktopLayerAdapter();
    this.host = new WidgetHost(this.settings, () => {
      void this.openPreferences();
    });
    this.layer.actor.add_child(this.host.actor);
    this.unwatch = watchDesktopLayout(() => this.layout());
    this.settingsChanged = this.settings.connect("changed", (_settings, key) => {
      if (key === "card-columns" && this.settings) initializeCardColumns(this.settings);
      this.syncProviders();
      this.layout();
    });
    const store = new ProviderStore();
    this.client = createWidgetDataSession({ extensionPath: this.path, store, changed: (provider) => {
      const before = this.host?.visibleCards.join(",");
      if (provider) this.host?.updateProvider(provider, store.get(provider));
      else for (const name of PROVIDERS) this.host?.updateProvider(name, store.get(name));
      if (!provider || before !== this.host?.visibleCards.join(",")) this.layout();
    }, connection: (state) => this.host?.setConnected(state === "connected") });
    this.syncProviders();
    this.clock = new ClockController();
    this.clock.start((now) => {
      const clock = this.clock;
      this.host?.tick(now, clock.timeZone, clock.hour12, clock.locale, clock.weekStart);
      const today = clockValues(now, clock.timeZone, clock.hour12, clock.locale).today;
      this.client?.setCalendarContext({ month: today.slice(0, 7), timeZone: clock.timeZone, weekStart: clock.weekStart }, today);
    }, () => this.client?.refreshAfterResume());
    this.layout();
  }
  syncProviders() {
    if (!this.settings || !this.client) return;
    const providers = requestedProviders(this.settings.get_strv("visible")), key = providers.join(",");
    if (key === this.subscribed) return;
    this.subscribed = key;
    if (providers.length) this.client.start(providers);
    else this.client.stop();
  }
  layout() {
    if (!this.settings || !this.host) return;
    const placement = desktopWorkarea(this.settings.get_string("monitor"));
    if (!placement) {
      this.host.actor.hide();
      return;
    }
    this.host.actor.show();
    const config = { monitor: this.settings.get_string("monitor"), anchor: this.settings.get_string("anchor"), offsetX: this.settings.get_int("offset-x"), offsetY: this.settings.get_int("offset-y"), scale: this.settings.get_double("scale"), visible: this.settings.get_strv("visible") };
    this.host.layout(config, placement.area, placement.index);
  }
  disable() {
    this.subscribed = "";
    this.client?.destroy();
    this.client = null;
    this.clock?.destroy();
    this.clock = null;
    this.unwatch?.();
    this.unwatch = null;
    if (this.settingsChanged) this.settings?.disconnect(this.settingsChanged);
    this.settingsChanged = 0;
    this.settings = null;
    this.host?.destroy();
    this.host = null;
    this.layer?.destroy();
    this.layer = null;
  }
};
export {
  LiquidWidgets as default
};
