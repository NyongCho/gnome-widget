// <define:__LIQUID_EDITION__>
var define_LIQUID_EDITION_default = { backend: "rust", uuid: "liquid-widgets@local", schemaId: "org.gnome.shell.extensions.liquid-widgets", schemaPath: "/org/gnome/shell/extensions/liquid-widgets/", dataDirectory: "liquid-widgets", secretApplication: "org.local.LiquidWidgets", output: "dist", homepage: "https://github.com/NyongCho/gnome-widget" };

// src/prefs.ts
import "gi://Adw";
import { ExtensionPreferences } from "resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js";

// src/prefs/pages.ts
import Adw7 from "gi://Adw";
import Gtk7 from "gi://Gtk?version=4.0";
import Gio19 from "gi://Gio";

// src/prefs/language.ts
import Adw from "gi://Adw";
import Gtk from "gi://Gtk?version=4.0";
import "gi://Gio";

// src/shared/i18n.ts
var messages = {
  "\uC704\uC82F \uB3D9\uAE30\uD654": "Widget synchronization",
  "\uC124\uC815\uCC3D \uC5F0\uACB0 \uD655\uC778": "Connection check in settings",
  "\uC5F0\uACB0 \uC815\uBCF4 \uC800\uC7A5\uB428 \xB7 \uC0C1\uD0DC \uD655\uC778 \uC911": "Connection saved \xB7 Checking status",
  "\uC5F0\uACB0 \uD655\uC778 \uC644\uB8CC \xB7 \uC77C\uC815 {count}\uAC1C": "Connection verified \xB7 {count} events",
  "\uC5F0\uACB0\uC744 \uD655\uC778\uD558\uB294 \uC911\u2026": "Verifying the connection\u2026",
  "\uC5F0\uACB0 \uD655\uC778 \uC911 \xB7 \uB9C8\uC9C0\uB9C9 \uB370\uC774\uD130 \uD45C\uC2DC": "Verifying connection \xB7 Showing last data",
  "{message} \xB7 \uB9C8\uC9C0\uB9C9 \uD655\uC778 \uB370\uC774\uD130 \uD45C\uC2DC": "{message} \xB7 Showing last verified data",
  "\uC124\uC815\uC744 \uC77D\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.": "Could not read settings. Please try again shortly.",
  "\uC67C\uCABD \uC5F4": "Left column",
  "\uC624\uB978\uCABD \uC5F4": "Right column",
  "\uC67C\uCABD \uC5F4\uB85C \uC774\uB3D9": "Move to left column",
  "\uC624\uB978\uCABD \uC5F4\uB85C \uC774\uB3D9": "Move to right column",
  "\uAC01 \uC5F4 \uC548\uC5D0\uC11C \uC21C\uC11C\uB97C \uBC14\uAFB8\uAC70\uB098 \uBC18\uB300\uCABD \uC5F4\uB85C \uC62E\uAE38 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uC74C\uC545\uC740 \uC7AC\uC0DD \uC911\uC77C \uB54C\uB9CC \uD45C\uC2DC\uB429\uB2C8\uB2E4.": "Reorder cards within each column or move them to the other column. Music appears only while playing.",
  "\uC704\uB85C \uC774\uB3D9": "Move up",
  "\uC544\uB798\uB85C \uC774\uB3D9": "Move down",
  "\uC704\xB7\uC544\uB798 \uBC84\uD2BC\uC73C\uB85C \uC21C\uC11C\uB97C \uBC14\uAFC9\uB2C8\uB2E4. \uCE74\uB4DC\uB294 \uC67C\uCABD\uBD80\uD130 \uD55C \uC904\uC5D0 \uB450 \uAC1C\uC529 \uBC30\uCE58\uB429\uB2C8\uB2E4. \uC74C\uC545\uC740 \uC7AC\uC0DD \uC911\uC77C \uB54C\uB9CC \uD45C\uC2DC\uB429\uB2C8\uB2E4.": "Use the up/down buttons to reorder. Cards fill each row from left to right, two per row. Music appears only while playing.",
  "\uC704\uC82F": "Widgets",
  "\uB370\uC774\uD130": "Data",
  "\uC5B8\uC5B4 / Language": "\uC5B8\uC5B4 / Language",
  "\uD45C\uC2DC \uC5B8\uC5B4": "Display language",
  "\uC704\uC82F\uACFC \uC124\uC815\uC5D0 \uBC14\uB85C \uC801\uC6A9\uB429\uB2C8\uB2E4.": "Applies immediately to widgets and settings.",
  "\uD45C\uC2DC\uD560 \uCE74\uB4DC": "Visible cards",
  "\uC74C\uC545\uC740 \uC7AC\uC0DD \uC911\uC77C \uB54C\uB9CC \uD45C\uC2DC\uB429\uB2C8\uB2E4.": "Music appears only while playing.",
  "\uB0A0\uC9DC\uC640 \uC2DC\uACC4": "Date and clock",
  "\uC6D4\uAC04 \uB2EC\uB825": "Monthly calendar",
  "\uB2E4\uAC00\uC624\uB294 \uC77C\uC815": "Upcoming events",
  "\uC2DC\uACC4": "Clock",
  "\uC2DC\uACC4 \uC2A4\uD0C0\uC77C": "Clock style",
  "\uC120\uD0DD\uD55C \uC2A4\uD0C0\uC77C\uC774 \uBC14\uB85C \uC801\uC6A9\uB429\uB2C8\uB2E4.": "The selected style applies immediately.",
  "\uD070 \uB514\uC9C0\uD138": "Large digital",
  "\uC0AC\uAC01 \uB208\uAE08": "Square dial",
  "\uD074\uB798\uC2DD \uC6D0\uD615": "Classic round",
  "\uBBF8\uB2C8\uBA40 \uC544\uB0A0\uB85C\uADF8": "Minimal analog",
  "\uB0A0\uC528": "Weather",
  "\uB124\uD2B8\uC6CC\uD06C": "Network",
  "CPU \xB7 \uBA54\uBAA8\uB9AC \xB7 \uC628\uB3C4": "CPU \xB7 Memory \xB7 Temperature",
  "\uC74C\uC545": "Music",
  "\uC720\uB9AC\uC640 \uD06C\uAE30": "Glass and size",
  "\uC720\uB9AC \uB18D\uB3C4": "Glass tint",
  "\uC720\uB9AC \uB18D\uB3C4\uB97C \uB192\uC774\uBA74 \uBC30\uACBD\uC774 \uB354 \uCC28\uBD84\uD574\uC9D1\uB2C8\uB2E4. \uAE00\uC790 \uB300\uBE44\uB294 \uC790\uB3D9\uC73C\uB85C \uC720\uC9C0\uD569\uB2C8\uB2E4.": "Increase glass tint for a calmer backdrop. Text contrast is maintained automatically.",
  "\uC804\uCCB4 \uD06C\uAE30": "Scale",
  "\uAD74\uC808 \uAC15\uB3C4": "Refraction strength",
  "\uC800\uC804\uB825 \uBAA8\uB4DC": "Low power mode",
  "\uAD74\uC808 \uB300\uC2E0 \uBC18\uD22C\uBA85 \uBC30\uACBD\uC744 \uC0AC\uC6A9\uD569\uB2C8\uB2E4.": "Uses a translucent background instead of refraction.",
  "\uD654\uBA74\uACFC \uC704\uCE58": "Display and position",
  "\uC120\uD0DD\uD55C \uD654\uBA74\uC774 \uC5C6\uC73C\uBA74 \uC8FC \uBAA8\uB2C8\uD130\uC5D0 \uD45C\uC2DC\uD569\uB2C8\uB2E4. \uC5EC\uBC31\uC740 \uC791\uC5C5 \uC601\uC5ED\uC5D0 \uB9DE\uAC8C \uC81C\uD55C\uB429\uB2C8\uB2E4.": "Uses the primary monitor if the selected display is unavailable. Margins stay within the work area.",
  "\uBAA8\uB2C8\uD130": "Monitor",
  "\uC8FC \uBAA8\uB2C8\uD130 (\uC790\uB3D9)": "Primary monitor (automatic)",
  "{monitor} \xB7 \uC5F0\uACB0 \uC548 \uB428 (\uC8FC \uBAA8\uB2C8\uD130\uC5D0 \uD45C\uC2DC)": "{monitor} \xB7 Disconnected (using primary)",
  "\uAE30\uC900 \uC704\uCE58": "Corner",
  "\uC624\uB978\uCABD \uC704": "Top right",
  "\uC67C\uCABD \uC704": "Top left",
  "\uAC00\uB85C \uC5EC\uBC31": "Horizontal margin",
  "\uC138\uB85C \uC5EC\uBC31": "Vertical margin",
  "\uB17C\uB9AC \uD53D\uC140": "Logical pixels",
  "\uC790\uB3D9\uC740 \uAE30\uBCF8 \uACBD\uB85C\uC758 \uBB3C\uB9AC \uC778\uD130\uD398\uC774\uC2A4 \uD558\uB098\uB97C \uC0AC\uC6A9\uD569\uB2C8\uB2E4. Tailscale \uD2B8\uB798\uD53D\uC740 tailscale0\uC744 \uC9C1\uC811 \uC120\uD0DD\uD558\uC138\uC694.": "Automatic uses the physical interface for the default route. Select tailscale0 to show Tailscale traffic.",
  "\uB124\uD2B8\uC6CC\uD06C \uC778\uD130\uD398\uC774\uC2A4": "Network interface",
  "\uC778\uD130\uD398\uC774\uC2A4 \uC801\uC6A9": "Apply interface",
  "\uC800\uC7A5": "Save",
  "\uD604\uC7AC \uC124\uC815\uC744 \uD655\uC778\uD558\uB294 \uC911\u2026": "Loading current settings\u2026",
  "\uC790\uB3D9 (\uAE30\uBCF8 \uACBD\uB85C)": "Automatic (default route)",
  "\uC790\uB3D9": "Automatic",
  "\uC0AC\uC6A9 \uC911: {value}": "In use: {value}",
  "\uB370\uC774\uD130 \uC11C\uBE44\uC2A4\uB97C \uC2DC\uC791\uD55C \uB4A4 \uB2E4\uC2DC \uC5F4\uC5B4 \uC8FC\uC138\uC694.": "Start the data service, then reopen settings.",
  "\uC800\uC7A5\uD558\uB294 \uC911\u2026": "Saving\u2026",
  "\uC800\uC7A5\uD588\uC5B4\uC694. \uC0C8 \uC778\uD130\uD398\uC774\uC2A4\uC758 \uCCAB \uC18D\uB3C4\uB97C \uCE21\uC815\uD569\uB2C8\uB2E4.": "Saved. Measuring the new interface\u2019s initial speed.",
  "\uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.": "Could not save. Please try again.",
  "Google Calendar": "Google Calendar",
  "\uC77D\uAE30 \uC804\uC6A9\uC73C\uB85C \uC5F0\uACB0\uD569\uB2C8\uB2E4. Google Calendar \uC124\uC815 \u2192 \uCE98\uB9B0\uB354 \uD1B5\uD569 \u2192 iCal \uD615\uC2DD\uC758 \uBE44\uACF5\uAC1C \uC8FC\uC18C\uB97C \uC785\uB825\uD558\uC138\uC694.": "Read-only connection. Enter the secret iCal address from Google Calendar settings \u2192 Integrate calendar.",
  "\uC5F0\uACB0 \uC0C1\uD0DC": "Connection status",
  "\uD655\uC778 \uC911\u2026": "Checking\u2026",
  "\uBE44\uACF5\uAC1C iCal \uC8FC\uC18C": "Private iCal address",
  "\uCE98\uB9B0\uB354 \uC5F0\uACB0 \uAD00\uB9AC": "Calendar connection",
  "\uC5F0\uACB0": "Connect",
  "\uC5F0\uACB0 \uD574\uC81C": "Disconnect",
  "\uC8FC\uC18C\uB294 \uC800\uC7A5 \uD6C4 \uB2E4\uC2DC \uD45C\uC2DC\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.": "The address is not shown again after saving.",
  "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C": "Delete connection details",
  "\uCC98\uB9AC \uC911\u2026": "Working\u2026",
  "\uC5F0\uACB0 \uC815\uBCF4\uB97C \uC800\uC7A5\uD588\uC5B4\uC694. \uB3D9\uAE30\uD654 \uACB0\uACFC\uB294 \uC704 \uC5F0\uACB0 \uC0C1\uD0DC\uC5D0 \uD45C\uC2DC\uB429\uB2C8\uB2E4.": "Connection saved. Sync results appear in the connection status above.",
  "\uC77C\uC815\uACFC \uC5F0\uACB0 \uC815\uBCF4\uB97C \uC0AD\uC81C\uD588\uC5B4\uC694.": "Events and connection details deleted.",
  "\uCC98\uB9AC\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC8FC\uC18C \uD615\uC2DD\uACFC \uD0A4\uB9C1 \uC7A0\uAE08\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.": "Could not complete. Check the address format and unlock the keyring.",
  "\uB0A0\uC528 \uC9C0\uC5ED": "Weather location",
  "\uC120\uD0DD\uD55C \uB3C4\uC2DC\uC758 \uD604\uC7AC \uB0A0\uC528\uC640 \uC55E\uC73C\uB85C 6\uC2DC\uAC04 \uC608\uBCF4\uB97C \uD45C\uC2DC\uD569\uB2C8\uB2E4.": "Shows current weather and the next six hours for your city.",
  "\uC120\uD0DD\uD55C \uC9C0\uC5ED": "Selected location",
  "\uD574\uC81C": "Clear",
  "\uB3C4\uC2DC \uC774\uB984": "City name",
  "\uAC80\uC0C9": "Search",
  "\uB450 \uAE00\uC790 \uC774\uC0C1 \uC785\uB825\uD574 \uAC80\uC0C9\uD558\uC138\uC694.": "Enter at least two characters to search.",
  "\uAC80\uC0C9 \uACB0\uACFC": "Search results",
  "\uC9C0\uC5ED\uC744 \uC120\uD0DD\uD558\uC9C0 \uC54A\uC558\uC5B4\uC694.": "No location selected.",
  "\uC9C0\uC5ED\uC744 \uC800\uC7A5\uD558\uB294 \uC911\u2026": "Saving location\u2026",
  "\uC9C0\uC5ED\uC744 \uC120\uD0DD\uD588\uC5B4\uC694. \uB0A0\uC528 \uB3D9\uAE30\uD654\uB97C \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694.": "Location saved. Waiting for weather to sync.",
  "\uC9C0\uC5ED\uC744 \uD574\uC81C\uD588\uC5B4\uC694.": "Location cleared.",
  "\uC9C0\uC5ED\uC744 \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.": "Could not save location. Please try again.",
  "\uB450 \uAE00\uC790 \uC774\uC0C1 \uC785\uB825\uD574 \uC8FC\uC138\uC694.": "Enter at least two characters.",
  "\uB3C4\uC2DC\uB97C \uCC3E\uB294 \uC911\u2026": "Searching for cities\u2026",
  "\uC120\uD0DD": "Select",
  "\uD45C\uC2DC\uD560 \uB3C4\uC2DC\uB97C \uC120\uD0DD\uD558\uC138\uC694.": "Select a city to display.",
  "\uAC80\uC0C9 \uACB0\uACFC\uAC00 \uC5C6\uC5B4\uC694.": "No results found.",
  "\uAC80\uC0C9\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uAE30\uC874 \uC120\uD0DD\uC740 \uC720\uC9C0\uB429\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.": "Search failed. Your previous selection is saved. Please try again shortly.",
  "\uB0A0\uC528 \uB370\uC774\uD130": "Weather data",
  "\uBB34\uB8CC API\uB294 \uAC1C\uC778 \uBE44\uC0C1\uC5C5\uC6A9\uC73C\uB85C \uC0AC\uC6A9\uD569\uB2C8\uB2E4. \uB370\uC774\uD130: CC BY 4.0.": "The free API is for personal, non-commercial use. Data: CC BY 4.0.",
  "\uCD9C\uCC98": "Sources",
  "\uC624\uB298": "Today",
  "\uB2EC\uB825": "Calendar",
  "\uC2DC\uC2A4\uD15C": "System",
  "\uC9C0\uAE08 \uC7AC\uC0DD \uC911": "Now playing",
  "\uC704\uC82F \uC124\uC815": "Widget settings",
  "\uBE0C\uB77C\uC6B0\uC800\uB97C \uC5F4 \uC218 \uC5C6\uC5B4\uC694": "Could not open the browser",
  "\uAD74\uC808 \uBD88\uAC00 \xB7 \uBC18\uD22C\uBA85": "Translucent mode",
  "{date} \xB7 \uC77C\uC815 \uC788\uC74C": "{date} \xB7 Has events",
  "\u2193 \uB2E4\uC6B4\uB85C\uB4DC": "\u2193 Download",
  "\u2191 \uC5C5\uB85C\uB4DC": "\u2191 Upload",
  "\uD45C\uC2DC\uD560 \uB3C4\uC2DC\uB97C \uC120\uD0DD\uD558\uC138\uC694": "Select a city to display",
  "\uC124\uC815\uC5D0\uC11C \uCE98\uB9B0\uB354\uB97C \uC5F0\uACB0\uD558\uC138\uC694": "Connect a calendar",
  "\uC5F0\uACB0\uB418\uBA74 \uC815\uBCF4\uB97C \uD45C\uC2DC\uD574\uC694": "Waiting for connection",
  "\uC608\uC815\uB41C \uC77C\uC815 \uC5C6\uC74C": "No upcoming events",
  "\uC81C\uBAA9 \uC5C6\uB294 \uC77C\uC815": "Untitled event",
  "\uC885\uC77C": "All day",
  "\uB0A0\uC528 \uC2DC\uAC04\uB300\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694": "Check the weather time zone",
  "\uB0A0\uC528 \uC815\uBCF4 \uC5C6\uC74C": "Weather unavailable",
  "\uB9D1\uC74C": "Clear",
  "\uAD6C\uB984 \uC870\uAE08": "Partly cloudy",
  "\uD750\uB9BC": "Overcast",
  "\uC548\uAC1C": "Fog",
  "\uC774\uC2AC\uBE44": "Drizzle",
  "\uBE44": "Rain",
  "\uB208": "Snow",
  "\uB1CC\uC6B0": "Thunderstorm",
  "\uCD5C\uADFC 60\uCD08 \uB124\uD2B8\uC6CC\uD06C \uC18D\uB3C4 \xB7 \uC2E4\uC120 \uB2E4\uC6B4\uB85C\uB4DC, \uC810\uC120 \uC5C5\uB85C\uB4DC": "Network speed over the last 60 seconds \xB7 Solid: download, dashed: upload",
  "\uCE21\uC815 \uC911": "Measuring\u2026",
  "CPU \uCE21\uC815 \uC911": "Measuring CPU\u2026",
  "CPU \uC628\uB3C4 \uC13C\uC11C \uC5C6\uC74C": "CPU temperature sensor unavailable",
  "CPU \uC628\uB3C4  {value}\xB0C": "CPU temperature  {value}\xB0C",
  "\uC81C\uBAA9 \uC5C6\uB294 \uACE1": "Untitled track",
  "\uC544\uD2F0\uC2A4\uD2B8 \uC815\uBCF4 \uC5C6\uC74C": "Unknown artist",
  "\uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694": "Check your connection",
  "\uB370\uC774\uD130\uB97C \uC77D\uC744 \uC218 \uC5C6\uC5B4\uC694": "Could not read the data",
  "\uB370\uC774\uD130\uAC00 \uB108\uBB34 \uCEE4\uC694": "Data is too large",
  "\uC77C\uC815\uC774 \uB108\uBB34 \uB9CE\uC544\uC694": "Too many events",
  "\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uC77C\uC815 \uD615\uC2DD": "Unsupported calendar format",
  "\uC2DC\uAC04\uB300\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694": "Check the time zone",
  "\uD0A4\uB9C1 \uC7A0\uAE08\uC744 \uD574\uC81C\uD574 \uC8FC\uC138\uC694": "Unlock the keyring",
  "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C\uB97C \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694": "Retry deleting connection details",
  "\uCE98\uB9B0\uB354 \uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694": "Check the calendar connection",
  "\uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4": "Retrying shortly",
  "\uC7AC\uC0DD \uC911\uC778 \uC74C\uC545 \uC5C6\uC74C": "No music playing",
  "\uB124\uD2B8\uC6CC\uD06C\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694": "Check the network",
  "\uB370\uC774\uD130\uB97C \uAE30\uB2E4\uB9AC\uB294 \uC911": "Waiting for data",
  "\uB2E4\uC2DC \uC5F0\uACB0\uD558\uB294 \uC911": "Reconnecting",
  "\uB370\uC774\uD130 \uC11C\uBE44\uC2A4 \uC5F0\uACB0 \uB300\uAE30": "Waiting for the data service",
  "\uC5F0\uACB0 \uB04A\uAE40 \xB7 \uB9C8\uC9C0\uB9C9 \uB370\uC774\uD130": "Disconnected \xB7 Last available data",
  "\uC124\uC815\uC774 \uD544\uC694\uD574\uC694": "Setup required",
  "\uC5C5\uB370\uC774\uD2B8 \uC911\u2026": "Updating\u2026",
  "\uB370\uC774\uD130\uB97C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC5B4\uC694": "Data unavailable",
  "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C\uAC00 \uB0A8\uC544 \uC788\uC5B4\uC694. \uD0A4\uB9C1\uC744 \uD574\uC81C\uD558\uACE0 \uB2E4\uC2DC \uC0AD\uC81C\uD574 \uC8FC\uC138\uC694.": "Connection details still need deletion. Unlock the keyring and delete them again.",
  "\uC5F0\uACB0\uD558\uC9C0 \uC54A\uC74C": "Not connected",
  "\uC5F0\uACB0 \uC815\uBCF4 \uC800\uC7A5\uB428 \xB7 \uB370\uC774\uD130 \uC11C\uBE44\uC2A4 \uC5F0\uACB0 \uB300\uAE30": "Connection saved \xB7 Waiting for the data service",
  "\uB3D9\uAE30\uD654 \uC644\uB8CC \xB7 \uD45C\uC2DC \uBC94\uC704\uC758 \uC77C\uC815 {count}\uAC1C": "Synced \xB7 Events in range: {count}",
  "\uC77C\uC815\uC744 \uBD88\uB7EC\uC624\uB294 \uC911\u2026": "Loading events\u2026",
  "\uC77C\uC815 \uAC31\uC2E0 \uC911 \xB7 \uB9C8\uC9C0\uB9C9 \uB3D9\uAE30\uD654 \uB370\uC774\uD130 \uD45C\uC2DC": "Refreshing events \xB7 Showing last synced data",
  "{message} \xB7 \uB9C8\uC9C0\uB9C9 \uB3D9\uAE30\uD654 \uB370\uC774\uD130 \uD45C\uC2DC": "{message} \xB7 Showing last synced data"
};
function language(value) {
  return value === "en" ? "en" : "ko";
}
function translate(value, message, values = {}) {
  const template = value === "en" ? messages[message] : message;
  return template.replace(/\{(\w+)\}/g, (original, key) => String(values[key] ?? original));
}
var TextBindings = class {
  targets = /* @__PURE__ */ new Map();
  listeners = /* @__PURE__ */ new Set();
  language;
  constructor(value) {
    this.language = language(value);
  }
  t(message, values) {
    return translate(this.language, message, values);
  }
  bind(target, properties) {
    let bindings = this.targets.get(target);
    if (!bindings) {
      bindings = /* @__PURE__ */ new Map();
      this.targets.set(target, bindings);
    }
    for (const [property, source] of Object.entries(properties)) {
      const read = typeof source === "function" ? source : () => this.t(source);
      bindings.set(property, read);
      Reflect.set(target, property, read());
    }
    return target;
  }
  onChange(callback) {
    this.listeners.add(callback);
  }
  setLanguage(value) {
    this.language = language(value);
    for (const [target, properties] of this.targets) for (const [property, read] of properties) Reflect.set(target, property, read());
    for (const listener of this.listeners) listener();
  }
  unbind(target) {
    this.targets.delete(target);
  }
  destroy() {
    this.targets.clear();
    this.listeners.clear();
  }
};

// src/prefs/language.ts
function onPreferencesClosed(window, cleanup) {
  let closed = false;
  const release = () => {
    if (!closed) {
      closed = true;
      cleanup();
    }
  };
  window.connect("close-request", () => {
    release();
    return false;
  });
  window.connect("destroy", release);
}
function preferencesLanguage(window, settings2) {
  const ui = new TextBindings(settings2.get_string("language"));
  const signal = settings2.connect("changed::language", () => ui.setLanguage(settings2.get_string("language")));
  onPreferencesClosed(window, () => {
    settings2.disconnect(signal);
    ui.destroy();
  });
  return ui;
}
function addLanguageSettings(page, settings2, ui) {
  const group = ui.bind(new Adw.PreferencesGroup(), { title: "\uD45C\uC2DC \uC5B8\uC5B4" });
  const values = ["ko", "en"];
  const row = ui.bind(new Adw.ComboRow({ model: Gtk.StringList.new(["\uD55C\uAD6D\uC5B4", "English"]), selected: values.indexOf(ui.language) }), { title: "\uC5B8\uC5B4 / Language", subtitle: "\uC704\uC82F\uACFC \uC124\uC815\uC5D0 \uBC14\uB85C \uC801\uC6A9\uB429\uB2C8\uB2E4." });
  row.connect("notify::selected", () => {
    const value = values[row.selected];
    if (value && value !== settings2.get_string("language")) settings2.set_string("language", value);
  });
  ui.onChange(() => {
    row.selected = values.indexOf(ui.language);
  });
  group.add(row);
  page.add(group);
}

// src/prefs/weather.ts
import Adw2 from "gi://Adw";
import Gtk2 from "gi://Gtk?version=4.0";

// generated/validators.js
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var require_formats = __commonJS({
  "node_modules/ajv-formats/dist/formats.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.formatNames = exports.fastFormats = exports.fullFormats = void 0;
    function fmtDef(validate, compare) {
      return { validate, compare };
    }
    exports.fullFormats = {
      // date: http://tools.ietf.org/html/rfc3339#section-5.6
      date: fmtDef(date, compareDate),
      // date-time: http://tools.ietf.org/html/rfc3339#section-5.6
      time: fmtDef(getTime(true), compareTime),
      "date-time": fmtDef(getDateTime(true), compareDateTime),
      "iso-time": fmtDef(getTime(), compareIsoTime),
      "iso-date-time": fmtDef(getDateTime(), compareIsoDateTime),
      // duration: https://tools.ietf.org/html/rfc3339#appendix-A
      duration: /^P(?!$)((\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+S)?)?|(\d+W)?)$/,
      uri,
      "uri-reference": /^(?:[a-z][a-z0-9+\-.]*:)?(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'"()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?(?:\?(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i,
      // uri-template: https://tools.ietf.org/html/rfc6570
      "uri-template": /^(?:(?:[^\x00-\x20"'<>%\\^`{|}]|%[0-9a-f]{2})|\{[+#./;?&=,!@|]?(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?(?:,(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?)*\})*$/i,
      // For the source: https://gist.github.com/dperini/729294
      // For test cases: https://mathiasbynens.be/demo/url-regex
      url: /^(?:https?|ftp):\/\/(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)(?:\.(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)*(?:\.(?:[a-z\u{00a1}-\u{ffff}]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/iu,
      email: /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i,
      hostname: /^(?=.{1,253}\.?$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[-0-9a-z]{0,61}[0-9a-z])?)*\.?$/i,
      // optimized https://www.safaribooksonline.com/library/view/regular-expressions-cookbook/9780596802837/ch07s16.html
      ipv4: /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/,
      ipv6: /^((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))$/i,
      regex,
      // uuid: http://tools.ietf.org/html/rfc4122
      uuid: /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i,
      // JSON-pointer: https://tools.ietf.org/html/rfc6901
      // uri fragment: https://tools.ietf.org/html/rfc3986#appendix-A
      "json-pointer": /^(?:\/(?:[^~/]|~0|~1)*)*$/,
      "json-pointer-uri-fragment": /^#(?:\/(?:[a-z0-9_\-.!$&'()*+,;:=@]|%[0-9a-f]{2}|~0|~1)*)*$/i,
      // relative JSON-pointer: http://tools.ietf.org/html/draft-luff-relative-json-pointer-00
      "relative-json-pointer": /^(?:0|[1-9][0-9]*)(?:#|(?:\/(?:[^~/]|~0|~1)*)*)$/,
      // the following formats are used by the openapi specification: https://spec.openapis.org/oas/v3.0.0#data-types
      // byte: https://github.com/miguelmota/is-base64
      byte,
      // signed 32 bit integer
      int32: { type: "number", validate: validateInt32 },
      // signed 64 bit integer
      int64: { type: "number", validate: validateInt64 },
      // C-type float
      float: { type: "number", validate: validateNumber },
      // C-type double
      double: { type: "number", validate: validateNumber },
      // hint to the UI to hide input strings
      password: true,
      // unchecked string payload
      binary: true
    };
    exports.fastFormats = {
      ...exports.fullFormats,
      date: fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\d$/, compareDate),
      time: fmtDef(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, compareTime),
      "date-time": fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\dt(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, compareDateTime),
      "iso-time": fmtDef(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, compareIsoTime),
      "iso-date-time": fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\d[t\s](?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, compareIsoDateTime),
      // uri: https://github.com/mafintosh/is-my-json-valid/blob/master/formats.js
      uri: /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/)?[^\s]*$/i,
      "uri-reference": /^(?:(?:[a-z][a-z0-9+\-.]*:)?\/?\/)?(?:[^\\\s#][^\s#]*)?(?:#[^\\\s]*)?$/i,
      // email (sources from jsen validator):
      // http://stackoverflow.com/questions/201323/using-a-regular-expression-to-validate-an-email-address#answer-8829363
      // http://www.w3.org/TR/html5/forms.html#valid-e-mail-address (search for 'wilful violation')
      email: /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i
    };
    exports.formatNames = Object.keys(exports.fullFormats);
    function isLeapYear(year) {
      return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    }
    var DATE = /^(\d\d\d\d)-(\d\d)-(\d\d)$/;
    var DAYS = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    function date(str) {
      const matches = DATE.exec(str);
      if (!matches)
        return false;
      const year = +matches[1];
      const month = +matches[2];
      const day = +matches[3];
      return month >= 1 && month <= 12 && day >= 1 && day <= (month === 2 && isLeapYear(year) ? 29 : DAYS[month]);
    }
    function compareDate(d1, d2) {
      if (!(d1 && d2))
        return void 0;
      if (d1 > d2)
        return 1;
      if (d1 < d2)
        return -1;
      return 0;
    }
    var TIME = /^(\d\d):(\d\d):(\d\d(?:\.\d+)?)(z|([+-])(\d\d)(?::?(\d\d))?)?$/i;
    function getTime(strictTimeZone) {
      return function time(str) {
        const matches = TIME.exec(str);
        if (!matches)
          return false;
        const hr = +matches[1];
        const min = +matches[2];
        const sec = +matches[3];
        const tz = matches[4];
        const tzSign = matches[5] === "-" ? -1 : 1;
        const tzH = +(matches[6] || 0);
        const tzM = +(matches[7] || 0);
        if (tzH > 23 || tzM > 59 || strictTimeZone && !tz)
          return false;
        if (hr <= 23 && min <= 59 && sec < 60)
          return true;
        const utcMin = min - tzM * tzSign;
        const utcHr = hr - tzH * tzSign - (utcMin < 0 ? 1 : 0);
        return (utcHr === 23 || utcHr === -1) && (utcMin === 59 || utcMin === -1) && sec < 61;
      };
    }
    function compareTime(s1, s2) {
      if (!(s1 && s2))
        return void 0;
      const t1 = (/* @__PURE__ */ new Date("2020-01-01T" + s1)).valueOf();
      const t2 = (/* @__PURE__ */ new Date("2020-01-01T" + s2)).valueOf();
      if (!(t1 && t2))
        return void 0;
      return t1 - t2;
    }
    function compareIsoTime(t1, t2) {
      if (!(t1 && t2))
        return void 0;
      const a1 = TIME.exec(t1);
      const a2 = TIME.exec(t2);
      if (!(a1 && a2))
        return void 0;
      t1 = a1[1] + a1[2] + a1[3];
      t2 = a2[1] + a2[2] + a2[3];
      if (t1 > t2)
        return 1;
      if (t1 < t2)
        return -1;
      return 0;
    }
    var DATE_TIME_SEPARATOR = /t|\s/i;
    function getDateTime(strictTimeZone) {
      const time = getTime(strictTimeZone);
      return function date_time(str) {
        const dateTime = str.split(DATE_TIME_SEPARATOR);
        return dateTime.length === 2 && date(dateTime[0]) && time(dateTime[1]);
      };
    }
    function compareDateTime(dt1, dt2) {
      if (!(dt1 && dt2))
        return void 0;
      const d1 = new Date(dt1).valueOf();
      const d2 = new Date(dt2).valueOf();
      if (!(d1 && d2))
        return void 0;
      return d1 - d2;
    }
    function compareIsoDateTime(dt1, dt2) {
      if (!(dt1 && dt2))
        return void 0;
      const [d1, t1] = dt1.split(DATE_TIME_SEPARATOR);
      const [d2, t2] = dt2.split(DATE_TIME_SEPARATOR);
      const res = compareDate(d1, d2);
      if (res === void 0)
        return void 0;
      return res || compareTime(t1, t2);
    }
    var NOT_URI_FRAGMENT = /\/|:/;
    var URI = /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)(?:\?(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
    function uri(str) {
      return NOT_URI_FRAGMENT.test(str) && URI.test(str);
    }
    var BYTE = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/gm;
    function byte(str) {
      BYTE.lastIndex = 0;
      return BYTE.test(str);
    }
    var MIN_INT32 = -(2 ** 31);
    var MAX_INT32 = 2 ** 31 - 1;
    function validateInt32(value) {
      return Number.isInteger(value) && value <= MAX_INT32 && value >= MIN_INT32;
    }
    function validateInt64(value) {
      return Number.isInteger(value);
    }
    function validateNumber() {
      return true;
    }
    var Z_ANCHOR = /[^\\]\\Z/;
    function regex(str) {
      if (Z_ANCHOR.test(str))
        return false;
      try {
        new RegExp(str);
        return true;
      } catch (e) {
        return false;
      }
    }
  }
});
var require_ucs2length = __commonJS({
  "node_modules/ajv/dist/runtime/ucs2length.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function ucs2length(str) {
      const len = str.length;
      let length = 0;
      let pos = 0;
      let value;
      while (pos < len) {
        length++;
        value = str.charCodeAt(pos++);
        if (value >= 55296 && value <= 56319 && pos < len) {
          value = str.charCodeAt(pos);
          if ((value & 64512) === 56320)
            pos++;
        }
      }
      return length;
    }
    exports.default = ucs2length;
    ucs2length.code = 'require("ajv/dist/runtime/ucs2length").default';
  }
});
var snapshot = validate20;
var formats0 = require_formats().fullFormats["date-time"];
var func1 = require_ucs2length().default;
var schema32 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/CalendarData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/CalendarData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
var pattern4 = new RegExp("^[0-9]{4}-(0[1-9]|1[0-2])$", "u");
var formats2 = require_formats().fullFormats.date;
function validate22(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate22.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.month === void 0 && (missing0 = "month") || data.timeZone === void 0 && (missing0 = "timeZone") || data.weekStart === void 0 && (missing0 = "weekStart") || data.events === void 0 && (missing0 = "events")) {
        validate22.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "month" || key0 === "timeZone" || key0 === "weekStart" || key0 === "events")) {
            validate22.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.month !== void 0) {
            let data0 = data.month;
            const _errs2 = errors2;
            if (errors2 === _errs2) {
              if (typeof data0 === "string") {
                if (func1(data0) > 7) {
                  validate22.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                  return false;
                } else {
                  if (!pattern4.test(data0)) {
                    validate22.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                    return false;
                  }
                }
              } else {
                validate22.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.timeZone !== void 0) {
              let data1 = data.timeZone;
              const _errs4 = errors2;
              if (errors2 === _errs4) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 255) {
                    validate22.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate22.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate22.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs4 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weekStart !== void 0) {
                let data2 = data.weekStart;
                const _errs6 = errors2;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate22.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors2 === _errs6) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 6 || isNaN(data2)) {
                      validate22.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate22.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs6 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.events !== void 0) {
                  let data3 = data.events;
                  const _errs8 = errors2;
                  if (errors2 === _errs8) {
                    if (Array.isArray(data3)) {
                      if (data3.length > 1e4) {
                        validate22.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/maxItems", keyword: "maxItems", params: { limit: 1e4 }, message: "must NOT have more than 10000 items" }];
                        return false;
                      } else {
                        var valid1 = true;
                        const len0 = data3.length;
                        for (let i0 = 0; i0 < len0; i0++) {
                          let data4 = data3[i0];
                          const _errs10 = errors2;
                          const _errs11 = errors2;
                          const _errs14 = errors2;
                          let valid4 = true;
                          const _errs15 = errors2;
                          if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                            if (data4.allDay !== void 0) {
                              if (true !== data4.allDay) {
                                const err0 = {};
                                if (vErrors === null) {
                                  vErrors = [err0];
                                } else {
                                  vErrors.push(err0);
                                }
                                errors2++;
                              }
                            }
                          }
                          var _valid0 = _errs15 === errors2;
                          errors2 = _errs14;
                          if (vErrors !== null) {
                            if (_errs14) {
                              vErrors.length = _errs14;
                            } else {
                              vErrors = null;
                            }
                          }
                          let ifClause0;
                          if (_valid0) {
                            const _errs17 = errors2;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data6 = data4.start;
                                const _errs18 = errors2;
                                if (errors2 === _errs18) {
                                  if (errors2 === _errs18) {
                                    if (typeof data6 === "string") {
                                      if (func1(data6) > 10) {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                        return false;
                                      } else {
                                        if (!formats2.validate(data6)) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid6 = _errs18 === errors2;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.end !== void 0) {
                                  let data7 = data4.end;
                                  const _errs20 = errors2;
                                  if (errors2 === _errs20) {
                                    if (errors2 === _errs20) {
                                      if (typeof data7 === "string") {
                                        if (func1(data7) > 10) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                          return false;
                                        } else {
                                          if (!formats2.validate(data7)) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid6 = _errs20 === errors2;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                            var _valid0 = _errs17 === errors2;
                            valid4 = _valid0;
                            if (valid4) {
                              var props0 = {};
                              props0.start = true;
                              props0.end = true;
                              props0.allDay = true;
                            }
                            ifClause0 = "then";
                          } else {
                            const _errs22 = errors2;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data8 = data4.start;
                                const _errs23 = errors2;
                                if (errors2 === _errs23) {
                                  if (errors2 === _errs23) {
                                    if (typeof data8 === "string") {
                                      if (func1(data8) > 64) {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                        return false;
                                      } else {
                                        if (!formats0.validate(data8)) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid7 = _errs23 === errors2;
                              } else {
                                var valid7 = true;
                              }
                              if (valid7) {
                                if (data4.end !== void 0) {
                                  let data9 = data4.end;
                                  const _errs25 = errors2;
                                  if (errors2 === _errs25) {
                                    if (errors2 === _errs25) {
                                      if (typeof data9 === "string") {
                                        if (func1(data9) > 64) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                          return false;
                                        } else {
                                          if (!formats0.validate(data9)) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid7 = _errs25 === errors2;
                                } else {
                                  var valid7 = true;
                                }
                              }
                            }
                            var _valid0 = _errs22 === errors2;
                            valid4 = _valid0;
                            if (valid4) {
                              if (props0 !== true) {
                                props0 = props0 || {};
                                props0.start = true;
                                props0.end = true;
                              }
                            }
                            ifClause0 = "else";
                          }
                          if (!valid4) {
                            const err1 = { instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/allOf/0/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
                            if (vErrors === null) {
                              vErrors = [err1];
                            } else {
                              vErrors.push(err1);
                            }
                            errors2++;
                            validate22.errors = vErrors;
                            return false;
                          }
                          if (errors2 === _errs11) {
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              let missing1;
                              if (data4.uid === void 0 && (missing1 = "uid") || data4.occurrenceKey === void 0 && (missing1 = "occurrenceKey") || data4.title === void 0 && (missing1 = "title") || data4.start === void 0 && (missing1 = "start") || data4.end === void 0 && (missing1 = "end") || data4.allDay === void 0 && (missing1 = "allDay")) {
                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                return false;
                              } else {
                                const _errs27 = errors2;
                                for (const key1 in data4) {
                                  if (!(key1 === "uid" || key1 === "occurrenceKey" || key1 === "title" || key1 === "start" || key1 === "end" || key1 === "allDay")) {
                                    validate22.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                    return false;
                                    break;
                                  }
                                }
                                if (_errs27 === errors2) {
                                  if (data4.uid !== void 0) {
                                    let data10 = data4.uid;
                                    const _errs28 = errors2;
                                    if (errors2 === _errs28) {
                                      if (typeof data10 === "string") {
                                        if (func1(data10) > 2048) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/maxLength", keyword: "maxLength", params: { limit: 2048 }, message: "must NOT have more than 2048 characters" }];
                                          return false;
                                        } else {
                                          if (func1(data10) < 1) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                    var valid8 = _errs28 === errors2;
                                  } else {
                                    var valid8 = true;
                                  }
                                  if (valid8) {
                                    if (data4.occurrenceKey !== void 0) {
                                      let data11 = data4.occurrenceKey;
                                      const _errs30 = errors2;
                                      if (errors2 === _errs30) {
                                        if (typeof data11 === "string") {
                                          if (func1(data11) > 64) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                            return false;
                                          } else {
                                            if (func1(data11) < 1) {
                                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                              return false;
                                            }
                                          }
                                        } else {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                          return false;
                                        }
                                      }
                                      var valid8 = _errs30 === errors2;
                                    } else {
                                      var valid8 = true;
                                    }
                                    if (valid8) {
                                      if (data4.title !== void 0) {
                                        let data12 = data4.title;
                                        const _errs32 = errors2;
                                        if (errors2 === _errs32) {
                                          if (typeof data12 === "string") {
                                            if (func1(data12) > 4096) {
                                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                                              return false;
                                            }
                                          } else {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                            return false;
                                          }
                                        }
                                        var valid8 = _errs32 === errors2;
                                      } else {
                                        var valid8 = true;
                                      }
                                      if (valid8) {
                                        if (data4.start !== void 0) {
                                          let data13 = data4.start;
                                          const _errs34 = errors2;
                                          if (errors2 === _errs34) {
                                            if (typeof data13 === "string") {
                                              if (func1(data13) > 64) {
                                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                return false;
                                              }
                                            } else {
                                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                              return false;
                                            }
                                          }
                                          var valid8 = _errs34 === errors2;
                                        } else {
                                          var valid8 = true;
                                        }
                                        if (valid8) {
                                          if (data4.end !== void 0) {
                                            let data14 = data4.end;
                                            const _errs36 = errors2;
                                            if (errors2 === _errs36) {
                                              if (typeof data14 === "string") {
                                                if (func1(data14) > 64) {
                                                  validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                }
                                              } else {
                                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                            var valid8 = _errs36 === errors2;
                                          } else {
                                            var valid8 = true;
                                          }
                                          if (valid8) {
                                            if (data4.allDay !== void 0) {
                                              const _errs38 = errors2;
                                              if (typeof data4.allDay !== "boolean") {
                                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/allDay", schemaPath: "#/$defs/CalendarEvent/properties/allDay/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                                                return false;
                                              }
                                              var valid8 = _errs38 === errors2;
                                            } else {
                                              var valid8 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            } else {
                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                              return false;
                            }
                          }
                          var valid1 = _errs10 === errors2;
                          if (!valid1) {
                            break;
                          }
                        }
                      }
                    } else {
                      validate22.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                      return false;
                    }
                  }
                  var valid0 = _errs8 === errors2;
                } else {
                  var valid0 = true;
                }
              }
            }
          }
        }
      }
    } else {
      validate22.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate22.errors = vErrors;
  return errors2 === 0;
}
validate22.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var pattern5 = new RegExp("^[A-Za-z0-9_-]+$", "u");
function validate21(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate21.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        const _errs6 = errors2;
        if (!validate22(data.data, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
          vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
          errors2 = vErrors.length;
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data2 = data.updatedAt;
          const _errs7 = errors2;
          if (errors2 === _errs7) {
            if (errors2 === _errs7) {
              if (typeof data2 === "string") {
                if (func1(data2) > 64) {
                  validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data2)) {
                    validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs7 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err1 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err1];
    } else {
      vErrors.push(err1);
    }
    errors2++;
    validate21.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs9 = errors2;
    const _errs10 = errors2;
    let valid4 = true;
    const _errs11 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data3 = data.status;
        if (!(data3 === "unconfigured" || data3 === "unavailable")) {
          const err2 = {};
          if (vErrors === null) {
            vErrors = [err2];
          } else {
            vErrors.push(err2);
          }
          errors2++;
        }
      }
    }
    var _valid1 = _errs11 === errors2;
    errors2 = _errs10;
    if (vErrors !== null) {
      if (_errs10) {
        vErrors.length = _errs10;
      } else {
        vErrors = null;
      }
    }
    if (_valid1) {
      const _errs13 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs14 = errors2;
          if (data.data !== null) {
            validate21.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid6 = _errs14 === errors2;
        } else {
          var valid6 = true;
        }
        if (valid6) {
          if (data.updatedAt !== void 0) {
            const _errs16 = errors2;
            if (data.updatedAt !== null) {
              validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid6 = _errs16 === errors2;
          } else {
            var valid6 = true;
          }
        }
      }
      var _valid1 = _errs13 === errors2;
      valid4 = _valid1;
      if (valid4) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid4) {
      const err3 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors2++;
      validate21.errors = vErrors;
      return false;
    }
    var valid0 = _errs9 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs18 = errors2;
      const _errs19 = errors2;
      let valid7 = true;
      const _errs20 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data6 = data.status;
          if (!(data6 === "ok" || data6 === "unconfigured" || data6 === "loading")) {
            const err4 = {};
            if (vErrors === null) {
              vErrors = [err4];
            } else {
              vErrors.push(err4);
            }
            errors2++;
          }
        }
      }
      var _valid2 = _errs20 === errors2;
      errors2 = _errs19;
      if (vErrors !== null) {
        if (_errs19) {
          vErrors.length = _errs19;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid2) {
        const _errs22 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate21.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid2 = _errs22 === errors2;
        valid7 = _valid2;
        if (valid7) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs25 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data8 = data.errorCode;
            if (!(data8 === "NETWORK_ERROR" || data8 === "INVALID_DATA" || data8 === "PAYLOAD_TOO_LARGE" || data8 === "EXPANSION_LIMIT" || data8 === "UNSUPPORTED_CALENDAR" || data8 === "UNKNOWN_TIME_ZONE" || data8 === "KEYRING_LOCKED" || data8 === "SECRET_DELETION_FAILED" || data8 === "AUTH_ERROR" || data8 === "RATE_LIMITED" || data8 === "NO_PLAYER" || data8 === "NO_INTERFACE" || data8 === "SERVICE_UNAVAILABLE" || data8 === "INTERNAL_ERROR")) {
              validate21.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema32.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid2 = _errs25 === errors2;
        valid7 = _valid2;
        if (valid7) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid7) {
        const err5 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err5];
        } else {
          vErrors.push(err5);
        }
        errors2++;
        validate21.errors = vErrors;
        return false;
      }
      var valid0 = _errs18 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.status === void 0 && (missing0 = "status") || data.sourceId === void 0 && (missing0 = "sourceId") || data.updatedAt === void 0 && (missing0 = "updatedAt") || data.data === void 0 && (missing0 = "data") || data.errorCode === void 0 && (missing0 = "errorCode")) {
        validate21.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs27 = errors2;
        for (const key0 in data) {
          if (!(key0 === "status" || key0 === "sourceId" || key0 === "updatedAt" || key0 === "data" || key0 === "errorCode")) {
            validate21.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs27 === errors2) {
          if (data.status !== void 0) {
            let data9 = data.status;
            const _errs28 = errors2;
            if (!(data9 === "loading" || data9 === "ok" || data9 === "stale" || data9 === "unconfigured" || data9 === "unavailable")) {
              validate21.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema32.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid11 = _errs28 === errors2;
          } else {
            var valid11 = true;
          }
          if (valid11) {
            if (data.sourceId !== void 0) {
              let data10 = data.sourceId;
              const _errs29 = errors2;
              const _errs30 = errors2;
              let valid12 = false;
              const _errs31 = errors2;
              if (errors2 === _errs31) {
                if (typeof data10 === "string") {
                  if (func1(data10) > 128) {
                    const err6 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err6];
                    } else {
                      vErrors.push(err6);
                    }
                    errors2++;
                  } else {
                    if (func1(data10) < 1) {
                      const err7 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err7];
                      } else {
                        vErrors.push(err7);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data10)) {
                        const err8 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err9 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err9];
                  } else {
                    vErrors.push(err9);
                  }
                  errors2++;
                }
              }
              var _valid3 = _errs31 === errors2;
              valid12 = valid12 || _valid3;
              const _errs33 = errors2;
              if (data10 !== null) {
                const err10 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err10];
                } else {
                  vErrors.push(err10);
                }
                errors2++;
              }
              var _valid3 = _errs33 === errors2;
              valid12 = valid12 || _valid3;
              if (!valid12) {
                const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err11];
                } else {
                  vErrors.push(err11);
                }
                errors2++;
                validate21.errors = vErrors;
                return false;
              } else {
                errors2 = _errs30;
                if (vErrors !== null) {
                  if (_errs30) {
                    vErrors.length = _errs30;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid11 = _errs29 === errors2;
            } else {
              var valid11 = true;
            }
            if (valid11) {
              if (data.updatedAt !== void 0) {
                let data11 = data.updatedAt;
                const _errs35 = errors2;
                const _errs36 = errors2;
                let valid13 = false;
                const _errs37 = errors2;
                if (errors2 === _errs37) {
                  if (errors2 === _errs37) {
                    if (typeof data11 === "string") {
                      if (func1(data11) > 64) {
                        const err12 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err12];
                        } else {
                          vErrors.push(err12);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data11)) {
                          const err13 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err13];
                          } else {
                            vErrors.push(err13);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err14 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err14];
                      } else {
                        vErrors.push(err14);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid4 = _errs37 === errors2;
                valid13 = valid13 || _valid4;
                const _errs39 = errors2;
                if (data11 !== null) {
                  const err15 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err15];
                  } else {
                    vErrors.push(err15);
                  }
                  errors2++;
                }
                var _valid4 = _errs39 === errors2;
                valid13 = valid13 || _valid4;
                if (!valid13) {
                  const err16 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err16];
                  } else {
                    vErrors.push(err16);
                  }
                  errors2++;
                  validate21.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs36;
                  if (vErrors !== null) {
                    if (_errs36) {
                      vErrors.length = _errs36;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid11 = _errs35 === errors2;
              } else {
                var valid11 = true;
              }
              if (valid11) {
                if (data.data !== void 0) {
                  let data12 = data.data;
                  const _errs41 = errors2;
                  const _errs42 = errors2;
                  let valid14 = false;
                  const _errs43 = errors2;
                  if (!validate22(data12, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
                    vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
                    errors2 = vErrors.length;
                  }
                  var _valid5 = _errs43 === errors2;
                  valid14 = valid14 || _valid5;
                  const _errs44 = errors2;
                  if (data12 !== null) {
                    const err17 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors2++;
                  }
                  var _valid5 = _errs44 === errors2;
                  valid14 = valid14 || _valid5;
                  if (!valid14) {
                    const err18 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err18];
                    } else {
                      vErrors.push(err18);
                    }
                    errors2++;
                    validate21.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs42;
                    if (vErrors !== null) {
                      if (_errs42) {
                        vErrors.length = _errs42;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid11 = _errs41 === errors2;
                } else {
                  var valid11 = true;
                }
                if (valid11) {
                  if (data.errorCode !== void 0) {
                    let data13 = data.errorCode;
                    const _errs46 = errors2;
                    const _errs47 = errors2;
                    let valid15 = false;
                    const _errs48 = errors2;
                    if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
                      const err19 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema32.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors2++;
                    }
                    var _valid6 = _errs48 === errors2;
                    valid15 = valid15 || _valid6;
                    const _errs49 = errors2;
                    if (data13 !== null) {
                      const err20 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err20];
                      } else {
                        vErrors.push(err20);
                      }
                      errors2++;
                    }
                    var _valid6 = _errs49 === errors2;
                    valid15 = valid15 || _valid6;
                    if (!valid15) {
                      const err21 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err21];
                      } else {
                        vErrors.push(err21);
                      }
                      errors2++;
                      validate21.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs47;
                      if (vErrors !== null) {
                        if (_errs47) {
                          vErrors.length = _errs47;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid11 = _errs46 === errors2;
                  } else {
                    var valid11 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate21.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate21.errors = vErrors;
  return errors2 === 0;
}
validate21.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema35 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/WeatherData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/WeatherData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
var pattern6 = new RegExp("^https://", "u");
function validate26(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate26.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.location === void 0 && (missing0 = "location") || data1.timeZone === void 0 && (missing0 = "timeZone") || data1.current === void 0 && (missing0 = "current") || data1.hourly === void 0 && (missing0 = "hourly") || data1.attributionUrl === void 0 && (missing0 = "attributionUrl")) {
              validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "location" || key0 === "timeZone" || key0 === "current" || key0 === "hourly" || key0 === "attributionUrl")) {
                  validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.location !== void 0) {
                  let data2 = data1.location;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 512) {
                        validate26.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                        return false;
                      }
                    } else {
                      validate26.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.timeZone !== void 0) {
                    let data3 = data1.timeZone;
                    const _errs12 = errors2;
                    if (errors2 === _errs12) {
                      if (typeof data3 === "string") {
                        if (func1(data3) > 255) {
                          validate26.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                          return false;
                        } else {
                          if (func1(data3) < 1) {
                            validate26.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          }
                        }
                      } else {
                        validate26.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.current !== void 0) {
                      let data4 = data1.current;
                      const _errs14 = errors2;
                      if (errors2 === _errs14) {
                        if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                          let missing1;
                          if (data4.temperatureC === void 0 && (missing1 = "temperatureC") || data4.code === void 0 && (missing1 = "code")) {
                            validate26.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                            return false;
                          } else {
                            const _errs16 = errors2;
                            for (const key1 in data4) {
                              if (!(key1 === "temperatureC" || key1 === "code")) {
                                validate26.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                return false;
                                break;
                              }
                            }
                            if (_errs16 === errors2) {
                              if (data4.temperatureC !== void 0) {
                                let data5 = data4.temperatureC;
                                const _errs17 = errors2;
                                const _errs18 = errors2;
                                let valid7 = false;
                                const _errs19 = errors2;
                                if (!(typeof data5 == "number" && isFinite(data5))) {
                                  const err1 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err1];
                                  } else {
                                    vErrors.push(err1);
                                  }
                                  errors2++;
                                }
                                var _valid1 = _errs19 === errors2;
                                valid7 = valid7 || _valid1;
                                const _errs21 = errors2;
                                if (data5 !== null) {
                                  const err2 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors2++;
                                }
                                var _valid1 = _errs21 === errors2;
                                valid7 = valid7 || _valid1;
                                if (!valid7) {
                                  const err3 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err3];
                                  } else {
                                    vErrors.push(err3);
                                  }
                                  errors2++;
                                  validate26.errors = vErrors;
                                  return false;
                                } else {
                                  errors2 = _errs18;
                                  if (vErrors !== null) {
                                    if (_errs18) {
                                      vErrors.length = _errs18;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid6 = _errs17 === errors2;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.code !== void 0) {
                                  let data6 = data4.code;
                                  const _errs23 = errors2;
                                  const _errs24 = errors2;
                                  let valid8 = false;
                                  const _errs25 = errors2;
                                  if (!(typeof data6 == "number" && (!(data6 % 1) && !isNaN(data6)) && isFinite(data6))) {
                                    const err4 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err4];
                                    } else {
                                      vErrors.push(err4);
                                    }
                                    errors2++;
                                  }
                                  if (errors2 === _errs25) {
                                    if (typeof data6 == "number" && isFinite(data6)) {
                                      if (data6 > 99 || isNaN(data6)) {
                                        const err5 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                        if (vErrors === null) {
                                          vErrors = [err5];
                                        } else {
                                          vErrors.push(err5);
                                        }
                                        errors2++;
                                      } else {
                                        if (data6 < 0 || isNaN(data6)) {
                                          const err6 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                          if (vErrors === null) {
                                            vErrors = [err6];
                                          } else {
                                            vErrors.push(err6);
                                          }
                                          errors2++;
                                        }
                                      }
                                    }
                                  }
                                  var _valid2 = _errs25 === errors2;
                                  valid8 = valid8 || _valid2;
                                  const _errs27 = errors2;
                                  if (data6 !== null) {
                                    const err7 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err7];
                                    } else {
                                      vErrors.push(err7);
                                    }
                                    errors2++;
                                  }
                                  var _valid2 = _errs27 === errors2;
                                  valid8 = valid8 || _valid2;
                                  if (!valid8) {
                                    const err8 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors2++;
                                    validate26.errors = vErrors;
                                    return false;
                                  } else {
                                    errors2 = _errs24;
                                    if (vErrors !== null) {
                                      if (_errs24) {
                                        vErrors.length = _errs24;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid6 = _errs23 === errors2;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                          }
                        } else {
                          validate26.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                          return false;
                        }
                      }
                      var valid5 = _errs14 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.hourly !== void 0) {
                        let data7 = data1.hourly;
                        const _errs29 = errors2;
                        if (errors2 === _errs29) {
                          if (Array.isArray(data7)) {
                            if (data7.length > 6) {
                              validate26.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" }];
                              return false;
                            } else {
                              var valid9 = true;
                              const len0 = data7.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data8 = data7[i0];
                                const _errs31 = errors2;
                                if (errors2 === _errs31) {
                                  if (data8 && typeof data8 == "object" && !Array.isArray(data8)) {
                                    let missing2;
                                    if (data8.at === void 0 && (missing2 = "at") || data8.temperatureC === void 0 && (missing2 = "temperatureC") || data8.precipitationProbability === void 0 && (missing2 = "precipitationProbability")) {
                                      validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
                                      return false;
                                    } else {
                                      const _errs33 = errors2;
                                      for (const key2 in data8) {
                                        if (!(key2 === "at" || key2 === "temperatureC" || key2 === "precipitationProbability")) {
                                          validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs33 === errors2) {
                                        if (data8.at !== void 0) {
                                          let data9 = data8.at;
                                          const _errs34 = errors2;
                                          if (errors2 === _errs34) {
                                            if (errors2 === _errs34) {
                                              if (typeof data9 === "string") {
                                                if (func1(data9) > 64) {
                                                  validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data9)) {
                                                    validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid10 = _errs34 === errors2;
                                        } else {
                                          var valid10 = true;
                                        }
                                        if (valid10) {
                                          if (data8.temperatureC !== void 0) {
                                            let data10 = data8.temperatureC;
                                            const _errs36 = errors2;
                                            const _errs37 = errors2;
                                            let valid11 = false;
                                            const _errs38 = errors2;
                                            if (!(typeof data10 == "number" && isFinite(data10))) {
                                              const err9 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                              if (vErrors === null) {
                                                vErrors = [err9];
                                              } else {
                                                vErrors.push(err9);
                                              }
                                              errors2++;
                                            }
                                            var _valid3 = _errs38 === errors2;
                                            valid11 = valid11 || _valid3;
                                            const _errs40 = errors2;
                                            if (data10 !== null) {
                                              const err10 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err10];
                                              } else {
                                                vErrors.push(err10);
                                              }
                                              errors2++;
                                            }
                                            var _valid3 = _errs40 === errors2;
                                            valid11 = valid11 || _valid3;
                                            if (!valid11) {
                                              const err11 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err11];
                                              } else {
                                                vErrors.push(err11);
                                              }
                                              errors2++;
                                              validate26.errors = vErrors;
                                              return false;
                                            } else {
                                              errors2 = _errs37;
                                              if (vErrors !== null) {
                                                if (_errs37) {
                                                  vErrors.length = _errs37;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid10 = _errs36 === errors2;
                                          } else {
                                            var valid10 = true;
                                          }
                                          if (valid10) {
                                            if (data8.precipitationProbability !== void 0) {
                                              let data11 = data8.precipitationProbability;
                                              const _errs42 = errors2;
                                              const _errs43 = errors2;
                                              let valid12 = false;
                                              const _errs44 = errors2;
                                              if (errors2 === _errs44) {
                                                if (typeof data11 == "number" && isFinite(data11)) {
                                                  if (data11 > 100 || isNaN(data11)) {
                                                    const err12 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                    if (vErrors === null) {
                                                      vErrors = [err12];
                                                    } else {
                                                      vErrors.push(err12);
                                                    }
                                                    errors2++;
                                                  } else {
                                                    if (data11 < 0 || isNaN(data11)) {
                                                      const err13 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                      if (vErrors === null) {
                                                        vErrors = [err13];
                                                      } else {
                                                        vErrors.push(err13);
                                                      }
                                                      errors2++;
                                                    }
                                                  }
                                                } else {
                                                  const err14 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                  if (vErrors === null) {
                                                    vErrors = [err14];
                                                  } else {
                                                    vErrors.push(err14);
                                                  }
                                                  errors2++;
                                                }
                                              }
                                              var _valid4 = _errs44 === errors2;
                                              valid12 = valid12 || _valid4;
                                              const _errs46 = errors2;
                                              if (data11 !== null) {
                                                const err15 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                if (vErrors === null) {
                                                  vErrors = [err15];
                                                } else {
                                                  vErrors.push(err15);
                                                }
                                                errors2++;
                                              }
                                              var _valid4 = _errs46 === errors2;
                                              valid12 = valid12 || _valid4;
                                              if (!valid12) {
                                                const err16 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                if (vErrors === null) {
                                                  vErrors = [err16];
                                                } else {
                                                  vErrors.push(err16);
                                                }
                                                errors2++;
                                                validate26.errors = vErrors;
                                                return false;
                                              } else {
                                                errors2 = _errs43;
                                                if (vErrors !== null) {
                                                  if (_errs43) {
                                                    vErrors.length = _errs43;
                                                  } else {
                                                    vErrors = null;
                                                  }
                                                }
                                              }
                                              var valid10 = _errs42 === errors2;
                                            } else {
                                              var valid10 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid9 = _errs31 === errors2;
                                if (!valid9) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate26.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs29 === errors2;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.attributionUrl !== void 0) {
                          let data12 = data1.attributionUrl;
                          const _errs48 = errors2;
                          if (errors2 === _errs48) {
                            if (typeof data12 === "string") {
                              if (func1(data12) > 512) {
                                validate26.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                                return false;
                              } else {
                                if (!pattern6.test(data12)) {
                                  validate26.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' }];
                                  return false;
                                }
                              }
                            } else {
                              validate26.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                              return false;
                            }
                          }
                          var valid5 = _errs48 === errors2;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data13 = data.updatedAt;
          const _errs50 = errors2;
          if (errors2 === _errs50) {
            if (errors2 === _errs50) {
              if (typeof data13 === "string") {
                if (func1(data13) > 64) {
                  validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data13)) {
                    validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs50 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err17 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err17];
    } else {
      vErrors.push(err17);
    }
    errors2++;
    validate26.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs52 = errors2;
    const _errs53 = errors2;
    let valid13 = true;
    const _errs54 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data14 = data.status;
        if (!(data14 === "unconfigured" || data14 === "unavailable")) {
          const err18 = {};
          if (vErrors === null) {
            vErrors = [err18];
          } else {
            vErrors.push(err18);
          }
          errors2++;
        }
      }
    }
    var _valid5 = _errs54 === errors2;
    errors2 = _errs53;
    if (vErrors !== null) {
      if (_errs53) {
        vErrors.length = _errs53;
      } else {
        vErrors = null;
      }
    }
    if (_valid5) {
      const _errs56 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs57 = errors2;
          if (data.data !== null) {
            validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid15 = _errs57 === errors2;
        } else {
          var valid15 = true;
        }
        if (valid15) {
          if (data.updatedAt !== void 0) {
            const _errs59 = errors2;
            if (data.updatedAt !== null) {
              validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid15 = _errs59 === errors2;
          } else {
            var valid15 = true;
          }
        }
      }
      var _valid5 = _errs56 === errors2;
      valid13 = _valid5;
      if (valid13) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid13) {
      const err19 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err19];
      } else {
        vErrors.push(err19);
      }
      errors2++;
      validate26.errors = vErrors;
      return false;
    }
    var valid0 = _errs52 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs61 = errors2;
      const _errs62 = errors2;
      let valid16 = true;
      const _errs63 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data17 = data.status;
          if (!(data17 === "ok" || data17 === "unconfigured" || data17 === "loading")) {
            const err20 = {};
            if (vErrors === null) {
              vErrors = [err20];
            } else {
              vErrors.push(err20);
            }
            errors2++;
          }
        }
      }
      var _valid6 = _errs63 === errors2;
      errors2 = _errs62;
      if (vErrors !== null) {
        if (_errs62) {
          vErrors.length = _errs62;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid6) {
        const _errs65 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate26.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid6 = _errs65 === errors2;
        valid16 = _valid6;
        if (valid16) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs68 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data19 = data.errorCode;
            if (!(data19 === "NETWORK_ERROR" || data19 === "INVALID_DATA" || data19 === "PAYLOAD_TOO_LARGE" || data19 === "EXPANSION_LIMIT" || data19 === "UNSUPPORTED_CALENDAR" || data19 === "UNKNOWN_TIME_ZONE" || data19 === "KEYRING_LOCKED" || data19 === "SECRET_DELETION_FAILED" || data19 === "AUTH_ERROR" || data19 === "RATE_LIMITED" || data19 === "NO_PLAYER" || data19 === "NO_INTERFACE" || data19 === "SERVICE_UNAVAILABLE" || data19 === "INTERNAL_ERROR")) {
              validate26.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema35.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid6 = _errs68 === errors2;
        valid16 = _valid6;
        if (valid16) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid16) {
        const err21 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err21];
        } else {
          vErrors.push(err21);
        }
        errors2++;
        validate26.errors = vErrors;
        return false;
      }
      var valid0 = _errs61 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing3;
      if (data.status === void 0 && (missing3 = "status") || data.sourceId === void 0 && (missing3 = "sourceId") || data.updatedAt === void 0 && (missing3 = "updatedAt") || data.data === void 0 && (missing3 = "data") || data.errorCode === void 0 && (missing3 = "errorCode")) {
        validate26.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" }];
        return false;
      } else {
        const _errs70 = errors2;
        for (const key3 in data) {
          if (!(key3 === "status" || key3 === "sourceId" || key3 === "updatedAt" || key3 === "data" || key3 === "errorCode")) {
            validate26.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs70 === errors2) {
          if (data.status !== void 0) {
            let data20 = data.status;
            const _errs71 = errors2;
            if (!(data20 === "loading" || data20 === "ok" || data20 === "stale" || data20 === "unconfigured" || data20 === "unavailable")) {
              validate26.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema35.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid20 = _errs71 === errors2;
          } else {
            var valid20 = true;
          }
          if (valid20) {
            if (data.sourceId !== void 0) {
              let data21 = data.sourceId;
              const _errs72 = errors2;
              const _errs73 = errors2;
              let valid21 = false;
              const _errs74 = errors2;
              if (errors2 === _errs74) {
                if (typeof data21 === "string") {
                  if (func1(data21) > 128) {
                    const err22 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err22];
                    } else {
                      vErrors.push(err22);
                    }
                    errors2++;
                  } else {
                    if (func1(data21) < 1) {
                      const err23 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err23];
                      } else {
                        vErrors.push(err23);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data21)) {
                        const err24 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err24];
                        } else {
                          vErrors.push(err24);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err25 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err25];
                  } else {
                    vErrors.push(err25);
                  }
                  errors2++;
                }
              }
              var _valid7 = _errs74 === errors2;
              valid21 = valid21 || _valid7;
              const _errs76 = errors2;
              if (data21 !== null) {
                const err26 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err26];
                } else {
                  vErrors.push(err26);
                }
                errors2++;
              }
              var _valid7 = _errs76 === errors2;
              valid21 = valid21 || _valid7;
              if (!valid21) {
                const err27 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err27];
                } else {
                  vErrors.push(err27);
                }
                errors2++;
                validate26.errors = vErrors;
                return false;
              } else {
                errors2 = _errs73;
                if (vErrors !== null) {
                  if (_errs73) {
                    vErrors.length = _errs73;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid20 = _errs72 === errors2;
            } else {
              var valid20 = true;
            }
            if (valid20) {
              if (data.updatedAt !== void 0) {
                let data22 = data.updatedAt;
                const _errs78 = errors2;
                const _errs79 = errors2;
                let valid22 = false;
                const _errs80 = errors2;
                if (errors2 === _errs80) {
                  if (errors2 === _errs80) {
                    if (typeof data22 === "string") {
                      if (func1(data22) > 64) {
                        const err28 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err28];
                        } else {
                          vErrors.push(err28);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data22)) {
                          const err29 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err29];
                          } else {
                            vErrors.push(err29);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err30 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err30];
                      } else {
                        vErrors.push(err30);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid8 = _errs80 === errors2;
                valid22 = valid22 || _valid8;
                const _errs82 = errors2;
                if (data22 !== null) {
                  const err31 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err31];
                  } else {
                    vErrors.push(err31);
                  }
                  errors2++;
                }
                var _valid8 = _errs82 === errors2;
                valid22 = valid22 || _valid8;
                if (!valid22) {
                  const err32 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err32];
                  } else {
                    vErrors.push(err32);
                  }
                  errors2++;
                  validate26.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs79;
                  if (vErrors !== null) {
                    if (_errs79) {
                      vErrors.length = _errs79;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid20 = _errs78 === errors2;
              } else {
                var valid20 = true;
              }
              if (valid20) {
                if (data.data !== void 0) {
                  let data23 = data.data;
                  const _errs84 = errors2;
                  const _errs85 = errors2;
                  let valid23 = false;
                  const _errs86 = errors2;
                  const _errs87 = errors2;
                  if (errors2 === _errs87) {
                    if (data23 && typeof data23 == "object" && !Array.isArray(data23)) {
                      let missing4;
                      if (data23.location === void 0 && (missing4 = "location") || data23.timeZone === void 0 && (missing4 = "timeZone") || data23.current === void 0 && (missing4 = "current") || data23.hourly === void 0 && (missing4 = "hourly") || data23.attributionUrl === void 0 && (missing4 = "attributionUrl")) {
                        const err33 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                        if (vErrors === null) {
                          vErrors = [err33];
                        } else {
                          vErrors.push(err33);
                        }
                        errors2++;
                      } else {
                        const _errs89 = errors2;
                        for (const key4 in data23) {
                          if (!(key4 === "location" || key4 === "timeZone" || key4 === "current" || key4 === "hourly" || key4 === "attributionUrl")) {
                            const err34 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err34];
                            } else {
                              vErrors.push(err34);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs89 === errors2) {
                          if (data23.location !== void 0) {
                            let data24 = data23.location;
                            const _errs90 = errors2;
                            if (errors2 === _errs90) {
                              if (typeof data24 === "string") {
                                if (func1(data24) > 512) {
                                  const err35 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors2++;
                                }
                              } else {
                                const err36 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err36];
                                } else {
                                  vErrors.push(err36);
                                }
                                errors2++;
                              }
                            }
                            var valid25 = _errs90 === errors2;
                          } else {
                            var valid25 = true;
                          }
                          if (valid25) {
                            if (data23.timeZone !== void 0) {
                              let data25 = data23.timeZone;
                              const _errs92 = errors2;
                              if (errors2 === _errs92) {
                                if (typeof data25 === "string") {
                                  if (func1(data25) > 255) {
                                    const err37 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err37];
                                    } else {
                                      vErrors.push(err37);
                                    }
                                    errors2++;
                                  } else {
                                    if (func1(data25) < 1) {
                                      const err38 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err38];
                                      } else {
                                        vErrors.push(err38);
                                      }
                                      errors2++;
                                    }
                                  }
                                } else {
                                  const err39 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err39];
                                  } else {
                                    vErrors.push(err39);
                                  }
                                  errors2++;
                                }
                              }
                              var valid25 = _errs92 === errors2;
                            } else {
                              var valid25 = true;
                            }
                            if (valid25) {
                              if (data23.current !== void 0) {
                                let data26 = data23.current;
                                const _errs94 = errors2;
                                if (errors2 === _errs94) {
                                  if (data26 && typeof data26 == "object" && !Array.isArray(data26)) {
                                    let missing5;
                                    if (data26.temperatureC === void 0 && (missing5 = "temperatureC") || data26.code === void 0 && (missing5 = "code")) {
                                      const err40 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing5 }, message: "must have required property '" + missing5 + "'" };
                                      if (vErrors === null) {
                                        vErrors = [err40];
                                      } else {
                                        vErrors.push(err40);
                                      }
                                      errors2++;
                                    } else {
                                      const _errs96 = errors2;
                                      for (const key5 in data26) {
                                        if (!(key5 === "temperatureC" || key5 === "code")) {
                                          const err41 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                                          if (vErrors === null) {
                                            vErrors = [err41];
                                          } else {
                                            vErrors.push(err41);
                                          }
                                          errors2++;
                                          break;
                                        }
                                      }
                                      if (_errs96 === errors2) {
                                        if (data26.temperatureC !== void 0) {
                                          let data27 = data26.temperatureC;
                                          const _errs97 = errors2;
                                          const _errs98 = errors2;
                                          let valid27 = false;
                                          const _errs99 = errors2;
                                          if (!(typeof data27 == "number" && isFinite(data27))) {
                                            const err42 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                            if (vErrors === null) {
                                              vErrors = [err42];
                                            } else {
                                              vErrors.push(err42);
                                            }
                                            errors2++;
                                          }
                                          var _valid10 = _errs99 === errors2;
                                          valid27 = valid27 || _valid10;
                                          const _errs101 = errors2;
                                          if (data27 !== null) {
                                            const err43 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                            if (vErrors === null) {
                                              vErrors = [err43];
                                            } else {
                                              vErrors.push(err43);
                                            }
                                            errors2++;
                                          }
                                          var _valid10 = _errs101 === errors2;
                                          valid27 = valid27 || _valid10;
                                          if (!valid27) {
                                            const err44 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                            if (vErrors === null) {
                                              vErrors = [err44];
                                            } else {
                                              vErrors.push(err44);
                                            }
                                            errors2++;
                                          } else {
                                            errors2 = _errs98;
                                            if (vErrors !== null) {
                                              if (_errs98) {
                                                vErrors.length = _errs98;
                                              } else {
                                                vErrors = null;
                                              }
                                            }
                                          }
                                          var valid26 = _errs97 === errors2;
                                        } else {
                                          var valid26 = true;
                                        }
                                        if (valid26) {
                                          if (data26.code !== void 0) {
                                            let data28 = data26.code;
                                            const _errs103 = errors2;
                                            const _errs104 = errors2;
                                            let valid28 = false;
                                            const _errs105 = errors2;
                                            if (!(typeof data28 == "number" && (!(data28 % 1) && !isNaN(data28)) && isFinite(data28))) {
                                              const err45 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                              if (vErrors === null) {
                                                vErrors = [err45];
                                              } else {
                                                vErrors.push(err45);
                                              }
                                              errors2++;
                                            }
                                            if (errors2 === _errs105) {
                                              if (typeof data28 == "number" && isFinite(data28)) {
                                                if (data28 > 99 || isNaN(data28)) {
                                                  const err46 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                                  if (vErrors === null) {
                                                    vErrors = [err46];
                                                  } else {
                                                    vErrors.push(err46);
                                                  }
                                                  errors2++;
                                                } else {
                                                  if (data28 < 0 || isNaN(data28)) {
                                                    const err47 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                    if (vErrors === null) {
                                                      vErrors = [err47];
                                                    } else {
                                                      vErrors.push(err47);
                                                    }
                                                    errors2++;
                                                  }
                                                }
                                              }
                                            }
                                            var _valid11 = _errs105 === errors2;
                                            valid28 = valid28 || _valid11;
                                            const _errs107 = errors2;
                                            if (data28 !== null) {
                                              const err48 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors2++;
                                            }
                                            var _valid11 = _errs107 === errors2;
                                            valid28 = valid28 || _valid11;
                                            if (!valid28) {
                                              const err49 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err49];
                                              } else {
                                                vErrors.push(err49);
                                              }
                                              errors2++;
                                            } else {
                                              errors2 = _errs104;
                                              if (vErrors !== null) {
                                                if (_errs104) {
                                                  vErrors.length = _errs104;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid26 = _errs103 === errors2;
                                          } else {
                                            var valid26 = true;
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    const err50 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                    if (vErrors === null) {
                                      vErrors = [err50];
                                    } else {
                                      vErrors.push(err50);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid25 = _errs94 === errors2;
                              } else {
                                var valid25 = true;
                              }
                              if (valid25) {
                                if (data23.hourly !== void 0) {
                                  let data29 = data23.hourly;
                                  const _errs109 = errors2;
                                  if (errors2 === _errs109) {
                                    if (Array.isArray(data29)) {
                                      if (data29.length > 6) {
                                        const err51 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" };
                                        if (vErrors === null) {
                                          vErrors = [err51];
                                        } else {
                                          vErrors.push(err51);
                                        }
                                        errors2++;
                                      } else {
                                        var valid29 = true;
                                        const len1 = data29.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data30 = data29[i1];
                                          const _errs111 = errors2;
                                          if (errors2 === _errs111) {
                                            if (data30 && typeof data30 == "object" && !Array.isArray(data30)) {
                                              let missing6;
                                              if (data30.at === void 0 && (missing6 = "at") || data30.temperatureC === void 0 && (missing6 = "temperatureC") || data30.precipitationProbability === void 0 && (missing6 = "precipitationProbability")) {
                                                const err52 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing6 }, message: "must have required property '" + missing6 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err52];
                                                } else {
                                                  vErrors.push(err52);
                                                }
                                                errors2++;
                                              } else {
                                                const _errs113 = errors2;
                                                for (const key6 in data30) {
                                                  if (!(key6 === "at" || key6 === "temperatureC" || key6 === "precipitationProbability")) {
                                                    const err53 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err53];
                                                    } else {
                                                      vErrors.push(err53);
                                                    }
                                                    errors2++;
                                                    break;
                                                  }
                                                }
                                                if (_errs113 === errors2) {
                                                  if (data30.at !== void 0) {
                                                    let data31 = data30.at;
                                                    const _errs114 = errors2;
                                                    if (errors2 === _errs114) {
                                                      if (errors2 === _errs114) {
                                                        if (typeof data31 === "string") {
                                                          if (func1(data31) > 64) {
                                                            const err54 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err54];
                                                            } else {
                                                              vErrors.push(err54);
                                                            }
                                                            errors2++;
                                                          } else {
                                                            if (!formats0.validate(data31)) {
                                                              const err55 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err55];
                                                              } else {
                                                                vErrors.push(err55);
                                                              }
                                                              errors2++;
                                                            }
                                                          }
                                                        } else {
                                                          const err56 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err56];
                                                          } else {
                                                            vErrors.push(err56);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                    }
                                                    var valid30 = _errs114 === errors2;
                                                  } else {
                                                    var valid30 = true;
                                                  }
                                                  if (valid30) {
                                                    if (data30.temperatureC !== void 0) {
                                                      let data32 = data30.temperatureC;
                                                      const _errs116 = errors2;
                                                      const _errs117 = errors2;
                                                      let valid31 = false;
                                                      const _errs118 = errors2;
                                                      if (!(typeof data32 == "number" && isFinite(data32))) {
                                                        const err57 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                        if (vErrors === null) {
                                                          vErrors = [err57];
                                                        } else {
                                                          vErrors.push(err57);
                                                        }
                                                        errors2++;
                                                      }
                                                      var _valid12 = _errs118 === errors2;
                                                      valid31 = valid31 || _valid12;
                                                      const _errs120 = errors2;
                                                      if (data32 !== null) {
                                                        const err58 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                        if (vErrors === null) {
                                                          vErrors = [err58];
                                                        } else {
                                                          vErrors.push(err58);
                                                        }
                                                        errors2++;
                                                      }
                                                      var _valid12 = _errs120 === errors2;
                                                      valid31 = valid31 || _valid12;
                                                      if (!valid31) {
                                                        const err59 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                        if (vErrors === null) {
                                                          vErrors = [err59];
                                                        } else {
                                                          vErrors.push(err59);
                                                        }
                                                        errors2++;
                                                      } else {
                                                        errors2 = _errs117;
                                                        if (vErrors !== null) {
                                                          if (_errs117) {
                                                            vErrors.length = _errs117;
                                                          } else {
                                                            vErrors = null;
                                                          }
                                                        }
                                                      }
                                                      var valid30 = _errs116 === errors2;
                                                    } else {
                                                      var valid30 = true;
                                                    }
                                                    if (valid30) {
                                                      if (data30.precipitationProbability !== void 0) {
                                                        let data33 = data30.precipitationProbability;
                                                        const _errs122 = errors2;
                                                        const _errs123 = errors2;
                                                        let valid32 = false;
                                                        const _errs124 = errors2;
                                                        if (errors2 === _errs124) {
                                                          if (typeof data33 == "number" && isFinite(data33)) {
                                                            if (data33 > 100 || isNaN(data33)) {
                                                              const err60 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                              if (vErrors === null) {
                                                                vErrors = [err60];
                                                              } else {
                                                                vErrors.push(err60);
                                                              }
                                                              errors2++;
                                                            } else {
                                                              if (data33 < 0 || isNaN(data33)) {
                                                                const err61 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                                if (vErrors === null) {
                                                                  vErrors = [err61];
                                                                } else {
                                                                  vErrors.push(err61);
                                                                }
                                                                errors2++;
                                                              }
                                                            }
                                                          } else {
                                                            const err62 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err62];
                                                            } else {
                                                              vErrors.push(err62);
                                                            }
                                                            errors2++;
                                                          }
                                                        }
                                                        var _valid13 = _errs124 === errors2;
                                                        valid32 = valid32 || _valid13;
                                                        const _errs126 = errors2;
                                                        if (data33 !== null) {
                                                          const err63 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                          if (vErrors === null) {
                                                            vErrors = [err63];
                                                          } else {
                                                            vErrors.push(err63);
                                                          }
                                                          errors2++;
                                                        }
                                                        var _valid13 = _errs126 === errors2;
                                                        valid32 = valid32 || _valid13;
                                                        if (!valid32) {
                                                          const err64 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                          if (vErrors === null) {
                                                            vErrors = [err64];
                                                          } else {
                                                            vErrors.push(err64);
                                                          }
                                                          errors2++;
                                                        } else {
                                                          errors2 = _errs123;
                                                          if (vErrors !== null) {
                                                            if (_errs123) {
                                                              vErrors.length = _errs123;
                                                            } else {
                                                              vErrors = null;
                                                            }
                                                          }
                                                        }
                                                        var valid30 = _errs122 === errors2;
                                                      } else {
                                                        var valid30 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err65 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err65];
                                              } else {
                                                vErrors.push(err65);
                                              }
                                              errors2++;
                                            }
                                          }
                                          var valid29 = _errs111 === errors2;
                                          if (!valid29) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err66 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err66];
                                      } else {
                                        vErrors.push(err66);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid25 = _errs109 === errors2;
                                } else {
                                  var valid25 = true;
                                }
                                if (valid25) {
                                  if (data23.attributionUrl !== void 0) {
                                    let data34 = data23.attributionUrl;
                                    const _errs128 = errors2;
                                    if (errors2 === _errs128) {
                                      if (typeof data34 === "string") {
                                        if (func1(data34) > 512) {
                                          const err67 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err67];
                                          } else {
                                            vErrors.push(err67);
                                          }
                                          errors2++;
                                        } else {
                                          if (!pattern6.test(data34)) {
                                            const err68 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' };
                                            if (vErrors === null) {
                                              vErrors = [err68];
                                            } else {
                                              vErrors.push(err68);
                                            }
                                            errors2++;
                                          }
                                        }
                                      } else {
                                        const err69 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err69];
                                        } else {
                                          vErrors.push(err69);
                                        }
                                        errors2++;
                                      }
                                    }
                                    var valid25 = _errs128 === errors2;
                                  } else {
                                    var valid25 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err70 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err70];
                      } else {
                        vErrors.push(err70);
                      }
                      errors2++;
                    }
                  }
                  var _valid9 = _errs86 === errors2;
                  valid23 = valid23 || _valid9;
                  const _errs130 = errors2;
                  if (data23 !== null) {
                    const err71 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err71];
                    } else {
                      vErrors.push(err71);
                    }
                    errors2++;
                  }
                  var _valid9 = _errs130 === errors2;
                  valid23 = valid23 || _valid9;
                  if (!valid23) {
                    const err72 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err72];
                    } else {
                      vErrors.push(err72);
                    }
                    errors2++;
                    validate26.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs85;
                    if (vErrors !== null) {
                      if (_errs85) {
                        vErrors.length = _errs85;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid20 = _errs84 === errors2;
                } else {
                  var valid20 = true;
                }
                if (valid20) {
                  if (data.errorCode !== void 0) {
                    let data35 = data.errorCode;
                    const _errs132 = errors2;
                    const _errs133 = errors2;
                    let valid33 = false;
                    const _errs134 = errors2;
                    if (!(data35 === "NETWORK_ERROR" || data35 === "INVALID_DATA" || data35 === "PAYLOAD_TOO_LARGE" || data35 === "EXPANSION_LIMIT" || data35 === "UNSUPPORTED_CALENDAR" || data35 === "UNKNOWN_TIME_ZONE" || data35 === "KEYRING_LOCKED" || data35 === "SECRET_DELETION_FAILED" || data35 === "AUTH_ERROR" || data35 === "RATE_LIMITED" || data35 === "NO_PLAYER" || data35 === "NO_INTERFACE" || data35 === "SERVICE_UNAVAILABLE" || data35 === "INTERNAL_ERROR")) {
                      const err73 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema35.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err73];
                      } else {
                        vErrors.push(err73);
                      }
                      errors2++;
                    }
                    var _valid14 = _errs134 === errors2;
                    valid33 = valid33 || _valid14;
                    const _errs135 = errors2;
                    if (data35 !== null) {
                      const err74 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err74];
                      } else {
                        vErrors.push(err74);
                      }
                      errors2++;
                    }
                    var _valid14 = _errs135 === errors2;
                    valid33 = valid33 || _valid14;
                    if (!valid33) {
                      const err75 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err75];
                      } else {
                        vErrors.push(err75);
                      }
                      errors2++;
                      validate26.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs133;
                      if (vErrors !== null) {
                        if (_errs133) {
                          vErrors.length = _errs133;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid20 = _errs132 === errors2;
                  } else {
                    var valid20 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate26.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate26.errors = vErrors;
  return errors2 === 0;
}
validate26.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema38 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/SystemData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/SystemData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
function validate28(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate28.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.cpuPercent === void 0 && (missing0 = "cpuPercent") || data1.memoryUsedBytes === void 0 && (missing0 = "memoryUsedBytes") || data1.memoryTotalBytes === void 0 && (missing0 = "memoryTotalBytes") || data1.temperatureC === void 0 && (missing0 = "temperatureC")) {
              validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "cpuPercent" || key0 === "memoryUsedBytes" || key0 === "memoryTotalBytes" || key0 === "temperatureC")) {
                  validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.cpuPercent !== void 0) {
                  let data2 = data1.cpuPercent;
                  const _errs10 = errors2;
                  const _errs11 = errors2;
                  let valid6 = false;
                  const _errs12 = errors2;
                  if (errors2 === _errs12) {
                    if (typeof data2 == "number" && isFinite(data2)) {
                      if (data2 > 100 || isNaN(data2)) {
                        const err1 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                        if (vErrors === null) {
                          vErrors = [err1];
                        } else {
                          vErrors.push(err1);
                        }
                        errors2++;
                      } else {
                        if (data2 < 0 || isNaN(data2)) {
                          const err2 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err2];
                          } else {
                            vErrors.push(err2);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err3 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors2++;
                    }
                  }
                  var _valid1 = _errs12 === errors2;
                  valid6 = valid6 || _valid1;
                  const _errs14 = errors2;
                  if (data2 !== null) {
                    const err4 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err4];
                    } else {
                      vErrors.push(err4);
                    }
                    errors2++;
                  }
                  var _valid1 = _errs14 === errors2;
                  valid6 = valid6 || _valid1;
                  if (!valid6) {
                    const err5 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err5];
                    } else {
                      vErrors.push(err5);
                    }
                    errors2++;
                    validate28.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs11;
                    if (vErrors !== null) {
                      if (_errs11) {
                        vErrors.length = _errs11;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.memoryUsedBytes !== void 0) {
                    let data3 = data1.memoryUsedBytes;
                    const _errs16 = errors2;
                    if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                      validate28.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                      return false;
                    }
                    if (errors2 === _errs16) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 > 9007199254740991 || isNaN(data3)) {
                          validate28.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                          return false;
                        } else {
                          if (data3 < 0 || isNaN(data3)) {
                            validate28.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                            return false;
                          }
                        }
                      }
                    }
                    var valid5 = _errs16 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.memoryTotalBytes !== void 0) {
                      let data4 = data1.memoryTotalBytes;
                      const _errs18 = errors2;
                      if (!(typeof data4 == "number" && (!(data4 % 1) && !isNaN(data4)) && isFinite(data4))) {
                        validate28.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                        return false;
                      }
                      if (errors2 === _errs18) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 > 9007199254740991 || isNaN(data4)) {
                            validate28.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                            return false;
                          } else {
                            if (data4 < 0 || isNaN(data4)) {
                              validate28.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                              return false;
                            }
                          }
                        }
                      }
                      var valid5 = _errs18 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.temperatureC !== void 0) {
                        let data5 = data1.temperatureC;
                        const _errs20 = errors2;
                        const _errs21 = errors2;
                        let valid7 = false;
                        const _errs22 = errors2;
                        if (!(typeof data5 == "number" && isFinite(data5))) {
                          const err6 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors2++;
                        }
                        var _valid2 = _errs22 === errors2;
                        valid7 = valid7 || _valid2;
                        const _errs24 = errors2;
                        if (data5 !== null) {
                          const err7 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                          if (vErrors === null) {
                            vErrors = [err7];
                          } else {
                            vErrors.push(err7);
                          }
                          errors2++;
                        }
                        var _valid2 = _errs24 === errors2;
                        valid7 = valid7 || _valid2;
                        if (!valid7) {
                          const err8 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                          if (vErrors === null) {
                            vErrors = [err8];
                          } else {
                            vErrors.push(err8);
                          }
                          errors2++;
                          validate28.errors = vErrors;
                          return false;
                        } else {
                          errors2 = _errs21;
                          if (vErrors !== null) {
                            if (_errs21) {
                              vErrors.length = _errs21;
                            } else {
                              vErrors = null;
                            }
                          }
                        }
                        var valid5 = _errs20 === errors2;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data6 = data.updatedAt;
          const _errs26 = errors2;
          if (errors2 === _errs26) {
            if (errors2 === _errs26) {
              if (typeof data6 === "string") {
                if (func1(data6) > 64) {
                  validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data6)) {
                    validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs26 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors2++;
    validate28.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs28 = errors2;
    const _errs29 = errors2;
    let valid8 = true;
    const _errs30 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data7 = data.status;
        if (!(data7 === "unconfigured" || data7 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors2++;
        }
      }
    }
    var _valid3 = _errs30 === errors2;
    errors2 = _errs29;
    if (vErrors !== null) {
      if (_errs29) {
        vErrors.length = _errs29;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs32 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs33 = errors2;
          if (data.data !== null) {
            validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid10 = _errs33 === errors2;
        } else {
          var valid10 = true;
        }
        if (valid10) {
          if (data.updatedAt !== void 0) {
            const _errs35 = errors2;
            if (data.updatedAt !== null) {
              validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid10 = _errs35 === errors2;
          } else {
            var valid10 = true;
          }
        }
      }
      var _valid3 = _errs32 === errors2;
      valid8 = _valid3;
      if (valid8) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid8) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors2++;
      validate28.errors = vErrors;
      return false;
    }
    var valid0 = _errs28 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs37 = errors2;
      const _errs38 = errors2;
      let valid11 = true;
      const _errs39 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data10 = data.status;
          if (!(data10 === "ok" || data10 === "unconfigured" || data10 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors2++;
          }
        }
      }
      var _valid4 = _errs39 === errors2;
      errors2 = _errs38;
      if (vErrors !== null) {
        if (_errs38) {
          vErrors.length = _errs38;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs41 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate28.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs41 === errors2;
        valid11 = _valid4;
        if (valid11) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs44 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data12 = data.errorCode;
            if (!(data12 === "NETWORK_ERROR" || data12 === "INVALID_DATA" || data12 === "PAYLOAD_TOO_LARGE" || data12 === "EXPANSION_LIMIT" || data12 === "UNSUPPORTED_CALENDAR" || data12 === "UNKNOWN_TIME_ZONE" || data12 === "KEYRING_LOCKED" || data12 === "SECRET_DELETION_FAILED" || data12 === "AUTH_ERROR" || data12 === "RATE_LIMITED" || data12 === "NO_PLAYER" || data12 === "NO_INTERFACE" || data12 === "SERVICE_UNAVAILABLE" || data12 === "INTERNAL_ERROR")) {
              validate28.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema38.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs44 === errors2;
        valid11 = _valid4;
        if (valid11) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid11) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors2++;
        validate28.errors = vErrors;
        return false;
      }
      var valid0 = _errs37 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate28.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs46 = errors2;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate28.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs46 === errors2) {
          if (data.status !== void 0) {
            let data13 = data.status;
            const _errs47 = errors2;
            if (!(data13 === "loading" || data13 === "ok" || data13 === "stale" || data13 === "unconfigured" || data13 === "unavailable")) {
              validate28.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema38.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid15 = _errs47 === errors2;
          } else {
            var valid15 = true;
          }
          if (valid15) {
            if (data.sourceId !== void 0) {
              let data14 = data.sourceId;
              const _errs48 = errors2;
              const _errs49 = errors2;
              let valid16 = false;
              const _errs50 = errors2;
              if (errors2 === _errs50) {
                if (typeof data14 === "string") {
                  if (func1(data14) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors2++;
                  } else {
                    if (func1(data14) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data14)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors2++;
                }
              }
              var _valid5 = _errs50 === errors2;
              valid16 = valid16 || _valid5;
              const _errs52 = errors2;
              if (data14 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors2++;
              }
              var _valid5 = _errs52 === errors2;
              valid16 = valid16 || _valid5;
              if (!valid16) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors2++;
                validate28.errors = vErrors;
                return false;
              } else {
                errors2 = _errs49;
                if (vErrors !== null) {
                  if (_errs49) {
                    vErrors.length = _errs49;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid15 = _errs48 === errors2;
            } else {
              var valid15 = true;
            }
            if (valid15) {
              if (data.updatedAt !== void 0) {
                let data15 = data.updatedAt;
                const _errs54 = errors2;
                const _errs55 = errors2;
                let valid17 = false;
                const _errs56 = errors2;
                if (errors2 === _errs56) {
                  if (errors2 === _errs56) {
                    if (typeof data15 === "string") {
                      if (func1(data15) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data15)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid6 = _errs56 === errors2;
                valid17 = valid17 || _valid6;
                const _errs58 = errors2;
                if (data15 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors2++;
                }
                var _valid6 = _errs58 === errors2;
                valid17 = valid17 || _valid6;
                if (!valid17) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors2++;
                  validate28.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs55;
                  if (vErrors !== null) {
                    if (_errs55) {
                      vErrors.length = _errs55;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid15 = _errs54 === errors2;
              } else {
                var valid15 = true;
              }
              if (valid15) {
                if (data.data !== void 0) {
                  let data16 = data.data;
                  const _errs60 = errors2;
                  const _errs61 = errors2;
                  let valid18 = false;
                  const _errs62 = errors2;
                  const _errs63 = errors2;
                  if (errors2 === _errs63) {
                    if (data16 && typeof data16 == "object" && !Array.isArray(data16)) {
                      let missing2;
                      if (data16.cpuPercent === void 0 && (missing2 = "cpuPercent") || data16.memoryUsedBytes === void 0 && (missing2 = "memoryUsedBytes") || data16.memoryTotalBytes === void 0 && (missing2 = "memoryTotalBytes") || data16.temperatureC === void 0 && (missing2 = "temperatureC")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors2++;
                      } else {
                        const _errs65 = errors2;
                        for (const key2 in data16) {
                          if (!(key2 === "cpuPercent" || key2 === "memoryUsedBytes" || key2 === "memoryTotalBytes" || key2 === "temperatureC")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs65 === errors2) {
                          if (data16.cpuPercent !== void 0) {
                            let data17 = data16.cpuPercent;
                            const _errs66 = errors2;
                            const _errs67 = errors2;
                            let valid21 = false;
                            const _errs68 = errors2;
                            if (errors2 === _errs68) {
                              if (typeof data17 == "number" && isFinite(data17)) {
                                if (data17 > 100 || isNaN(data17)) {
                                  const err27 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors2++;
                                } else {
                                  if (data17 < 0 || isNaN(data17)) {
                                    const err28 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors2++;
                              }
                            }
                            var _valid8 = _errs68 === errors2;
                            valid21 = valid21 || _valid8;
                            const _errs70 = errors2;
                            if (data17 !== null) {
                              const err30 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                              if (vErrors === null) {
                                vErrors = [err30];
                              } else {
                                vErrors.push(err30);
                              }
                              errors2++;
                            }
                            var _valid8 = _errs70 === errors2;
                            valid21 = valid21 || _valid8;
                            if (!valid21) {
                              const err31 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                              if (vErrors === null) {
                                vErrors = [err31];
                              } else {
                                vErrors.push(err31);
                              }
                              errors2++;
                            } else {
                              errors2 = _errs67;
                              if (vErrors !== null) {
                                if (_errs67) {
                                  vErrors.length = _errs67;
                                } else {
                                  vErrors = null;
                                }
                              }
                            }
                            var valid20 = _errs66 === errors2;
                          } else {
                            var valid20 = true;
                          }
                          if (valid20) {
                            if (data16.memoryUsedBytes !== void 0) {
                              let data18 = data16.memoryUsedBytes;
                              const _errs72 = errors2;
                              if (!(typeof data18 == "number" && (!(data18 % 1) && !isNaN(data18)) && isFinite(data18))) {
                                const err32 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors2++;
                              }
                              if (errors2 === _errs72) {
                                if (typeof data18 == "number" && isFinite(data18)) {
                                  if (data18 > 9007199254740991 || isNaN(data18)) {
                                    const err33 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                    if (vErrors === null) {
                                      vErrors = [err33];
                                    } else {
                                      vErrors.push(err33);
                                    }
                                    errors2++;
                                  } else {
                                    if (data18 < 0 || isNaN(data18)) {
                                      const err34 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors2++;
                                    }
                                  }
                                }
                              }
                              var valid20 = _errs72 === errors2;
                            } else {
                              var valid20 = true;
                            }
                            if (valid20) {
                              if (data16.memoryTotalBytes !== void 0) {
                                let data19 = data16.memoryTotalBytes;
                                const _errs74 = errors2;
                                if (!(typeof data19 == "number" && (!(data19 % 1) && !isNaN(data19)) && isFinite(data19))) {
                                  const err35 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors2++;
                                }
                                if (errors2 === _errs74) {
                                  if (typeof data19 == "number" && isFinite(data19)) {
                                    if (data19 > 9007199254740991 || isNaN(data19)) {
                                      const err36 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors2++;
                                    } else {
                                      if (data19 < 0 || isNaN(data19)) {
                                        const err37 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                        if (vErrors === null) {
                                          vErrors = [err37];
                                        } else {
                                          vErrors.push(err37);
                                        }
                                        errors2++;
                                      }
                                    }
                                  }
                                }
                                var valid20 = _errs74 === errors2;
                              } else {
                                var valid20 = true;
                              }
                              if (valid20) {
                                if (data16.temperatureC !== void 0) {
                                  let data20 = data16.temperatureC;
                                  const _errs76 = errors2;
                                  const _errs77 = errors2;
                                  let valid22 = false;
                                  const _errs78 = errors2;
                                  if (!(typeof data20 == "number" && isFinite(data20))) {
                                    const err38 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err38];
                                    } else {
                                      vErrors.push(err38);
                                    }
                                    errors2++;
                                  }
                                  var _valid9 = _errs78 === errors2;
                                  valid22 = valid22 || _valid9;
                                  const _errs80 = errors2;
                                  if (data20 !== null) {
                                    const err39 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err39];
                                    } else {
                                      vErrors.push(err39);
                                    }
                                    errors2++;
                                  }
                                  var _valid9 = _errs80 === errors2;
                                  valid22 = valid22 || _valid9;
                                  if (!valid22) {
                                    const err40 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err40];
                                    } else {
                                      vErrors.push(err40);
                                    }
                                    errors2++;
                                  } else {
                                    errors2 = _errs77;
                                    if (vErrors !== null) {
                                      if (_errs77) {
                                        vErrors.length = _errs77;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid20 = _errs76 === errors2;
                                } else {
                                  var valid20 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err41 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors2++;
                    }
                  }
                  var _valid7 = _errs62 === errors2;
                  valid18 = valid18 || _valid7;
                  const _errs82 = errors2;
                  if (data16 !== null) {
                    const err42 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err42];
                    } else {
                      vErrors.push(err42);
                    }
                    errors2++;
                  }
                  var _valid7 = _errs82 === errors2;
                  valid18 = valid18 || _valid7;
                  if (!valid18) {
                    const err43 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err43];
                    } else {
                      vErrors.push(err43);
                    }
                    errors2++;
                    validate28.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs61;
                    if (vErrors !== null) {
                      if (_errs61) {
                        vErrors.length = _errs61;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid15 = _errs60 === errors2;
                } else {
                  var valid15 = true;
                }
                if (valid15) {
                  if (data.errorCode !== void 0) {
                    let data21 = data.errorCode;
                    const _errs84 = errors2;
                    const _errs85 = errors2;
                    let valid23 = false;
                    const _errs86 = errors2;
                    if (!(data21 === "NETWORK_ERROR" || data21 === "INVALID_DATA" || data21 === "PAYLOAD_TOO_LARGE" || data21 === "EXPANSION_LIMIT" || data21 === "UNSUPPORTED_CALENDAR" || data21 === "UNKNOWN_TIME_ZONE" || data21 === "KEYRING_LOCKED" || data21 === "SECRET_DELETION_FAILED" || data21 === "AUTH_ERROR" || data21 === "RATE_LIMITED" || data21 === "NO_PLAYER" || data21 === "NO_INTERFACE" || data21 === "SERVICE_UNAVAILABLE" || data21 === "INTERNAL_ERROR")) {
                      const err44 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema38.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err44];
                      } else {
                        vErrors.push(err44);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs86 === errors2;
                    valid23 = valid23 || _valid10;
                    const _errs87 = errors2;
                    if (data21 !== null) {
                      const err45 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err45];
                      } else {
                        vErrors.push(err45);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs87 === errors2;
                    valid23 = valid23 || _valid10;
                    if (!valid23) {
                      const err46 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err46];
                      } else {
                        vErrors.push(err46);
                      }
                      errors2++;
                      validate28.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs85;
                      if (vErrors !== null) {
                        if (_errs85) {
                          vErrors.length = _errs85;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid15 = _errs84 === errors2;
                  } else {
                    var valid15 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate28.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate28.errors = vErrors;
  return errors2 === 0;
}
validate28.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema41 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/NetworkData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/NetworkData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
function validate30(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate30.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.interface === void 0 && (missing0 = "interface") || data1.rxBytesPerSec === void 0 && (missing0 = "rxBytesPerSec") || data1.txBytesPerSec === void 0 && (missing0 = "txBytesPerSec") || data1.history === void 0 && (missing0 = "history")) {
              validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "interface" || key0 === "rxBytesPerSec" || key0 === "txBytesPerSec" || key0 === "history")) {
                  validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.interface !== void 0) {
                  let data2 = data1.interface;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 64) {
                        validate30.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate30.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate30.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.rxBytesPerSec !== void 0) {
                    let data3 = data1.rxBytesPerSec;
                    const _errs12 = errors2;
                    const _errs13 = errors2;
                    let valid6 = false;
                    const _errs14 = errors2;
                    if (errors2 === _errs14) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 < 0 || isNaN(data3)) {
                          const err1 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err1];
                          } else {
                            vErrors.push(err1);
                          }
                          errors2++;
                        }
                      } else {
                        const err2 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err2];
                        } else {
                          vErrors.push(err2);
                        }
                        errors2++;
                      }
                    }
                    var _valid1 = _errs14 === errors2;
                    valid6 = valid6 || _valid1;
                    const _errs16 = errors2;
                    if (data3 !== null) {
                      const err3 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors2++;
                    }
                    var _valid1 = _errs16 === errors2;
                    valid6 = valid6 || _valid1;
                    if (!valid6) {
                      const err4 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err4];
                      } else {
                        vErrors.push(err4);
                      }
                      errors2++;
                      validate30.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs13;
                      if (vErrors !== null) {
                        if (_errs13) {
                          vErrors.length = _errs13;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.txBytesPerSec !== void 0) {
                      let data4 = data1.txBytesPerSec;
                      const _errs18 = errors2;
                      const _errs19 = errors2;
                      let valid7 = false;
                      const _errs20 = errors2;
                      if (errors2 === _errs20) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 < 0 || isNaN(data4)) {
                            const err5 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors2++;
                          }
                        } else {
                          const err6 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors2++;
                        }
                      }
                      var _valid2 = _errs20 === errors2;
                      valid7 = valid7 || _valid2;
                      const _errs22 = errors2;
                      if (data4 !== null) {
                        const err7 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                        if (vErrors === null) {
                          vErrors = [err7];
                        } else {
                          vErrors.push(err7);
                        }
                        errors2++;
                      }
                      var _valid2 = _errs22 === errors2;
                      valid7 = valid7 || _valid2;
                      if (!valid7) {
                        const err8 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors2++;
                        validate30.errors = vErrors;
                        return false;
                      } else {
                        errors2 = _errs19;
                        if (vErrors !== null) {
                          if (_errs19) {
                            vErrors.length = _errs19;
                          } else {
                            vErrors = null;
                          }
                        }
                      }
                      var valid5 = _errs18 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.history !== void 0) {
                        let data5 = data1.history;
                        const _errs24 = errors2;
                        if (errors2 === _errs24) {
                          if (Array.isArray(data5)) {
                            if (data5.length > 60) {
                              validate30.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" }];
                              return false;
                            } else {
                              var valid8 = true;
                              const len0 = data5.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data6 = data5[i0];
                                const _errs26 = errors2;
                                if (errors2 === _errs26) {
                                  if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
                                    let missing1;
                                    if (data6.at === void 0 && (missing1 = "at") || data6.rx === void 0 && (missing1 = "rx") || data6.tx === void 0 && (missing1 = "tx")) {
                                      validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                      return false;
                                    } else {
                                      const _errs28 = errors2;
                                      for (const key1 in data6) {
                                        if (!(key1 === "at" || key1 === "rx" || key1 === "tx")) {
                                          validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs28 === errors2) {
                                        if (data6.at !== void 0) {
                                          let data7 = data6.at;
                                          const _errs29 = errors2;
                                          if (errors2 === _errs29) {
                                            if (errors2 === _errs29) {
                                              if (typeof data7 === "string") {
                                                if (func1(data7) > 64) {
                                                  validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data7)) {
                                                    validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid9 = _errs29 === errors2;
                                        } else {
                                          var valid9 = true;
                                        }
                                        if (valid9) {
                                          if (data6.rx !== void 0) {
                                            let data8 = data6.rx;
                                            const _errs31 = errors2;
                                            if (errors2 === _errs31) {
                                              if (typeof data8 == "number" && isFinite(data8)) {
                                                if (data8 < 0 || isNaN(data8)) {
                                                  validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                  return false;
                                                }
                                              } else {
                                                validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                return false;
                                              }
                                            }
                                            var valid9 = _errs31 === errors2;
                                          } else {
                                            var valid9 = true;
                                          }
                                          if (valid9) {
                                            if (data6.tx !== void 0) {
                                              let data9 = data6.tx;
                                              const _errs33 = errors2;
                                              if (errors2 === _errs33) {
                                                if (typeof data9 == "number" && isFinite(data9)) {
                                                  if (data9 < 0 || isNaN(data9)) {
                                                    validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                    return false;
                                                  }
                                                } else {
                                                  validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                  return false;
                                                }
                                              }
                                              var valid9 = _errs33 === errors2;
                                            } else {
                                              var valid9 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid8 = _errs26 === errors2;
                                if (!valid8) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate30.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs24 === errors2;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data10 = data.updatedAt;
          const _errs35 = errors2;
          if (errors2 === _errs35) {
            if (errors2 === _errs35) {
              if (typeof data10 === "string") {
                if (func1(data10) > 64) {
                  validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data10)) {
                    validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs35 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors2++;
    validate30.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs37 = errors2;
    const _errs38 = errors2;
    let valid10 = true;
    const _errs39 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data11 = data.status;
        if (!(data11 === "unconfigured" || data11 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors2++;
        }
      }
    }
    var _valid3 = _errs39 === errors2;
    errors2 = _errs38;
    if (vErrors !== null) {
      if (_errs38) {
        vErrors.length = _errs38;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs41 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs42 = errors2;
          if (data.data !== null) {
            validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid12 = _errs42 === errors2;
        } else {
          var valid12 = true;
        }
        if (valid12) {
          if (data.updatedAt !== void 0) {
            const _errs44 = errors2;
            if (data.updatedAt !== null) {
              validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid12 = _errs44 === errors2;
          } else {
            var valid12 = true;
          }
        }
      }
      var _valid3 = _errs41 === errors2;
      valid10 = _valid3;
      if (valid10) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid10) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors2++;
      validate30.errors = vErrors;
      return false;
    }
    var valid0 = _errs37 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs46 = errors2;
      const _errs47 = errors2;
      let valid13 = true;
      const _errs48 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data14 = data.status;
          if (!(data14 === "ok" || data14 === "unconfigured" || data14 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors2++;
          }
        }
      }
      var _valid4 = _errs48 === errors2;
      errors2 = _errs47;
      if (vErrors !== null) {
        if (_errs47) {
          vErrors.length = _errs47;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs50 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate30.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs50 === errors2;
        valid13 = _valid4;
        if (valid13) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs53 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data16 = data.errorCode;
            if (!(data16 === "NETWORK_ERROR" || data16 === "INVALID_DATA" || data16 === "PAYLOAD_TOO_LARGE" || data16 === "EXPANSION_LIMIT" || data16 === "UNSUPPORTED_CALENDAR" || data16 === "UNKNOWN_TIME_ZONE" || data16 === "KEYRING_LOCKED" || data16 === "SECRET_DELETION_FAILED" || data16 === "AUTH_ERROR" || data16 === "RATE_LIMITED" || data16 === "NO_PLAYER" || data16 === "NO_INTERFACE" || data16 === "SERVICE_UNAVAILABLE" || data16 === "INTERNAL_ERROR")) {
              validate30.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema41.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs53 === errors2;
        valid13 = _valid4;
        if (valid13) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid13) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors2++;
        validate30.errors = vErrors;
        return false;
      }
      var valid0 = _errs46 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing2;
      if (data.status === void 0 && (missing2 = "status") || data.sourceId === void 0 && (missing2 = "sourceId") || data.updatedAt === void 0 && (missing2 = "updatedAt") || data.data === void 0 && (missing2 = "data") || data.errorCode === void 0 && (missing2 = "errorCode")) {
        validate30.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
        return false;
      } else {
        const _errs55 = errors2;
        for (const key2 in data) {
          if (!(key2 === "status" || key2 === "sourceId" || key2 === "updatedAt" || key2 === "data" || key2 === "errorCode")) {
            validate30.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs55 === errors2) {
          if (data.status !== void 0) {
            let data17 = data.status;
            const _errs56 = errors2;
            if (!(data17 === "loading" || data17 === "ok" || data17 === "stale" || data17 === "unconfigured" || data17 === "unavailable")) {
              validate30.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema41.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid17 = _errs56 === errors2;
          } else {
            var valid17 = true;
          }
          if (valid17) {
            if (data.sourceId !== void 0) {
              let data18 = data.sourceId;
              const _errs57 = errors2;
              const _errs58 = errors2;
              let valid18 = false;
              const _errs59 = errors2;
              if (errors2 === _errs59) {
                if (typeof data18 === "string") {
                  if (func1(data18) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors2++;
                  } else {
                    if (func1(data18) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data18)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors2++;
                }
              }
              var _valid5 = _errs59 === errors2;
              valid18 = valid18 || _valid5;
              const _errs61 = errors2;
              if (data18 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors2++;
              }
              var _valid5 = _errs61 === errors2;
              valid18 = valid18 || _valid5;
              if (!valid18) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors2++;
                validate30.errors = vErrors;
                return false;
              } else {
                errors2 = _errs58;
                if (vErrors !== null) {
                  if (_errs58) {
                    vErrors.length = _errs58;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid17 = _errs57 === errors2;
            } else {
              var valid17 = true;
            }
            if (valid17) {
              if (data.updatedAt !== void 0) {
                let data19 = data.updatedAt;
                const _errs63 = errors2;
                const _errs64 = errors2;
                let valid19 = false;
                const _errs65 = errors2;
                if (errors2 === _errs65) {
                  if (errors2 === _errs65) {
                    if (typeof data19 === "string") {
                      if (func1(data19) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data19)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid6 = _errs65 === errors2;
                valid19 = valid19 || _valid6;
                const _errs67 = errors2;
                if (data19 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors2++;
                }
                var _valid6 = _errs67 === errors2;
                valid19 = valid19 || _valid6;
                if (!valid19) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors2++;
                  validate30.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs64;
                  if (vErrors !== null) {
                    if (_errs64) {
                      vErrors.length = _errs64;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid17 = _errs63 === errors2;
              } else {
                var valid17 = true;
              }
              if (valid17) {
                if (data.data !== void 0) {
                  let data20 = data.data;
                  const _errs69 = errors2;
                  const _errs70 = errors2;
                  let valid20 = false;
                  const _errs71 = errors2;
                  const _errs72 = errors2;
                  if (errors2 === _errs72) {
                    if (data20 && typeof data20 == "object" && !Array.isArray(data20)) {
                      let missing3;
                      if (data20.interface === void 0 && (missing3 = "interface") || data20.rxBytesPerSec === void 0 && (missing3 = "rxBytesPerSec") || data20.txBytesPerSec === void 0 && (missing3 = "txBytesPerSec") || data20.history === void 0 && (missing3 = "history")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors2++;
                      } else {
                        const _errs74 = errors2;
                        for (const key3 in data20) {
                          if (!(key3 === "interface" || key3 === "rxBytesPerSec" || key3 === "txBytesPerSec" || key3 === "history")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs74 === errors2) {
                          if (data20.interface !== void 0) {
                            let data21 = data20.interface;
                            const _errs75 = errors2;
                            if (errors2 === _errs75) {
                              if (typeof data21 === "string") {
                                if (func1(data21) > 64) {
                                  const err27 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors2++;
                                } else {
                                  if (func1(data21) < 1) {
                                    const err28 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors2++;
                              }
                            }
                            var valid22 = _errs75 === errors2;
                          } else {
                            var valid22 = true;
                          }
                          if (valid22) {
                            if (data20.rxBytesPerSec !== void 0) {
                              let data22 = data20.rxBytesPerSec;
                              const _errs77 = errors2;
                              const _errs78 = errors2;
                              let valid23 = false;
                              const _errs79 = errors2;
                              if (errors2 === _errs79) {
                                if (typeof data22 == "number" && isFinite(data22)) {
                                  if (data22 < 0 || isNaN(data22)) {
                                    const err30 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err30];
                                    } else {
                                      vErrors.push(err30);
                                    }
                                    errors2++;
                                  }
                                } else {
                                  const err31 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err31];
                                  } else {
                                    vErrors.push(err31);
                                  }
                                  errors2++;
                                }
                              }
                              var _valid8 = _errs79 === errors2;
                              valid23 = valid23 || _valid8;
                              const _errs81 = errors2;
                              if (data22 !== null) {
                                const err32 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors2++;
                              }
                              var _valid8 = _errs81 === errors2;
                              valid23 = valid23 || _valid8;
                              if (!valid23) {
                                const err33 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err33];
                                } else {
                                  vErrors.push(err33);
                                }
                                errors2++;
                              } else {
                                errors2 = _errs78;
                                if (vErrors !== null) {
                                  if (_errs78) {
                                    vErrors.length = _errs78;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid22 = _errs77 === errors2;
                            } else {
                              var valid22 = true;
                            }
                            if (valid22) {
                              if (data20.txBytesPerSec !== void 0) {
                                let data23 = data20.txBytesPerSec;
                                const _errs83 = errors2;
                                const _errs84 = errors2;
                                let valid24 = false;
                                const _errs85 = errors2;
                                if (errors2 === _errs85) {
                                  if (typeof data23 == "number" && isFinite(data23)) {
                                    if (data23 < 0 || isNaN(data23)) {
                                      const err34 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors2++;
                                    }
                                  } else {
                                    const err35 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err35];
                                    } else {
                                      vErrors.push(err35);
                                    }
                                    errors2++;
                                  }
                                }
                                var _valid9 = _errs85 === errors2;
                                valid24 = valid24 || _valid9;
                                const _errs87 = errors2;
                                if (data23 !== null) {
                                  const err36 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err36];
                                  } else {
                                    vErrors.push(err36);
                                  }
                                  errors2++;
                                }
                                var _valid9 = _errs87 === errors2;
                                valid24 = valid24 || _valid9;
                                if (!valid24) {
                                  const err37 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err37];
                                  } else {
                                    vErrors.push(err37);
                                  }
                                  errors2++;
                                } else {
                                  errors2 = _errs84;
                                  if (vErrors !== null) {
                                    if (_errs84) {
                                      vErrors.length = _errs84;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid22 = _errs83 === errors2;
                              } else {
                                var valid22 = true;
                              }
                              if (valid22) {
                                if (data20.history !== void 0) {
                                  let data24 = data20.history;
                                  const _errs89 = errors2;
                                  if (errors2 === _errs89) {
                                    if (Array.isArray(data24)) {
                                      if (data24.length > 60) {
                                        const err38 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" };
                                        if (vErrors === null) {
                                          vErrors = [err38];
                                        } else {
                                          vErrors.push(err38);
                                        }
                                        errors2++;
                                      } else {
                                        var valid25 = true;
                                        const len1 = data24.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data25 = data24[i1];
                                          const _errs91 = errors2;
                                          if (errors2 === _errs91) {
                                            if (data25 && typeof data25 == "object" && !Array.isArray(data25)) {
                                              let missing4;
                                              if (data25.at === void 0 && (missing4 = "at") || data25.rx === void 0 && (missing4 = "rx") || data25.tx === void 0 && (missing4 = "tx")) {
                                                const err39 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err39];
                                                } else {
                                                  vErrors.push(err39);
                                                }
                                                errors2++;
                                              } else {
                                                const _errs93 = errors2;
                                                for (const key4 in data25) {
                                                  if (!(key4 === "at" || key4 === "rx" || key4 === "tx")) {
                                                    const err40 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err40];
                                                    } else {
                                                      vErrors.push(err40);
                                                    }
                                                    errors2++;
                                                    break;
                                                  }
                                                }
                                                if (_errs93 === errors2) {
                                                  if (data25.at !== void 0) {
                                                    let data26 = data25.at;
                                                    const _errs94 = errors2;
                                                    if (errors2 === _errs94) {
                                                      if (errors2 === _errs94) {
                                                        if (typeof data26 === "string") {
                                                          if (func1(data26) > 64) {
                                                            const err41 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err41];
                                                            } else {
                                                              vErrors.push(err41);
                                                            }
                                                            errors2++;
                                                          } else {
                                                            if (!formats0.validate(data26)) {
                                                              const err42 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err42];
                                                              } else {
                                                                vErrors.push(err42);
                                                              }
                                                              errors2++;
                                                            }
                                                          }
                                                        } else {
                                                          const err43 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err43];
                                                          } else {
                                                            vErrors.push(err43);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                    }
                                                    var valid26 = _errs94 === errors2;
                                                  } else {
                                                    var valid26 = true;
                                                  }
                                                  if (valid26) {
                                                    if (data25.rx !== void 0) {
                                                      let data27 = data25.rx;
                                                      const _errs96 = errors2;
                                                      if (errors2 === _errs96) {
                                                        if (typeof data27 == "number" && isFinite(data27)) {
                                                          if (data27 < 0 || isNaN(data27)) {
                                                            const err44 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                            if (vErrors === null) {
                                                              vErrors = [err44];
                                                            } else {
                                                              vErrors.push(err44);
                                                            }
                                                            errors2++;
                                                          }
                                                        } else {
                                                          const err45 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                          if (vErrors === null) {
                                                            vErrors = [err45];
                                                          } else {
                                                            vErrors.push(err45);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                      var valid26 = _errs96 === errors2;
                                                    } else {
                                                      var valid26 = true;
                                                    }
                                                    if (valid26) {
                                                      if (data25.tx !== void 0) {
                                                        let data28 = data25.tx;
                                                        const _errs98 = errors2;
                                                        if (errors2 === _errs98) {
                                                          if (typeof data28 == "number" && isFinite(data28)) {
                                                            if (data28 < 0 || isNaN(data28)) {
                                                              const err46 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                              if (vErrors === null) {
                                                                vErrors = [err46];
                                                              } else {
                                                                vErrors.push(err46);
                                                              }
                                                              errors2++;
                                                            }
                                                          } else {
                                                            const err47 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err47];
                                                            } else {
                                                              vErrors.push(err47);
                                                            }
                                                            errors2++;
                                                          }
                                                        }
                                                        var valid26 = _errs98 === errors2;
                                                      } else {
                                                        var valid26 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err48 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors2++;
                                            }
                                          }
                                          var valid25 = _errs91 === errors2;
                                          if (!valid25) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err49 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err49];
                                      } else {
                                        vErrors.push(err49);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid22 = _errs89 === errors2;
                                } else {
                                  var valid22 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err50 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err50];
                      } else {
                        vErrors.push(err50);
                      }
                      errors2++;
                    }
                  }
                  var _valid7 = _errs71 === errors2;
                  valid20 = valid20 || _valid7;
                  const _errs100 = errors2;
                  if (data20 !== null) {
                    const err51 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err51];
                    } else {
                      vErrors.push(err51);
                    }
                    errors2++;
                  }
                  var _valid7 = _errs100 === errors2;
                  valid20 = valid20 || _valid7;
                  if (!valid20) {
                    const err52 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err52];
                    } else {
                      vErrors.push(err52);
                    }
                    errors2++;
                    validate30.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs70;
                    if (vErrors !== null) {
                      if (_errs70) {
                        vErrors.length = _errs70;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid17 = _errs69 === errors2;
                } else {
                  var valid17 = true;
                }
                if (valid17) {
                  if (data.errorCode !== void 0) {
                    let data29 = data.errorCode;
                    const _errs102 = errors2;
                    const _errs103 = errors2;
                    let valid27 = false;
                    const _errs104 = errors2;
                    if (!(data29 === "NETWORK_ERROR" || data29 === "INVALID_DATA" || data29 === "PAYLOAD_TOO_LARGE" || data29 === "EXPANSION_LIMIT" || data29 === "UNSUPPORTED_CALENDAR" || data29 === "UNKNOWN_TIME_ZONE" || data29 === "KEYRING_LOCKED" || data29 === "SECRET_DELETION_FAILED" || data29 === "AUTH_ERROR" || data29 === "RATE_LIMITED" || data29 === "NO_PLAYER" || data29 === "NO_INTERFACE" || data29 === "SERVICE_UNAVAILABLE" || data29 === "INTERNAL_ERROR")) {
                      const err53 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema41.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err53];
                      } else {
                        vErrors.push(err53);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs104 === errors2;
                    valid27 = valid27 || _valid10;
                    const _errs105 = errors2;
                    if (data29 !== null) {
                      const err54 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err54];
                      } else {
                        vErrors.push(err54);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs105 === errors2;
                    valid27 = valid27 || _valid10;
                    if (!valid27) {
                      const err55 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err55];
                      } else {
                        vErrors.push(err55);
                      }
                      errors2++;
                      validate30.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs103;
                      if (vErrors !== null) {
                        if (_errs103) {
                          vErrors.length = _errs103;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid17 = _errs102 === errors2;
                  } else {
                    var valid17 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate30.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate30.errors = vErrors;
  return errors2 === 0;
}
validate30.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema44 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/MediaData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/MediaData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
var schema45 = { "type": "object", "additionalProperties": false, "required": ["player", "status", "title", "artist", "artUri"], "properties": { "player": { "type": "string", "maxLength": 255, "minLength": 1 }, "status": { "enum": ["playing", "paused", "stopped"] }, "title": { "type": "string", "maxLength": 4096 }, "artist": { "type": "string", "maxLength": 4096 }, "artUri": { "anyOf": [{ "type": "string", "maxLength": 4096, "pattern": "^file:///" }, { "type": "null" }] } } };
var pattern11 = new RegExp("^file:///", "u");
function validate32(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate32.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.player === void 0 && (missing0 = "player") || data1.status === void 0 && (missing0 = "status") || data1.title === void 0 && (missing0 = "title") || data1.artist === void 0 && (missing0 = "artist") || data1.artUri === void 0 && (missing0 = "artUri")) {
              validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "player" || key0 === "status" || key0 === "title" || key0 === "artist" || key0 === "artUri")) {
                  validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.player !== void 0) {
                  let data2 = data1.player;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 255) {
                        validate32.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate32.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate32.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.status !== void 0) {
                    let data3 = data1.status;
                    const _errs12 = errors2;
                    if (!(data3 === "playing" || data3 === "paused" || data3 === "stopped")) {
                      validate32.errors = [{ instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" }];
                      return false;
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.title !== void 0) {
                      let data4 = data1.title;
                      const _errs13 = errors2;
                      if (errors2 === _errs13) {
                        if (typeof data4 === "string") {
                          if (func1(data4) > 4096) {
                            validate32.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                            return false;
                          }
                        } else {
                          validate32.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                          return false;
                        }
                      }
                      var valid5 = _errs13 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.artist !== void 0) {
                        let data5 = data1.artist;
                        const _errs15 = errors2;
                        if (errors2 === _errs15) {
                          if (typeof data5 === "string") {
                            if (func1(data5) > 4096) {
                              validate32.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                              return false;
                            }
                          } else {
                            validate32.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                            return false;
                          }
                        }
                        var valid5 = _errs15 === errors2;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.artUri !== void 0) {
                          let data6 = data1.artUri;
                          const _errs17 = errors2;
                          const _errs18 = errors2;
                          let valid6 = false;
                          const _errs19 = errors2;
                          if (errors2 === _errs19) {
                            if (typeof data6 === "string") {
                              if (func1(data6) > 4096) {
                                const err1 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                if (vErrors === null) {
                                  vErrors = [err1];
                                } else {
                                  vErrors.push(err1);
                                }
                                errors2++;
                              } else {
                                if (!pattern11.test(data6)) {
                                  const err2 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors2++;
                                }
                              }
                            } else {
                              const err3 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err3];
                              } else {
                                vErrors.push(err3);
                              }
                              errors2++;
                            }
                          }
                          var _valid1 = _errs19 === errors2;
                          valid6 = valid6 || _valid1;
                          const _errs21 = errors2;
                          if (data6 !== null) {
                            const err4 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err4];
                            } else {
                              vErrors.push(err4);
                            }
                            errors2++;
                          }
                          var _valid1 = _errs21 === errors2;
                          valid6 = valid6 || _valid1;
                          if (!valid6) {
                            const err5 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors2++;
                            validate32.errors = vErrors;
                            return false;
                          } else {
                            errors2 = _errs18;
                            if (vErrors !== null) {
                              if (_errs18) {
                                vErrors.length = _errs18;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid5 = _errs17 === errors2;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data7 = data.updatedAt;
          const _errs23 = errors2;
          if (errors2 === _errs23) {
            if (errors2 === _errs23) {
              if (typeof data7 === "string") {
                if (func1(data7) > 64) {
                  validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data7)) {
                    validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs23 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err6 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err6];
    } else {
      vErrors.push(err6);
    }
    errors2++;
    validate32.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs25 = errors2;
    const _errs26 = errors2;
    let valid7 = true;
    const _errs27 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data8 = data.status;
        if (!(data8 === "unconfigured" || data8 === "unavailable")) {
          const err7 = {};
          if (vErrors === null) {
            vErrors = [err7];
          } else {
            vErrors.push(err7);
          }
          errors2++;
        }
      }
    }
    var _valid2 = _errs27 === errors2;
    errors2 = _errs26;
    if (vErrors !== null) {
      if (_errs26) {
        vErrors.length = _errs26;
      } else {
        vErrors = null;
      }
    }
    if (_valid2) {
      const _errs29 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs30 = errors2;
          if (data.data !== null) {
            validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid9 = _errs30 === errors2;
        } else {
          var valid9 = true;
        }
        if (valid9) {
          if (data.updatedAt !== void 0) {
            const _errs32 = errors2;
            if (data.updatedAt !== null) {
              validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid9 = _errs32 === errors2;
          } else {
            var valid9 = true;
          }
        }
      }
      var _valid2 = _errs29 === errors2;
      valid7 = _valid2;
      if (valid7) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid7) {
      const err8 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors2++;
      validate32.errors = vErrors;
      return false;
    }
    var valid0 = _errs25 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs34 = errors2;
      const _errs35 = errors2;
      let valid10 = true;
      const _errs36 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data11 = data.status;
          if (!(data11 === "ok" || data11 === "unconfigured" || data11 === "loading")) {
            const err9 = {};
            if (vErrors === null) {
              vErrors = [err9];
            } else {
              vErrors.push(err9);
            }
            errors2++;
          }
        }
      }
      var _valid3 = _errs36 === errors2;
      errors2 = _errs35;
      if (vErrors !== null) {
        if (_errs35) {
          vErrors.length = _errs35;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid3) {
        const _errs38 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate32.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid3 = _errs38 === errors2;
        valid10 = _valid3;
        if (valid10) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs41 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data13 = data.errorCode;
            if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
              validate32.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema44.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid3 = _errs41 === errors2;
        valid10 = _valid3;
        if (valid10) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid10) {
        const err10 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err10];
        } else {
          vErrors.push(err10);
        }
        errors2++;
        validate32.errors = vErrors;
        return false;
      }
      var valid0 = _errs34 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate32.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs43 = errors2;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate32.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs43 === errors2) {
          if (data.status !== void 0) {
            let data14 = data.status;
            const _errs44 = errors2;
            if (!(data14 === "loading" || data14 === "ok" || data14 === "stale" || data14 === "unconfigured" || data14 === "unavailable")) {
              validate32.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema44.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid14 = _errs44 === errors2;
          } else {
            var valid14 = true;
          }
          if (valid14) {
            if (data.sourceId !== void 0) {
              let data15 = data.sourceId;
              const _errs45 = errors2;
              const _errs46 = errors2;
              let valid15 = false;
              const _errs47 = errors2;
              if (errors2 === _errs47) {
                if (typeof data15 === "string") {
                  if (func1(data15) > 128) {
                    const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err11];
                    } else {
                      vErrors.push(err11);
                    }
                    errors2++;
                  } else {
                    if (func1(data15) < 1) {
                      const err12 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data15)) {
                        const err13 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err13];
                        } else {
                          vErrors.push(err13);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err14];
                  } else {
                    vErrors.push(err14);
                  }
                  errors2++;
                }
              }
              var _valid4 = _errs47 === errors2;
              valid15 = valid15 || _valid4;
              const _errs49 = errors2;
              if (data15 !== null) {
                const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err15];
                } else {
                  vErrors.push(err15);
                }
                errors2++;
              }
              var _valid4 = _errs49 === errors2;
              valid15 = valid15 || _valid4;
              if (!valid15) {
                const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err16];
                } else {
                  vErrors.push(err16);
                }
                errors2++;
                validate32.errors = vErrors;
                return false;
              } else {
                errors2 = _errs46;
                if (vErrors !== null) {
                  if (_errs46) {
                    vErrors.length = _errs46;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid14 = _errs45 === errors2;
            } else {
              var valid14 = true;
            }
            if (valid14) {
              if (data.updatedAt !== void 0) {
                let data16 = data.updatedAt;
                const _errs51 = errors2;
                const _errs52 = errors2;
                let valid16 = false;
                const _errs53 = errors2;
                if (errors2 === _errs53) {
                  if (errors2 === _errs53) {
                    if (typeof data16 === "string") {
                      if (func1(data16) > 64) {
                        const err17 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err17];
                        } else {
                          vErrors.push(err17);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data16)) {
                          const err18 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err18];
                          } else {
                            vErrors.push(err18);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err19 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid5 = _errs53 === errors2;
                valid16 = valid16 || _valid5;
                const _errs55 = errors2;
                if (data16 !== null) {
                  const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err20];
                  } else {
                    vErrors.push(err20);
                  }
                  errors2++;
                }
                var _valid5 = _errs55 === errors2;
                valid16 = valid16 || _valid5;
                if (!valid16) {
                  const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err21];
                  } else {
                    vErrors.push(err21);
                  }
                  errors2++;
                  validate32.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs52;
                  if (vErrors !== null) {
                    if (_errs52) {
                      vErrors.length = _errs52;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid14 = _errs51 === errors2;
              } else {
                var valid14 = true;
              }
              if (valid14) {
                if (data.data !== void 0) {
                  let data17 = data.data;
                  const _errs57 = errors2;
                  const _errs58 = errors2;
                  let valid17 = false;
                  const _errs59 = errors2;
                  const _errs60 = errors2;
                  if (errors2 === _errs60) {
                    if (data17 && typeof data17 == "object" && !Array.isArray(data17)) {
                      let missing2;
                      if (data17.player === void 0 && (missing2 = "player") || data17.status === void 0 && (missing2 = "status") || data17.title === void 0 && (missing2 = "title") || data17.artist === void 0 && (missing2 = "artist") || data17.artUri === void 0 && (missing2 = "artUri")) {
                        const err22 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err22];
                        } else {
                          vErrors.push(err22);
                        }
                        errors2++;
                      } else {
                        const _errs62 = errors2;
                        for (const key2 in data17) {
                          if (!(key2 === "player" || key2 === "status" || key2 === "title" || key2 === "artist" || key2 === "artUri")) {
                            const err23 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err23];
                            } else {
                              vErrors.push(err23);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs62 === errors2) {
                          if (data17.player !== void 0) {
                            let data18 = data17.player;
                            const _errs63 = errors2;
                            if (errors2 === _errs63) {
                              if (typeof data18 === "string") {
                                if (func1(data18) > 255) {
                                  const err24 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err24];
                                  } else {
                                    vErrors.push(err24);
                                  }
                                  errors2++;
                                } else {
                                  if (func1(data18) < 1) {
                                    const err25 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err25];
                                    } else {
                                      vErrors.push(err25);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err26 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err26];
                                } else {
                                  vErrors.push(err26);
                                }
                                errors2++;
                              }
                            }
                            var valid19 = _errs63 === errors2;
                          } else {
                            var valid19 = true;
                          }
                          if (valid19) {
                            if (data17.status !== void 0) {
                              let data19 = data17.status;
                              const _errs65 = errors2;
                              if (!(data19 === "playing" || data19 === "paused" || data19 === "stopped")) {
                                const err27 = { instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" };
                                if (vErrors === null) {
                                  vErrors = [err27];
                                } else {
                                  vErrors.push(err27);
                                }
                                errors2++;
                              }
                              var valid19 = _errs65 === errors2;
                            } else {
                              var valid19 = true;
                            }
                            if (valid19) {
                              if (data17.title !== void 0) {
                                let data20 = data17.title;
                                const _errs66 = errors2;
                                if (errors2 === _errs66) {
                                  if (typeof data20 === "string") {
                                    if (func1(data20) > 4096) {
                                      const err28 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err28];
                                      } else {
                                        vErrors.push(err28);
                                      }
                                      errors2++;
                                    }
                                  } else {
                                    const err29 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err29];
                                    } else {
                                      vErrors.push(err29);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid19 = _errs66 === errors2;
                              } else {
                                var valid19 = true;
                              }
                              if (valid19) {
                                if (data17.artist !== void 0) {
                                  let data21 = data17.artist;
                                  const _errs68 = errors2;
                                  if (errors2 === _errs68) {
                                    if (typeof data21 === "string") {
                                      if (func1(data21) > 4096) {
                                        const err30 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err30];
                                        } else {
                                          vErrors.push(err30);
                                        }
                                        errors2++;
                                      }
                                    } else {
                                      const err31 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err31];
                                      } else {
                                        vErrors.push(err31);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid19 = _errs68 === errors2;
                                } else {
                                  var valid19 = true;
                                }
                                if (valid19) {
                                  if (data17.artUri !== void 0) {
                                    let data22 = data17.artUri;
                                    const _errs70 = errors2;
                                    const _errs71 = errors2;
                                    let valid20 = false;
                                    const _errs72 = errors2;
                                    if (errors2 === _errs72) {
                                      if (typeof data22 === "string") {
                                        if (func1(data22) > 4096) {
                                          const err32 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err32];
                                          } else {
                                            vErrors.push(err32);
                                          }
                                          errors2++;
                                        } else {
                                          if (!pattern11.test(data22)) {
                                            const err33 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                            if (vErrors === null) {
                                              vErrors = [err33];
                                            } else {
                                              vErrors.push(err33);
                                            }
                                            errors2++;
                                          }
                                        }
                                      } else {
                                        const err34 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err34];
                                        } else {
                                          vErrors.push(err34);
                                        }
                                        errors2++;
                                      }
                                    }
                                    var _valid7 = _errs72 === errors2;
                                    valid20 = valid20 || _valid7;
                                    const _errs74 = errors2;
                                    if (data22 !== null) {
                                      const err35 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                      if (vErrors === null) {
                                        vErrors = [err35];
                                      } else {
                                        vErrors.push(err35);
                                      }
                                      errors2++;
                                    }
                                    var _valid7 = _errs74 === errors2;
                                    valid20 = valid20 || _valid7;
                                    if (!valid20) {
                                      const err36 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors2++;
                                    } else {
                                      errors2 = _errs71;
                                      if (vErrors !== null) {
                                        if (_errs71) {
                                          vErrors.length = _errs71;
                                        } else {
                                          vErrors = null;
                                        }
                                      }
                                    }
                                    var valid19 = _errs70 === errors2;
                                  } else {
                                    var valid19 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err37 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err37];
                      } else {
                        vErrors.push(err37);
                      }
                      errors2++;
                    }
                  }
                  var _valid6 = _errs59 === errors2;
                  valid17 = valid17 || _valid6;
                  const _errs76 = errors2;
                  if (data17 !== null) {
                    const err38 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err38];
                    } else {
                      vErrors.push(err38);
                    }
                    errors2++;
                  }
                  var _valid6 = _errs76 === errors2;
                  valid17 = valid17 || _valid6;
                  if (!valid17) {
                    const err39 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err39];
                    } else {
                      vErrors.push(err39);
                    }
                    errors2++;
                    validate32.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs58;
                    if (vErrors !== null) {
                      if (_errs58) {
                        vErrors.length = _errs58;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid14 = _errs57 === errors2;
                } else {
                  var valid14 = true;
                }
                if (valid14) {
                  if (data.errorCode !== void 0) {
                    let data23 = data.errorCode;
                    const _errs78 = errors2;
                    const _errs79 = errors2;
                    let valid21 = false;
                    const _errs80 = errors2;
                    if (!(data23 === "NETWORK_ERROR" || data23 === "INVALID_DATA" || data23 === "PAYLOAD_TOO_LARGE" || data23 === "EXPANSION_LIMIT" || data23 === "UNSUPPORTED_CALENDAR" || data23 === "UNKNOWN_TIME_ZONE" || data23 === "KEYRING_LOCKED" || data23 === "SECRET_DELETION_FAILED" || data23 === "AUTH_ERROR" || data23 === "RATE_LIMITED" || data23 === "NO_PLAYER" || data23 === "NO_INTERFACE" || data23 === "SERVICE_UNAVAILABLE" || data23 === "INTERNAL_ERROR")) {
                      const err40 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema44.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err40];
                      } else {
                        vErrors.push(err40);
                      }
                      errors2++;
                    }
                    var _valid8 = _errs80 === errors2;
                    valid21 = valid21 || _valid8;
                    const _errs81 = errors2;
                    if (data23 !== null) {
                      const err41 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors2++;
                    }
                    var _valid8 = _errs81 === errors2;
                    valid21 = valid21 || _valid8;
                    if (!valid21) {
                      const err42 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err42];
                      } else {
                        vErrors.push(err42);
                      }
                      errors2++;
                      validate32.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs79;
                      if (vErrors !== null) {
                        if (_errs79) {
                          vErrors.length = _errs79;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid14 = _errs78 === errors2;
                  } else {
                    var valid14 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate32.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate32.errors = vErrors;
  return errors2 === 0;
}
validate32.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate20(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate20.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.schemaVersion === void 0 && (missing0 = "schemaVersion") || data.generatedAt === void 0 && (missing0 = "generatedAt") || data.revisions === void 0 && (missing0 = "revisions") || data.calendar === void 0 && (missing0 = "calendar") || data.weather === void 0 && (missing0 = "weather") || data.system === void 0 && (missing0 = "system") || data.network === void 0 && (missing0 = "network") || data.media === void 0 && (missing0 = "media")) {
        validate20.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "schemaVersion" || key0 === "generatedAt" || key0 === "revisions" || key0 === "calendar" || key0 === "weather" || key0 === "system" || key0 === "network" || key0 === "media")) {
            validate20.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.schemaVersion !== void 0) {
            const _errs2 = errors2;
            if (1 !== data.schemaVersion) {
              validate20.errors = [{ instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.generatedAt !== void 0) {
              let data1 = data.generatedAt;
              const _errs3 = errors2;
              if (errors2 === _errs3) {
                if (errors2 === _errs3) {
                  if (typeof data1 === "string") {
                    if (func1(data1) > 64) {
                      validate20.errors = [{ instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                      return false;
                    } else {
                      if (!formats0.validate(data1)) {
                        validate20.errors = [{ instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                        return false;
                      }
                    }
                  } else {
                    validate20.errors = [{ instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
              }
              var valid0 = _errs3 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.revisions !== void 0) {
                let data2 = data.revisions;
                const _errs5 = errors2;
                if (errors2 === _errs5) {
                  if (data2 && typeof data2 == "object" && !Array.isArray(data2)) {
                    let missing1;
                    if (data2.calendar === void 0 && (missing1 = "calendar") || data2.weather === void 0 && (missing1 = "weather") || data2.system === void 0 && (missing1 = "system") || data2.network === void 0 && (missing1 = "network") || data2.media === void 0 && (missing1 = "media")) {
                      validate20.errors = [{ instancePath: instancePath + "/revisions", schemaPath: "#/properties/revisions/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                      return false;
                    } else {
                      const _errs7 = errors2;
                      for (const key1 in data2) {
                        if (!(key1 === "calendar" || key1 === "weather" || key1 === "system" || key1 === "network" || key1 === "media")) {
                          validate20.errors = [{ instancePath: instancePath + "/revisions", schemaPath: "#/properties/revisions/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                          return false;
                          break;
                        }
                      }
                      if (_errs7 === errors2) {
                        if (data2.calendar !== void 0) {
                          let data3 = data2.calendar;
                          const _errs8 = errors2;
                          if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                            validate20.errors = [{ instancePath: instancePath + "/revisions/calendar", schemaPath: "#/properties/revisions/properties/calendar/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                            return false;
                          }
                          if (errors2 === _errs8) {
                            if (typeof data3 == "number" && isFinite(data3)) {
                              if (data3 > 4294967295 || isNaN(data3)) {
                                validate20.errors = [{ instancePath: instancePath + "/revisions/calendar", schemaPath: "#/properties/revisions/properties/calendar/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                return false;
                              } else {
                                if (data3 < 0 || isNaN(data3)) {
                                  validate20.errors = [{ instancePath: instancePath + "/revisions/calendar", schemaPath: "#/properties/revisions/properties/calendar/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                  return false;
                                }
                              }
                            }
                          }
                          var valid1 = _errs8 === errors2;
                        } else {
                          var valid1 = true;
                        }
                        if (valid1) {
                          if (data2.weather !== void 0) {
                            let data4 = data2.weather;
                            const _errs10 = errors2;
                            if (!(typeof data4 == "number" && (!(data4 % 1) && !isNaN(data4)) && isFinite(data4))) {
                              validate20.errors = [{ instancePath: instancePath + "/revisions/weather", schemaPath: "#/properties/revisions/properties/weather/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                              return false;
                            }
                            if (errors2 === _errs10) {
                              if (typeof data4 == "number" && isFinite(data4)) {
                                if (data4 > 4294967295 || isNaN(data4)) {
                                  validate20.errors = [{ instancePath: instancePath + "/revisions/weather", schemaPath: "#/properties/revisions/properties/weather/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                  return false;
                                } else {
                                  if (data4 < 0 || isNaN(data4)) {
                                    validate20.errors = [{ instancePath: instancePath + "/revisions/weather", schemaPath: "#/properties/revisions/properties/weather/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                    return false;
                                  }
                                }
                              }
                            }
                            var valid1 = _errs10 === errors2;
                          } else {
                            var valid1 = true;
                          }
                          if (valid1) {
                            if (data2.system !== void 0) {
                              let data5 = data2.system;
                              const _errs12 = errors2;
                              if (!(typeof data5 == "number" && (!(data5 % 1) && !isNaN(data5)) && isFinite(data5))) {
                                validate20.errors = [{ instancePath: instancePath + "/revisions/system", schemaPath: "#/properties/revisions/properties/system/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                return false;
                              }
                              if (errors2 === _errs12) {
                                if (typeof data5 == "number" && isFinite(data5)) {
                                  if (data5 > 4294967295 || isNaN(data5)) {
                                    validate20.errors = [{ instancePath: instancePath + "/revisions/system", schemaPath: "#/properties/revisions/properties/system/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                    return false;
                                  } else {
                                    if (data5 < 0 || isNaN(data5)) {
                                      validate20.errors = [{ instancePath: instancePath + "/revisions/system", schemaPath: "#/properties/revisions/properties/system/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                      return false;
                                    }
                                  }
                                }
                              }
                              var valid1 = _errs12 === errors2;
                            } else {
                              var valid1 = true;
                            }
                            if (valid1) {
                              if (data2.network !== void 0) {
                                let data6 = data2.network;
                                const _errs14 = errors2;
                                if (!(typeof data6 == "number" && (!(data6 % 1) && !isNaN(data6)) && isFinite(data6))) {
                                  validate20.errors = [{ instancePath: instancePath + "/revisions/network", schemaPath: "#/properties/revisions/properties/network/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                  return false;
                                }
                                if (errors2 === _errs14) {
                                  if (typeof data6 == "number" && isFinite(data6)) {
                                    if (data6 > 4294967295 || isNaN(data6)) {
                                      validate20.errors = [{ instancePath: instancePath + "/revisions/network", schemaPath: "#/properties/revisions/properties/network/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                      return false;
                                    } else {
                                      if (data6 < 0 || isNaN(data6)) {
                                        validate20.errors = [{ instancePath: instancePath + "/revisions/network", schemaPath: "#/properties/revisions/properties/network/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                        return false;
                                      }
                                    }
                                  }
                                }
                                var valid1 = _errs14 === errors2;
                              } else {
                                var valid1 = true;
                              }
                              if (valid1) {
                                if (data2.media !== void 0) {
                                  let data7 = data2.media;
                                  const _errs16 = errors2;
                                  if (!(typeof data7 == "number" && (!(data7 % 1) && !isNaN(data7)) && isFinite(data7))) {
                                    validate20.errors = [{ instancePath: instancePath + "/revisions/media", schemaPath: "#/properties/revisions/properties/media/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                    return false;
                                  }
                                  if (errors2 === _errs16) {
                                    if (typeof data7 == "number" && isFinite(data7)) {
                                      if (data7 > 4294967295 || isNaN(data7)) {
                                        validate20.errors = [{ instancePath: instancePath + "/revisions/media", schemaPath: "#/properties/revisions/properties/media/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                        return false;
                                      } else {
                                        if (data7 < 0 || isNaN(data7)) {
                                          validate20.errors = [{ instancePath: instancePath + "/revisions/media", schemaPath: "#/properties/revisions/properties/media/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                          return false;
                                        }
                                      }
                                    }
                                  }
                                  var valid1 = _errs16 === errors2;
                                } else {
                                  var valid1 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    validate20.errors = [{ instancePath: instancePath + "/revisions", schemaPath: "#/properties/revisions/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                    return false;
                  }
                }
                var valid0 = _errs5 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.calendar !== void 0) {
                  const _errs18 = errors2;
                  if (!validate21(data.calendar, { instancePath: instancePath + "/calendar", parentData: data, parentDataProperty: "calendar", rootData, dynamicAnchors })) {
                    vErrors = vErrors === null ? validate21.errors : vErrors.concat(validate21.errors);
                    errors2 = vErrors.length;
                  }
                  var valid0 = _errs18 === errors2;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.weather !== void 0) {
                    const _errs19 = errors2;
                    if (!validate26(data.weather, { instancePath: instancePath + "/weather", parentData: data, parentDataProperty: "weather", rootData, dynamicAnchors })) {
                      vErrors = vErrors === null ? validate26.errors : vErrors.concat(validate26.errors);
                      errors2 = vErrors.length;
                    }
                    var valid0 = _errs19 === errors2;
                  } else {
                    var valid0 = true;
                  }
                  if (valid0) {
                    if (data.system !== void 0) {
                      const _errs20 = errors2;
                      if (!validate28(data.system, { instancePath: instancePath + "/system", parentData: data, parentDataProperty: "system", rootData, dynamicAnchors })) {
                        vErrors = vErrors === null ? validate28.errors : vErrors.concat(validate28.errors);
                        errors2 = vErrors.length;
                      }
                      var valid0 = _errs20 === errors2;
                    } else {
                      var valid0 = true;
                    }
                    if (valid0) {
                      if (data.network !== void 0) {
                        const _errs21 = errors2;
                        if (!validate30(data.network, { instancePath: instancePath + "/network", parentData: data, parentDataProperty: "network", rootData, dynamicAnchors })) {
                          vErrors = vErrors === null ? validate30.errors : vErrors.concat(validate30.errors);
                          errors2 = vErrors.length;
                        }
                        var valid0 = _errs21 === errors2;
                      } else {
                        var valid0 = true;
                      }
                      if (valid0) {
                        if (data.media !== void 0) {
                          const _errs22 = errors2;
                          if (!validate32(data.media, { instancePath: instancePath + "/media", parentData: data, parentDataProperty: "media", rootData, dynamicAnchors })) {
                            vErrors = vErrors === null ? validate32.errors : vErrors.concat(validate32.errors);
                            errors2 = vErrors.length;
                          }
                          var valid0 = _errs22 === errors2;
                        } else {
                          var valid0 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate20.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate20.errors = vErrors;
  return errors2 === 0;
}
validate20.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var settings = validate34;
function validate34(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate34.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.calendarEnabled === void 0 && (missing0 = "calendarEnabled") || data.calendarSecretDeletionPending === void 0 && (missing0 = "calendarSecretDeletionPending") || data.weatherLocation === void 0 && (missing0 = "weatherLocation") || data.networkInterface === void 0 && (missing0 = "networkInterface")) {
        validate34.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "calendarEnabled" || key0 === "calendarSecretDeletionPending" || key0 === "weatherLocation" || key0 === "networkInterface")) {
            validate34.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.calendarEnabled !== void 0) {
            const _errs2 = errors2;
            if (typeof data.calendarEnabled !== "boolean") {
              validate34.errors = [{ instancePath: instancePath + "/calendarEnabled", schemaPath: "#/properties/calendarEnabled/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.calendarSecretDeletionPending !== void 0) {
              const _errs4 = errors2;
              if (typeof data.calendarSecretDeletionPending !== "boolean") {
                validate34.errors = [{ instancePath: instancePath + "/calendarSecretDeletionPending", schemaPath: "#/properties/calendarSecretDeletionPending/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                return false;
              }
              var valid0 = _errs4 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weatherLocation !== void 0) {
                let data2 = data.weatherLocation;
                const _errs6 = errors2;
                const _errs7 = errors2;
                let valid1 = false;
                const _errs8 = errors2;
                const _errs9 = errors2;
                if (errors2 === _errs9) {
                  if (data2 && typeof data2 == "object" && !Array.isArray(data2)) {
                    let missing1;
                    if (data2.id === void 0 && (missing1 = "id") || data2.label === void 0 && (missing1 = "label") || data2.latitude === void 0 && (missing1 = "latitude") || data2.longitude === void 0 && (missing1 = "longitude") || data2.timeZone === void 0 && (missing1 = "timeZone")) {
                      const err0 = { instancePath: instancePath + "/weatherLocation", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" };
                      if (vErrors === null) {
                        vErrors = [err0];
                      } else {
                        vErrors.push(err0);
                      }
                      errors2++;
                    } else {
                      const _errs11 = errors2;
                      for (const key1 in data2) {
                        if (!(key1 === "id" || key1 === "label" || key1 === "latitude" || key1 === "longitude" || key1 === "timeZone")) {
                          const err1 = { instancePath: instancePath + "/weatherLocation", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
                          if (vErrors === null) {
                            vErrors = [err1];
                          } else {
                            vErrors.push(err1);
                          }
                          errors2++;
                          break;
                        }
                      }
                      if (_errs11 === errors2) {
                        if (data2.id !== void 0) {
                          let data3 = data2.id;
                          const _errs12 = errors2;
                          if (errors2 === _errs12) {
                            if (typeof data3 === "string") {
                              if (func1(data3) > 128) {
                                const err2 = { instancePath: instancePath + "/weatherLocation/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                                if (vErrors === null) {
                                  vErrors = [err2];
                                } else {
                                  vErrors.push(err2);
                                }
                                errors2++;
                              } else {
                                if (func1(data3) < 1) {
                                  const err3 = { instancePath: instancePath + "/weatherLocation/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err3];
                                  } else {
                                    vErrors.push(err3);
                                  }
                                  errors2++;
                                }
                              }
                            } else {
                              const err4 = { instancePath: instancePath + "/weatherLocation/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err4];
                              } else {
                                vErrors.push(err4);
                              }
                              errors2++;
                            }
                          }
                          var valid3 = _errs12 === errors2;
                        } else {
                          var valid3 = true;
                        }
                        if (valid3) {
                          if (data2.label !== void 0) {
                            let data4 = data2.label;
                            const _errs14 = errors2;
                            if (errors2 === _errs14) {
                              if (typeof data4 === "string") {
                                if (func1(data4) > 512) {
                                  const err5 = { instancePath: instancePath + "/weatherLocation/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err5];
                                  } else {
                                    vErrors.push(err5);
                                  }
                                  errors2++;
                                } else {
                                  if (func1(data4) < 1) {
                                    const err6 = { instancePath: instancePath + "/weatherLocation/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err6];
                                    } else {
                                      vErrors.push(err6);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err7 = { instancePath: instancePath + "/weatherLocation/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err7];
                                } else {
                                  vErrors.push(err7);
                                }
                                errors2++;
                              }
                            }
                            var valid3 = _errs14 === errors2;
                          } else {
                            var valid3 = true;
                          }
                          if (valid3) {
                            if (data2.latitude !== void 0) {
                              let data5 = data2.latitude;
                              const _errs16 = errors2;
                              if (errors2 === _errs16) {
                                if (typeof data5 == "number" && isFinite(data5)) {
                                  if (data5 > 90 || isNaN(data5)) {
                                    const err8 = { instancePath: instancePath + "/weatherLocation/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors2++;
                                  } else {
                                    if (data5 < -90 || isNaN(data5)) {
                                      const err9 = { instancePath: instancePath + "/weatherLocation/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" };
                                      if (vErrors === null) {
                                        vErrors = [err9];
                                      } else {
                                        vErrors.push(err9);
                                      }
                                      errors2++;
                                    }
                                  }
                                } else {
                                  const err10 = { instancePath: instancePath + "/weatherLocation/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err10];
                                  } else {
                                    vErrors.push(err10);
                                  }
                                  errors2++;
                                }
                              }
                              var valid3 = _errs16 === errors2;
                            } else {
                              var valid3 = true;
                            }
                            if (valid3) {
                              if (data2.longitude !== void 0) {
                                let data6 = data2.longitude;
                                const _errs18 = errors2;
                                if (errors2 === _errs18) {
                                  if (typeof data6 == "number" && isFinite(data6)) {
                                    if (data6 > 180 || isNaN(data6)) {
                                      const err11 = { instancePath: instancePath + "/weatherLocation/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" };
                                      if (vErrors === null) {
                                        vErrors = [err11];
                                      } else {
                                        vErrors.push(err11);
                                      }
                                      errors2++;
                                    } else {
                                      if (data6 < -180 || isNaN(data6)) {
                                        const err12 = { instancePath: instancePath + "/weatherLocation/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" };
                                        if (vErrors === null) {
                                          vErrors = [err12];
                                        } else {
                                          vErrors.push(err12);
                                        }
                                        errors2++;
                                      }
                                    }
                                  } else {
                                    const err13 = { instancePath: instancePath + "/weatherLocation/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err13];
                                    } else {
                                      vErrors.push(err13);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid3 = _errs18 === errors2;
                              } else {
                                var valid3 = true;
                              }
                              if (valid3) {
                                if (data2.timeZone !== void 0) {
                                  let data7 = data2.timeZone;
                                  const _errs20 = errors2;
                                  if (errors2 === _errs20) {
                                    if (typeof data7 === "string") {
                                      if (func1(data7) > 255) {
                                        const err14 = { instancePath: instancePath + "/weatherLocation/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err14];
                                        } else {
                                          vErrors.push(err14);
                                        }
                                        errors2++;
                                      } else {
                                        if (func1(data7) < 1) {
                                          const err15 = { instancePath: instancePath + "/weatherLocation/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err15];
                                          } else {
                                            vErrors.push(err15);
                                          }
                                          errors2++;
                                        }
                                      }
                                    } else {
                                      const err16 = { instancePath: instancePath + "/weatherLocation/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err16];
                                      } else {
                                        vErrors.push(err16);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid3 = _errs20 === errors2;
                                } else {
                                  var valid3 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    const err17 = { instancePath: instancePath + "/weatherLocation", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors2++;
                  }
                }
                var _valid0 = _errs8 === errors2;
                valid1 = valid1 || _valid0;
                const _errs22 = errors2;
                if (data2 !== null) {
                  const err18 = { instancePath: instancePath + "/weatherLocation", schemaPath: "#/properties/weatherLocation/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err18];
                  } else {
                    vErrors.push(err18);
                  }
                  errors2++;
                }
                var _valid0 = _errs22 === errors2;
                valid1 = valid1 || _valid0;
                if (!valid1) {
                  const err19 = { instancePath: instancePath + "/weatherLocation", schemaPath: "#/properties/weatherLocation/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err19];
                  } else {
                    vErrors.push(err19);
                  }
                  errors2++;
                  validate34.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs7;
                  if (vErrors !== null) {
                    if (_errs7) {
                      vErrors.length = _errs7;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid0 = _errs6 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.networkInterface !== void 0) {
                  let data8 = data.networkInterface;
                  const _errs24 = errors2;
                  if (errors2 === _errs24) {
                    if (typeof data8 === "string") {
                      if (func1(data8) > 64) {
                        validate34.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                        return false;
                      } else {
                        if (func1(data8) < 1) {
                          validate34.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate34.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid0 = _errs24 === errors2;
                } else {
                  var valid0 = true;
                }
              }
            }
          }
        }
      }
    } else {
      validate34.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate34.errors = vErrors;
  return errors2 === 0;
}
validate34.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate35(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate35.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.month === void 0 && (missing0 = "month") || data.timeZone === void 0 && (missing0 = "timeZone") || data.weekStart === void 0 && (missing0 = "weekStart")) {
        validate35.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "month" || key0 === "timeZone" || key0 === "weekStart")) {
            validate35.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.month !== void 0) {
            let data0 = data.month;
            const _errs2 = errors2;
            if (errors2 === _errs2) {
              if (typeof data0 === "string") {
                if (func1(data0) > 7) {
                  validate35.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                  return false;
                } else {
                  if (!pattern4.test(data0)) {
                    validate35.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                    return false;
                  }
                }
              } else {
                validate35.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.timeZone !== void 0) {
              let data1 = data.timeZone;
              const _errs4 = errors2;
              if (errors2 === _errs4) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 255) {
                    validate35.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate35.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate35.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs4 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weekStart !== void 0) {
                let data2 = data.weekStart;
                const _errs6 = errors2;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate35.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors2 === _errs6) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 6 || isNaN(data2)) {
                      validate35.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate35.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs6 === errors2;
              } else {
                var valid0 = true;
              }
            }
          }
        }
      }
    } else {
      validate35.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate35.errors = vErrors;
  return errors2 === 0;
}
validate35.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate36(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate36.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs0 = errors2;
  let valid0 = false;
  const _errs1 = errors2;
  const _errs2 = errors2;
  if (errors2 === _errs2) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.id === void 0 && (missing0 = "id") || data.label === void 0 && (missing0 = "label") || data.latitude === void 0 && (missing0 = "latitude") || data.longitude === void 0 && (missing0 = "longitude") || data.timeZone === void 0 && (missing0 = "timeZone")) {
        const err0 = { instancePath, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" };
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      } else {
        const _errs4 = errors2;
        for (const key0 in data) {
          if (!(key0 === "id" || key0 === "label" || key0 === "latitude" || key0 === "longitude" || key0 === "timeZone")) {
            const err1 = { instancePath, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err1];
            } else {
              vErrors.push(err1);
            }
            errors2++;
            break;
          }
        }
        if (_errs4 === errors2) {
          if (data.id !== void 0) {
            let data0 = data.id;
            const _errs5 = errors2;
            if (errors2 === _errs5) {
              if (typeof data0 === "string") {
                if (func1(data0) > 128) {
                  const err2 = { instancePath: instancePath + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                  if (vErrors === null) {
                    vErrors = [err2];
                  } else {
                    vErrors.push(err2);
                  }
                  errors2++;
                } else {
                  if (func1(data0) < 1) {
                    const err3 = { instancePath: instancePath + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                    if (vErrors === null) {
                      vErrors = [err3];
                    } else {
                      vErrors.push(err3);
                    }
                    errors2++;
                  }
                }
              } else {
                const err4 = { instancePath: instancePath + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err4];
                } else {
                  vErrors.push(err4);
                }
                errors2++;
              }
            }
            var valid2 = _errs5 === errors2;
          } else {
            var valid2 = true;
          }
          if (valid2) {
            if (data.label !== void 0) {
              let data1 = data.label;
              const _errs7 = errors2;
              if (errors2 === _errs7) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 512) {
                    const err5 = { instancePath: instancePath + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                    if (vErrors === null) {
                      vErrors = [err5];
                    } else {
                      vErrors.push(err5);
                    }
                    errors2++;
                  } else {
                    if (func1(data1) < 1) {
                      const err6 = { instancePath: instancePath + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err6];
                      } else {
                        vErrors.push(err6);
                      }
                      errors2++;
                    }
                  }
                } else {
                  const err7 = { instancePath: instancePath + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err7];
                  } else {
                    vErrors.push(err7);
                  }
                  errors2++;
                }
              }
              var valid2 = _errs7 === errors2;
            } else {
              var valid2 = true;
            }
            if (valid2) {
              if (data.latitude !== void 0) {
                let data2 = data.latitude;
                const _errs9 = errors2;
                if (errors2 === _errs9) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 90 || isNaN(data2)) {
                      const err8 = { instancePath: instancePath + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" };
                      if (vErrors === null) {
                        vErrors = [err8];
                      } else {
                        vErrors.push(err8);
                      }
                      errors2++;
                    } else {
                      if (data2 < -90 || isNaN(data2)) {
                        const err9 = { instancePath: instancePath + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" };
                        if (vErrors === null) {
                          vErrors = [err9];
                        } else {
                          vErrors.push(err9);
                        }
                        errors2++;
                      }
                    }
                  } else {
                    const err10 = { instancePath: instancePath + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                    if (vErrors === null) {
                      vErrors = [err10];
                    } else {
                      vErrors.push(err10);
                    }
                    errors2++;
                  }
                }
                var valid2 = _errs9 === errors2;
              } else {
                var valid2 = true;
              }
              if (valid2) {
                if (data.longitude !== void 0) {
                  let data3 = data.longitude;
                  const _errs11 = errors2;
                  if (errors2 === _errs11) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 180 || isNaN(data3)) {
                        const err11 = { instancePath: instancePath + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" };
                        if (vErrors === null) {
                          vErrors = [err11];
                        } else {
                          vErrors.push(err11);
                        }
                        errors2++;
                      } else {
                        if (data3 < -180 || isNaN(data3)) {
                          const err12 = { instancePath: instancePath + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" };
                          if (vErrors === null) {
                            vErrors = [err12];
                          } else {
                            vErrors.push(err12);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err13 = { instancePath: instancePath + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                      if (vErrors === null) {
                        vErrors = [err13];
                      } else {
                        vErrors.push(err13);
                      }
                      errors2++;
                    }
                  }
                  var valid2 = _errs11 === errors2;
                } else {
                  var valid2 = true;
                }
                if (valid2) {
                  if (data.timeZone !== void 0) {
                    let data4 = data.timeZone;
                    const _errs13 = errors2;
                    if (errors2 === _errs13) {
                      if (typeof data4 === "string") {
                        if (func1(data4) > 255) {
                          const err14 = { instancePath: instancePath + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                          if (vErrors === null) {
                            vErrors = [err14];
                          } else {
                            vErrors.push(err14);
                          }
                          errors2++;
                        } else {
                          if (func1(data4) < 1) {
                            const err15 = { instancePath: instancePath + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err15];
                            } else {
                              vErrors.push(err15);
                            }
                            errors2++;
                          }
                        }
                      } else {
                        const err16 = { instancePath: instancePath + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors2++;
                      }
                    }
                    var valid2 = _errs13 === errors2;
                  } else {
                    var valid2 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      const err17 = { instancePath, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" };
      if (vErrors === null) {
        vErrors = [err17];
      } else {
        vErrors.push(err17);
      }
      errors2++;
    }
  }
  var _valid0 = _errs1 === errors2;
  valid0 = valid0 || _valid0;
  if (_valid0) {
    var props0 = true;
  }
  const _errs15 = errors2;
  if (data !== null) {
    const err18 = { instancePath, schemaPath: "#/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
    if (vErrors === null) {
      vErrors = [err18];
    } else {
      vErrors.push(err18);
    }
    errors2++;
  }
  var _valid0 = _errs15 === errors2;
  valid0 = valid0 || _valid0;
  if (!valid0) {
    const err19 = { instancePath, schemaPath: "#/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
    if (vErrors === null) {
      vErrors = [err19];
    } else {
      vErrors.push(err19);
    }
    errors2++;
    validate36.errors = vErrors;
    return false;
  } else {
    errors2 = _errs0;
    if (vErrors !== null) {
      if (_errs0) {
        vErrors.length = _errs0;
      } else {
        vErrors = null;
      }
    }
  }
  validate36.errors = vErrors;
  evaluated0.props = props0;
  return errors2 === 0;
}
validate36.evaluated = { "dynamicProps": true, "dynamicItems": false };
var locationSearchResults = validate37;
function validate37(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate37.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (Array.isArray(data)) {
      if (data.length > 20) {
        validate37.errors = [{ instancePath, schemaPath: "#/maxItems", keyword: "maxItems", params: { limit: 20 }, message: "must NOT have more than 20 items" }];
        return false;
      } else {
        var valid0 = true;
        const len0 = data.length;
        for (let i0 = 0; i0 < len0; i0++) {
          let data0 = data[i0];
          const _errs1 = errors2;
          const _errs2 = errors2;
          if (errors2 === _errs2) {
            if (data0 && typeof data0 == "object" && !Array.isArray(data0)) {
              let missing0;
              if (data0.id === void 0 && (missing0 = "id") || data0.label === void 0 && (missing0 = "label") || data0.latitude === void 0 && (missing0 = "latitude") || data0.longitude === void 0 && (missing0 = "longitude") || data0.timeZone === void 0 && (missing0 = "timeZone")) {
                validate37.errors = [{ instancePath: instancePath + "/" + i0, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
                return false;
              } else {
                const _errs4 = errors2;
                for (const key0 in data0) {
                  if (!(key0 === "id" || key0 === "label" || key0 === "latitude" || key0 === "longitude" || key0 === "timeZone")) {
                    validate37.errors = [{ instancePath: instancePath + "/" + i0, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                    return false;
                    break;
                  }
                }
                if (_errs4 === errors2) {
                  if (data0.id !== void 0) {
                    let data1 = data0.id;
                    const _errs5 = errors2;
                    if (errors2 === _errs5) {
                      if (typeof data1 === "string") {
                        if (func1(data1) > 128) {
                          validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" }];
                          return false;
                        } else {
                          if (func1(data1) < 1) {
                            validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          }
                        }
                      } else {
                        validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid2 = _errs5 === errors2;
                  } else {
                    var valid2 = true;
                  }
                  if (valid2) {
                    if (data0.label !== void 0) {
                      let data2 = data0.label;
                      const _errs7 = errors2;
                      if (errors2 === _errs7) {
                        if (typeof data2 === "string") {
                          if (func1(data2) > 512) {
                            validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                            return false;
                          } else {
                            if (func1(data2) < 1) {
                              validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                              return false;
                            }
                          }
                        } else {
                          validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                          return false;
                        }
                      }
                      var valid2 = _errs7 === errors2;
                    } else {
                      var valid2 = true;
                    }
                    if (valid2) {
                      if (data0.latitude !== void 0) {
                        let data3 = data0.latitude;
                        const _errs9 = errors2;
                        if (errors2 === _errs9) {
                          if (typeof data3 == "number" && isFinite(data3)) {
                            if (data3 > 90 || isNaN(data3)) {
                              validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" }];
                              return false;
                            } else {
                              if (data3 < -90 || isNaN(data3)) {
                                validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" }];
                                return false;
                              }
                            }
                          } else {
                            validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                            return false;
                          }
                        }
                        var valid2 = _errs9 === errors2;
                      } else {
                        var valid2 = true;
                      }
                      if (valid2) {
                        if (data0.longitude !== void 0) {
                          let data4 = data0.longitude;
                          const _errs11 = errors2;
                          if (errors2 === _errs11) {
                            if (typeof data4 == "number" && isFinite(data4)) {
                              if (data4 > 180 || isNaN(data4)) {
                                validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" }];
                                return false;
                              } else {
                                if (data4 < -180 || isNaN(data4)) {
                                  validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" }];
                                  return false;
                                }
                              }
                            } else {
                              validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                              return false;
                            }
                          }
                          var valid2 = _errs11 === errors2;
                        } else {
                          var valid2 = true;
                        }
                        if (valid2) {
                          if (data0.timeZone !== void 0) {
                            let data5 = data0.timeZone;
                            const _errs13 = errors2;
                            if (errors2 === _errs13) {
                              if (typeof data5 === "string") {
                                if (func1(data5) > 255) {
                                  validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                                  return false;
                                } else {
                                  if (func1(data5) < 1) {
                                    validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                    return false;
                                  }
                                }
                              } else {
                                validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                return false;
                              }
                            }
                            var valid2 = _errs13 === errors2;
                          } else {
                            var valid2 = true;
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              validate37.errors = [{ instancePath: instancePath + "/" + i0, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
              return false;
            }
          }
          var valid0 = _errs1 === errors2;
          if (!valid0) {
            break;
          }
        }
      }
    } else {
      validate37.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
      return false;
    }
  }
  validate37.errors = vErrors;
  return errors2 === 0;
}
validate37.evaluated = { "items": true, "dynamicProps": false, "dynamicItems": false };
var calendar = validate38;
function validate38(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate38.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        const _errs6 = errors2;
        if (!validate22(data.data, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
          vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
          errors2 = vErrors.length;
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data2 = data.updatedAt;
          const _errs7 = errors2;
          if (errors2 === _errs7) {
            if (errors2 === _errs7) {
              if (typeof data2 === "string") {
                if (func1(data2) > 64) {
                  validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data2)) {
                    validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs7 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err1 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err1];
    } else {
      vErrors.push(err1);
    }
    errors2++;
    validate38.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs9 = errors2;
    const _errs10 = errors2;
    let valid4 = true;
    const _errs11 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data3 = data.status;
        if (!(data3 === "unconfigured" || data3 === "unavailable")) {
          const err2 = {};
          if (vErrors === null) {
            vErrors = [err2];
          } else {
            vErrors.push(err2);
          }
          errors2++;
        }
      }
    }
    var _valid1 = _errs11 === errors2;
    errors2 = _errs10;
    if (vErrors !== null) {
      if (_errs10) {
        vErrors.length = _errs10;
      } else {
        vErrors = null;
      }
    }
    if (_valid1) {
      const _errs13 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs14 = errors2;
          if (data.data !== null) {
            validate38.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid6 = _errs14 === errors2;
        } else {
          var valid6 = true;
        }
        if (valid6) {
          if (data.updatedAt !== void 0) {
            const _errs16 = errors2;
            if (data.updatedAt !== null) {
              validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid6 = _errs16 === errors2;
          } else {
            var valid6 = true;
          }
        }
      }
      var _valid1 = _errs13 === errors2;
      valid4 = _valid1;
      if (valid4) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid4) {
      const err3 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors2++;
      validate38.errors = vErrors;
      return false;
    }
    var valid0 = _errs9 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs18 = errors2;
      const _errs19 = errors2;
      let valid7 = true;
      const _errs20 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data6 = data.status;
          if (!(data6 === "ok" || data6 === "unconfigured" || data6 === "loading")) {
            const err4 = {};
            if (vErrors === null) {
              vErrors = [err4];
            } else {
              vErrors.push(err4);
            }
            errors2++;
          }
        }
      }
      var _valid2 = _errs20 === errors2;
      errors2 = _errs19;
      if (vErrors !== null) {
        if (_errs19) {
          vErrors.length = _errs19;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid2) {
        const _errs22 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate38.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid2 = _errs22 === errors2;
        valid7 = _valid2;
        if (valid7) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs25 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data8 = data.errorCode;
            if (!(data8 === "NETWORK_ERROR" || data8 === "INVALID_DATA" || data8 === "PAYLOAD_TOO_LARGE" || data8 === "EXPANSION_LIMIT" || data8 === "UNSUPPORTED_CALENDAR" || data8 === "UNKNOWN_TIME_ZONE" || data8 === "KEYRING_LOCKED" || data8 === "SECRET_DELETION_FAILED" || data8 === "AUTH_ERROR" || data8 === "RATE_LIMITED" || data8 === "NO_PLAYER" || data8 === "NO_INTERFACE" || data8 === "SERVICE_UNAVAILABLE" || data8 === "INTERNAL_ERROR")) {
              validate38.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema32.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid2 = _errs25 === errors2;
        valid7 = _valid2;
        if (valid7) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid7) {
        const err5 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err5];
        } else {
          vErrors.push(err5);
        }
        errors2++;
        validate38.errors = vErrors;
        return false;
      }
      var valid0 = _errs18 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.status === void 0 && (missing0 = "status") || data.sourceId === void 0 && (missing0 = "sourceId") || data.updatedAt === void 0 && (missing0 = "updatedAt") || data.data === void 0 && (missing0 = "data") || data.errorCode === void 0 && (missing0 = "errorCode")) {
        validate38.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs27 = errors2;
        for (const key0 in data) {
          if (!(key0 === "status" || key0 === "sourceId" || key0 === "updatedAt" || key0 === "data" || key0 === "errorCode")) {
            validate38.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs27 === errors2) {
          if (data.status !== void 0) {
            let data9 = data.status;
            const _errs28 = errors2;
            if (!(data9 === "loading" || data9 === "ok" || data9 === "stale" || data9 === "unconfigured" || data9 === "unavailable")) {
              validate38.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema32.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid11 = _errs28 === errors2;
          } else {
            var valid11 = true;
          }
          if (valid11) {
            if (data.sourceId !== void 0) {
              let data10 = data.sourceId;
              const _errs29 = errors2;
              const _errs30 = errors2;
              let valid12 = false;
              const _errs31 = errors2;
              if (errors2 === _errs31) {
                if (typeof data10 === "string") {
                  if (func1(data10) > 128) {
                    const err6 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err6];
                    } else {
                      vErrors.push(err6);
                    }
                    errors2++;
                  } else {
                    if (func1(data10) < 1) {
                      const err7 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err7];
                      } else {
                        vErrors.push(err7);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data10)) {
                        const err8 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err9 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err9];
                  } else {
                    vErrors.push(err9);
                  }
                  errors2++;
                }
              }
              var _valid3 = _errs31 === errors2;
              valid12 = valid12 || _valid3;
              const _errs33 = errors2;
              if (data10 !== null) {
                const err10 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err10];
                } else {
                  vErrors.push(err10);
                }
                errors2++;
              }
              var _valid3 = _errs33 === errors2;
              valid12 = valid12 || _valid3;
              if (!valid12) {
                const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err11];
                } else {
                  vErrors.push(err11);
                }
                errors2++;
                validate38.errors = vErrors;
                return false;
              } else {
                errors2 = _errs30;
                if (vErrors !== null) {
                  if (_errs30) {
                    vErrors.length = _errs30;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid11 = _errs29 === errors2;
            } else {
              var valid11 = true;
            }
            if (valid11) {
              if (data.updatedAt !== void 0) {
                let data11 = data.updatedAt;
                const _errs35 = errors2;
                const _errs36 = errors2;
                let valid13 = false;
                const _errs37 = errors2;
                if (errors2 === _errs37) {
                  if (errors2 === _errs37) {
                    if (typeof data11 === "string") {
                      if (func1(data11) > 64) {
                        const err12 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err12];
                        } else {
                          vErrors.push(err12);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data11)) {
                          const err13 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err13];
                          } else {
                            vErrors.push(err13);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err14 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err14];
                      } else {
                        vErrors.push(err14);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid4 = _errs37 === errors2;
                valid13 = valid13 || _valid4;
                const _errs39 = errors2;
                if (data11 !== null) {
                  const err15 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err15];
                  } else {
                    vErrors.push(err15);
                  }
                  errors2++;
                }
                var _valid4 = _errs39 === errors2;
                valid13 = valid13 || _valid4;
                if (!valid13) {
                  const err16 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err16];
                  } else {
                    vErrors.push(err16);
                  }
                  errors2++;
                  validate38.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs36;
                  if (vErrors !== null) {
                    if (_errs36) {
                      vErrors.length = _errs36;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid11 = _errs35 === errors2;
              } else {
                var valid11 = true;
              }
              if (valid11) {
                if (data.data !== void 0) {
                  let data12 = data.data;
                  const _errs41 = errors2;
                  const _errs42 = errors2;
                  let valid14 = false;
                  const _errs43 = errors2;
                  if (!validate22(data12, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
                    vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
                    errors2 = vErrors.length;
                  }
                  var _valid5 = _errs43 === errors2;
                  valid14 = valid14 || _valid5;
                  const _errs44 = errors2;
                  if (data12 !== null) {
                    const err17 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors2++;
                  }
                  var _valid5 = _errs44 === errors2;
                  valid14 = valid14 || _valid5;
                  if (!valid14) {
                    const err18 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err18];
                    } else {
                      vErrors.push(err18);
                    }
                    errors2++;
                    validate38.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs42;
                    if (vErrors !== null) {
                      if (_errs42) {
                        vErrors.length = _errs42;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid11 = _errs41 === errors2;
                } else {
                  var valid11 = true;
                }
                if (valid11) {
                  if (data.errorCode !== void 0) {
                    let data13 = data.errorCode;
                    const _errs46 = errors2;
                    const _errs47 = errors2;
                    let valid15 = false;
                    const _errs48 = errors2;
                    if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
                      const err19 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema32.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors2++;
                    }
                    var _valid6 = _errs48 === errors2;
                    valid15 = valid15 || _valid6;
                    const _errs49 = errors2;
                    if (data13 !== null) {
                      const err20 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err20];
                      } else {
                        vErrors.push(err20);
                      }
                      errors2++;
                    }
                    var _valid6 = _errs49 === errors2;
                    valid15 = valid15 || _valid6;
                    if (!valid15) {
                      const err21 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err21];
                      } else {
                        vErrors.push(err21);
                      }
                      errors2++;
                      validate38.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs47;
                      if (vErrors !== null) {
                        if (_errs47) {
                          vErrors.length = _errs47;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid11 = _errs46 === errors2;
                  } else {
                    var valid11 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate38.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate38.errors = vErrors;
  return errors2 === 0;
}
validate38.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var weather = validate41;
function validate41(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate41.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.location === void 0 && (missing0 = "location") || data1.timeZone === void 0 && (missing0 = "timeZone") || data1.current === void 0 && (missing0 = "current") || data1.hourly === void 0 && (missing0 = "hourly") || data1.attributionUrl === void 0 && (missing0 = "attributionUrl")) {
              validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "location" || key0 === "timeZone" || key0 === "current" || key0 === "hourly" || key0 === "attributionUrl")) {
                  validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.location !== void 0) {
                  let data2 = data1.location;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 512) {
                        validate41.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                        return false;
                      }
                    } else {
                      validate41.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.timeZone !== void 0) {
                    let data3 = data1.timeZone;
                    const _errs12 = errors2;
                    if (errors2 === _errs12) {
                      if (typeof data3 === "string") {
                        if (func1(data3) > 255) {
                          validate41.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                          return false;
                        } else {
                          if (func1(data3) < 1) {
                            validate41.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          }
                        }
                      } else {
                        validate41.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.current !== void 0) {
                      let data4 = data1.current;
                      const _errs14 = errors2;
                      if (errors2 === _errs14) {
                        if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                          let missing1;
                          if (data4.temperatureC === void 0 && (missing1 = "temperatureC") || data4.code === void 0 && (missing1 = "code")) {
                            validate41.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                            return false;
                          } else {
                            const _errs16 = errors2;
                            for (const key1 in data4) {
                              if (!(key1 === "temperatureC" || key1 === "code")) {
                                validate41.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                return false;
                                break;
                              }
                            }
                            if (_errs16 === errors2) {
                              if (data4.temperatureC !== void 0) {
                                let data5 = data4.temperatureC;
                                const _errs17 = errors2;
                                const _errs18 = errors2;
                                let valid7 = false;
                                const _errs19 = errors2;
                                if (!(typeof data5 == "number" && isFinite(data5))) {
                                  const err1 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err1];
                                  } else {
                                    vErrors.push(err1);
                                  }
                                  errors2++;
                                }
                                var _valid1 = _errs19 === errors2;
                                valid7 = valid7 || _valid1;
                                const _errs21 = errors2;
                                if (data5 !== null) {
                                  const err2 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors2++;
                                }
                                var _valid1 = _errs21 === errors2;
                                valid7 = valid7 || _valid1;
                                if (!valid7) {
                                  const err3 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err3];
                                  } else {
                                    vErrors.push(err3);
                                  }
                                  errors2++;
                                  validate41.errors = vErrors;
                                  return false;
                                } else {
                                  errors2 = _errs18;
                                  if (vErrors !== null) {
                                    if (_errs18) {
                                      vErrors.length = _errs18;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid6 = _errs17 === errors2;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.code !== void 0) {
                                  let data6 = data4.code;
                                  const _errs23 = errors2;
                                  const _errs24 = errors2;
                                  let valid8 = false;
                                  const _errs25 = errors2;
                                  if (!(typeof data6 == "number" && (!(data6 % 1) && !isNaN(data6)) && isFinite(data6))) {
                                    const err4 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err4];
                                    } else {
                                      vErrors.push(err4);
                                    }
                                    errors2++;
                                  }
                                  if (errors2 === _errs25) {
                                    if (typeof data6 == "number" && isFinite(data6)) {
                                      if (data6 > 99 || isNaN(data6)) {
                                        const err5 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                        if (vErrors === null) {
                                          vErrors = [err5];
                                        } else {
                                          vErrors.push(err5);
                                        }
                                        errors2++;
                                      } else {
                                        if (data6 < 0 || isNaN(data6)) {
                                          const err6 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                          if (vErrors === null) {
                                            vErrors = [err6];
                                          } else {
                                            vErrors.push(err6);
                                          }
                                          errors2++;
                                        }
                                      }
                                    }
                                  }
                                  var _valid2 = _errs25 === errors2;
                                  valid8 = valid8 || _valid2;
                                  const _errs27 = errors2;
                                  if (data6 !== null) {
                                    const err7 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err7];
                                    } else {
                                      vErrors.push(err7);
                                    }
                                    errors2++;
                                  }
                                  var _valid2 = _errs27 === errors2;
                                  valid8 = valid8 || _valid2;
                                  if (!valid8) {
                                    const err8 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors2++;
                                    validate41.errors = vErrors;
                                    return false;
                                  } else {
                                    errors2 = _errs24;
                                    if (vErrors !== null) {
                                      if (_errs24) {
                                        vErrors.length = _errs24;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid6 = _errs23 === errors2;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                          }
                        } else {
                          validate41.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                          return false;
                        }
                      }
                      var valid5 = _errs14 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.hourly !== void 0) {
                        let data7 = data1.hourly;
                        const _errs29 = errors2;
                        if (errors2 === _errs29) {
                          if (Array.isArray(data7)) {
                            if (data7.length > 6) {
                              validate41.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" }];
                              return false;
                            } else {
                              var valid9 = true;
                              const len0 = data7.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data8 = data7[i0];
                                const _errs31 = errors2;
                                if (errors2 === _errs31) {
                                  if (data8 && typeof data8 == "object" && !Array.isArray(data8)) {
                                    let missing2;
                                    if (data8.at === void 0 && (missing2 = "at") || data8.temperatureC === void 0 && (missing2 = "temperatureC") || data8.precipitationProbability === void 0 && (missing2 = "precipitationProbability")) {
                                      validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
                                      return false;
                                    } else {
                                      const _errs33 = errors2;
                                      for (const key2 in data8) {
                                        if (!(key2 === "at" || key2 === "temperatureC" || key2 === "precipitationProbability")) {
                                          validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs33 === errors2) {
                                        if (data8.at !== void 0) {
                                          let data9 = data8.at;
                                          const _errs34 = errors2;
                                          if (errors2 === _errs34) {
                                            if (errors2 === _errs34) {
                                              if (typeof data9 === "string") {
                                                if (func1(data9) > 64) {
                                                  validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data9)) {
                                                    validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid10 = _errs34 === errors2;
                                        } else {
                                          var valid10 = true;
                                        }
                                        if (valid10) {
                                          if (data8.temperatureC !== void 0) {
                                            let data10 = data8.temperatureC;
                                            const _errs36 = errors2;
                                            const _errs37 = errors2;
                                            let valid11 = false;
                                            const _errs38 = errors2;
                                            if (!(typeof data10 == "number" && isFinite(data10))) {
                                              const err9 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                              if (vErrors === null) {
                                                vErrors = [err9];
                                              } else {
                                                vErrors.push(err9);
                                              }
                                              errors2++;
                                            }
                                            var _valid3 = _errs38 === errors2;
                                            valid11 = valid11 || _valid3;
                                            const _errs40 = errors2;
                                            if (data10 !== null) {
                                              const err10 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err10];
                                              } else {
                                                vErrors.push(err10);
                                              }
                                              errors2++;
                                            }
                                            var _valid3 = _errs40 === errors2;
                                            valid11 = valid11 || _valid3;
                                            if (!valid11) {
                                              const err11 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err11];
                                              } else {
                                                vErrors.push(err11);
                                              }
                                              errors2++;
                                              validate41.errors = vErrors;
                                              return false;
                                            } else {
                                              errors2 = _errs37;
                                              if (vErrors !== null) {
                                                if (_errs37) {
                                                  vErrors.length = _errs37;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid10 = _errs36 === errors2;
                                          } else {
                                            var valid10 = true;
                                          }
                                          if (valid10) {
                                            if (data8.precipitationProbability !== void 0) {
                                              let data11 = data8.precipitationProbability;
                                              const _errs42 = errors2;
                                              const _errs43 = errors2;
                                              let valid12 = false;
                                              const _errs44 = errors2;
                                              if (errors2 === _errs44) {
                                                if (typeof data11 == "number" && isFinite(data11)) {
                                                  if (data11 > 100 || isNaN(data11)) {
                                                    const err12 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                    if (vErrors === null) {
                                                      vErrors = [err12];
                                                    } else {
                                                      vErrors.push(err12);
                                                    }
                                                    errors2++;
                                                  } else {
                                                    if (data11 < 0 || isNaN(data11)) {
                                                      const err13 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                      if (vErrors === null) {
                                                        vErrors = [err13];
                                                      } else {
                                                        vErrors.push(err13);
                                                      }
                                                      errors2++;
                                                    }
                                                  }
                                                } else {
                                                  const err14 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                  if (vErrors === null) {
                                                    vErrors = [err14];
                                                  } else {
                                                    vErrors.push(err14);
                                                  }
                                                  errors2++;
                                                }
                                              }
                                              var _valid4 = _errs44 === errors2;
                                              valid12 = valid12 || _valid4;
                                              const _errs46 = errors2;
                                              if (data11 !== null) {
                                                const err15 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                if (vErrors === null) {
                                                  vErrors = [err15];
                                                } else {
                                                  vErrors.push(err15);
                                                }
                                                errors2++;
                                              }
                                              var _valid4 = _errs46 === errors2;
                                              valid12 = valid12 || _valid4;
                                              if (!valid12) {
                                                const err16 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                if (vErrors === null) {
                                                  vErrors = [err16];
                                                } else {
                                                  vErrors.push(err16);
                                                }
                                                errors2++;
                                                validate41.errors = vErrors;
                                                return false;
                                              } else {
                                                errors2 = _errs43;
                                                if (vErrors !== null) {
                                                  if (_errs43) {
                                                    vErrors.length = _errs43;
                                                  } else {
                                                    vErrors = null;
                                                  }
                                                }
                                              }
                                              var valid10 = _errs42 === errors2;
                                            } else {
                                              var valid10 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid9 = _errs31 === errors2;
                                if (!valid9) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate41.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs29 === errors2;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.attributionUrl !== void 0) {
                          let data12 = data1.attributionUrl;
                          const _errs48 = errors2;
                          if (errors2 === _errs48) {
                            if (typeof data12 === "string") {
                              if (func1(data12) > 512) {
                                validate41.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                                return false;
                              } else {
                                if (!pattern6.test(data12)) {
                                  validate41.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' }];
                                  return false;
                                }
                              }
                            } else {
                              validate41.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                              return false;
                            }
                          }
                          var valid5 = _errs48 === errors2;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data13 = data.updatedAt;
          const _errs50 = errors2;
          if (errors2 === _errs50) {
            if (errors2 === _errs50) {
              if (typeof data13 === "string") {
                if (func1(data13) > 64) {
                  validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data13)) {
                    validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs50 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err17 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err17];
    } else {
      vErrors.push(err17);
    }
    errors2++;
    validate41.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs52 = errors2;
    const _errs53 = errors2;
    let valid13 = true;
    const _errs54 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data14 = data.status;
        if (!(data14 === "unconfigured" || data14 === "unavailable")) {
          const err18 = {};
          if (vErrors === null) {
            vErrors = [err18];
          } else {
            vErrors.push(err18);
          }
          errors2++;
        }
      }
    }
    var _valid5 = _errs54 === errors2;
    errors2 = _errs53;
    if (vErrors !== null) {
      if (_errs53) {
        vErrors.length = _errs53;
      } else {
        vErrors = null;
      }
    }
    if (_valid5) {
      const _errs56 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs57 = errors2;
          if (data.data !== null) {
            validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid15 = _errs57 === errors2;
        } else {
          var valid15 = true;
        }
        if (valid15) {
          if (data.updatedAt !== void 0) {
            const _errs59 = errors2;
            if (data.updatedAt !== null) {
              validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid15 = _errs59 === errors2;
          } else {
            var valid15 = true;
          }
        }
      }
      var _valid5 = _errs56 === errors2;
      valid13 = _valid5;
      if (valid13) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid13) {
      const err19 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err19];
      } else {
        vErrors.push(err19);
      }
      errors2++;
      validate41.errors = vErrors;
      return false;
    }
    var valid0 = _errs52 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs61 = errors2;
      const _errs62 = errors2;
      let valid16 = true;
      const _errs63 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data17 = data.status;
          if (!(data17 === "ok" || data17 === "unconfigured" || data17 === "loading")) {
            const err20 = {};
            if (vErrors === null) {
              vErrors = [err20];
            } else {
              vErrors.push(err20);
            }
            errors2++;
          }
        }
      }
      var _valid6 = _errs63 === errors2;
      errors2 = _errs62;
      if (vErrors !== null) {
        if (_errs62) {
          vErrors.length = _errs62;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid6) {
        const _errs65 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate41.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid6 = _errs65 === errors2;
        valid16 = _valid6;
        if (valid16) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs68 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data19 = data.errorCode;
            if (!(data19 === "NETWORK_ERROR" || data19 === "INVALID_DATA" || data19 === "PAYLOAD_TOO_LARGE" || data19 === "EXPANSION_LIMIT" || data19 === "UNSUPPORTED_CALENDAR" || data19 === "UNKNOWN_TIME_ZONE" || data19 === "KEYRING_LOCKED" || data19 === "SECRET_DELETION_FAILED" || data19 === "AUTH_ERROR" || data19 === "RATE_LIMITED" || data19 === "NO_PLAYER" || data19 === "NO_INTERFACE" || data19 === "SERVICE_UNAVAILABLE" || data19 === "INTERNAL_ERROR")) {
              validate41.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema35.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid6 = _errs68 === errors2;
        valid16 = _valid6;
        if (valid16) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid16) {
        const err21 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err21];
        } else {
          vErrors.push(err21);
        }
        errors2++;
        validate41.errors = vErrors;
        return false;
      }
      var valid0 = _errs61 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing3;
      if (data.status === void 0 && (missing3 = "status") || data.sourceId === void 0 && (missing3 = "sourceId") || data.updatedAt === void 0 && (missing3 = "updatedAt") || data.data === void 0 && (missing3 = "data") || data.errorCode === void 0 && (missing3 = "errorCode")) {
        validate41.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" }];
        return false;
      } else {
        const _errs70 = errors2;
        for (const key3 in data) {
          if (!(key3 === "status" || key3 === "sourceId" || key3 === "updatedAt" || key3 === "data" || key3 === "errorCode")) {
            validate41.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs70 === errors2) {
          if (data.status !== void 0) {
            let data20 = data.status;
            const _errs71 = errors2;
            if (!(data20 === "loading" || data20 === "ok" || data20 === "stale" || data20 === "unconfigured" || data20 === "unavailable")) {
              validate41.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema35.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid20 = _errs71 === errors2;
          } else {
            var valid20 = true;
          }
          if (valid20) {
            if (data.sourceId !== void 0) {
              let data21 = data.sourceId;
              const _errs72 = errors2;
              const _errs73 = errors2;
              let valid21 = false;
              const _errs74 = errors2;
              if (errors2 === _errs74) {
                if (typeof data21 === "string") {
                  if (func1(data21) > 128) {
                    const err22 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err22];
                    } else {
                      vErrors.push(err22);
                    }
                    errors2++;
                  } else {
                    if (func1(data21) < 1) {
                      const err23 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err23];
                      } else {
                        vErrors.push(err23);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data21)) {
                        const err24 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err24];
                        } else {
                          vErrors.push(err24);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err25 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err25];
                  } else {
                    vErrors.push(err25);
                  }
                  errors2++;
                }
              }
              var _valid7 = _errs74 === errors2;
              valid21 = valid21 || _valid7;
              const _errs76 = errors2;
              if (data21 !== null) {
                const err26 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err26];
                } else {
                  vErrors.push(err26);
                }
                errors2++;
              }
              var _valid7 = _errs76 === errors2;
              valid21 = valid21 || _valid7;
              if (!valid21) {
                const err27 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err27];
                } else {
                  vErrors.push(err27);
                }
                errors2++;
                validate41.errors = vErrors;
                return false;
              } else {
                errors2 = _errs73;
                if (vErrors !== null) {
                  if (_errs73) {
                    vErrors.length = _errs73;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid20 = _errs72 === errors2;
            } else {
              var valid20 = true;
            }
            if (valid20) {
              if (data.updatedAt !== void 0) {
                let data22 = data.updatedAt;
                const _errs78 = errors2;
                const _errs79 = errors2;
                let valid22 = false;
                const _errs80 = errors2;
                if (errors2 === _errs80) {
                  if (errors2 === _errs80) {
                    if (typeof data22 === "string") {
                      if (func1(data22) > 64) {
                        const err28 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err28];
                        } else {
                          vErrors.push(err28);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data22)) {
                          const err29 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err29];
                          } else {
                            vErrors.push(err29);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err30 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err30];
                      } else {
                        vErrors.push(err30);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid8 = _errs80 === errors2;
                valid22 = valid22 || _valid8;
                const _errs82 = errors2;
                if (data22 !== null) {
                  const err31 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err31];
                  } else {
                    vErrors.push(err31);
                  }
                  errors2++;
                }
                var _valid8 = _errs82 === errors2;
                valid22 = valid22 || _valid8;
                if (!valid22) {
                  const err32 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err32];
                  } else {
                    vErrors.push(err32);
                  }
                  errors2++;
                  validate41.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs79;
                  if (vErrors !== null) {
                    if (_errs79) {
                      vErrors.length = _errs79;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid20 = _errs78 === errors2;
              } else {
                var valid20 = true;
              }
              if (valid20) {
                if (data.data !== void 0) {
                  let data23 = data.data;
                  const _errs84 = errors2;
                  const _errs85 = errors2;
                  let valid23 = false;
                  const _errs86 = errors2;
                  const _errs87 = errors2;
                  if (errors2 === _errs87) {
                    if (data23 && typeof data23 == "object" && !Array.isArray(data23)) {
                      let missing4;
                      if (data23.location === void 0 && (missing4 = "location") || data23.timeZone === void 0 && (missing4 = "timeZone") || data23.current === void 0 && (missing4 = "current") || data23.hourly === void 0 && (missing4 = "hourly") || data23.attributionUrl === void 0 && (missing4 = "attributionUrl")) {
                        const err33 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                        if (vErrors === null) {
                          vErrors = [err33];
                        } else {
                          vErrors.push(err33);
                        }
                        errors2++;
                      } else {
                        const _errs89 = errors2;
                        for (const key4 in data23) {
                          if (!(key4 === "location" || key4 === "timeZone" || key4 === "current" || key4 === "hourly" || key4 === "attributionUrl")) {
                            const err34 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err34];
                            } else {
                              vErrors.push(err34);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs89 === errors2) {
                          if (data23.location !== void 0) {
                            let data24 = data23.location;
                            const _errs90 = errors2;
                            if (errors2 === _errs90) {
                              if (typeof data24 === "string") {
                                if (func1(data24) > 512) {
                                  const err35 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors2++;
                                }
                              } else {
                                const err36 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err36];
                                } else {
                                  vErrors.push(err36);
                                }
                                errors2++;
                              }
                            }
                            var valid25 = _errs90 === errors2;
                          } else {
                            var valid25 = true;
                          }
                          if (valid25) {
                            if (data23.timeZone !== void 0) {
                              let data25 = data23.timeZone;
                              const _errs92 = errors2;
                              if (errors2 === _errs92) {
                                if (typeof data25 === "string") {
                                  if (func1(data25) > 255) {
                                    const err37 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err37];
                                    } else {
                                      vErrors.push(err37);
                                    }
                                    errors2++;
                                  } else {
                                    if (func1(data25) < 1) {
                                      const err38 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err38];
                                      } else {
                                        vErrors.push(err38);
                                      }
                                      errors2++;
                                    }
                                  }
                                } else {
                                  const err39 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err39];
                                  } else {
                                    vErrors.push(err39);
                                  }
                                  errors2++;
                                }
                              }
                              var valid25 = _errs92 === errors2;
                            } else {
                              var valid25 = true;
                            }
                            if (valid25) {
                              if (data23.current !== void 0) {
                                let data26 = data23.current;
                                const _errs94 = errors2;
                                if (errors2 === _errs94) {
                                  if (data26 && typeof data26 == "object" && !Array.isArray(data26)) {
                                    let missing5;
                                    if (data26.temperatureC === void 0 && (missing5 = "temperatureC") || data26.code === void 0 && (missing5 = "code")) {
                                      const err40 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing5 }, message: "must have required property '" + missing5 + "'" };
                                      if (vErrors === null) {
                                        vErrors = [err40];
                                      } else {
                                        vErrors.push(err40);
                                      }
                                      errors2++;
                                    } else {
                                      const _errs96 = errors2;
                                      for (const key5 in data26) {
                                        if (!(key5 === "temperatureC" || key5 === "code")) {
                                          const err41 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                                          if (vErrors === null) {
                                            vErrors = [err41];
                                          } else {
                                            vErrors.push(err41);
                                          }
                                          errors2++;
                                          break;
                                        }
                                      }
                                      if (_errs96 === errors2) {
                                        if (data26.temperatureC !== void 0) {
                                          let data27 = data26.temperatureC;
                                          const _errs97 = errors2;
                                          const _errs98 = errors2;
                                          let valid27 = false;
                                          const _errs99 = errors2;
                                          if (!(typeof data27 == "number" && isFinite(data27))) {
                                            const err42 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                            if (vErrors === null) {
                                              vErrors = [err42];
                                            } else {
                                              vErrors.push(err42);
                                            }
                                            errors2++;
                                          }
                                          var _valid10 = _errs99 === errors2;
                                          valid27 = valid27 || _valid10;
                                          const _errs101 = errors2;
                                          if (data27 !== null) {
                                            const err43 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                            if (vErrors === null) {
                                              vErrors = [err43];
                                            } else {
                                              vErrors.push(err43);
                                            }
                                            errors2++;
                                          }
                                          var _valid10 = _errs101 === errors2;
                                          valid27 = valid27 || _valid10;
                                          if (!valid27) {
                                            const err44 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                            if (vErrors === null) {
                                              vErrors = [err44];
                                            } else {
                                              vErrors.push(err44);
                                            }
                                            errors2++;
                                          } else {
                                            errors2 = _errs98;
                                            if (vErrors !== null) {
                                              if (_errs98) {
                                                vErrors.length = _errs98;
                                              } else {
                                                vErrors = null;
                                              }
                                            }
                                          }
                                          var valid26 = _errs97 === errors2;
                                        } else {
                                          var valid26 = true;
                                        }
                                        if (valid26) {
                                          if (data26.code !== void 0) {
                                            let data28 = data26.code;
                                            const _errs103 = errors2;
                                            const _errs104 = errors2;
                                            let valid28 = false;
                                            const _errs105 = errors2;
                                            if (!(typeof data28 == "number" && (!(data28 % 1) && !isNaN(data28)) && isFinite(data28))) {
                                              const err45 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                              if (vErrors === null) {
                                                vErrors = [err45];
                                              } else {
                                                vErrors.push(err45);
                                              }
                                              errors2++;
                                            }
                                            if (errors2 === _errs105) {
                                              if (typeof data28 == "number" && isFinite(data28)) {
                                                if (data28 > 99 || isNaN(data28)) {
                                                  const err46 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                                  if (vErrors === null) {
                                                    vErrors = [err46];
                                                  } else {
                                                    vErrors.push(err46);
                                                  }
                                                  errors2++;
                                                } else {
                                                  if (data28 < 0 || isNaN(data28)) {
                                                    const err47 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                    if (vErrors === null) {
                                                      vErrors = [err47];
                                                    } else {
                                                      vErrors.push(err47);
                                                    }
                                                    errors2++;
                                                  }
                                                }
                                              }
                                            }
                                            var _valid11 = _errs105 === errors2;
                                            valid28 = valid28 || _valid11;
                                            const _errs107 = errors2;
                                            if (data28 !== null) {
                                              const err48 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors2++;
                                            }
                                            var _valid11 = _errs107 === errors2;
                                            valid28 = valid28 || _valid11;
                                            if (!valid28) {
                                              const err49 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err49];
                                              } else {
                                                vErrors.push(err49);
                                              }
                                              errors2++;
                                            } else {
                                              errors2 = _errs104;
                                              if (vErrors !== null) {
                                                if (_errs104) {
                                                  vErrors.length = _errs104;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid26 = _errs103 === errors2;
                                          } else {
                                            var valid26 = true;
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    const err50 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                    if (vErrors === null) {
                                      vErrors = [err50];
                                    } else {
                                      vErrors.push(err50);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid25 = _errs94 === errors2;
                              } else {
                                var valid25 = true;
                              }
                              if (valid25) {
                                if (data23.hourly !== void 0) {
                                  let data29 = data23.hourly;
                                  const _errs109 = errors2;
                                  if (errors2 === _errs109) {
                                    if (Array.isArray(data29)) {
                                      if (data29.length > 6) {
                                        const err51 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" };
                                        if (vErrors === null) {
                                          vErrors = [err51];
                                        } else {
                                          vErrors.push(err51);
                                        }
                                        errors2++;
                                      } else {
                                        var valid29 = true;
                                        const len1 = data29.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data30 = data29[i1];
                                          const _errs111 = errors2;
                                          if (errors2 === _errs111) {
                                            if (data30 && typeof data30 == "object" && !Array.isArray(data30)) {
                                              let missing6;
                                              if (data30.at === void 0 && (missing6 = "at") || data30.temperatureC === void 0 && (missing6 = "temperatureC") || data30.precipitationProbability === void 0 && (missing6 = "precipitationProbability")) {
                                                const err52 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing6 }, message: "must have required property '" + missing6 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err52];
                                                } else {
                                                  vErrors.push(err52);
                                                }
                                                errors2++;
                                              } else {
                                                const _errs113 = errors2;
                                                for (const key6 in data30) {
                                                  if (!(key6 === "at" || key6 === "temperatureC" || key6 === "precipitationProbability")) {
                                                    const err53 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err53];
                                                    } else {
                                                      vErrors.push(err53);
                                                    }
                                                    errors2++;
                                                    break;
                                                  }
                                                }
                                                if (_errs113 === errors2) {
                                                  if (data30.at !== void 0) {
                                                    let data31 = data30.at;
                                                    const _errs114 = errors2;
                                                    if (errors2 === _errs114) {
                                                      if (errors2 === _errs114) {
                                                        if (typeof data31 === "string") {
                                                          if (func1(data31) > 64) {
                                                            const err54 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err54];
                                                            } else {
                                                              vErrors.push(err54);
                                                            }
                                                            errors2++;
                                                          } else {
                                                            if (!formats0.validate(data31)) {
                                                              const err55 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err55];
                                                              } else {
                                                                vErrors.push(err55);
                                                              }
                                                              errors2++;
                                                            }
                                                          }
                                                        } else {
                                                          const err56 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err56];
                                                          } else {
                                                            vErrors.push(err56);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                    }
                                                    var valid30 = _errs114 === errors2;
                                                  } else {
                                                    var valid30 = true;
                                                  }
                                                  if (valid30) {
                                                    if (data30.temperatureC !== void 0) {
                                                      let data32 = data30.temperatureC;
                                                      const _errs116 = errors2;
                                                      const _errs117 = errors2;
                                                      let valid31 = false;
                                                      const _errs118 = errors2;
                                                      if (!(typeof data32 == "number" && isFinite(data32))) {
                                                        const err57 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                        if (vErrors === null) {
                                                          vErrors = [err57];
                                                        } else {
                                                          vErrors.push(err57);
                                                        }
                                                        errors2++;
                                                      }
                                                      var _valid12 = _errs118 === errors2;
                                                      valid31 = valid31 || _valid12;
                                                      const _errs120 = errors2;
                                                      if (data32 !== null) {
                                                        const err58 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                        if (vErrors === null) {
                                                          vErrors = [err58];
                                                        } else {
                                                          vErrors.push(err58);
                                                        }
                                                        errors2++;
                                                      }
                                                      var _valid12 = _errs120 === errors2;
                                                      valid31 = valid31 || _valid12;
                                                      if (!valid31) {
                                                        const err59 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                        if (vErrors === null) {
                                                          vErrors = [err59];
                                                        } else {
                                                          vErrors.push(err59);
                                                        }
                                                        errors2++;
                                                      } else {
                                                        errors2 = _errs117;
                                                        if (vErrors !== null) {
                                                          if (_errs117) {
                                                            vErrors.length = _errs117;
                                                          } else {
                                                            vErrors = null;
                                                          }
                                                        }
                                                      }
                                                      var valid30 = _errs116 === errors2;
                                                    } else {
                                                      var valid30 = true;
                                                    }
                                                    if (valid30) {
                                                      if (data30.precipitationProbability !== void 0) {
                                                        let data33 = data30.precipitationProbability;
                                                        const _errs122 = errors2;
                                                        const _errs123 = errors2;
                                                        let valid32 = false;
                                                        const _errs124 = errors2;
                                                        if (errors2 === _errs124) {
                                                          if (typeof data33 == "number" && isFinite(data33)) {
                                                            if (data33 > 100 || isNaN(data33)) {
                                                              const err60 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                              if (vErrors === null) {
                                                                vErrors = [err60];
                                                              } else {
                                                                vErrors.push(err60);
                                                              }
                                                              errors2++;
                                                            } else {
                                                              if (data33 < 0 || isNaN(data33)) {
                                                                const err61 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                                if (vErrors === null) {
                                                                  vErrors = [err61];
                                                                } else {
                                                                  vErrors.push(err61);
                                                                }
                                                                errors2++;
                                                              }
                                                            }
                                                          } else {
                                                            const err62 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err62];
                                                            } else {
                                                              vErrors.push(err62);
                                                            }
                                                            errors2++;
                                                          }
                                                        }
                                                        var _valid13 = _errs124 === errors2;
                                                        valid32 = valid32 || _valid13;
                                                        const _errs126 = errors2;
                                                        if (data33 !== null) {
                                                          const err63 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                          if (vErrors === null) {
                                                            vErrors = [err63];
                                                          } else {
                                                            vErrors.push(err63);
                                                          }
                                                          errors2++;
                                                        }
                                                        var _valid13 = _errs126 === errors2;
                                                        valid32 = valid32 || _valid13;
                                                        if (!valid32) {
                                                          const err64 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                          if (vErrors === null) {
                                                            vErrors = [err64];
                                                          } else {
                                                            vErrors.push(err64);
                                                          }
                                                          errors2++;
                                                        } else {
                                                          errors2 = _errs123;
                                                          if (vErrors !== null) {
                                                            if (_errs123) {
                                                              vErrors.length = _errs123;
                                                            } else {
                                                              vErrors = null;
                                                            }
                                                          }
                                                        }
                                                        var valid30 = _errs122 === errors2;
                                                      } else {
                                                        var valid30 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err65 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err65];
                                              } else {
                                                vErrors.push(err65);
                                              }
                                              errors2++;
                                            }
                                          }
                                          var valid29 = _errs111 === errors2;
                                          if (!valid29) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err66 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err66];
                                      } else {
                                        vErrors.push(err66);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid25 = _errs109 === errors2;
                                } else {
                                  var valid25 = true;
                                }
                                if (valid25) {
                                  if (data23.attributionUrl !== void 0) {
                                    let data34 = data23.attributionUrl;
                                    const _errs128 = errors2;
                                    if (errors2 === _errs128) {
                                      if (typeof data34 === "string") {
                                        if (func1(data34) > 512) {
                                          const err67 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err67];
                                          } else {
                                            vErrors.push(err67);
                                          }
                                          errors2++;
                                        } else {
                                          if (!pattern6.test(data34)) {
                                            const err68 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' };
                                            if (vErrors === null) {
                                              vErrors = [err68];
                                            } else {
                                              vErrors.push(err68);
                                            }
                                            errors2++;
                                          }
                                        }
                                      } else {
                                        const err69 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err69];
                                        } else {
                                          vErrors.push(err69);
                                        }
                                        errors2++;
                                      }
                                    }
                                    var valid25 = _errs128 === errors2;
                                  } else {
                                    var valid25 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err70 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err70];
                      } else {
                        vErrors.push(err70);
                      }
                      errors2++;
                    }
                  }
                  var _valid9 = _errs86 === errors2;
                  valid23 = valid23 || _valid9;
                  const _errs130 = errors2;
                  if (data23 !== null) {
                    const err71 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err71];
                    } else {
                      vErrors.push(err71);
                    }
                    errors2++;
                  }
                  var _valid9 = _errs130 === errors2;
                  valid23 = valid23 || _valid9;
                  if (!valid23) {
                    const err72 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err72];
                    } else {
                      vErrors.push(err72);
                    }
                    errors2++;
                    validate41.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs85;
                    if (vErrors !== null) {
                      if (_errs85) {
                        vErrors.length = _errs85;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid20 = _errs84 === errors2;
                } else {
                  var valid20 = true;
                }
                if (valid20) {
                  if (data.errorCode !== void 0) {
                    let data35 = data.errorCode;
                    const _errs132 = errors2;
                    const _errs133 = errors2;
                    let valid33 = false;
                    const _errs134 = errors2;
                    if (!(data35 === "NETWORK_ERROR" || data35 === "INVALID_DATA" || data35 === "PAYLOAD_TOO_LARGE" || data35 === "EXPANSION_LIMIT" || data35 === "UNSUPPORTED_CALENDAR" || data35 === "UNKNOWN_TIME_ZONE" || data35 === "KEYRING_LOCKED" || data35 === "SECRET_DELETION_FAILED" || data35 === "AUTH_ERROR" || data35 === "RATE_LIMITED" || data35 === "NO_PLAYER" || data35 === "NO_INTERFACE" || data35 === "SERVICE_UNAVAILABLE" || data35 === "INTERNAL_ERROR")) {
                      const err73 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema35.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err73];
                      } else {
                        vErrors.push(err73);
                      }
                      errors2++;
                    }
                    var _valid14 = _errs134 === errors2;
                    valid33 = valid33 || _valid14;
                    const _errs135 = errors2;
                    if (data35 !== null) {
                      const err74 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err74];
                      } else {
                        vErrors.push(err74);
                      }
                      errors2++;
                    }
                    var _valid14 = _errs135 === errors2;
                    valid33 = valid33 || _valid14;
                    if (!valid33) {
                      const err75 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err75];
                      } else {
                        vErrors.push(err75);
                      }
                      errors2++;
                      validate41.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs133;
                      if (vErrors !== null) {
                        if (_errs133) {
                          vErrors.length = _errs133;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid20 = _errs132 === errors2;
                  } else {
                    var valid20 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate41.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate41.errors = vErrors;
  return errors2 === 0;
}
validate41.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var system = validate42;
function validate42(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate42.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.cpuPercent === void 0 && (missing0 = "cpuPercent") || data1.memoryUsedBytes === void 0 && (missing0 = "memoryUsedBytes") || data1.memoryTotalBytes === void 0 && (missing0 = "memoryTotalBytes") || data1.temperatureC === void 0 && (missing0 = "temperatureC")) {
              validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "cpuPercent" || key0 === "memoryUsedBytes" || key0 === "memoryTotalBytes" || key0 === "temperatureC")) {
                  validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.cpuPercent !== void 0) {
                  let data2 = data1.cpuPercent;
                  const _errs10 = errors2;
                  const _errs11 = errors2;
                  let valid6 = false;
                  const _errs12 = errors2;
                  if (errors2 === _errs12) {
                    if (typeof data2 == "number" && isFinite(data2)) {
                      if (data2 > 100 || isNaN(data2)) {
                        const err1 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                        if (vErrors === null) {
                          vErrors = [err1];
                        } else {
                          vErrors.push(err1);
                        }
                        errors2++;
                      } else {
                        if (data2 < 0 || isNaN(data2)) {
                          const err2 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err2];
                          } else {
                            vErrors.push(err2);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err3 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors2++;
                    }
                  }
                  var _valid1 = _errs12 === errors2;
                  valid6 = valid6 || _valid1;
                  const _errs14 = errors2;
                  if (data2 !== null) {
                    const err4 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err4];
                    } else {
                      vErrors.push(err4);
                    }
                    errors2++;
                  }
                  var _valid1 = _errs14 === errors2;
                  valid6 = valid6 || _valid1;
                  if (!valid6) {
                    const err5 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err5];
                    } else {
                      vErrors.push(err5);
                    }
                    errors2++;
                    validate42.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs11;
                    if (vErrors !== null) {
                      if (_errs11) {
                        vErrors.length = _errs11;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.memoryUsedBytes !== void 0) {
                    let data3 = data1.memoryUsedBytes;
                    const _errs16 = errors2;
                    if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                      validate42.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                      return false;
                    }
                    if (errors2 === _errs16) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 > 9007199254740991 || isNaN(data3)) {
                          validate42.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                          return false;
                        } else {
                          if (data3 < 0 || isNaN(data3)) {
                            validate42.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                            return false;
                          }
                        }
                      }
                    }
                    var valid5 = _errs16 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.memoryTotalBytes !== void 0) {
                      let data4 = data1.memoryTotalBytes;
                      const _errs18 = errors2;
                      if (!(typeof data4 == "number" && (!(data4 % 1) && !isNaN(data4)) && isFinite(data4))) {
                        validate42.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                        return false;
                      }
                      if (errors2 === _errs18) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 > 9007199254740991 || isNaN(data4)) {
                            validate42.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                            return false;
                          } else {
                            if (data4 < 0 || isNaN(data4)) {
                              validate42.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                              return false;
                            }
                          }
                        }
                      }
                      var valid5 = _errs18 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.temperatureC !== void 0) {
                        let data5 = data1.temperatureC;
                        const _errs20 = errors2;
                        const _errs21 = errors2;
                        let valid7 = false;
                        const _errs22 = errors2;
                        if (!(typeof data5 == "number" && isFinite(data5))) {
                          const err6 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors2++;
                        }
                        var _valid2 = _errs22 === errors2;
                        valid7 = valid7 || _valid2;
                        const _errs24 = errors2;
                        if (data5 !== null) {
                          const err7 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                          if (vErrors === null) {
                            vErrors = [err7];
                          } else {
                            vErrors.push(err7);
                          }
                          errors2++;
                        }
                        var _valid2 = _errs24 === errors2;
                        valid7 = valid7 || _valid2;
                        if (!valid7) {
                          const err8 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                          if (vErrors === null) {
                            vErrors = [err8];
                          } else {
                            vErrors.push(err8);
                          }
                          errors2++;
                          validate42.errors = vErrors;
                          return false;
                        } else {
                          errors2 = _errs21;
                          if (vErrors !== null) {
                            if (_errs21) {
                              vErrors.length = _errs21;
                            } else {
                              vErrors = null;
                            }
                          }
                        }
                        var valid5 = _errs20 === errors2;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data6 = data.updatedAt;
          const _errs26 = errors2;
          if (errors2 === _errs26) {
            if (errors2 === _errs26) {
              if (typeof data6 === "string") {
                if (func1(data6) > 64) {
                  validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data6)) {
                    validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs26 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors2++;
    validate42.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs28 = errors2;
    const _errs29 = errors2;
    let valid8 = true;
    const _errs30 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data7 = data.status;
        if (!(data7 === "unconfigured" || data7 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors2++;
        }
      }
    }
    var _valid3 = _errs30 === errors2;
    errors2 = _errs29;
    if (vErrors !== null) {
      if (_errs29) {
        vErrors.length = _errs29;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs32 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs33 = errors2;
          if (data.data !== null) {
            validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid10 = _errs33 === errors2;
        } else {
          var valid10 = true;
        }
        if (valid10) {
          if (data.updatedAt !== void 0) {
            const _errs35 = errors2;
            if (data.updatedAt !== null) {
              validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid10 = _errs35 === errors2;
          } else {
            var valid10 = true;
          }
        }
      }
      var _valid3 = _errs32 === errors2;
      valid8 = _valid3;
      if (valid8) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid8) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors2++;
      validate42.errors = vErrors;
      return false;
    }
    var valid0 = _errs28 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs37 = errors2;
      const _errs38 = errors2;
      let valid11 = true;
      const _errs39 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data10 = data.status;
          if (!(data10 === "ok" || data10 === "unconfigured" || data10 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors2++;
          }
        }
      }
      var _valid4 = _errs39 === errors2;
      errors2 = _errs38;
      if (vErrors !== null) {
        if (_errs38) {
          vErrors.length = _errs38;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs41 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate42.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs41 === errors2;
        valid11 = _valid4;
        if (valid11) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs44 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data12 = data.errorCode;
            if (!(data12 === "NETWORK_ERROR" || data12 === "INVALID_DATA" || data12 === "PAYLOAD_TOO_LARGE" || data12 === "EXPANSION_LIMIT" || data12 === "UNSUPPORTED_CALENDAR" || data12 === "UNKNOWN_TIME_ZONE" || data12 === "KEYRING_LOCKED" || data12 === "SECRET_DELETION_FAILED" || data12 === "AUTH_ERROR" || data12 === "RATE_LIMITED" || data12 === "NO_PLAYER" || data12 === "NO_INTERFACE" || data12 === "SERVICE_UNAVAILABLE" || data12 === "INTERNAL_ERROR")) {
              validate42.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema38.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs44 === errors2;
        valid11 = _valid4;
        if (valid11) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid11) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors2++;
        validate42.errors = vErrors;
        return false;
      }
      var valid0 = _errs37 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate42.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs46 = errors2;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate42.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs46 === errors2) {
          if (data.status !== void 0) {
            let data13 = data.status;
            const _errs47 = errors2;
            if (!(data13 === "loading" || data13 === "ok" || data13 === "stale" || data13 === "unconfigured" || data13 === "unavailable")) {
              validate42.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema38.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid15 = _errs47 === errors2;
          } else {
            var valid15 = true;
          }
          if (valid15) {
            if (data.sourceId !== void 0) {
              let data14 = data.sourceId;
              const _errs48 = errors2;
              const _errs49 = errors2;
              let valid16 = false;
              const _errs50 = errors2;
              if (errors2 === _errs50) {
                if (typeof data14 === "string") {
                  if (func1(data14) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors2++;
                  } else {
                    if (func1(data14) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data14)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors2++;
                }
              }
              var _valid5 = _errs50 === errors2;
              valid16 = valid16 || _valid5;
              const _errs52 = errors2;
              if (data14 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors2++;
              }
              var _valid5 = _errs52 === errors2;
              valid16 = valid16 || _valid5;
              if (!valid16) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors2++;
                validate42.errors = vErrors;
                return false;
              } else {
                errors2 = _errs49;
                if (vErrors !== null) {
                  if (_errs49) {
                    vErrors.length = _errs49;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid15 = _errs48 === errors2;
            } else {
              var valid15 = true;
            }
            if (valid15) {
              if (data.updatedAt !== void 0) {
                let data15 = data.updatedAt;
                const _errs54 = errors2;
                const _errs55 = errors2;
                let valid17 = false;
                const _errs56 = errors2;
                if (errors2 === _errs56) {
                  if (errors2 === _errs56) {
                    if (typeof data15 === "string") {
                      if (func1(data15) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data15)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid6 = _errs56 === errors2;
                valid17 = valid17 || _valid6;
                const _errs58 = errors2;
                if (data15 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors2++;
                }
                var _valid6 = _errs58 === errors2;
                valid17 = valid17 || _valid6;
                if (!valid17) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors2++;
                  validate42.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs55;
                  if (vErrors !== null) {
                    if (_errs55) {
                      vErrors.length = _errs55;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid15 = _errs54 === errors2;
              } else {
                var valid15 = true;
              }
              if (valid15) {
                if (data.data !== void 0) {
                  let data16 = data.data;
                  const _errs60 = errors2;
                  const _errs61 = errors2;
                  let valid18 = false;
                  const _errs62 = errors2;
                  const _errs63 = errors2;
                  if (errors2 === _errs63) {
                    if (data16 && typeof data16 == "object" && !Array.isArray(data16)) {
                      let missing2;
                      if (data16.cpuPercent === void 0 && (missing2 = "cpuPercent") || data16.memoryUsedBytes === void 0 && (missing2 = "memoryUsedBytes") || data16.memoryTotalBytes === void 0 && (missing2 = "memoryTotalBytes") || data16.temperatureC === void 0 && (missing2 = "temperatureC")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors2++;
                      } else {
                        const _errs65 = errors2;
                        for (const key2 in data16) {
                          if (!(key2 === "cpuPercent" || key2 === "memoryUsedBytes" || key2 === "memoryTotalBytes" || key2 === "temperatureC")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs65 === errors2) {
                          if (data16.cpuPercent !== void 0) {
                            let data17 = data16.cpuPercent;
                            const _errs66 = errors2;
                            const _errs67 = errors2;
                            let valid21 = false;
                            const _errs68 = errors2;
                            if (errors2 === _errs68) {
                              if (typeof data17 == "number" && isFinite(data17)) {
                                if (data17 > 100 || isNaN(data17)) {
                                  const err27 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors2++;
                                } else {
                                  if (data17 < 0 || isNaN(data17)) {
                                    const err28 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors2++;
                              }
                            }
                            var _valid8 = _errs68 === errors2;
                            valid21 = valid21 || _valid8;
                            const _errs70 = errors2;
                            if (data17 !== null) {
                              const err30 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                              if (vErrors === null) {
                                vErrors = [err30];
                              } else {
                                vErrors.push(err30);
                              }
                              errors2++;
                            }
                            var _valid8 = _errs70 === errors2;
                            valid21 = valid21 || _valid8;
                            if (!valid21) {
                              const err31 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                              if (vErrors === null) {
                                vErrors = [err31];
                              } else {
                                vErrors.push(err31);
                              }
                              errors2++;
                            } else {
                              errors2 = _errs67;
                              if (vErrors !== null) {
                                if (_errs67) {
                                  vErrors.length = _errs67;
                                } else {
                                  vErrors = null;
                                }
                              }
                            }
                            var valid20 = _errs66 === errors2;
                          } else {
                            var valid20 = true;
                          }
                          if (valid20) {
                            if (data16.memoryUsedBytes !== void 0) {
                              let data18 = data16.memoryUsedBytes;
                              const _errs72 = errors2;
                              if (!(typeof data18 == "number" && (!(data18 % 1) && !isNaN(data18)) && isFinite(data18))) {
                                const err32 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors2++;
                              }
                              if (errors2 === _errs72) {
                                if (typeof data18 == "number" && isFinite(data18)) {
                                  if (data18 > 9007199254740991 || isNaN(data18)) {
                                    const err33 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                    if (vErrors === null) {
                                      vErrors = [err33];
                                    } else {
                                      vErrors.push(err33);
                                    }
                                    errors2++;
                                  } else {
                                    if (data18 < 0 || isNaN(data18)) {
                                      const err34 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors2++;
                                    }
                                  }
                                }
                              }
                              var valid20 = _errs72 === errors2;
                            } else {
                              var valid20 = true;
                            }
                            if (valid20) {
                              if (data16.memoryTotalBytes !== void 0) {
                                let data19 = data16.memoryTotalBytes;
                                const _errs74 = errors2;
                                if (!(typeof data19 == "number" && (!(data19 % 1) && !isNaN(data19)) && isFinite(data19))) {
                                  const err35 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors2++;
                                }
                                if (errors2 === _errs74) {
                                  if (typeof data19 == "number" && isFinite(data19)) {
                                    if (data19 > 9007199254740991 || isNaN(data19)) {
                                      const err36 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors2++;
                                    } else {
                                      if (data19 < 0 || isNaN(data19)) {
                                        const err37 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                        if (vErrors === null) {
                                          vErrors = [err37];
                                        } else {
                                          vErrors.push(err37);
                                        }
                                        errors2++;
                                      }
                                    }
                                  }
                                }
                                var valid20 = _errs74 === errors2;
                              } else {
                                var valid20 = true;
                              }
                              if (valid20) {
                                if (data16.temperatureC !== void 0) {
                                  let data20 = data16.temperatureC;
                                  const _errs76 = errors2;
                                  const _errs77 = errors2;
                                  let valid22 = false;
                                  const _errs78 = errors2;
                                  if (!(typeof data20 == "number" && isFinite(data20))) {
                                    const err38 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err38];
                                    } else {
                                      vErrors.push(err38);
                                    }
                                    errors2++;
                                  }
                                  var _valid9 = _errs78 === errors2;
                                  valid22 = valid22 || _valid9;
                                  const _errs80 = errors2;
                                  if (data20 !== null) {
                                    const err39 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err39];
                                    } else {
                                      vErrors.push(err39);
                                    }
                                    errors2++;
                                  }
                                  var _valid9 = _errs80 === errors2;
                                  valid22 = valid22 || _valid9;
                                  if (!valid22) {
                                    const err40 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err40];
                                    } else {
                                      vErrors.push(err40);
                                    }
                                    errors2++;
                                  } else {
                                    errors2 = _errs77;
                                    if (vErrors !== null) {
                                      if (_errs77) {
                                        vErrors.length = _errs77;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid20 = _errs76 === errors2;
                                } else {
                                  var valid20 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err41 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors2++;
                    }
                  }
                  var _valid7 = _errs62 === errors2;
                  valid18 = valid18 || _valid7;
                  const _errs82 = errors2;
                  if (data16 !== null) {
                    const err42 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err42];
                    } else {
                      vErrors.push(err42);
                    }
                    errors2++;
                  }
                  var _valid7 = _errs82 === errors2;
                  valid18 = valid18 || _valid7;
                  if (!valid18) {
                    const err43 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err43];
                    } else {
                      vErrors.push(err43);
                    }
                    errors2++;
                    validate42.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs61;
                    if (vErrors !== null) {
                      if (_errs61) {
                        vErrors.length = _errs61;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid15 = _errs60 === errors2;
                } else {
                  var valid15 = true;
                }
                if (valid15) {
                  if (data.errorCode !== void 0) {
                    let data21 = data.errorCode;
                    const _errs84 = errors2;
                    const _errs85 = errors2;
                    let valid23 = false;
                    const _errs86 = errors2;
                    if (!(data21 === "NETWORK_ERROR" || data21 === "INVALID_DATA" || data21 === "PAYLOAD_TOO_LARGE" || data21 === "EXPANSION_LIMIT" || data21 === "UNSUPPORTED_CALENDAR" || data21 === "UNKNOWN_TIME_ZONE" || data21 === "KEYRING_LOCKED" || data21 === "SECRET_DELETION_FAILED" || data21 === "AUTH_ERROR" || data21 === "RATE_LIMITED" || data21 === "NO_PLAYER" || data21 === "NO_INTERFACE" || data21 === "SERVICE_UNAVAILABLE" || data21 === "INTERNAL_ERROR")) {
                      const err44 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema38.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err44];
                      } else {
                        vErrors.push(err44);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs86 === errors2;
                    valid23 = valid23 || _valid10;
                    const _errs87 = errors2;
                    if (data21 !== null) {
                      const err45 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err45];
                      } else {
                        vErrors.push(err45);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs87 === errors2;
                    valid23 = valid23 || _valid10;
                    if (!valid23) {
                      const err46 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err46];
                      } else {
                        vErrors.push(err46);
                      }
                      errors2++;
                      validate42.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs85;
                      if (vErrors !== null) {
                        if (_errs85) {
                          vErrors.length = _errs85;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid15 = _errs84 === errors2;
                  } else {
                    var valid15 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate42.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate42.errors = vErrors;
  return errors2 === 0;
}
validate42.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var network = validate43;
function validate43(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate43.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.interface === void 0 && (missing0 = "interface") || data1.rxBytesPerSec === void 0 && (missing0 = "rxBytesPerSec") || data1.txBytesPerSec === void 0 && (missing0 = "txBytesPerSec") || data1.history === void 0 && (missing0 = "history")) {
              validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "interface" || key0 === "rxBytesPerSec" || key0 === "txBytesPerSec" || key0 === "history")) {
                  validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.interface !== void 0) {
                  let data2 = data1.interface;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 64) {
                        validate43.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate43.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate43.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.rxBytesPerSec !== void 0) {
                    let data3 = data1.rxBytesPerSec;
                    const _errs12 = errors2;
                    const _errs13 = errors2;
                    let valid6 = false;
                    const _errs14 = errors2;
                    if (errors2 === _errs14) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 < 0 || isNaN(data3)) {
                          const err1 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err1];
                          } else {
                            vErrors.push(err1);
                          }
                          errors2++;
                        }
                      } else {
                        const err2 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err2];
                        } else {
                          vErrors.push(err2);
                        }
                        errors2++;
                      }
                    }
                    var _valid1 = _errs14 === errors2;
                    valid6 = valid6 || _valid1;
                    const _errs16 = errors2;
                    if (data3 !== null) {
                      const err3 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors2++;
                    }
                    var _valid1 = _errs16 === errors2;
                    valid6 = valid6 || _valid1;
                    if (!valid6) {
                      const err4 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err4];
                      } else {
                        vErrors.push(err4);
                      }
                      errors2++;
                      validate43.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs13;
                      if (vErrors !== null) {
                        if (_errs13) {
                          vErrors.length = _errs13;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.txBytesPerSec !== void 0) {
                      let data4 = data1.txBytesPerSec;
                      const _errs18 = errors2;
                      const _errs19 = errors2;
                      let valid7 = false;
                      const _errs20 = errors2;
                      if (errors2 === _errs20) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 < 0 || isNaN(data4)) {
                            const err5 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors2++;
                          }
                        } else {
                          const err6 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors2++;
                        }
                      }
                      var _valid2 = _errs20 === errors2;
                      valid7 = valid7 || _valid2;
                      const _errs22 = errors2;
                      if (data4 !== null) {
                        const err7 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                        if (vErrors === null) {
                          vErrors = [err7];
                        } else {
                          vErrors.push(err7);
                        }
                        errors2++;
                      }
                      var _valid2 = _errs22 === errors2;
                      valid7 = valid7 || _valid2;
                      if (!valid7) {
                        const err8 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors2++;
                        validate43.errors = vErrors;
                        return false;
                      } else {
                        errors2 = _errs19;
                        if (vErrors !== null) {
                          if (_errs19) {
                            vErrors.length = _errs19;
                          } else {
                            vErrors = null;
                          }
                        }
                      }
                      var valid5 = _errs18 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.history !== void 0) {
                        let data5 = data1.history;
                        const _errs24 = errors2;
                        if (errors2 === _errs24) {
                          if (Array.isArray(data5)) {
                            if (data5.length > 60) {
                              validate43.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" }];
                              return false;
                            } else {
                              var valid8 = true;
                              const len0 = data5.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data6 = data5[i0];
                                const _errs26 = errors2;
                                if (errors2 === _errs26) {
                                  if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
                                    let missing1;
                                    if (data6.at === void 0 && (missing1 = "at") || data6.rx === void 0 && (missing1 = "rx") || data6.tx === void 0 && (missing1 = "tx")) {
                                      validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                      return false;
                                    } else {
                                      const _errs28 = errors2;
                                      for (const key1 in data6) {
                                        if (!(key1 === "at" || key1 === "rx" || key1 === "tx")) {
                                          validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs28 === errors2) {
                                        if (data6.at !== void 0) {
                                          let data7 = data6.at;
                                          const _errs29 = errors2;
                                          if (errors2 === _errs29) {
                                            if (errors2 === _errs29) {
                                              if (typeof data7 === "string") {
                                                if (func1(data7) > 64) {
                                                  validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data7)) {
                                                    validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid9 = _errs29 === errors2;
                                        } else {
                                          var valid9 = true;
                                        }
                                        if (valid9) {
                                          if (data6.rx !== void 0) {
                                            let data8 = data6.rx;
                                            const _errs31 = errors2;
                                            if (errors2 === _errs31) {
                                              if (typeof data8 == "number" && isFinite(data8)) {
                                                if (data8 < 0 || isNaN(data8)) {
                                                  validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                  return false;
                                                }
                                              } else {
                                                validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                return false;
                                              }
                                            }
                                            var valid9 = _errs31 === errors2;
                                          } else {
                                            var valid9 = true;
                                          }
                                          if (valid9) {
                                            if (data6.tx !== void 0) {
                                              let data9 = data6.tx;
                                              const _errs33 = errors2;
                                              if (errors2 === _errs33) {
                                                if (typeof data9 == "number" && isFinite(data9)) {
                                                  if (data9 < 0 || isNaN(data9)) {
                                                    validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                    return false;
                                                  }
                                                } else {
                                                  validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                  return false;
                                                }
                                              }
                                              var valid9 = _errs33 === errors2;
                                            } else {
                                              var valid9 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid8 = _errs26 === errors2;
                                if (!valid8) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate43.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs24 === errors2;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data10 = data.updatedAt;
          const _errs35 = errors2;
          if (errors2 === _errs35) {
            if (errors2 === _errs35) {
              if (typeof data10 === "string") {
                if (func1(data10) > 64) {
                  validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data10)) {
                    validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs35 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors2++;
    validate43.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs37 = errors2;
    const _errs38 = errors2;
    let valid10 = true;
    const _errs39 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data11 = data.status;
        if (!(data11 === "unconfigured" || data11 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors2++;
        }
      }
    }
    var _valid3 = _errs39 === errors2;
    errors2 = _errs38;
    if (vErrors !== null) {
      if (_errs38) {
        vErrors.length = _errs38;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs41 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs42 = errors2;
          if (data.data !== null) {
            validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid12 = _errs42 === errors2;
        } else {
          var valid12 = true;
        }
        if (valid12) {
          if (data.updatedAt !== void 0) {
            const _errs44 = errors2;
            if (data.updatedAt !== null) {
              validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid12 = _errs44 === errors2;
          } else {
            var valid12 = true;
          }
        }
      }
      var _valid3 = _errs41 === errors2;
      valid10 = _valid3;
      if (valid10) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid10) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors2++;
      validate43.errors = vErrors;
      return false;
    }
    var valid0 = _errs37 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs46 = errors2;
      const _errs47 = errors2;
      let valid13 = true;
      const _errs48 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data14 = data.status;
          if (!(data14 === "ok" || data14 === "unconfigured" || data14 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors2++;
          }
        }
      }
      var _valid4 = _errs48 === errors2;
      errors2 = _errs47;
      if (vErrors !== null) {
        if (_errs47) {
          vErrors.length = _errs47;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs50 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate43.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs50 === errors2;
        valid13 = _valid4;
        if (valid13) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs53 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data16 = data.errorCode;
            if (!(data16 === "NETWORK_ERROR" || data16 === "INVALID_DATA" || data16 === "PAYLOAD_TOO_LARGE" || data16 === "EXPANSION_LIMIT" || data16 === "UNSUPPORTED_CALENDAR" || data16 === "UNKNOWN_TIME_ZONE" || data16 === "KEYRING_LOCKED" || data16 === "SECRET_DELETION_FAILED" || data16 === "AUTH_ERROR" || data16 === "RATE_LIMITED" || data16 === "NO_PLAYER" || data16 === "NO_INTERFACE" || data16 === "SERVICE_UNAVAILABLE" || data16 === "INTERNAL_ERROR")) {
              validate43.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema41.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs53 === errors2;
        valid13 = _valid4;
        if (valid13) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid13) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors2++;
        validate43.errors = vErrors;
        return false;
      }
      var valid0 = _errs46 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing2;
      if (data.status === void 0 && (missing2 = "status") || data.sourceId === void 0 && (missing2 = "sourceId") || data.updatedAt === void 0 && (missing2 = "updatedAt") || data.data === void 0 && (missing2 = "data") || data.errorCode === void 0 && (missing2 = "errorCode")) {
        validate43.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
        return false;
      } else {
        const _errs55 = errors2;
        for (const key2 in data) {
          if (!(key2 === "status" || key2 === "sourceId" || key2 === "updatedAt" || key2 === "data" || key2 === "errorCode")) {
            validate43.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs55 === errors2) {
          if (data.status !== void 0) {
            let data17 = data.status;
            const _errs56 = errors2;
            if (!(data17 === "loading" || data17 === "ok" || data17 === "stale" || data17 === "unconfigured" || data17 === "unavailable")) {
              validate43.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema41.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid17 = _errs56 === errors2;
          } else {
            var valid17 = true;
          }
          if (valid17) {
            if (data.sourceId !== void 0) {
              let data18 = data.sourceId;
              const _errs57 = errors2;
              const _errs58 = errors2;
              let valid18 = false;
              const _errs59 = errors2;
              if (errors2 === _errs59) {
                if (typeof data18 === "string") {
                  if (func1(data18) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors2++;
                  } else {
                    if (func1(data18) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data18)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors2++;
                }
              }
              var _valid5 = _errs59 === errors2;
              valid18 = valid18 || _valid5;
              const _errs61 = errors2;
              if (data18 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors2++;
              }
              var _valid5 = _errs61 === errors2;
              valid18 = valid18 || _valid5;
              if (!valid18) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors2++;
                validate43.errors = vErrors;
                return false;
              } else {
                errors2 = _errs58;
                if (vErrors !== null) {
                  if (_errs58) {
                    vErrors.length = _errs58;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid17 = _errs57 === errors2;
            } else {
              var valid17 = true;
            }
            if (valid17) {
              if (data.updatedAt !== void 0) {
                let data19 = data.updatedAt;
                const _errs63 = errors2;
                const _errs64 = errors2;
                let valid19 = false;
                const _errs65 = errors2;
                if (errors2 === _errs65) {
                  if (errors2 === _errs65) {
                    if (typeof data19 === "string") {
                      if (func1(data19) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data19)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid6 = _errs65 === errors2;
                valid19 = valid19 || _valid6;
                const _errs67 = errors2;
                if (data19 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors2++;
                }
                var _valid6 = _errs67 === errors2;
                valid19 = valid19 || _valid6;
                if (!valid19) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors2++;
                  validate43.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs64;
                  if (vErrors !== null) {
                    if (_errs64) {
                      vErrors.length = _errs64;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid17 = _errs63 === errors2;
              } else {
                var valid17 = true;
              }
              if (valid17) {
                if (data.data !== void 0) {
                  let data20 = data.data;
                  const _errs69 = errors2;
                  const _errs70 = errors2;
                  let valid20 = false;
                  const _errs71 = errors2;
                  const _errs72 = errors2;
                  if (errors2 === _errs72) {
                    if (data20 && typeof data20 == "object" && !Array.isArray(data20)) {
                      let missing3;
                      if (data20.interface === void 0 && (missing3 = "interface") || data20.rxBytesPerSec === void 0 && (missing3 = "rxBytesPerSec") || data20.txBytesPerSec === void 0 && (missing3 = "txBytesPerSec") || data20.history === void 0 && (missing3 = "history")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors2++;
                      } else {
                        const _errs74 = errors2;
                        for (const key3 in data20) {
                          if (!(key3 === "interface" || key3 === "rxBytesPerSec" || key3 === "txBytesPerSec" || key3 === "history")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs74 === errors2) {
                          if (data20.interface !== void 0) {
                            let data21 = data20.interface;
                            const _errs75 = errors2;
                            if (errors2 === _errs75) {
                              if (typeof data21 === "string") {
                                if (func1(data21) > 64) {
                                  const err27 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors2++;
                                } else {
                                  if (func1(data21) < 1) {
                                    const err28 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors2++;
                              }
                            }
                            var valid22 = _errs75 === errors2;
                          } else {
                            var valid22 = true;
                          }
                          if (valid22) {
                            if (data20.rxBytesPerSec !== void 0) {
                              let data22 = data20.rxBytesPerSec;
                              const _errs77 = errors2;
                              const _errs78 = errors2;
                              let valid23 = false;
                              const _errs79 = errors2;
                              if (errors2 === _errs79) {
                                if (typeof data22 == "number" && isFinite(data22)) {
                                  if (data22 < 0 || isNaN(data22)) {
                                    const err30 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err30];
                                    } else {
                                      vErrors.push(err30);
                                    }
                                    errors2++;
                                  }
                                } else {
                                  const err31 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err31];
                                  } else {
                                    vErrors.push(err31);
                                  }
                                  errors2++;
                                }
                              }
                              var _valid8 = _errs79 === errors2;
                              valid23 = valid23 || _valid8;
                              const _errs81 = errors2;
                              if (data22 !== null) {
                                const err32 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors2++;
                              }
                              var _valid8 = _errs81 === errors2;
                              valid23 = valid23 || _valid8;
                              if (!valid23) {
                                const err33 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err33];
                                } else {
                                  vErrors.push(err33);
                                }
                                errors2++;
                              } else {
                                errors2 = _errs78;
                                if (vErrors !== null) {
                                  if (_errs78) {
                                    vErrors.length = _errs78;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid22 = _errs77 === errors2;
                            } else {
                              var valid22 = true;
                            }
                            if (valid22) {
                              if (data20.txBytesPerSec !== void 0) {
                                let data23 = data20.txBytesPerSec;
                                const _errs83 = errors2;
                                const _errs84 = errors2;
                                let valid24 = false;
                                const _errs85 = errors2;
                                if (errors2 === _errs85) {
                                  if (typeof data23 == "number" && isFinite(data23)) {
                                    if (data23 < 0 || isNaN(data23)) {
                                      const err34 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors2++;
                                    }
                                  } else {
                                    const err35 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err35];
                                    } else {
                                      vErrors.push(err35);
                                    }
                                    errors2++;
                                  }
                                }
                                var _valid9 = _errs85 === errors2;
                                valid24 = valid24 || _valid9;
                                const _errs87 = errors2;
                                if (data23 !== null) {
                                  const err36 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err36];
                                  } else {
                                    vErrors.push(err36);
                                  }
                                  errors2++;
                                }
                                var _valid9 = _errs87 === errors2;
                                valid24 = valid24 || _valid9;
                                if (!valid24) {
                                  const err37 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err37];
                                  } else {
                                    vErrors.push(err37);
                                  }
                                  errors2++;
                                } else {
                                  errors2 = _errs84;
                                  if (vErrors !== null) {
                                    if (_errs84) {
                                      vErrors.length = _errs84;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid22 = _errs83 === errors2;
                              } else {
                                var valid22 = true;
                              }
                              if (valid22) {
                                if (data20.history !== void 0) {
                                  let data24 = data20.history;
                                  const _errs89 = errors2;
                                  if (errors2 === _errs89) {
                                    if (Array.isArray(data24)) {
                                      if (data24.length > 60) {
                                        const err38 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" };
                                        if (vErrors === null) {
                                          vErrors = [err38];
                                        } else {
                                          vErrors.push(err38);
                                        }
                                        errors2++;
                                      } else {
                                        var valid25 = true;
                                        const len1 = data24.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data25 = data24[i1];
                                          const _errs91 = errors2;
                                          if (errors2 === _errs91) {
                                            if (data25 && typeof data25 == "object" && !Array.isArray(data25)) {
                                              let missing4;
                                              if (data25.at === void 0 && (missing4 = "at") || data25.rx === void 0 && (missing4 = "rx") || data25.tx === void 0 && (missing4 = "tx")) {
                                                const err39 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err39];
                                                } else {
                                                  vErrors.push(err39);
                                                }
                                                errors2++;
                                              } else {
                                                const _errs93 = errors2;
                                                for (const key4 in data25) {
                                                  if (!(key4 === "at" || key4 === "rx" || key4 === "tx")) {
                                                    const err40 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err40];
                                                    } else {
                                                      vErrors.push(err40);
                                                    }
                                                    errors2++;
                                                    break;
                                                  }
                                                }
                                                if (_errs93 === errors2) {
                                                  if (data25.at !== void 0) {
                                                    let data26 = data25.at;
                                                    const _errs94 = errors2;
                                                    if (errors2 === _errs94) {
                                                      if (errors2 === _errs94) {
                                                        if (typeof data26 === "string") {
                                                          if (func1(data26) > 64) {
                                                            const err41 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err41];
                                                            } else {
                                                              vErrors.push(err41);
                                                            }
                                                            errors2++;
                                                          } else {
                                                            if (!formats0.validate(data26)) {
                                                              const err42 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err42];
                                                              } else {
                                                                vErrors.push(err42);
                                                              }
                                                              errors2++;
                                                            }
                                                          }
                                                        } else {
                                                          const err43 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err43];
                                                          } else {
                                                            vErrors.push(err43);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                    }
                                                    var valid26 = _errs94 === errors2;
                                                  } else {
                                                    var valid26 = true;
                                                  }
                                                  if (valid26) {
                                                    if (data25.rx !== void 0) {
                                                      let data27 = data25.rx;
                                                      const _errs96 = errors2;
                                                      if (errors2 === _errs96) {
                                                        if (typeof data27 == "number" && isFinite(data27)) {
                                                          if (data27 < 0 || isNaN(data27)) {
                                                            const err44 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                            if (vErrors === null) {
                                                              vErrors = [err44];
                                                            } else {
                                                              vErrors.push(err44);
                                                            }
                                                            errors2++;
                                                          }
                                                        } else {
                                                          const err45 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                          if (vErrors === null) {
                                                            vErrors = [err45];
                                                          } else {
                                                            vErrors.push(err45);
                                                          }
                                                          errors2++;
                                                        }
                                                      }
                                                      var valid26 = _errs96 === errors2;
                                                    } else {
                                                      var valid26 = true;
                                                    }
                                                    if (valid26) {
                                                      if (data25.tx !== void 0) {
                                                        let data28 = data25.tx;
                                                        const _errs98 = errors2;
                                                        if (errors2 === _errs98) {
                                                          if (typeof data28 == "number" && isFinite(data28)) {
                                                            if (data28 < 0 || isNaN(data28)) {
                                                              const err46 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                              if (vErrors === null) {
                                                                vErrors = [err46];
                                                              } else {
                                                                vErrors.push(err46);
                                                              }
                                                              errors2++;
                                                            }
                                                          } else {
                                                            const err47 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err47];
                                                            } else {
                                                              vErrors.push(err47);
                                                            }
                                                            errors2++;
                                                          }
                                                        }
                                                        var valid26 = _errs98 === errors2;
                                                      } else {
                                                        var valid26 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err48 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors2++;
                                            }
                                          }
                                          var valid25 = _errs91 === errors2;
                                          if (!valid25) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err49 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err49];
                                      } else {
                                        vErrors.push(err49);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid22 = _errs89 === errors2;
                                } else {
                                  var valid22 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err50 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err50];
                      } else {
                        vErrors.push(err50);
                      }
                      errors2++;
                    }
                  }
                  var _valid7 = _errs71 === errors2;
                  valid20 = valid20 || _valid7;
                  const _errs100 = errors2;
                  if (data20 !== null) {
                    const err51 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err51];
                    } else {
                      vErrors.push(err51);
                    }
                    errors2++;
                  }
                  var _valid7 = _errs100 === errors2;
                  valid20 = valid20 || _valid7;
                  if (!valid20) {
                    const err52 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err52];
                    } else {
                      vErrors.push(err52);
                    }
                    errors2++;
                    validate43.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs70;
                    if (vErrors !== null) {
                      if (_errs70) {
                        vErrors.length = _errs70;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid17 = _errs69 === errors2;
                } else {
                  var valid17 = true;
                }
                if (valid17) {
                  if (data.errorCode !== void 0) {
                    let data29 = data.errorCode;
                    const _errs102 = errors2;
                    const _errs103 = errors2;
                    let valid27 = false;
                    const _errs104 = errors2;
                    if (!(data29 === "NETWORK_ERROR" || data29 === "INVALID_DATA" || data29 === "PAYLOAD_TOO_LARGE" || data29 === "EXPANSION_LIMIT" || data29 === "UNSUPPORTED_CALENDAR" || data29 === "UNKNOWN_TIME_ZONE" || data29 === "KEYRING_LOCKED" || data29 === "SECRET_DELETION_FAILED" || data29 === "AUTH_ERROR" || data29 === "RATE_LIMITED" || data29 === "NO_PLAYER" || data29 === "NO_INTERFACE" || data29 === "SERVICE_UNAVAILABLE" || data29 === "INTERNAL_ERROR")) {
                      const err53 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema41.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err53];
                      } else {
                        vErrors.push(err53);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs104 === errors2;
                    valid27 = valid27 || _valid10;
                    const _errs105 = errors2;
                    if (data29 !== null) {
                      const err54 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err54];
                      } else {
                        vErrors.push(err54);
                      }
                      errors2++;
                    }
                    var _valid10 = _errs105 === errors2;
                    valid27 = valid27 || _valid10;
                    if (!valid27) {
                      const err55 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err55];
                      } else {
                        vErrors.push(err55);
                      }
                      errors2++;
                      validate43.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs103;
                      if (vErrors !== null) {
                        if (_errs103) {
                          vErrors.length = _errs103;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid17 = _errs102 === errors2;
                  } else {
                    var valid17 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate43.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate43.errors = vErrors;
  return errors2 === 0;
}
validate43.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var media = validate44;
function validate44(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate44.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors2;
  const _errs2 = errors2;
  let valid1 = true;
  const _errs3 = errors2;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      }
    }
  }
  var _valid0 = _errs3 === errors2;
  errors2 = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors2;
        const _errs7 = errors2;
        if (errors2 === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.player === void 0 && (missing0 = "player") || data1.status === void 0 && (missing0 = "status") || data1.title === void 0 && (missing0 = "title") || data1.artist === void 0 && (missing0 = "artist") || data1.artUri === void 0 && (missing0 = "artUri")) {
              validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors2;
              for (const key0 in data1) {
                if (!(key0 === "player" || key0 === "status" || key0 === "title" || key0 === "artist" || key0 === "artUri")) {
                  validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors2) {
                if (data1.player !== void 0) {
                  let data2 = data1.player;
                  const _errs10 = errors2;
                  if (errors2 === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 255) {
                        validate44.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate44.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate44.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors2;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.status !== void 0) {
                    let data3 = data1.status;
                    const _errs12 = errors2;
                    if (!(data3 === "playing" || data3 === "paused" || data3 === "stopped")) {
                      validate44.errors = [{ instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" }];
                      return false;
                    }
                    var valid5 = _errs12 === errors2;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.title !== void 0) {
                      let data4 = data1.title;
                      const _errs13 = errors2;
                      if (errors2 === _errs13) {
                        if (typeof data4 === "string") {
                          if (func1(data4) > 4096) {
                            validate44.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                            return false;
                          }
                        } else {
                          validate44.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                          return false;
                        }
                      }
                      var valid5 = _errs13 === errors2;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.artist !== void 0) {
                        let data5 = data1.artist;
                        const _errs15 = errors2;
                        if (errors2 === _errs15) {
                          if (typeof data5 === "string") {
                            if (func1(data5) > 4096) {
                              validate44.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                              return false;
                            }
                          } else {
                            validate44.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                            return false;
                          }
                        }
                        var valid5 = _errs15 === errors2;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.artUri !== void 0) {
                          let data6 = data1.artUri;
                          const _errs17 = errors2;
                          const _errs18 = errors2;
                          let valid6 = false;
                          const _errs19 = errors2;
                          if (errors2 === _errs19) {
                            if (typeof data6 === "string") {
                              if (func1(data6) > 4096) {
                                const err1 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                if (vErrors === null) {
                                  vErrors = [err1];
                                } else {
                                  vErrors.push(err1);
                                }
                                errors2++;
                              } else {
                                if (!pattern11.test(data6)) {
                                  const err2 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors2++;
                                }
                              }
                            } else {
                              const err3 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err3];
                              } else {
                                vErrors.push(err3);
                              }
                              errors2++;
                            }
                          }
                          var _valid1 = _errs19 === errors2;
                          valid6 = valid6 || _valid1;
                          const _errs21 = errors2;
                          if (data6 !== null) {
                            const err4 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err4];
                            } else {
                              vErrors.push(err4);
                            }
                            errors2++;
                          }
                          var _valid1 = _errs21 === errors2;
                          valid6 = valid6 || _valid1;
                          if (!valid6) {
                            const err5 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors2++;
                            validate44.errors = vErrors;
                            return false;
                          } else {
                            errors2 = _errs18;
                            if (vErrors !== null) {
                              if (_errs18) {
                                vErrors.length = _errs18;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid5 = _errs17 === errors2;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors2;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data7 = data.updatedAt;
          const _errs23 = errors2;
          if (errors2 === _errs23) {
            if (errors2 === _errs23) {
              if (typeof data7 === "string") {
                if (func1(data7) > 64) {
                  validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data7)) {
                    validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs23 === errors2;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors2;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err6 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err6];
    } else {
      vErrors.push(err6);
    }
    errors2++;
    validate44.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors2;
  if (valid0) {
    const _errs25 = errors2;
    const _errs26 = errors2;
    let valid7 = true;
    const _errs27 = errors2;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data8 = data.status;
        if (!(data8 === "unconfigured" || data8 === "unavailable")) {
          const err7 = {};
          if (vErrors === null) {
            vErrors = [err7];
          } else {
            vErrors.push(err7);
          }
          errors2++;
        }
      }
    }
    var _valid2 = _errs27 === errors2;
    errors2 = _errs26;
    if (vErrors !== null) {
      if (_errs26) {
        vErrors.length = _errs26;
      } else {
        vErrors = null;
      }
    }
    if (_valid2) {
      const _errs29 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs30 = errors2;
          if (data.data !== null) {
            validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid9 = _errs30 === errors2;
        } else {
          var valid9 = true;
        }
        if (valid9) {
          if (data.updatedAt !== void 0) {
            const _errs32 = errors2;
            if (data.updatedAt !== null) {
              validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid9 = _errs32 === errors2;
          } else {
            var valid9 = true;
          }
        }
      }
      var _valid2 = _errs29 === errors2;
      valid7 = _valid2;
      if (valid7) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid7) {
      const err8 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors2++;
      validate44.errors = vErrors;
      return false;
    }
    var valid0 = _errs25 === errors2;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs34 = errors2;
      const _errs35 = errors2;
      let valid10 = true;
      const _errs36 = errors2;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data11 = data.status;
          if (!(data11 === "ok" || data11 === "unconfigured" || data11 === "loading")) {
            const err9 = {};
            if (vErrors === null) {
              vErrors = [err9];
            } else {
              vErrors.push(err9);
            }
            errors2++;
          }
        }
      }
      var _valid3 = _errs36 === errors2;
      errors2 = _errs35;
      if (vErrors !== null) {
        if (_errs35) {
          vErrors.length = _errs35;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid3) {
        const _errs38 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate44.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid3 = _errs38 === errors2;
        valid10 = _valid3;
        if (valid10) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs41 = errors2;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data13 = data.errorCode;
            if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
              validate44.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema44.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid3 = _errs41 === errors2;
        valid10 = _valid3;
        if (valid10) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid10) {
        const err10 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err10];
        } else {
          vErrors.push(err10);
        }
        errors2++;
        validate44.errors = vErrors;
        return false;
      }
      var valid0 = _errs34 === errors2;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate44.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs43 = errors2;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate44.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs43 === errors2) {
          if (data.status !== void 0) {
            let data14 = data.status;
            const _errs44 = errors2;
            if (!(data14 === "loading" || data14 === "ok" || data14 === "stale" || data14 === "unconfigured" || data14 === "unavailable")) {
              validate44.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema44.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid14 = _errs44 === errors2;
          } else {
            var valid14 = true;
          }
          if (valid14) {
            if (data.sourceId !== void 0) {
              let data15 = data.sourceId;
              const _errs45 = errors2;
              const _errs46 = errors2;
              let valid15 = false;
              const _errs47 = errors2;
              if (errors2 === _errs47) {
                if (typeof data15 === "string") {
                  if (func1(data15) > 128) {
                    const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err11];
                    } else {
                      vErrors.push(err11);
                    }
                    errors2++;
                  } else {
                    if (func1(data15) < 1) {
                      const err12 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors2++;
                    } else {
                      if (!pattern5.test(data15)) {
                        const err13 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err13];
                        } else {
                          vErrors.push(err13);
                        }
                        errors2++;
                      }
                    }
                  }
                } else {
                  const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err14];
                  } else {
                    vErrors.push(err14);
                  }
                  errors2++;
                }
              }
              var _valid4 = _errs47 === errors2;
              valid15 = valid15 || _valid4;
              const _errs49 = errors2;
              if (data15 !== null) {
                const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err15];
                } else {
                  vErrors.push(err15);
                }
                errors2++;
              }
              var _valid4 = _errs49 === errors2;
              valid15 = valid15 || _valid4;
              if (!valid15) {
                const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err16];
                } else {
                  vErrors.push(err16);
                }
                errors2++;
                validate44.errors = vErrors;
                return false;
              } else {
                errors2 = _errs46;
                if (vErrors !== null) {
                  if (_errs46) {
                    vErrors.length = _errs46;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid14 = _errs45 === errors2;
            } else {
              var valid14 = true;
            }
            if (valid14) {
              if (data.updatedAt !== void 0) {
                let data16 = data.updatedAt;
                const _errs51 = errors2;
                const _errs52 = errors2;
                let valid16 = false;
                const _errs53 = errors2;
                if (errors2 === _errs53) {
                  if (errors2 === _errs53) {
                    if (typeof data16 === "string") {
                      if (func1(data16) > 64) {
                        const err17 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err17];
                        } else {
                          vErrors.push(err17);
                        }
                        errors2++;
                      } else {
                        if (!formats0.validate(data16)) {
                          const err18 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err18];
                          } else {
                            vErrors.push(err18);
                          }
                          errors2++;
                        }
                      }
                    } else {
                      const err19 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors2++;
                    }
                  }
                }
                var _valid5 = _errs53 === errors2;
                valid16 = valid16 || _valid5;
                const _errs55 = errors2;
                if (data16 !== null) {
                  const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err20];
                  } else {
                    vErrors.push(err20);
                  }
                  errors2++;
                }
                var _valid5 = _errs55 === errors2;
                valid16 = valid16 || _valid5;
                if (!valid16) {
                  const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err21];
                  } else {
                    vErrors.push(err21);
                  }
                  errors2++;
                  validate44.errors = vErrors;
                  return false;
                } else {
                  errors2 = _errs52;
                  if (vErrors !== null) {
                    if (_errs52) {
                      vErrors.length = _errs52;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid14 = _errs51 === errors2;
              } else {
                var valid14 = true;
              }
              if (valid14) {
                if (data.data !== void 0) {
                  let data17 = data.data;
                  const _errs57 = errors2;
                  const _errs58 = errors2;
                  let valid17 = false;
                  const _errs59 = errors2;
                  const _errs60 = errors2;
                  if (errors2 === _errs60) {
                    if (data17 && typeof data17 == "object" && !Array.isArray(data17)) {
                      let missing2;
                      if (data17.player === void 0 && (missing2 = "player") || data17.status === void 0 && (missing2 = "status") || data17.title === void 0 && (missing2 = "title") || data17.artist === void 0 && (missing2 = "artist") || data17.artUri === void 0 && (missing2 = "artUri")) {
                        const err22 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err22];
                        } else {
                          vErrors.push(err22);
                        }
                        errors2++;
                      } else {
                        const _errs62 = errors2;
                        for (const key2 in data17) {
                          if (!(key2 === "player" || key2 === "status" || key2 === "title" || key2 === "artist" || key2 === "artUri")) {
                            const err23 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err23];
                            } else {
                              vErrors.push(err23);
                            }
                            errors2++;
                            break;
                          }
                        }
                        if (_errs62 === errors2) {
                          if (data17.player !== void 0) {
                            let data18 = data17.player;
                            const _errs63 = errors2;
                            if (errors2 === _errs63) {
                              if (typeof data18 === "string") {
                                if (func1(data18) > 255) {
                                  const err24 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err24];
                                  } else {
                                    vErrors.push(err24);
                                  }
                                  errors2++;
                                } else {
                                  if (func1(data18) < 1) {
                                    const err25 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err25];
                                    } else {
                                      vErrors.push(err25);
                                    }
                                    errors2++;
                                  }
                                }
                              } else {
                                const err26 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err26];
                                } else {
                                  vErrors.push(err26);
                                }
                                errors2++;
                              }
                            }
                            var valid19 = _errs63 === errors2;
                          } else {
                            var valid19 = true;
                          }
                          if (valid19) {
                            if (data17.status !== void 0) {
                              let data19 = data17.status;
                              const _errs65 = errors2;
                              if (!(data19 === "playing" || data19 === "paused" || data19 === "stopped")) {
                                const err27 = { instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" };
                                if (vErrors === null) {
                                  vErrors = [err27];
                                } else {
                                  vErrors.push(err27);
                                }
                                errors2++;
                              }
                              var valid19 = _errs65 === errors2;
                            } else {
                              var valid19 = true;
                            }
                            if (valid19) {
                              if (data17.title !== void 0) {
                                let data20 = data17.title;
                                const _errs66 = errors2;
                                if (errors2 === _errs66) {
                                  if (typeof data20 === "string") {
                                    if (func1(data20) > 4096) {
                                      const err28 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err28];
                                      } else {
                                        vErrors.push(err28);
                                      }
                                      errors2++;
                                    }
                                  } else {
                                    const err29 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err29];
                                    } else {
                                      vErrors.push(err29);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid19 = _errs66 === errors2;
                              } else {
                                var valid19 = true;
                              }
                              if (valid19) {
                                if (data17.artist !== void 0) {
                                  let data21 = data17.artist;
                                  const _errs68 = errors2;
                                  if (errors2 === _errs68) {
                                    if (typeof data21 === "string") {
                                      if (func1(data21) > 4096) {
                                        const err30 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err30];
                                        } else {
                                          vErrors.push(err30);
                                        }
                                        errors2++;
                                      }
                                    } else {
                                      const err31 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err31];
                                      } else {
                                        vErrors.push(err31);
                                      }
                                      errors2++;
                                    }
                                  }
                                  var valid19 = _errs68 === errors2;
                                } else {
                                  var valid19 = true;
                                }
                                if (valid19) {
                                  if (data17.artUri !== void 0) {
                                    let data22 = data17.artUri;
                                    const _errs70 = errors2;
                                    const _errs71 = errors2;
                                    let valid20 = false;
                                    const _errs72 = errors2;
                                    if (errors2 === _errs72) {
                                      if (typeof data22 === "string") {
                                        if (func1(data22) > 4096) {
                                          const err32 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err32];
                                          } else {
                                            vErrors.push(err32);
                                          }
                                          errors2++;
                                        } else {
                                          if (!pattern11.test(data22)) {
                                            const err33 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                            if (vErrors === null) {
                                              vErrors = [err33];
                                            } else {
                                              vErrors.push(err33);
                                            }
                                            errors2++;
                                          }
                                        }
                                      } else {
                                        const err34 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err34];
                                        } else {
                                          vErrors.push(err34);
                                        }
                                        errors2++;
                                      }
                                    }
                                    var _valid7 = _errs72 === errors2;
                                    valid20 = valid20 || _valid7;
                                    const _errs74 = errors2;
                                    if (data22 !== null) {
                                      const err35 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                      if (vErrors === null) {
                                        vErrors = [err35];
                                      } else {
                                        vErrors.push(err35);
                                      }
                                      errors2++;
                                    }
                                    var _valid7 = _errs74 === errors2;
                                    valid20 = valid20 || _valid7;
                                    if (!valid20) {
                                      const err36 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors2++;
                                    } else {
                                      errors2 = _errs71;
                                      if (vErrors !== null) {
                                        if (_errs71) {
                                          vErrors.length = _errs71;
                                        } else {
                                          vErrors = null;
                                        }
                                      }
                                    }
                                    var valid19 = _errs70 === errors2;
                                  } else {
                                    var valid19 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err37 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err37];
                      } else {
                        vErrors.push(err37);
                      }
                      errors2++;
                    }
                  }
                  var _valid6 = _errs59 === errors2;
                  valid17 = valid17 || _valid6;
                  const _errs76 = errors2;
                  if (data17 !== null) {
                    const err38 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err38];
                    } else {
                      vErrors.push(err38);
                    }
                    errors2++;
                  }
                  var _valid6 = _errs76 === errors2;
                  valid17 = valid17 || _valid6;
                  if (!valid17) {
                    const err39 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err39];
                    } else {
                      vErrors.push(err39);
                    }
                    errors2++;
                    validate44.errors = vErrors;
                    return false;
                  } else {
                    errors2 = _errs58;
                    if (vErrors !== null) {
                      if (_errs58) {
                        vErrors.length = _errs58;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid14 = _errs57 === errors2;
                } else {
                  var valid14 = true;
                }
                if (valid14) {
                  if (data.errorCode !== void 0) {
                    let data23 = data.errorCode;
                    const _errs78 = errors2;
                    const _errs79 = errors2;
                    let valid21 = false;
                    const _errs80 = errors2;
                    if (!(data23 === "NETWORK_ERROR" || data23 === "INVALID_DATA" || data23 === "PAYLOAD_TOO_LARGE" || data23 === "EXPANSION_LIMIT" || data23 === "UNSUPPORTED_CALENDAR" || data23 === "UNKNOWN_TIME_ZONE" || data23 === "KEYRING_LOCKED" || data23 === "SECRET_DELETION_FAILED" || data23 === "AUTH_ERROR" || data23 === "RATE_LIMITED" || data23 === "NO_PLAYER" || data23 === "NO_INTERFACE" || data23 === "SERVICE_UNAVAILABLE" || data23 === "INTERNAL_ERROR")) {
                      const err40 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema44.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err40];
                      } else {
                        vErrors.push(err40);
                      }
                      errors2++;
                    }
                    var _valid8 = _errs80 === errors2;
                    valid21 = valid21 || _valid8;
                    const _errs81 = errors2;
                    if (data23 !== null) {
                      const err41 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors2++;
                    }
                    var _valid8 = _errs81 === errors2;
                    valid21 = valid21 || _valid8;
                    if (!valid21) {
                      const err42 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err42];
                      } else {
                        vErrors.push(err42);
                      }
                      errors2++;
                      validate44.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs79;
                      if (vErrors !== null) {
                        if (_errs79) {
                          vErrors.length = _errs79;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid14 = _errs78 === errors2;
                  } else {
                    var valid14 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate44.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate44.errors = vErrors;
  return errors2 === 0;
}
validate44.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate46(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate46.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.jobId === void 0 && (missing0 = "jobId") || data.sourceId === void 0 && (missing0 = "sourceId") || data.generation === void 0 && (missing0 = "generation") || data.context === void 0 && (missing0 = "context") || data.now === void 0 && (missing0 = "now")) {
        validate46.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "version" || key0 === "jobId" || key0 === "sourceId" || key0 === "generation" || key0 === "context" || key0 === "now")) {
            validate46.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.version !== void 0) {
            const _errs2 = errors2;
            if (1 !== data.version) {
              validate46.errors = [{ instancePath: instancePath + "/version", schemaPath: "#/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.jobId !== void 0) {
              let data1 = data.jobId;
              const _errs3 = errors2;
              if (errors2 === _errs3) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 128) {
                    validate46.errors = [{ instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate46.errors = [{ instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate46.errors = [{ instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs3 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.sourceId !== void 0) {
                let data2 = data.sourceId;
                const _errs5 = errors2;
                if (errors2 === _errs5) {
                  if (typeof data2 === "string") {
                    if (func1(data2) > 128) {
                      validate46.errors = [{ instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" }];
                      return false;
                    } else {
                      if (func1(data2) < 1) {
                        validate46.errors = [{ instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                        return false;
                      }
                    }
                  } else {
                    validate46.errors = [{ instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
                var valid0 = _errs5 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.generation !== void 0) {
                  let data3 = data.generation;
                  const _errs7 = errors2;
                  if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                    validate46.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                    return false;
                  }
                  if (errors2 === _errs7) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 4294967295 || isNaN(data3)) {
                        validate46.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                        return false;
                      } else {
                        if (data3 < 0 || isNaN(data3)) {
                          validate46.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                          return false;
                        }
                      }
                    }
                  }
                  var valid0 = _errs7 === errors2;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.context !== void 0) {
                    let data4 = data.context;
                    const _errs9 = errors2;
                    const _errs10 = errors2;
                    if (errors2 === _errs10) {
                      if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                        let missing1;
                        if (data4.month === void 0 && (missing1 = "month") || data4.timeZone === void 0 && (missing1 = "timeZone") || data4.weekStart === void 0 && (missing1 = "weekStart")) {
                          validate46.errors = [{ instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                          return false;
                        } else {
                          const _errs12 = errors2;
                          for (const key1 in data4) {
                            if (!(key1 === "month" || key1 === "timeZone" || key1 === "weekStart")) {
                              validate46.errors = [{ instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                              return false;
                              break;
                            }
                          }
                          if (_errs12 === errors2) {
                            if (data4.month !== void 0) {
                              let data5 = data4.month;
                              const _errs13 = errors2;
                              if (errors2 === _errs13) {
                                if (typeof data5 === "string") {
                                  if (func1(data5) > 7) {
                                    validate46.errors = [{ instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                                    return false;
                                  } else {
                                    if (!pattern4.test(data5)) {
                                      validate46.errors = [{ instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                                      return false;
                                    }
                                  }
                                } else {
                                  validate46.errors = [{ instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                  return false;
                                }
                              }
                              var valid2 = _errs13 === errors2;
                            } else {
                              var valid2 = true;
                            }
                            if (valid2) {
                              if (data4.timeZone !== void 0) {
                                let data6 = data4.timeZone;
                                const _errs15 = errors2;
                                if (errors2 === _errs15) {
                                  if (typeof data6 === "string") {
                                    if (func1(data6) > 255) {
                                      validate46.errors = [{ instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                                      return false;
                                    } else {
                                      if (func1(data6) < 1) {
                                        validate46.errors = [{ instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                        return false;
                                      }
                                    }
                                  } else {
                                    validate46.errors = [{ instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                    return false;
                                  }
                                }
                                var valid2 = _errs15 === errors2;
                              } else {
                                var valid2 = true;
                              }
                              if (valid2) {
                                if (data4.weekStart !== void 0) {
                                  let data7 = data4.weekStart;
                                  const _errs17 = errors2;
                                  if (!(typeof data7 == "number" && (!(data7 % 1) && !isNaN(data7)) && isFinite(data7))) {
                                    validate46.errors = [{ instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                    return false;
                                  }
                                  if (errors2 === _errs17) {
                                    if (typeof data7 == "number" && isFinite(data7)) {
                                      if (data7 > 6 || isNaN(data7)) {
                                        validate46.errors = [{ instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                                        return false;
                                      } else {
                                        if (data7 < 0 || isNaN(data7)) {
                                          validate46.errors = [{ instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                          return false;
                                        }
                                      }
                                    }
                                  }
                                  var valid2 = _errs17 === errors2;
                                } else {
                                  var valid2 = true;
                                }
                              }
                            }
                          }
                        }
                      } else {
                        validate46.errors = [{ instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                        return false;
                      }
                    }
                    var valid0 = _errs9 === errors2;
                  } else {
                    var valid0 = true;
                  }
                  if (valid0) {
                    if (data.now !== void 0) {
                      let data8 = data.now;
                      const _errs19 = errors2;
                      if (errors2 === _errs19) {
                        if (errors2 === _errs19) {
                          if (typeof data8 === "string") {
                            if (func1(data8) > 64) {
                              validate46.errors = [{ instancePath: instancePath + "/now", schemaPath: "#/properties/now/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                              return false;
                            } else {
                              if (!formats0.validate(data8)) {
                                validate46.errors = [{ instancePath: instancePath + "/now", schemaPath: "#/properties/now/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                return false;
                              }
                            }
                          } else {
                            validate46.errors = [{ instancePath: instancePath + "/now", schemaPath: "#/properties/now/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                            return false;
                          }
                        }
                      }
                      var valid0 = _errs19 === errors2;
                    } else {
                      var valid0 = true;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate46.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate46.errors = vErrors;
  return errors2 === 0;
}
validate46.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema70 = { "type": "object", "additionalProperties": false, "required": ["version", "state"], "properties": { "version": { "const": 1 }, "state": { "enum": ["ready", "busy"] } } };
function validate47(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate47.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.state === void 0 && (missing0 = "state")) {
        validate47.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "version" || key0 === "state")) {
            validate47.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.version !== void 0) {
            const _errs2 = errors2;
            if (1 !== data.version) {
              validate47.errors = [{ instancePath: instancePath + "/version", schemaPath: "#/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.state !== void 0) {
              let data1 = data.state;
              const _errs3 = errors2;
              if (!(data1 === "ready" || data1 === "busy")) {
                validate47.errors = [{ instancePath: instancePath + "/state", schemaPath: "#/properties/state/enum", keyword: "enum", params: { allowedValues: schema70.properties.state.enum }, message: "must be equal to one of the allowed values" }];
                return false;
              }
              var valid0 = _errs3 === errors2;
            } else {
              var valid0 = true;
            }
          }
        }
      }
    } else {
      validate47.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate47.errors = vErrors;
  return errors2 === 0;
}
validate47.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema71 = { "oneOf": [{ "type": "object", "additionalProperties": false, "required": ["version", "jobId", "sourceId", "generation", "ok", "data"], "properties": { "version": { "const": 1 }, "jobId": { "type": "string", "minLength": 1, "maxLength": 128 }, "sourceId": { "type": "string", "minLength": 1, "maxLength": 128 }, "generation": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "ok": { "const": true }, "data": { "$ref": "urn:liquid-widgets:snapshot:v1#/$defs/CalendarData" } } }, { "type": "object", "additionalProperties": false, "required": ["version", "jobId", "sourceId", "generation", "ok", "errorCode"], "properties": { "version": { "const": 1 }, "jobId": { "type": "string", "minLength": 1, "maxLength": 128 }, "sourceId": { "type": "string", "minLength": 1, "maxLength": 128 }, "generation": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "ok": { "const": false }, "errorCode": { "enum": ["INVALID_DATA", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT"] } } }] };
function validate49(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate49.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.month === void 0 && (missing0 = "month") || data.timeZone === void 0 && (missing0 = "timeZone") || data.weekStart === void 0 && (missing0 = "weekStart") || data.events === void 0 && (missing0 = "events")) {
        validate49.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "month" || key0 === "timeZone" || key0 === "weekStart" || key0 === "events")) {
            validate49.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.month !== void 0) {
            let data0 = data.month;
            const _errs2 = errors2;
            if (errors2 === _errs2) {
              if (typeof data0 === "string") {
                if (func1(data0) > 7) {
                  validate49.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                  return false;
                } else {
                  if (!pattern4.test(data0)) {
                    validate49.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                    return false;
                  }
                }
              } else {
                validate49.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.timeZone !== void 0) {
              let data1 = data.timeZone;
              const _errs4 = errors2;
              if (errors2 === _errs4) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 255) {
                    validate49.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate49.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate49.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs4 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weekStart !== void 0) {
                let data2 = data.weekStart;
                const _errs6 = errors2;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate49.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors2 === _errs6) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 6 || isNaN(data2)) {
                      validate49.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate49.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs6 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.events !== void 0) {
                  let data3 = data.events;
                  const _errs8 = errors2;
                  if (errors2 === _errs8) {
                    if (Array.isArray(data3)) {
                      if (data3.length > 1e4) {
                        validate49.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/maxItems", keyword: "maxItems", params: { limit: 1e4 }, message: "must NOT have more than 10000 items" }];
                        return false;
                      } else {
                        var valid1 = true;
                        const len0 = data3.length;
                        for (let i0 = 0; i0 < len0; i0++) {
                          let data4 = data3[i0];
                          const _errs10 = errors2;
                          const _errs11 = errors2;
                          const _errs14 = errors2;
                          let valid4 = true;
                          const _errs15 = errors2;
                          if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                            if (data4.allDay !== void 0) {
                              if (true !== data4.allDay) {
                                const err0 = {};
                                if (vErrors === null) {
                                  vErrors = [err0];
                                } else {
                                  vErrors.push(err0);
                                }
                                errors2++;
                              }
                            }
                          }
                          var _valid0 = _errs15 === errors2;
                          errors2 = _errs14;
                          if (vErrors !== null) {
                            if (_errs14) {
                              vErrors.length = _errs14;
                            } else {
                              vErrors = null;
                            }
                          }
                          let ifClause0;
                          if (_valid0) {
                            const _errs17 = errors2;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data6 = data4.start;
                                const _errs18 = errors2;
                                if (errors2 === _errs18) {
                                  if (errors2 === _errs18) {
                                    if (typeof data6 === "string") {
                                      if (func1(data6) > 10) {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                        return false;
                                      } else {
                                        if (!formats2.validate(data6)) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid6 = _errs18 === errors2;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.end !== void 0) {
                                  let data7 = data4.end;
                                  const _errs20 = errors2;
                                  if (errors2 === _errs20) {
                                    if (errors2 === _errs20) {
                                      if (typeof data7 === "string") {
                                        if (func1(data7) > 10) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                          return false;
                                        } else {
                                          if (!formats2.validate(data7)) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid6 = _errs20 === errors2;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                            var _valid0 = _errs17 === errors2;
                            valid4 = _valid0;
                            if (valid4) {
                              var props0 = {};
                              props0.start = true;
                              props0.end = true;
                              props0.allDay = true;
                            }
                            ifClause0 = "then";
                          } else {
                            const _errs22 = errors2;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data8 = data4.start;
                                const _errs23 = errors2;
                                if (errors2 === _errs23) {
                                  if (errors2 === _errs23) {
                                    if (typeof data8 === "string") {
                                      if (func1(data8) > 64) {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                        return false;
                                      } else {
                                        if (!formats0.validate(data8)) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid7 = _errs23 === errors2;
                              } else {
                                var valid7 = true;
                              }
                              if (valid7) {
                                if (data4.end !== void 0) {
                                  let data9 = data4.end;
                                  const _errs25 = errors2;
                                  if (errors2 === _errs25) {
                                    if (errors2 === _errs25) {
                                      if (typeof data9 === "string") {
                                        if (func1(data9) > 64) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                          return false;
                                        } else {
                                          if (!formats0.validate(data9)) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid7 = _errs25 === errors2;
                                } else {
                                  var valid7 = true;
                                }
                              }
                            }
                            var _valid0 = _errs22 === errors2;
                            valid4 = _valid0;
                            if (valid4) {
                              if (props0 !== true) {
                                props0 = props0 || {};
                                props0.start = true;
                                props0.end = true;
                              }
                            }
                            ifClause0 = "else";
                          }
                          if (!valid4) {
                            const err1 = { instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/allOf/0/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
                            if (vErrors === null) {
                              vErrors = [err1];
                            } else {
                              vErrors.push(err1);
                            }
                            errors2++;
                            validate49.errors = vErrors;
                            return false;
                          }
                          if (errors2 === _errs11) {
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              let missing1;
                              if (data4.uid === void 0 && (missing1 = "uid") || data4.occurrenceKey === void 0 && (missing1 = "occurrenceKey") || data4.title === void 0 && (missing1 = "title") || data4.start === void 0 && (missing1 = "start") || data4.end === void 0 && (missing1 = "end") || data4.allDay === void 0 && (missing1 = "allDay")) {
                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                return false;
                              } else {
                                const _errs27 = errors2;
                                for (const key1 in data4) {
                                  if (!(key1 === "uid" || key1 === "occurrenceKey" || key1 === "title" || key1 === "start" || key1 === "end" || key1 === "allDay")) {
                                    validate49.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                    return false;
                                    break;
                                  }
                                }
                                if (_errs27 === errors2) {
                                  if (data4.uid !== void 0) {
                                    let data10 = data4.uid;
                                    const _errs28 = errors2;
                                    if (errors2 === _errs28) {
                                      if (typeof data10 === "string") {
                                        if (func1(data10) > 2048) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/maxLength", keyword: "maxLength", params: { limit: 2048 }, message: "must NOT have more than 2048 characters" }];
                                          return false;
                                        } else {
                                          if (func1(data10) < 1) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                    var valid8 = _errs28 === errors2;
                                  } else {
                                    var valid8 = true;
                                  }
                                  if (valid8) {
                                    if (data4.occurrenceKey !== void 0) {
                                      let data11 = data4.occurrenceKey;
                                      const _errs30 = errors2;
                                      if (errors2 === _errs30) {
                                        if (typeof data11 === "string") {
                                          if (func1(data11) > 64) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                            return false;
                                          } else {
                                            if (func1(data11) < 1) {
                                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                              return false;
                                            }
                                          }
                                        } else {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                          return false;
                                        }
                                      }
                                      var valid8 = _errs30 === errors2;
                                    } else {
                                      var valid8 = true;
                                    }
                                    if (valid8) {
                                      if (data4.title !== void 0) {
                                        let data12 = data4.title;
                                        const _errs32 = errors2;
                                        if (errors2 === _errs32) {
                                          if (typeof data12 === "string") {
                                            if (func1(data12) > 4096) {
                                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                                              return false;
                                            }
                                          } else {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                            return false;
                                          }
                                        }
                                        var valid8 = _errs32 === errors2;
                                      } else {
                                        var valid8 = true;
                                      }
                                      if (valid8) {
                                        if (data4.start !== void 0) {
                                          let data13 = data4.start;
                                          const _errs34 = errors2;
                                          if (errors2 === _errs34) {
                                            if (typeof data13 === "string") {
                                              if (func1(data13) > 64) {
                                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                return false;
                                              }
                                            } else {
                                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                              return false;
                                            }
                                          }
                                          var valid8 = _errs34 === errors2;
                                        } else {
                                          var valid8 = true;
                                        }
                                        if (valid8) {
                                          if (data4.end !== void 0) {
                                            let data14 = data4.end;
                                            const _errs36 = errors2;
                                            if (errors2 === _errs36) {
                                              if (typeof data14 === "string") {
                                                if (func1(data14) > 64) {
                                                  validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                }
                                              } else {
                                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                            var valid8 = _errs36 === errors2;
                                          } else {
                                            var valid8 = true;
                                          }
                                          if (valid8) {
                                            if (data4.allDay !== void 0) {
                                              const _errs38 = errors2;
                                              if (typeof data4.allDay !== "boolean") {
                                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/allDay", schemaPath: "#/$defs/CalendarEvent/properties/allDay/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                                                return false;
                                              }
                                              var valid8 = _errs38 === errors2;
                                            } else {
                                              var valid8 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            } else {
                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                              return false;
                            }
                          }
                          var valid1 = _errs10 === errors2;
                          if (!valid1) {
                            break;
                          }
                        }
                      }
                    } else {
                      validate49.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                      return false;
                    }
                  }
                  var valid0 = _errs8 === errors2;
                } else {
                  var valid0 = true;
                }
              }
            }
          }
        }
      }
    } else {
      validate49.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate49.errors = vErrors;
  return errors2 === 0;
}
validate49.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate48(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate48.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs0 = errors2;
  let valid0 = false;
  let passing0 = null;
  const _errs1 = errors2;
  if (errors2 === _errs1) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.jobId === void 0 && (missing0 = "jobId") || data.sourceId === void 0 && (missing0 = "sourceId") || data.generation === void 0 && (missing0 = "generation") || data.ok === void 0 && (missing0 = "ok") || data.data === void 0 && (missing0 = "data")) {
        const err0 = { instancePath, schemaPath: "#/oneOf/0/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" };
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors2++;
      } else {
        const _errs3 = errors2;
        for (const key0 in data) {
          if (!(key0 === "version" || key0 === "jobId" || key0 === "sourceId" || key0 === "generation" || key0 === "ok" || key0 === "data")) {
            const err1 = { instancePath, schemaPath: "#/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err1];
            } else {
              vErrors.push(err1);
            }
            errors2++;
            break;
          }
        }
        if (_errs3 === errors2) {
          if (data.version !== void 0) {
            const _errs4 = errors2;
            if (1 !== data.version) {
              const err2 = { instancePath: instancePath + "/version", schemaPath: "#/oneOf/0/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" };
              if (vErrors === null) {
                vErrors = [err2];
              } else {
                vErrors.push(err2);
              }
              errors2++;
            }
            var valid1 = _errs4 === errors2;
          } else {
            var valid1 = true;
          }
          if (valid1) {
            if (data.jobId !== void 0) {
              let data1 = data.jobId;
              const _errs5 = errors2;
              if (errors2 === _errs5) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 128) {
                    const err3 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/0/properties/jobId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err3];
                    } else {
                      vErrors.push(err3);
                    }
                    errors2++;
                  } else {
                    if (func1(data1) < 1) {
                      const err4 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/0/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err4];
                      } else {
                        vErrors.push(err4);
                      }
                      errors2++;
                    }
                  }
                } else {
                  const err5 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/0/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err5];
                  } else {
                    vErrors.push(err5);
                  }
                  errors2++;
                }
              }
              var valid1 = _errs5 === errors2;
            } else {
              var valid1 = true;
            }
            if (valid1) {
              if (data.sourceId !== void 0) {
                let data2 = data.sourceId;
                const _errs7 = errors2;
                if (errors2 === _errs7) {
                  if (typeof data2 === "string") {
                    if (func1(data2) > 128) {
                      const err6 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/0/properties/sourceId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                      if (vErrors === null) {
                        vErrors = [err6];
                      } else {
                        vErrors.push(err6);
                      }
                      errors2++;
                    } else {
                      if (func1(data2) < 1) {
                        const err7 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/0/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err7];
                        } else {
                          vErrors.push(err7);
                        }
                        errors2++;
                      }
                    }
                  } else {
                    const err8 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/0/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err8];
                    } else {
                      vErrors.push(err8);
                    }
                    errors2++;
                  }
                }
                var valid1 = _errs7 === errors2;
              } else {
                var valid1 = true;
              }
              if (valid1) {
                if (data.generation !== void 0) {
                  let data3 = data.generation;
                  const _errs9 = errors2;
                  if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                    const err9 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/0/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                    if (vErrors === null) {
                      vErrors = [err9];
                    } else {
                      vErrors.push(err9);
                    }
                    errors2++;
                  }
                  if (errors2 === _errs9) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 4294967295 || isNaN(data3)) {
                        const err10 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/0/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" };
                        if (vErrors === null) {
                          vErrors = [err10];
                        } else {
                          vErrors.push(err10);
                        }
                        errors2++;
                      } else {
                        if (data3 < 0 || isNaN(data3)) {
                          const err11 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/0/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err11];
                          } else {
                            vErrors.push(err11);
                          }
                          errors2++;
                        }
                      }
                    }
                  }
                  var valid1 = _errs9 === errors2;
                } else {
                  var valid1 = true;
                }
                if (valid1) {
                  if (data.ok !== void 0) {
                    const _errs11 = errors2;
                    if (true !== data.ok) {
                      const err12 = { instancePath: instancePath + "/ok", schemaPath: "#/oneOf/0/properties/ok/const", keyword: "const", params: { allowedValue: true }, message: "must be equal to constant" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors2++;
                    }
                    var valid1 = _errs11 === errors2;
                  } else {
                    var valid1 = true;
                  }
                  if (valid1) {
                    if (data.data !== void 0) {
                      const _errs12 = errors2;
                      if (!validate49(data.data, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
                        vErrors = vErrors === null ? validate49.errors : vErrors.concat(validate49.errors);
                        errors2 = vErrors.length;
                      }
                      var valid1 = _errs12 === errors2;
                    } else {
                      var valid1 = true;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      const err13 = { instancePath, schemaPath: "#/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
      if (vErrors === null) {
        vErrors = [err13];
      } else {
        vErrors.push(err13);
      }
      errors2++;
    }
  }
  var _valid0 = _errs1 === errors2;
  if (_valid0) {
    valid0 = true;
    passing0 = 0;
    var props0 = true;
  }
  const _errs13 = errors2;
  if (errors2 === _errs13) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.version === void 0 && (missing1 = "version") || data.jobId === void 0 && (missing1 = "jobId") || data.sourceId === void 0 && (missing1 = "sourceId") || data.generation === void 0 && (missing1 = "generation") || data.ok === void 0 && (missing1 = "ok") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        const err14 = { instancePath, schemaPath: "#/oneOf/1/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" };
        if (vErrors === null) {
          vErrors = [err14];
        } else {
          vErrors.push(err14);
        }
        errors2++;
      } else {
        const _errs15 = errors2;
        for (const key1 in data) {
          if (!(key1 === "version" || key1 === "jobId" || key1 === "sourceId" || key1 === "generation" || key1 === "ok" || key1 === "errorCode")) {
            const err15 = { instancePath, schemaPath: "#/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err15];
            } else {
              vErrors.push(err15);
            }
            errors2++;
            break;
          }
        }
        if (_errs15 === errors2) {
          if (data.version !== void 0) {
            const _errs16 = errors2;
            if (1 !== data.version) {
              const err16 = { instancePath: instancePath + "/version", schemaPath: "#/oneOf/1/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" };
              if (vErrors === null) {
                vErrors = [err16];
              } else {
                vErrors.push(err16);
              }
              errors2++;
            }
            var valid2 = _errs16 === errors2;
          } else {
            var valid2 = true;
          }
          if (valid2) {
            if (data.jobId !== void 0) {
              let data7 = data.jobId;
              const _errs17 = errors2;
              if (errors2 === _errs17) {
                if (typeof data7 === "string") {
                  if (func1(data7) > 128) {
                    const err17 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/1/properties/jobId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors2++;
                  } else {
                    if (func1(data7) < 1) {
                      const err18 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/1/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err18];
                      } else {
                        vErrors.push(err18);
                      }
                      errors2++;
                    }
                  }
                } else {
                  const err19 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/1/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err19];
                  } else {
                    vErrors.push(err19);
                  }
                  errors2++;
                }
              }
              var valid2 = _errs17 === errors2;
            } else {
              var valid2 = true;
            }
            if (valid2) {
              if (data.sourceId !== void 0) {
                let data8 = data.sourceId;
                const _errs19 = errors2;
                if (errors2 === _errs19) {
                  if (typeof data8 === "string") {
                    if (func1(data8) > 128) {
                      const err20 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/1/properties/sourceId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                      if (vErrors === null) {
                        vErrors = [err20];
                      } else {
                        vErrors.push(err20);
                      }
                      errors2++;
                    } else {
                      if (func1(data8) < 1) {
                        const err21 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/1/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err21];
                        } else {
                          vErrors.push(err21);
                        }
                        errors2++;
                      }
                    }
                  } else {
                    const err22 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/1/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err22];
                    } else {
                      vErrors.push(err22);
                    }
                    errors2++;
                  }
                }
                var valid2 = _errs19 === errors2;
              } else {
                var valid2 = true;
              }
              if (valid2) {
                if (data.generation !== void 0) {
                  let data9 = data.generation;
                  const _errs21 = errors2;
                  if (!(typeof data9 == "number" && (!(data9 % 1) && !isNaN(data9)) && isFinite(data9))) {
                    const err23 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/1/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                    if (vErrors === null) {
                      vErrors = [err23];
                    } else {
                      vErrors.push(err23);
                    }
                    errors2++;
                  }
                  if (errors2 === _errs21) {
                    if (typeof data9 == "number" && isFinite(data9)) {
                      if (data9 > 4294967295 || isNaN(data9)) {
                        const err24 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/1/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" };
                        if (vErrors === null) {
                          vErrors = [err24];
                        } else {
                          vErrors.push(err24);
                        }
                        errors2++;
                      } else {
                        if (data9 < 0 || isNaN(data9)) {
                          const err25 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/1/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err25];
                          } else {
                            vErrors.push(err25);
                          }
                          errors2++;
                        }
                      }
                    }
                  }
                  var valid2 = _errs21 === errors2;
                } else {
                  var valid2 = true;
                }
                if (valid2) {
                  if (data.ok !== void 0) {
                    const _errs23 = errors2;
                    if (false !== data.ok) {
                      const err26 = { instancePath: instancePath + "/ok", schemaPath: "#/oneOf/1/properties/ok/const", keyword: "const", params: { allowedValue: false }, message: "must be equal to constant" };
                      if (vErrors === null) {
                        vErrors = [err26];
                      } else {
                        vErrors.push(err26);
                      }
                      errors2++;
                    }
                    var valid2 = _errs23 === errors2;
                  } else {
                    var valid2 = true;
                  }
                  if (valid2) {
                    if (data.errorCode !== void 0) {
                      let data11 = data.errorCode;
                      const _errs24 = errors2;
                      if (!(data11 === "INVALID_DATA" || data11 === "UNSUPPORTED_CALENDAR" || data11 === "UNKNOWN_TIME_ZONE" || data11 === "PAYLOAD_TOO_LARGE" || data11 === "EXPANSION_LIMIT")) {
                        const err27 = { instancePath: instancePath + "/errorCode", schemaPath: "#/oneOf/1/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema71.oneOf[1].properties.errorCode.enum }, message: "must be equal to one of the allowed values" };
                        if (vErrors === null) {
                          vErrors = [err27];
                        } else {
                          vErrors.push(err27);
                        }
                        errors2++;
                      }
                      var valid2 = _errs24 === errors2;
                    } else {
                      var valid2 = true;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      const err28 = { instancePath, schemaPath: "#/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
      if (vErrors === null) {
        vErrors = [err28];
      } else {
        vErrors.push(err28);
      }
      errors2++;
    }
  }
  var _valid0 = _errs13 === errors2;
  if (_valid0 && valid0) {
    valid0 = false;
    passing0 = [passing0, 1];
  } else {
    if (_valid0) {
      valid0 = true;
      passing0 = 1;
      if (props0 !== true) {
        props0 = true;
      }
    }
  }
  if (!valid0) {
    const err29 = { instancePath, schemaPath: "#/oneOf", keyword: "oneOf", params: { passingSchemas: passing0 }, message: "must match exactly one schema in oneOf" };
    if (vErrors === null) {
      vErrors = [err29];
    } else {
      vErrors.push(err29);
    }
    errors2++;
    validate48.errors = vErrors;
    return false;
  } else {
    errors2 = _errs0;
    if (vErrors !== null) {
      if (_errs0) {
        vErrors.length = _errs0;
      } else {
        vErrors = null;
      }
    }
  }
  validate48.errors = vErrors;
  evaluated0.props = props0;
  return errors2 === 0;
}
validate48.evaluated = { "dynamicProps": true, "dynamicItems": false };
var formats76 = /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
var pattern26 = new RegExp("^[^/\\s\\x00-\\x1f]+$", "u");
function validate51(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate51.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.schemaVersion === void 0 && (missing0 = "schemaVersion") || data.revision === void 0 && (missing0 = "revision") || data.calendar === void 0 && (missing0 = "calendar") || data.weather === void 0 && (missing0 = "weather") || data.networkInterface === void 0 && (missing0 = "networkInterface")) {
        validate51.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!(key0 === "schemaVersion" || key0 === "revision" || key0 === "calendar" || key0 === "weather" || key0 === "networkInterface")) {
            validate51.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.schemaVersion !== void 0) {
            const _errs2 = errors2;
            if (1 !== data.schemaVersion) {
              validate51.errors = [{ instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.revision !== void 0) {
              let data1 = data.revision;
              const _errs3 = errors2;
              if (errors2 === _errs3) {
                if (errors2 === _errs3) {
                  if (typeof data1 === "string") {
                    if (!formats76.test(data1)) {
                      validate51.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' }];
                      return false;
                    }
                  } else {
                    validate51.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
              }
              var valid0 = _errs3 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.calendar !== void 0) {
                let data2 = data.calendar;
                const _errs5 = errors2;
                if (errors2 === _errs5) {
                  if (data2 && typeof data2 == "object" && !Array.isArray(data2)) {
                    let missing1;
                    if (data2.sourceId === void 0 && (missing1 = "sourceId") || data2.enabled === void 0 && (missing1 = "enabled") || data2.deletionPending === void 0 && (missing1 = "deletionPending")) {
                      validate51.errors = [{ instancePath: instancePath + "/calendar", schemaPath: "#/properties/calendar/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                      return false;
                    } else {
                      const _errs7 = errors2;
                      for (const key1 in data2) {
                        if (!(key1 === "sourceId" || key1 === "enabled" || key1 === "deletionPending")) {
                          validate51.errors = [{ instancePath: instancePath + "/calendar", schemaPath: "#/properties/calendar/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                          return false;
                          break;
                        }
                      }
                      if (_errs7 === errors2) {
                        if (data2.sourceId !== void 0) {
                          let data3 = data2.sourceId;
                          const _errs8 = errors2;
                          const _errs9 = errors2;
                          let valid2 = false;
                          const _errs10 = errors2;
                          if (errors2 === _errs10) {
                            if (errors2 === _errs10) {
                              if (typeof data3 === "string") {
                                if (!formats76.test(data3)) {
                                  const err0 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf/0/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' };
                                  if (vErrors === null) {
                                    vErrors = [err0];
                                  } else {
                                    vErrors.push(err0);
                                  }
                                  errors2++;
                                }
                              } else {
                                const err1 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err1];
                                } else {
                                  vErrors.push(err1);
                                }
                                errors2++;
                              }
                            }
                          }
                          var _valid0 = _errs10 === errors2;
                          valid2 = valid2 || _valid0;
                          const _errs12 = errors2;
                          if (data3 !== null) {
                            const err2 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err2];
                            } else {
                              vErrors.push(err2);
                            }
                            errors2++;
                          }
                          var _valid0 = _errs12 === errors2;
                          valid2 = valid2 || _valid0;
                          if (!valid2) {
                            const err3 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err3];
                            } else {
                              vErrors.push(err3);
                            }
                            errors2++;
                            validate51.errors = vErrors;
                            return false;
                          } else {
                            errors2 = _errs9;
                            if (vErrors !== null) {
                              if (_errs9) {
                                vErrors.length = _errs9;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid1 = _errs8 === errors2;
                        } else {
                          var valid1 = true;
                        }
                        if (valid1) {
                          if (data2.enabled !== void 0) {
                            const _errs14 = errors2;
                            if (typeof data2.enabled !== "boolean") {
                              validate51.errors = [{ instancePath: instancePath + "/calendar/enabled", schemaPath: "#/properties/calendar/properties/enabled/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                              return false;
                            }
                            var valid1 = _errs14 === errors2;
                          } else {
                            var valid1 = true;
                          }
                          if (valid1) {
                            if (data2.deletionPending !== void 0) {
                              const _errs16 = errors2;
                              if (typeof data2.deletionPending !== "boolean") {
                                validate51.errors = [{ instancePath: instancePath + "/calendar/deletionPending", schemaPath: "#/properties/calendar/properties/deletionPending/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                                return false;
                              }
                              var valid1 = _errs16 === errors2;
                            } else {
                              var valid1 = true;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    validate51.errors = [{ instancePath: instancePath + "/calendar", schemaPath: "#/properties/calendar/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                    return false;
                  }
                }
                var valid0 = _errs5 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.weather !== void 0) {
                  let data6 = data.weather;
                  const _errs18 = errors2;
                  if (errors2 === _errs18) {
                    if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
                      let missing2;
                      if (data6.sourceId === void 0 && (missing2 = "sourceId") || data6.location === void 0 && (missing2 = "location")) {
                        validate51.errors = [{ instancePath: instancePath + "/weather", schemaPath: "#/properties/weather/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
                        return false;
                      } else {
                        const _errs20 = errors2;
                        for (const key2 in data6) {
                          if (!(key2 === "sourceId" || key2 === "location")) {
                            validate51.errors = [{ instancePath: instancePath + "/weather", schemaPath: "#/properties/weather/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
                            return false;
                            break;
                          }
                        }
                        if (_errs20 === errors2) {
                          if (data6.sourceId !== void 0) {
                            let data7 = data6.sourceId;
                            const _errs21 = errors2;
                            const _errs22 = errors2;
                            let valid4 = false;
                            const _errs23 = errors2;
                            if (errors2 === _errs23) {
                              if (errors2 === _errs23) {
                                if (typeof data7 === "string") {
                                  if (!formats76.test(data7)) {
                                    const err4 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf/0/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' };
                                    if (vErrors === null) {
                                      vErrors = [err4];
                                    } else {
                                      vErrors.push(err4);
                                    }
                                    errors2++;
                                  }
                                } else {
                                  const err5 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err5];
                                  } else {
                                    vErrors.push(err5);
                                  }
                                  errors2++;
                                }
                              }
                            }
                            var _valid1 = _errs23 === errors2;
                            valid4 = valid4 || _valid1;
                            const _errs25 = errors2;
                            if (data7 !== null) {
                              const err6 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                              if (vErrors === null) {
                                vErrors = [err6];
                              } else {
                                vErrors.push(err6);
                              }
                              errors2++;
                            }
                            var _valid1 = _errs25 === errors2;
                            valid4 = valid4 || _valid1;
                            if (!valid4) {
                              const err7 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                              if (vErrors === null) {
                                vErrors = [err7];
                              } else {
                                vErrors.push(err7);
                              }
                              errors2++;
                              validate51.errors = vErrors;
                              return false;
                            } else {
                              errors2 = _errs22;
                              if (vErrors !== null) {
                                if (_errs22) {
                                  vErrors.length = _errs22;
                                } else {
                                  vErrors = null;
                                }
                              }
                            }
                            var valid3 = _errs21 === errors2;
                          } else {
                            var valid3 = true;
                          }
                          if (valid3) {
                            if (data6.location !== void 0) {
                              let data8 = data6.location;
                              const _errs27 = errors2;
                              const _errs28 = errors2;
                              let valid5 = false;
                              const _errs29 = errors2;
                              const _errs30 = errors2;
                              if (errors2 === _errs30) {
                                if (data8 && typeof data8 == "object" && !Array.isArray(data8)) {
                                  let missing3;
                                  if (data8.id === void 0 && (missing3 = "id") || data8.label === void 0 && (missing3 = "label") || data8.latitude === void 0 && (missing3 = "latitude") || data8.longitude === void 0 && (missing3 = "longitude") || data8.timeZone === void 0 && (missing3 = "timeZone")) {
                                    const err8 = { instancePath: instancePath + "/weather/location", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors2++;
                                  } else {
                                    const _errs32 = errors2;
                                    for (const key3 in data8) {
                                      if (!(key3 === "id" || key3 === "label" || key3 === "latitude" || key3 === "longitude" || key3 === "timeZone")) {
                                        const err9 = { instancePath: instancePath + "/weather/location", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                                        if (vErrors === null) {
                                          vErrors = [err9];
                                        } else {
                                          vErrors.push(err9);
                                        }
                                        errors2++;
                                        break;
                                      }
                                    }
                                    if (_errs32 === errors2) {
                                      if (data8.id !== void 0) {
                                        let data9 = data8.id;
                                        const _errs33 = errors2;
                                        if (errors2 === _errs33) {
                                          if (typeof data9 === "string") {
                                            if (func1(data9) > 128) {
                                              const err10 = { instancePath: instancePath + "/weather/location/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                                              if (vErrors === null) {
                                                vErrors = [err10];
                                              } else {
                                                vErrors.push(err10);
                                              }
                                              errors2++;
                                            } else {
                                              if (func1(data9) < 1) {
                                                const err11 = { instancePath: instancePath + "/weather/location/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                                if (vErrors === null) {
                                                  vErrors = [err11];
                                                } else {
                                                  vErrors.push(err11);
                                                }
                                                errors2++;
                                              }
                                            }
                                          } else {
                                            const err12 = { instancePath: instancePath + "/weather/location/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                            if (vErrors === null) {
                                              vErrors = [err12];
                                            } else {
                                              vErrors.push(err12);
                                            }
                                            errors2++;
                                          }
                                        }
                                        var valid7 = _errs33 === errors2;
                                      } else {
                                        var valid7 = true;
                                      }
                                      if (valid7) {
                                        if (data8.label !== void 0) {
                                          let data10 = data8.label;
                                          const _errs35 = errors2;
                                          if (errors2 === _errs35) {
                                            if (typeof data10 === "string") {
                                              if (func1(data10) > 512) {
                                                const err13 = { instancePath: instancePath + "/weather/location/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                                if (vErrors === null) {
                                                  vErrors = [err13];
                                                } else {
                                                  vErrors.push(err13);
                                                }
                                                errors2++;
                                              } else {
                                                if (func1(data10) < 1) {
                                                  const err14 = { instancePath: instancePath + "/weather/location/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                                  if (vErrors === null) {
                                                    vErrors = [err14];
                                                  } else {
                                                    vErrors.push(err14);
                                                  }
                                                  errors2++;
                                                }
                                              }
                                            } else {
                                              const err15 = { instancePath: instancePath + "/weather/location/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                              if (vErrors === null) {
                                                vErrors = [err15];
                                              } else {
                                                vErrors.push(err15);
                                              }
                                              errors2++;
                                            }
                                          }
                                          var valid7 = _errs35 === errors2;
                                        } else {
                                          var valid7 = true;
                                        }
                                        if (valid7) {
                                          if (data8.latitude !== void 0) {
                                            let data11 = data8.latitude;
                                            const _errs37 = errors2;
                                            if (errors2 === _errs37) {
                                              if (typeof data11 == "number" && isFinite(data11)) {
                                                if (data11 > 90 || isNaN(data11)) {
                                                  const err16 = { instancePath: instancePath + "/weather/location/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" };
                                                  if (vErrors === null) {
                                                    vErrors = [err16];
                                                  } else {
                                                    vErrors.push(err16);
                                                  }
                                                  errors2++;
                                                } else {
                                                  if (data11 < -90 || isNaN(data11)) {
                                                    const err17 = { instancePath: instancePath + "/weather/location/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" };
                                                    if (vErrors === null) {
                                                      vErrors = [err17];
                                                    } else {
                                                      vErrors.push(err17);
                                                    }
                                                    errors2++;
                                                  }
                                                }
                                              } else {
                                                const err18 = { instancePath: instancePath + "/weather/location/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                if (vErrors === null) {
                                                  vErrors = [err18];
                                                } else {
                                                  vErrors.push(err18);
                                                }
                                                errors2++;
                                              }
                                            }
                                            var valid7 = _errs37 === errors2;
                                          } else {
                                            var valid7 = true;
                                          }
                                          if (valid7) {
                                            if (data8.longitude !== void 0) {
                                              let data12 = data8.longitude;
                                              const _errs39 = errors2;
                                              if (errors2 === _errs39) {
                                                if (typeof data12 == "number" && isFinite(data12)) {
                                                  if (data12 > 180 || isNaN(data12)) {
                                                    const err19 = { instancePath: instancePath + "/weather/location/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" };
                                                    if (vErrors === null) {
                                                      vErrors = [err19];
                                                    } else {
                                                      vErrors.push(err19);
                                                    }
                                                    errors2++;
                                                  } else {
                                                    if (data12 < -180 || isNaN(data12)) {
                                                      const err20 = { instancePath: instancePath + "/weather/location/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" };
                                                      if (vErrors === null) {
                                                        vErrors = [err20];
                                                      } else {
                                                        vErrors.push(err20);
                                                      }
                                                      errors2++;
                                                    }
                                                  }
                                                } else {
                                                  const err21 = { instancePath: instancePath + "/weather/location/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                  if (vErrors === null) {
                                                    vErrors = [err21];
                                                  } else {
                                                    vErrors.push(err21);
                                                  }
                                                  errors2++;
                                                }
                                              }
                                              var valid7 = _errs39 === errors2;
                                            } else {
                                              var valid7 = true;
                                            }
                                            if (valid7) {
                                              if (data8.timeZone !== void 0) {
                                                let data13 = data8.timeZone;
                                                const _errs41 = errors2;
                                                if (errors2 === _errs41) {
                                                  if (typeof data13 === "string") {
                                                    if (func1(data13) > 255) {
                                                      const err22 = { instancePath: instancePath + "/weather/location/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                                      if (vErrors === null) {
                                                        vErrors = [err22];
                                                      } else {
                                                        vErrors.push(err22);
                                                      }
                                                      errors2++;
                                                    } else {
                                                      if (func1(data13) < 1) {
                                                        const err23 = { instancePath: instancePath + "/weather/location/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                                        if (vErrors === null) {
                                                          vErrors = [err23];
                                                        } else {
                                                          vErrors.push(err23);
                                                        }
                                                        errors2++;
                                                      }
                                                    }
                                                  } else {
                                                    const err24 = { instancePath: instancePath + "/weather/location/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                    if (vErrors === null) {
                                                      vErrors = [err24];
                                                    } else {
                                                      vErrors.push(err24);
                                                    }
                                                    errors2++;
                                                  }
                                                }
                                                var valid7 = _errs41 === errors2;
                                              } else {
                                                var valid7 = true;
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                } else {
                                  const err25 = { instancePath: instancePath + "/weather/location", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                  if (vErrors === null) {
                                    vErrors = [err25];
                                  } else {
                                    vErrors.push(err25);
                                  }
                                  errors2++;
                                }
                              }
                              var _valid2 = _errs29 === errors2;
                              valid5 = valid5 || _valid2;
                              const _errs43 = errors2;
                              if (data8 !== null) {
                                const err26 = { instancePath: instancePath + "/weather/location", schemaPath: "#/properties/weather/properties/location/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err26];
                                } else {
                                  vErrors.push(err26);
                                }
                                errors2++;
                              }
                              var _valid2 = _errs43 === errors2;
                              valid5 = valid5 || _valid2;
                              if (!valid5) {
                                const err27 = { instancePath: instancePath + "/weather/location", schemaPath: "#/properties/weather/properties/location/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err27];
                                } else {
                                  vErrors.push(err27);
                                }
                                errors2++;
                                validate51.errors = vErrors;
                                return false;
                              } else {
                                errors2 = _errs28;
                                if (vErrors !== null) {
                                  if (_errs28) {
                                    vErrors.length = _errs28;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid3 = _errs27 === errors2;
                            } else {
                              var valid3 = true;
                            }
                          }
                        }
                      }
                    } else {
                      validate51.errors = [{ instancePath: instancePath + "/weather", schemaPath: "#/properties/weather/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                      return false;
                    }
                  }
                  var valid0 = _errs18 === errors2;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.networkInterface !== void 0) {
                    let data14 = data.networkInterface;
                    const _errs45 = errors2;
                    if (errors2 === _errs45) {
                      if (typeof data14 === "string") {
                        if (func1(data14) > 64) {
                          validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                          return false;
                        } else {
                          if (func1(data14) < 1) {
                            validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          } else {
                            if (!pattern26.test(data14)) {
                              validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/pattern", keyword: "pattern", params: { pattern: "^[^/\\s\\x00-\\x1f]+$" }, message: 'must match pattern "^[^/\\s\\x00-\\x1f]+$"' }];
                              return false;
                            }
                          }
                        }
                      } else {
                        validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid0 = _errs45 === errors2;
                  } else {
                    var valid0 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate51.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate51.errors = vErrors;
  return errors2 === 0;
}
validate51.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var calendarSummary = validate52;
var schema76 = { "$schema": "https://json-schema.org/draft/2020-12/schema", "$id": "urn:liquid-widgets:calendar-status:v1", "type": "object", "additionalProperties": false, "properties": { "version": { "const": 1 }, "instanceId": { "type": "string", "format": "uuid" }, "revision": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "generation": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "context": { "anyOf": [{ "$ref": "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext" }, { "type": "null" }] }, "hasData": { "type": "boolean" }, "eventCount": { "type": "integer", "minimum": 0, "maximum": 1e4 }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "required": ["version", "instanceId", "revision", "generation", "context", "hasData", "eventCount", "sourceId", "status", "updatedAt", "errorCode"] };
var func169 = Object.prototype.hasOwnProperty;
function validate52(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors2 = 0;
  const evaluated0 = validate52.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors2 === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.instanceId === void 0 && (missing0 = "instanceId") || data.revision === void 0 && (missing0 = "revision") || data.generation === void 0 && (missing0 = "generation") || data.context === void 0 && (missing0 = "context") || data.hasData === void 0 && (missing0 = "hasData") || data.eventCount === void 0 && (missing0 = "eventCount") || data.sourceId === void 0 && (missing0 = "sourceId") || data.status === void 0 && (missing0 = "status") || data.updatedAt === void 0 && (missing0 = "updatedAt") || data.errorCode === void 0 && (missing0 = "errorCode")) {
        validate52.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors2;
        for (const key0 in data) {
          if (!func169.call(schema76.properties, key0)) {
            validate52.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors2) {
          if (data.version !== void 0) {
            const _errs2 = errors2;
            if (1 !== data.version) {
              validate52.errors = [{ instancePath: instancePath + "/version", schemaPath: "#/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors2;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.instanceId !== void 0) {
              let data1 = data.instanceId;
              const _errs3 = errors2;
              if (errors2 === _errs3) {
                if (errors2 === _errs3) {
                  if (typeof data1 === "string") {
                    if (!formats76.test(data1)) {
                      validate52.errors = [{ instancePath: instancePath + "/instanceId", schemaPath: "#/properties/instanceId/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' }];
                      return false;
                    }
                  } else {
                    validate52.errors = [{ instancePath: instancePath + "/instanceId", schemaPath: "#/properties/instanceId/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
              }
              var valid0 = _errs3 === errors2;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.revision !== void 0) {
                let data2 = data.revision;
                const _errs5 = errors2;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate52.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors2 === _errs5) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 4294967295 || isNaN(data2)) {
                      validate52.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate52.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs5 === errors2;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.generation !== void 0) {
                  let data3 = data.generation;
                  const _errs7 = errors2;
                  if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                    validate52.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                    return false;
                  }
                  if (errors2 === _errs7) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 4294967295 || isNaN(data3)) {
                        validate52.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                        return false;
                      } else {
                        if (data3 < 0 || isNaN(data3)) {
                          validate52.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                          return false;
                        }
                      }
                    }
                  }
                  var valid0 = _errs7 === errors2;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.context !== void 0) {
                    let data4 = data.context;
                    const _errs9 = errors2;
                    const _errs10 = errors2;
                    let valid1 = false;
                    const _errs11 = errors2;
                    const _errs12 = errors2;
                    if (errors2 === _errs12) {
                      if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                        let missing1;
                        if (data4.month === void 0 && (missing1 = "month") || data4.timeZone === void 0 && (missing1 = "timeZone") || data4.weekStart === void 0 && (missing1 = "weekStart")) {
                          const err0 = { instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" };
                          if (vErrors === null) {
                            vErrors = [err0];
                          } else {
                            vErrors.push(err0);
                          }
                          errors2++;
                        } else {
                          const _errs14 = errors2;
                          for (const key1 in data4) {
                            if (!(key1 === "month" || key1 === "timeZone" || key1 === "weekStart")) {
                              const err1 = { instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
                              if (vErrors === null) {
                                vErrors = [err1];
                              } else {
                                vErrors.push(err1);
                              }
                              errors2++;
                              break;
                            }
                          }
                          if (_errs14 === errors2) {
                            if (data4.month !== void 0) {
                              let data5 = data4.month;
                              const _errs15 = errors2;
                              if (errors2 === _errs15) {
                                if (typeof data5 === "string") {
                                  if (func1(data5) > 7) {
                                    const err2 = { instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err2];
                                    } else {
                                      vErrors.push(err2);
                                    }
                                    errors2++;
                                  } else {
                                    if (!pattern4.test(data5)) {
                                      const err3 = { instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' };
                                      if (vErrors === null) {
                                        vErrors = [err3];
                                      } else {
                                        vErrors.push(err3);
                                      }
                                      errors2++;
                                    }
                                  }
                                } else {
                                  const err4 = { instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err4];
                                  } else {
                                    vErrors.push(err4);
                                  }
                                  errors2++;
                                }
                              }
                              var valid3 = _errs15 === errors2;
                            } else {
                              var valid3 = true;
                            }
                            if (valid3) {
                              if (data4.timeZone !== void 0) {
                                let data6 = data4.timeZone;
                                const _errs17 = errors2;
                                if (errors2 === _errs17) {
                                  if (typeof data6 === "string") {
                                    if (func1(data6) > 255) {
                                      const err5 = { instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err5];
                                      } else {
                                        vErrors.push(err5);
                                      }
                                      errors2++;
                                    } else {
                                      if (func1(data6) < 1) {
                                        const err6 = { instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err6];
                                        } else {
                                          vErrors.push(err6);
                                        }
                                        errors2++;
                                      }
                                    }
                                  } else {
                                    const err7 = { instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err7];
                                    } else {
                                      vErrors.push(err7);
                                    }
                                    errors2++;
                                  }
                                }
                                var valid3 = _errs17 === errors2;
                              } else {
                                var valid3 = true;
                              }
                              if (valid3) {
                                if (data4.weekStart !== void 0) {
                                  let data7 = data4.weekStart;
                                  const _errs19 = errors2;
                                  if (!(typeof data7 == "number" && (!(data7 % 1) && !isNaN(data7)) && isFinite(data7))) {
                                    const err8 = { instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors2++;
                                  }
                                  if (errors2 === _errs19) {
                                    if (typeof data7 == "number" && isFinite(data7)) {
                                      if (data7 > 6 || isNaN(data7)) {
                                        const err9 = { instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" };
                                        if (vErrors === null) {
                                          vErrors = [err9];
                                        } else {
                                          vErrors.push(err9);
                                        }
                                        errors2++;
                                      } else {
                                        if (data7 < 0 || isNaN(data7)) {
                                          const err10 = { instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                          if (vErrors === null) {
                                            vErrors = [err10];
                                          } else {
                                            vErrors.push(err10);
                                          }
                                          errors2++;
                                        }
                                      }
                                    }
                                  }
                                  var valid3 = _errs19 === errors2;
                                } else {
                                  var valid3 = true;
                                }
                              }
                            }
                          }
                        }
                      } else {
                        const err11 = { instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err11];
                        } else {
                          vErrors.push(err11);
                        }
                        errors2++;
                      }
                    }
                    var _valid0 = _errs11 === errors2;
                    valid1 = valid1 || _valid0;
                    const _errs21 = errors2;
                    if (data4 !== null) {
                      const err12 = { instancePath: instancePath + "/context", schemaPath: "#/properties/context/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors2++;
                    }
                    var _valid0 = _errs21 === errors2;
                    valid1 = valid1 || _valid0;
                    if (!valid1) {
                      const err13 = { instancePath: instancePath + "/context", schemaPath: "#/properties/context/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err13];
                      } else {
                        vErrors.push(err13);
                      }
                      errors2++;
                      validate52.errors = vErrors;
                      return false;
                    } else {
                      errors2 = _errs10;
                      if (vErrors !== null) {
                        if (_errs10) {
                          vErrors.length = _errs10;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid0 = _errs9 === errors2;
                  } else {
                    var valid0 = true;
                  }
                  if (valid0) {
                    if (data.hasData !== void 0) {
                      const _errs23 = errors2;
                      if (typeof data.hasData !== "boolean") {
                        validate52.errors = [{ instancePath: instancePath + "/hasData", schemaPath: "#/properties/hasData/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                        return false;
                      }
                      var valid0 = _errs23 === errors2;
                    } else {
                      var valid0 = true;
                    }
                    if (valid0) {
                      if (data.eventCount !== void 0) {
                        let data9 = data.eventCount;
                        const _errs25 = errors2;
                        if (!(typeof data9 == "number" && (!(data9 % 1) && !isNaN(data9)) && isFinite(data9))) {
                          validate52.errors = [{ instancePath: instancePath + "/eventCount", schemaPath: "#/properties/eventCount/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                          return false;
                        }
                        if (errors2 === _errs25) {
                          if (typeof data9 == "number" && isFinite(data9)) {
                            if (data9 > 1e4 || isNaN(data9)) {
                              validate52.errors = [{ instancePath: instancePath + "/eventCount", schemaPath: "#/properties/eventCount/maximum", keyword: "maximum", params: { comparison: "<=", limit: 1e4 }, message: "must be <= 10000" }];
                              return false;
                            } else {
                              if (data9 < 0 || isNaN(data9)) {
                                validate52.errors = [{ instancePath: instancePath + "/eventCount", schemaPath: "#/properties/eventCount/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                return false;
                              }
                            }
                          }
                        }
                        var valid0 = _errs25 === errors2;
                      } else {
                        var valid0 = true;
                      }
                      if (valid0) {
                        if (data.sourceId !== void 0) {
                          let data10 = data.sourceId;
                          const _errs27 = errors2;
                          const _errs28 = errors2;
                          let valid4 = false;
                          const _errs29 = errors2;
                          if (errors2 === _errs29) {
                            if (typeof data10 === "string") {
                              if (func1(data10) > 128) {
                                const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                                if (vErrors === null) {
                                  vErrors = [err14];
                                } else {
                                  vErrors.push(err14);
                                }
                                errors2++;
                              } else {
                                if (func1(data10) < 1) {
                                  const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err15];
                                  } else {
                                    vErrors.push(err15);
                                  }
                                  errors2++;
                                } else {
                                  if (!pattern5.test(data10)) {
                                    const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                                    if (vErrors === null) {
                                      vErrors = [err16];
                                    } else {
                                      vErrors.push(err16);
                                    }
                                    errors2++;
                                  }
                                }
                              }
                            } else {
                              const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err17];
                              } else {
                                vErrors.push(err17);
                              }
                              errors2++;
                            }
                          }
                          var _valid1 = _errs29 === errors2;
                          valid4 = valid4 || _valid1;
                          const _errs31 = errors2;
                          if (data10 !== null) {
                            const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err18];
                            } else {
                              vErrors.push(err18);
                            }
                            errors2++;
                          }
                          var _valid1 = _errs31 === errors2;
                          valid4 = valid4 || _valid1;
                          if (!valid4) {
                            const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err19];
                            } else {
                              vErrors.push(err19);
                            }
                            errors2++;
                            validate52.errors = vErrors;
                            return false;
                          } else {
                            errors2 = _errs28;
                            if (vErrors !== null) {
                              if (_errs28) {
                                vErrors.length = _errs28;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid0 = _errs27 === errors2;
                        } else {
                          var valid0 = true;
                        }
                        if (valid0) {
                          if (data.status !== void 0) {
                            let data11 = data.status;
                            const _errs33 = errors2;
                            if (!(data11 === "loading" || data11 === "ok" || data11 === "stale" || data11 === "unconfigured" || data11 === "unavailable")) {
                              validate52.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema76.properties.status.enum }, message: "must be equal to one of the allowed values" }];
                              return false;
                            }
                            var valid0 = _errs33 === errors2;
                          } else {
                            var valid0 = true;
                          }
                          if (valid0) {
                            if (data.updatedAt !== void 0) {
                              let data12 = data.updatedAt;
                              const _errs34 = errors2;
                              const _errs35 = errors2;
                              let valid5 = false;
                              const _errs36 = errors2;
                              if (errors2 === _errs36) {
                                if (errors2 === _errs36) {
                                  if (typeof data12 === "string") {
                                    if (func1(data12) > 64) {
                                      const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err20];
                                      } else {
                                        vErrors.push(err20);
                                      }
                                      errors2++;
                                    } else {
                                      if (!formats0.validate(data12)) {
                                        const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                        if (vErrors === null) {
                                          vErrors = [err21];
                                        } else {
                                          vErrors.push(err21);
                                        }
                                        errors2++;
                                      }
                                    }
                                  } else {
                                    const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err22];
                                    } else {
                                      vErrors.push(err22);
                                    }
                                    errors2++;
                                  }
                                }
                              }
                              var _valid2 = _errs36 === errors2;
                              valid5 = valid5 || _valid2;
                              const _errs38 = errors2;
                              if (data12 !== null) {
                                const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err23];
                                } else {
                                  vErrors.push(err23);
                                }
                                errors2++;
                              }
                              var _valid2 = _errs38 === errors2;
                              valid5 = valid5 || _valid2;
                              if (!valid5) {
                                const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err24];
                                } else {
                                  vErrors.push(err24);
                                }
                                errors2++;
                                validate52.errors = vErrors;
                                return false;
                              } else {
                                errors2 = _errs35;
                                if (vErrors !== null) {
                                  if (_errs35) {
                                    vErrors.length = _errs35;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid0 = _errs34 === errors2;
                            } else {
                              var valid0 = true;
                            }
                            if (valid0) {
                              if (data.errorCode !== void 0) {
                                let data13 = data.errorCode;
                                const _errs40 = errors2;
                                const _errs41 = errors2;
                                let valid6 = false;
                                const _errs42 = errors2;
                                if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
                                  const err25 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema76.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                                  if (vErrors === null) {
                                    vErrors = [err25];
                                  } else {
                                    vErrors.push(err25);
                                  }
                                  errors2++;
                                }
                                var _valid3 = _errs42 === errors2;
                                valid6 = valid6 || _valid3;
                                const _errs43 = errors2;
                                if (data13 !== null) {
                                  const err26 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err26];
                                  } else {
                                    vErrors.push(err26);
                                  }
                                  errors2++;
                                }
                                var _valid3 = _errs43 === errors2;
                                valid6 = valid6 || _valid3;
                                if (!valid6) {
                                  const err27 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors2++;
                                  validate52.errors = vErrors;
                                  return false;
                                } else {
                                  errors2 = _errs41;
                                  if (vErrors !== null) {
                                    if (_errs41) {
                                      vErrors.length = _errs41;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid0 = _errs40 === errors2;
                              } else {
                                var valid0 = true;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate52.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate52.errors = vErrors;
  return errors2 === 0;
}
validate52.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };

// src/shared/validation.ts
var MAX_PAYLOAD_BYTES = 512 * 1024;
var ValidationError = class extends Error {
  constructor() {
    super("Invalid protocol payload");
    this.name = "ValidationError";
  }
};
function parse(input, validate) {
  if (new TextEncoder().encode(input).length > MAX_PAYLOAD_BYTES) throw new ValidationError();
  let value;
  try {
    value = JSON.parse(input);
  } catch {
    throw new ValidationError();
  }
  if (!validate(value)) throw new ValidationError();
  return value;
}
function parseSnapshot(input) {
  return parse(input, snapshot);
}
function parseSettings(input) {
  return parse(input, settings);
}
function parseLocationSearchResults(input) {
  return parse(input, locationSearchResults);
}
var providerValidators = { calendar, weather, system, network, media };
function parseProviderState(name, input) {
  if (!Object.hasOwn(providerValidators, name)) throw new ValidationError();
  return parse(input, providerValidators[name]);
}

// src/shared/providerStore.ts
var PROVIDERS = ["calendar", "weather", "system", "network", "media"];
var ProviderStore = class {
  states = {
    calendar: { status: "unconfigured", sourceId: null, updatedAt: null, data: null, errorCode: null },
    weather: { status: "unconfigured", sourceId: null, updatedAt: null, data: null, errorCode: null },
    system: { status: "unavailable", sourceId: null, updatedAt: null, data: null, errorCode: "SERVICE_UNAVAILABLE" },
    network: { status: "unavailable", sourceId: null, updatedAt: null, data: null, errorCode: "SERVICE_UNAVAILABLE" },
    media: { status: "unavailable", sourceId: null, updatedAt: null, data: null, errorCode: "SERVICE_UNAVAILABLE" }
  };
  revisions = /* @__PURE__ */ new Map();
  acceptSnapshot(snapshot2) {
    for (const name of PROVIDERS) this.applyChange(name, snapshot2.revisions[name], snapshot2[name]);
  }
  applyChange(name, revision, state) {
    if (!PROVIDERS.includes(name) || !Number.isInteger(revision) || revision < 0 || revision > 4294967295) throw new ValidationError();
    if (revision <= (this.revisions.get(name) ?? -1)) return false;
    this.states[name] = state;
    this.revisions.set(name, revision);
    return true;
  }
  markRefreshing(name) {
    const state = this.states[name];
    if (state.status !== "unconfigured") this.states[name] = { ...state, status: "loading", errorCode: null };
  }
  // Retain values for the disconnected UI; revision ownership never crosses owners.
  resetOwner() {
    this.revisions.clear();
  }
  get(name) {
    return this.states[name];
  }
};

// src/shared/dataClient.ts
var Cancellation = class {
  cancelled = false;
  listeners = /* @__PURE__ */ new Set();
  onCancel(callback) {
    if (this.cancelled) callback();
    else this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }
  cancel() {
    this.cancelled = true;
    for (const callback of this.listeners) callback();
    this.listeners.clear();
  }
};
var DataClient = class {
  constructor(wire, store, changed, connection) {
    this.wire = wire;
    this.store = store;
    this.changed = changed;
    this.connection = connection;
  }
  wire;
  store;
  changed;
  connection;
  desiredContext = null;
  appliedContext = null;
  contextPump = null;
  providers = [];
  resumePending = false;
  resumeRetries = /* @__PURE__ */ new Map();
  generation = 0;
  retryCancel = null;
  retryDelay = 1e3;
  owner = null;
  unwatch = null;
  unsignal = null;
  token = null;
  cancel = new Cancellation();
  setCalendarContext(context, day) {
    const json = JSON.stringify(context);
    this.desiredContext = { json, day, key: json + day };
    void this.syncContext().catch(() => {
    });
  }
  syncContext() {
    if (this.contextPump) return this.contextPump;
    if (!this.owner || !this.desiredContext || this.appliedContext?.key === this.desiredContext.key) return Promise.resolve();
    const owner = this.owner, generation = this.generation;
    const current = () => owner === this.owner && generation === this.generation;
    const pump = (async () => {
      while (current() && this.desiredContext && this.appliedContext?.key !== this.desiredContext.key) {
        const desired = this.desiredContext, previous = this.appliedContext;
        await this.wire.call(owner, "SetCalendarContext", [desired.json], this.cancel);
        if (!current()) return;
        if (previous && previous.day !== desired.day && this.token) {
          await this.wire.call(owner, "Refresh", ["calendar"], this.cancel).catch(() => {
          });
          if (!current()) return;
        }
        this.appliedContext = desired;
      }
    })();
    this.contextPump = pump;
    void pump.finally(() => {
      if (this.contextPump === pump) this.contextPump = null;
    }).catch(() => {
    });
    return pump;
  }
  refreshAfterResume() {
    this.resumePending = true;
    if (!this.owner || !this.token) return;
    this.resumePending = false;
    const owner = this.owner, generation = this.generation;
    const current = () => this.owner === owner && this.generation === generation;
    for (const name of this.providers.filter((p) => (p === "calendar" || p === "weather") && this.store.get(p).status !== "unconfigured")) {
      this.resumeRetries.get(name)?.();
      this.resumeRetries.delete(name);
      this.store.markRefreshing(name);
      this.changed(name);
      const source = this.store.get(name).sourceId;
      const relevant = () => current() && this.store.get(name).sourceId === source && this.store.get(name).status === "loading";
      const refresh = async () => {
        try {
          await this.wire.call(owner, "Refresh", [name], this.cancel);
        } catch {
          if (relevant()) this.resumeRetries.set(name, this.wire.schedule(6e4, () => {
            this.resumeRetries.delete(name);
            if (relevant()) void refresh();
          }));
        }
      };
      void refresh();
    }
  }
  start(providers) {
    this.stop();
    if (!providers.length || providers.some((p) => !PROVIDERS.includes(p))) throw new Error("Invalid providers");
    this.providers = [...new Set(providers)];
    this.unwatch = this.wire.watchOwner((owner) => {
      this.retryDelay = 1e3;
      void this.connect(owner, [...new Set(providers)]);
    });
  }
  release(owner, token) {
    void this.wire.call(owner, "Unsubscribe", [token], null).catch(() => {
    });
  }
  disconnect() {
    this.retryCancel?.();
    this.retryCancel = null;
    for (const cancel of this.resumeRetries.values()) cancel();
    this.resumeRetries.clear();
    this.appliedContext = null;
    this.contextPump = null;
    this.generation++;
    this.cancel.cancel();
    this.cancel = new Cancellation();
    this.unsignal?.();
    this.unsignal = null;
    if (this.owner && this.token) this.release(this.owner, this.token);
    this.token = null;
    this.owner = null;
    this.store.resetOwner();
  }
  stop() {
    this.resumePending = false;
    this.providers = [];
    this.retryDelay = 1e3;
    this.unwatch?.();
    this.unwatch = null;
    this.disconnect();
    this.connection("disconnected");
  }
  async connect(owner, providers) {
    if (owner && owner === this.owner) return;
    this.disconnect();
    this.owner = owner;
    if (!owner) {
      this.connection("disconnected");
      return;
    }
    const generation = this.generation;
    const current = () => generation === this.generation && owner === this.owner;
    this.connection("connecting");
    this.unsignal = this.wire.watchChanges(owner, (name, revision, payload) => {
      if (!current()) return;
      try {
        const provider = name;
        if (this.store.applyChange(provider, revision, parseProviderState(provider, payload))) {
          this.resumeRetries.get(provider)?.();
          this.resumeRetries.delete(provider);
          this.changed(provider);
        }
      } catch {
        this.connection("invalid-data");
      }
    });
    try {
      if (this.desiredContext) {
        await this.syncContext();
        if (!current()) return;
      }
      const [token] = await this.wire.call(owner, "Subscribe", [providers], null);
      if (typeof token !== "string" || !token || token.length > 128) throw new Error("Invalid subscription");
      if (!current()) {
        this.release(owner, token);
        return;
      }
      this.token = token;
      const [raw] = await this.wire.call(owner, "GetSnapshot", [], this.cancel);
      if (!current()) return;
      if (typeof raw !== "string") throw new Error("Invalid snapshot");
      this.store.acceptSnapshot(parseSnapshot(raw));
      this.retryDelay = 1e3;
      this.changed();
      this.connection("connected");
      if (this.resumePending) this.refreshAfterResume();
    } catch {
      if (current()) {
        this.disconnect();
        this.connection("unavailable");
        const retryGeneration = this.generation;
        const delay = this.retryDelay;
        this.retryDelay = Math.min(3e4, delay * 2);
        this.retryCancel = this.wire.schedule(delay, () => {
          this.retryCancel = null;
          if (this.generation === retryGeneration) void this.connect(owner, providers);
        });
      }
    }
  }
};

// src/prefs/weather.ts
function addWeatherSettings(window, page, ui, session) {
  const cancel = new Cancellation();
  let closed = false;
  onPreferencesClosed(window, () => {
    closed = true;
    cancel.cancel();
  });
  const group = ui.bind(new Adw2.PreferencesGroup(), { title: "\uB0A0\uC528 \uC9C0\uC5ED", description: "\uC120\uD0DD\uD55C \uB3C4\uC2DC\uC758 \uD604\uC7AC \uB0A0\uC528\uC640 \uC55E\uC73C\uB85C 6\uC2DC\uAC04 \uC608\uBCF4\uB97C \uD45C\uC2DC\uD569\uB2C8\uB2E4." });
  page.add(group);
  const current = ui.bind(new Adw2.ActionRow(), { title: "\uC120\uD0DD\uD55C \uC9C0\uC5ED", subtitle: "\uD655\uC778 \uC911\u2026" });
  group.add(current);
  const clear = ui.bind(new Gtk2.Button({ valign: Gtk2.Align.CENTER }), { label: "\uD574\uC81C" });
  current.add_suffix(clear);
  const entry = ui.bind(new Adw2.EntryRow(), { title: "\uB3C4\uC2DC \uC774\uB984" });
  const search = ui.bind(new Gtk2.Button({ valign: Gtk2.Align.CENTER }), { label: "\uAC80\uC0C9" });
  entry.add_suffix(search);
  group.add(entry);
  const message = ui.bind(new Gtk2.Label({ wrap: true, xalign: 0, margin_top: 8, margin_bottom: 8 }), { label: "\uB450 \uAE00\uC790 \uC774\uC0C1 \uC785\uB825\uD574 \uAC80\uC0C9\uD558\uC138\uC694." });
  group.add(message);
  const results = ui.bind(new Adw2.PreferencesGroup({ visible: false }), { title: "\uAC80\uC0C9 \uACB0\uACFC" });
  page.add(results);
  let rows = [];
  const empty = () => {
    for (const { row, button } of rows) {
      ui.unbind(button);
      results.remove(row);
    }
    rows = [];
    results.visible = false;
  };
  const load = async () => {
    try {
      const settings2 = await session.getSettings(cancel);
      if (closed) return;
      const location = settings2.weatherLocation;
      ui.bind(current, { subtitle: () => location?.label ?? ui.t("\uC9C0\uC5ED\uC744 \uC120\uD0DD\uD558\uC9C0 \uC54A\uC558\uC5B4\uC694.") });
    } catch {
      if (!closed) ui.bind(current, { subtitle: "\uC124\uC815\uC744 \uC77D\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694." });
    }
  };
  const choose = async (location) => {
    clear.sensitive = false;
    results.sensitive = false;
    ui.bind(message, { label: "\uC9C0\uC5ED\uC744 \uC800\uC7A5\uD558\uB294 \uC911\u2026" });
    try {
      await session.setWeatherLocation(location, cancel);
      if (!closed) {
        ui.bind(message, { label: location ? "\uC9C0\uC5ED\uC744 \uC120\uD0DD\uD588\uC5B4\uC694. \uB0A0\uC528 \uB3D9\uAE30\uD654\uB97C \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694." : "\uC9C0\uC5ED\uC744 \uD574\uC81C\uD588\uC5B4\uC694." });
        empty();
      }
    } catch {
      if (!closed) ui.bind(message, { label: "\uC9C0\uC5ED\uC744 \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694." });
    }
    if (!closed) {
      clear.sensitive = true;
      results.sensitive = true;
      await load();
    }
  };
  const find = async () => {
    const query = entry.text.trim();
    if ([...query].length < 2) {
      ui.bind(message, { label: "\uB450 \uAE00\uC790 \uC774\uC0C1 \uC785\uB825\uD574 \uC8FC\uC138\uC694." });
      return;
    }
    empty();
    search.sensitive = false;
    entry.sensitive = false;
    ui.bind(message, { label: "\uB3C4\uC2DC\uB97C \uCC3E\uB294 \uC911\u2026" });
    try {
      const locations = await session.searchLocations(query, cancel);
      if (closed) return;
      for (const location of locations) {
        const row = new Adw2.ActionRow({ title: location.label, subtitle: location.timeZone, title_lines: 2 });
        const button = ui.bind(new Gtk2.Button({ valign: Gtk2.Align.CENTER }), { label: "\uC120\uD0DD" });
        button.connect("clicked", () => {
          void choose(location);
        });
        row.add_suffix(button);
        row.activatable_widget = button;
        results.add(row);
        rows.push({ row, button });
      }
      results.visible = rows.length > 0;
      ui.bind(message, { label: rows.length ? "\uD45C\uC2DC\uD560 \uB3C4\uC2DC\uB97C \uC120\uD0DD\uD558\uC138\uC694." : "\uAC80\uC0C9 \uACB0\uACFC\uAC00 \uC5C6\uC5B4\uC694." });
    } catch {
      if (!closed) ui.bind(message, { label: "\uAC80\uC0C9\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uAE30\uC874 \uC120\uD0DD\uC740 \uC720\uC9C0\uB429\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694." });
    }
    if (!closed) {
      search.sensitive = true;
      entry.sensitive = true;
    }
  };
  search.connect("clicked", () => {
    void find();
  });
  entry.connect("entry-activated", () => {
    void find();
  });
  clear.connect("clicked", () => {
    void choose(null);
  });
  const source = ui.bind(new Adw2.PreferencesGroup(), { title: "\uB0A0\uC528 \uB370\uC774\uD130", description: "\uBB34\uB8CC API\uB294 \uAC1C\uC778 \uBE44\uC0C1\uC5C5\uC6A9\uC73C\uB85C \uC0AC\uC6A9\uD569\uB2C8\uB2E4. \uB370\uC774\uD130: CC BY 4.0." });
  page.add(source);
  const attribution = ui.bind(new Adw2.ActionRow(), { title: "\uCD9C\uCC98" });
  attribution.add_suffix(new Gtk2.LinkButton({ uri: "https://open-meteo.com/", label: "Open-Meteo", valign: Gtk2.Align.CENTER }));
  attribution.add_suffix(new Gtk2.LinkButton({ uri: "https://www.geonames.org/", label: "GeoNames", valign: Gtk2.Align.CENTER }));
  source.add(attribution);
  void load();
}

// src/prefs/calendar.ts
import Adw3 from "gi://Adw";
import Gtk3 from "gi://Gtk?version=4.0";

// src/shared/cardState.ts
var errors = { NETWORK_ERROR: "\uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694", INVALID_DATA: "\uB370\uC774\uD130\uB97C \uC77D\uC744 \uC218 \uC5C6\uC5B4\uC694", PAYLOAD_TOO_LARGE: "\uB370\uC774\uD130\uAC00 \uB108\uBB34 \uCEE4\uC694", EXPANSION_LIMIT: "\uC77C\uC815\uC774 \uB108\uBB34 \uB9CE\uC544\uC694", UNSUPPORTED_CALENDAR: "\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uC77C\uC815 \uD615\uC2DD", UNKNOWN_TIME_ZONE: "\uC2DC\uAC04\uB300\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694", KEYRING_LOCKED: "\uD0A4\uB9C1 \uC7A0\uAE08\uC744 \uD574\uC81C\uD574 \uC8FC\uC138\uC694", SECRET_DELETION_FAILED: "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C\uB97C \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694", AUTH_ERROR: "\uCE98\uB9B0\uB354 \uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694", RATE_LIMITED: "\uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4", NO_PLAYER: "\uC7AC\uC0DD \uC911\uC778 \uC74C\uC545 \uC5C6\uC74C", NO_INTERFACE: "\uB124\uD2B8\uC6CC\uD06C\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694", SERVICE_UNAVAILABLE: "\uB370\uC774\uD130\uB97C \uAE30\uB2E4\uB9AC\uB294 \uC911", INTERNAL_ERROR: "\uB2E4\uC2DC \uC5F0\uACB0\uD558\uB294 \uC911" };
function cardState(state, connected, language2 = "ko") {
  if (!connected) return { kind: state.data === null ? "disconnected" : "stale", data: state.data, updatedAt: state.updatedAt, message: translate(language2, state.data === null ? "\uB370\uC774\uD130 \uC11C\uBE44\uC2A4 \uC5F0\uACB0 \uB300\uAE30" : "\uC5F0\uACB0 \uB04A\uAE40 \xB7 \uB9C8\uC9C0\uB9C9 \uB370\uC774\uD130") };
  if (state.status === "unconfigured") return { kind: "unconfigured", data: null, updatedAt: null, message: translate(language2, "\uC124\uC815\uC774 \uD544\uC694\uD574\uC694") };
  if (state.status === "loading") return { kind: state.data === null ? "loading" : "stale", data: state.data, updatedAt: state.updatedAt, message: translate(language2, "\uC5C5\uB370\uC774\uD2B8 \uC911\u2026") };
  if (state.status === "ok" && state.data !== null) return { kind: "ready", data: state.data, updatedAt: state.updatedAt, message: "" };
  return { kind: state.data === null ? "unavailable" : "stale", data: state.data, updatedAt: state.updatedAt, message: translate(language2, errors[state.errorCode ?? ""] ?? "\uB370\uC774\uD130\uB97C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC5B4\uC694") };
}

// src/shared/calendarStatus.ts
function connectionStatus(settings2, state, connected, count, language2) {
  if (settings2.calendarSecretDeletionPending) return translate(language2, "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C\uAC00 \uB0A8\uC544 \uC788\uC5B4\uC694. \uD0A4\uB9C1\uC744 \uD574\uC81C\uD558\uACE0 \uB2E4\uC2DC \uC0AD\uC81C\uD574 \uC8FC\uC138\uC694.");
  if (!settings2.calendarEnabled) return translate(language2, "\uC5F0\uACB0\uD558\uC9C0 \uC54A\uC74C");
  if (!connected) return translate(language2, "\uC5F0\uACB0 \uC815\uBCF4 \uC800\uC7A5\uB428 \xB7 \uB370\uC774\uD130 \uC11C\uBE44\uC2A4 \uC5F0\uACB0 \uB300\uAE30");
  const view = cardState(state, true, language2);
  if (view.kind === "ready") return translate(language2, "\uB3D9\uAE30\uD654 \uC644\uB8CC \xB7 \uD45C\uC2DC \uBC94\uC704\uC758 \uC77C\uC815 {count}\uAC1C", { count });
  if (view.kind === "loading" || view.kind === "unconfigured") return translate(language2, "\uC77C\uC815\uC744 \uBD88\uB7EC\uC624\uB294 \uC911\u2026");
  if (state.status === "loading") return translate(language2, "\uC77C\uC815 \uAC31\uC2E0 \uC911 \xB7 \uB9C8\uC9C0\uB9C9 \uB3D9\uAE30\uD654 \uB370\uC774\uD130 \uD45C\uC2DC");
  return view.data !== null ? translate(language2, "{message} \xB7 \uB9C8\uC9C0\uB9C9 \uB3D9\uAE30\uD654 \uB370\uC774\uD130 \uD45C\uC2DC", { message: view.message }) : view.message;
}
function calendarSummaryStatus(settings2, summary, origin, language2 = "ko") {
  if (settings2.calendarSecretDeletionPending) return translate(language2, "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C\uAC00 \uB0A8\uC544 \uC788\uC5B4\uC694. \uD0A4\uB9C1\uC744 \uD574\uC81C\uD558\uACE0 \uB2E4\uC2DC \uC0AD\uC81C\uD574 \uC8FC\uC138\uC694.");
  if (!settings2.calendarEnabled) return translate(language2, "\uC5F0\uACB0\uD558\uC9C0 \uC54A\uC74C");
  if (!summary || origin === "unavailable") return translate(language2, "\uC5F0\uACB0 \uC815\uBCF4 \uC800\uC7A5\uB428 \xB7 \uC0C1\uD0DC \uD655\uC778 \uC911");
  const state = { ...summary, data: summary.hasData ? {} : null };
  if (origin !== "preview") return connectionStatus(settings2, state, true, summary.eventCount, language2);
  if (summary.status === "ok") return translate(language2, "\uC5F0\uACB0 \uD655\uC778 \uC644\uB8CC \xB7 \uC77C\uC815 {count}\uAC1C", { count: summary.eventCount });
  if (summary.status === "loading") return translate(language2, summary.hasData ? "\uC5F0\uACB0 \uD655\uC778 \uC911 \xB7 \uB9C8\uC9C0\uB9C9 \uB370\uC774\uD130 \uD45C\uC2DC" : "\uC5F0\uACB0\uC744 \uD655\uC778\uD558\uB294 \uC911\u2026");
  const view = cardState(state, true, language2);
  return summary.hasData ? translate(language2, "{message} \xB7 \uB9C8\uC9C0\uB9C9 \uD655\uC778 \uB370\uC774\uD130 \uD45C\uC2DC", { message: view.message }) : view.message;
}

// src/prefs/calendar.ts
function addCalendarSettings(window, page, ui, session) {
  const cancel = new Cancellation();
  let closed = false, loaded = null, loadFailed = false, summary = null, origin = "unavailable";
  const subtitle = () => loadFailed ? ui.t("\uC124\uC815\uC744 \uC77D\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.") : loaded ? calendarSummaryStatus(loaded, summary, origin, ui.language) : ui.t("\uD655\uC778 \uC911\u2026");
  const title = () => ui.t(origin === "preview" ? "\uC124\uC815\uCC3D \uC5F0\uACB0 \uD655\uC778" : "\uC704\uC82F \uB3D9\uAE30\uD654");
  const render = () => {
    if (!closed) ui.bind(status, { title, subtitle });
  };
  let stopWatch = () => {
  };
  onPreferencesClosed(window, () => {
    closed = true;
    cancel.cancel();
    stopWatch();
  });
  const group = ui.bind(new Adw3.PreferencesGroup(), { title: "Google Calendar", description: "\uC77D\uAE30 \uC804\uC6A9\uC73C\uB85C \uC5F0\uACB0\uD569\uB2C8\uB2E4. Google Calendar \uC124\uC815 \u2192 \uCE98\uB9B0\uB354 \uD1B5\uD569 \u2192 iCal \uD615\uC2DD\uC758 \uBE44\uACF5\uAC1C \uC8FC\uC18C\uB97C \uC785\uB825\uD558\uC138\uC694." });
  page.add(group);
  const status = ui.bind(new Adw3.ActionRow(), { title, subtitle });
  group.add(status);
  const entry = ui.bind(new Adw3.PasswordEntryRow(), { title: "\uBE44\uACF5\uAC1C iCal \uC8FC\uC18C" });
  group.add(entry);
  const controls = ui.bind(new Adw3.ActionRow(), { title: "\uCE98\uB9B0\uB354 \uC5F0\uACB0 \uAD00\uB9AC" });
  const connect = ui.bind(new Gtk3.Button({ valign: Gtk3.Align.CENTER, css_classes: ["suggested-action"] }), { label: "\uC5F0\uACB0" });
  const clear = ui.bind(new Gtk3.Button({ valign: Gtk3.Align.CENTER }), { label: "\uC5F0\uACB0 \uD574\uC81C" });
  controls.add_suffix(clear);
  controls.add_suffix(connect);
  group.add(controls);
  const notice = ui.bind(new Gtk3.Label({ wrap: true, xalign: 0, margin_top: 8, margin_bottom: 8 }), { label: "\uC8FC\uC18C\uB294 \uC800\uC7A5 \uD6C4 \uB2E4\uC2DC \uD45C\uC2DC\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4." });
  group.add(notice);
  const load = async () => {
    try {
      const settings2 = await session.getSettings(cancel);
      if (closed) return;
      loaded = settings2;
      loadFailed = false;
      render();
      ui.bind(clear, { label: loaded.calendarSecretDeletionPending ? "\uC5F0\uACB0 \uC815\uBCF4 \uC0AD\uC81C" : "\uC5F0\uACB0 \uD574\uC81C" });
    } catch {
      if (!closed) {
        loadFailed = true;
        render();
      }
    }
  };
  const act = async (method, args) => {
    connect.sensitive = false;
    clear.sensitive = false;
    entry.sensitive = false;
    ui.bind(notice, { label: "\uCC98\uB9AC \uC911\u2026" });
    try {
      if (method === "SetCalendarSecret") await session.setCalendarSecret(args[0], cancel);
      else await session.clearCalendarSecret(cancel);
      if (closed) return;
      ui.bind(notice, { label: method === "SetCalendarSecret" ? "\uC5F0\uACB0 \uC815\uBCF4\uB97C \uC800\uC7A5\uD588\uC5B4\uC694. \uB3D9\uAE30\uD654 \uACB0\uACFC\uB294 \uC704 \uC5F0\uACB0 \uC0C1\uD0DC\uC5D0 \uD45C\uC2DC\uB429\uB2C8\uB2E4." : "\uC77C\uC815\uACFC \uC5F0\uACB0 \uC815\uBCF4\uB97C \uC0AD\uC81C\uD588\uC5B4\uC694." });
    } catch {
      if (!closed) ui.bind(notice, { label: "\uCC98\uB9AC\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC8FC\uC18C \uD615\uC2DD\uACFC \uD0A4\uB9C1 \uC7A0\uAE08\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694." });
    }
    if (!closed) {
      connect.sensitive = true;
      clear.sensitive = true;
      entry.sensitive = true;
      await load();
    }
  };
  connect.connect("clicked", () => {
    const url = entry.text;
    entry.text = "";
    void act("SetCalendarSecret", [url]);
  });
  clear.connect("clicked", () => {
    entry.text = "";
    void act("ClearCalendarSecret", []);
  });
  let source;
  stopWatch = session.watchCalendar((state, nextOrigin) => {
    summary = state;
    origin = nextOrigin;
    if (source !== state.sourceId) {
      source = state.sourceId;
      void load();
    }
    render();
  });
  void load();
}

// src/prefs/placement.ts
import Adw4 from "gi://Adw";
import Gtk4 from "gi://Gtk?version=4.0";
import Gdk from "gi://Gdk?version=4.0";
import Gio2 from "gi://Gio";
function addDisplaySettings(window, page, settings2, ui) {
  const group = ui.bind(new Adw4.PreferencesGroup(), { title: "\uD654\uBA74\uACFC \uC704\uCE58", description: "\uC120\uD0DD\uD55C \uD654\uBA74\uC774 \uC5C6\uC73C\uBA74 \uC8FC \uBAA8\uB2C8\uD130\uC5D0 \uD45C\uC2DC\uD569\uB2C8\uB2E4. \uC5EC\uBC31\uC740 \uC791\uC5C5 \uC601\uC5ED\uC5D0 \uB9DE\uAC8C \uC81C\uD55C\uB429\uB2C8\uB2E4." });
  page.add(group);
  const monitor = ui.bind(new Adw4.ComboRow(), { title: "\uBAA8\uB2C8\uD130" });
  group.add(monitor);
  let ids = [], updating = false;
  const monitors = Gdk.Display.get_default()?.get_monitors();
  const refresh = () => {
    updating = true;
    ids = ["primary"];
    const labels2 = [ui.t("\uC8FC \uBAA8\uB2C8\uD130 (\uC790\uB3D9)")];
    if (monitors) for (let i = 0; i < monitors.get_n_items(); i++) {
      const item = monitors.get_item(i);
      const connector = item.get_connector();
      if (connector && !ids.includes(connector)) {
        ids.push(connector);
        labels2.push(`${connector} \xB7 ${item.get_model() ?? ui.t("\uBAA8\uB2C8\uD130")}`);
      }
    }
    const current = settings2.get_string("monitor");
    if (!ids.includes(current)) {
      ids.push(current);
      labels2.push(ui.t("{monitor} \xB7 \uC5F0\uACB0 \uC548 \uB428 (\uC8FC \uBAA8\uB2C8\uD130\uC5D0 \uD45C\uC2DC)", { monitor: current }));
    }
    monitor.model = Gtk4.StringList.new(labels2);
    monitor.selected = ids.indexOf(current);
    updating = false;
  };
  refresh();
  ui.onChange(refresh);
  monitor.connect("notify::selected", () => {
    const id = ids[monitor.selected];
    if (!updating && id) settings2.set_string("monitor", id);
  });
  const changed = monitors?.connect("items-changed", refresh);
  onPreferencesClosed(window, () => {
    if (changed) monitors?.disconnect(changed);
  });
  const anchors = ["top-right", "top-left"];
  let updatingAnchor = false;
  const anchor = ui.bind(new Adw4.ComboRow(), { title: "\uAE30\uC900 \uC704\uCE58" });
  const refreshAnchor = () => {
    updatingAnchor = true;
    anchor.model = Gtk4.StringList.new([ui.t("\uC624\uB978\uCABD \uC704"), ui.t("\uC67C\uCABD \uC704")]);
    anchor.selected = Math.max(0, anchors.indexOf(settings2.get_string("anchor")));
    updatingAnchor = false;
  };
  refreshAnchor();
  ui.onChange(refreshAnchor);
  anchor.connect("notify::selected", () => {
    const value = anchors[anchor.selected];
    if (!updatingAnchor && value) settings2.set_string("anchor", value);
  });
  group.add(anchor);
  for (const [key, title] of [["offset-x", "\uAC00\uB85C \uC5EC\uBC31"], ["offset-y", "\uC138\uB85C \uC5EC\uBC31"]]) {
    const row = ui.bind(new Adw4.SpinRow({ adjustment: new Gtk4.Adjustment({ lower: 0, upper: 1e3, step_increment: 1, page_increment: 10 }), digits: 0 }), { title, subtitle: "\uB17C\uB9AC \uD53D\uC140" });
    settings2.bind(key, row, "value", Gio2.SettingsBindFlags.DEFAULT);
    group.add(row);
  }
}
function addNetworkSettings(window, page, ui, session) {
  const cancel = new Cancellation();
  let closed = false;
  onPreferencesClosed(window, () => {
    closed = true;
    cancel.cancel();
  });
  const group = ui.bind(new Adw4.PreferencesGroup(), { title: "\uB124\uD2B8\uC6CC\uD06C", description: "\uC790\uB3D9\uC740 \uAE30\uBCF8 \uACBD\uB85C\uC758 \uBB3C\uB9AC \uC778\uD130\uD398\uC774\uC2A4 \uD558\uB098\uB97C \uC0AC\uC6A9\uD569\uB2C8\uB2E4. Tailscale \uD2B8\uB798\uD53D\uC740 tailscale0\uC744 \uC9C1\uC811 \uC120\uD0DD\uD558\uC138\uC694." });
  page.add(group);
  const row = ui.bind(new Adw4.ComboRow({ sensitive: false }), { title: "\uB124\uD2B8\uC6CC\uD06C \uC778\uD130\uD398\uC774\uC2A4" });
  group.add(row);
  const action = ui.bind(new Adw4.ActionRow(), { title: "\uC778\uD130\uD398\uC774\uC2A4 \uC801\uC6A9" });
  const save = ui.bind(new Gtk4.Button({ valign: Gtk4.Align.CENTER, sensitive: false }), { label: "\uC800\uC7A5" });
  action.add_suffix(save);
  group.add(action);
  const notice = ui.bind(new Gtk4.Label({ wrap: true, xalign: 0, margin_top: 8, margin_bottom: 8 }), { label: "\uD604\uC7AC \uC124\uC815\uC744 \uD655\uC778\uD558\uB294 \uC911\u2026" });
  group.add(notice);
  let values = [];
  const renderChoices = (value = values[row.selected]) => {
    row.model = Gtk4.StringList.new(values.map((id) => id === "auto" ? ui.t("\uC790\uB3D9 (\uAE30\uBCF8 \uACBD\uB85C)") : id));
    row.selected = Math.max(0, values.indexOf(value ?? "auto"));
  };
  ui.onChange(() => renderChoices());
  const load = async () => {
    try {
      const [settings2, names] = await Promise.all([session.getSettings(cancel), session.listNetworkInterfaces(cancel)]);
      if (closed) return;
      const value = settings2.networkInterface;
      values = ["auto", ...names];
      if (!values.includes(value)) values.push(value);
      renderChoices(value);
      row.sensitive = true;
      save.sensitive = true;
      ui.bind(notice, { label: () => ui.t("\uC0AC\uC6A9 \uC911: {value}", { value: value === "auto" ? ui.t("\uC790\uB3D9") : value }) });
    } catch {
      if (!closed) ui.bind(notice, { label: "\uC124\uC815\uC744 \uC77D\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694." });
    }
  };
  save.connect("clicked", () => {
    void (async () => {
      const value = values[row.selected];
      if (!value) return;
      row.sensitive = false;
      save.sensitive = false;
      ui.bind(notice, { label: "\uC800\uC7A5\uD558\uB294 \uC911\u2026" });
      try {
        await session.setNetworkInterface(value, cancel);
        if (!closed) ui.bind(notice, { label: "\uC800\uC7A5\uD588\uC5B4\uC694. \uC0C8 \uC778\uD130\uD398\uC774\uC2A4\uC758 \uCCAB \uC18D\uB3C4\uB97C \uCE21\uC815\uD569\uB2C8\uB2E4." });
      } catch {
        if (!closed) ui.bind(notice, { label: "\uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694." });
      }
      if (!closed) {
        row.sensitive = true;
        save.sensitive = true;
      }
    })();
  });
  void load();
}

// src/prefs/dataSession.ts
import GLib16 from "gi://GLib";

// src/data/runtime.ts
import GLib11 from "gi://GLib";
import Gio14 from "gi://Gio";

// src/calendar/statusBridge.ts
import Gio4 from "gi://Gio";
import GLib2 from "gi://GLib";

// src/data/errors.ts
var DataFailure = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "DataFailure";
  }
  code;
};
var DataCancelled = class extends Error {
  constructor() {
    super("CANCELLED");
  }
};

// src/shared/calendarSummary.ts
function parseCalendarSummary(raw) {
  if (raw.length > 16384 || new TextEncoder().encode(raw).length > 16384) throw new DataFailure("INVALID_DATA");
  let value;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new DataFailure("INVALID_DATA");
  }
  if (!calendarSummary(value)) throw new DataFailure("INVALID_DATA");
  const summary = value;
  if (!summary.hasData && summary.eventCount !== 0 || summary.hasData && !summary.context) throw new DataFailure("INVALID_DATA");
  try {
    parseProviderState("calendar", JSON.stringify({ status: summary.status, sourceId: summary.sourceId, updatedAt: summary.updatedAt, errorCode: summary.errorCode, data: summary.hasData ? { ...summary.context, events: [] } : null }));
  } catch {
    throw new DataFailure("INVALID_DATA");
  }
  return summary;
}
function summarizeCalendar(instanceId, revision, generation, state, context) {
  return parseCalendarSummary(JSON.stringify({ version: 1, instanceId, revision, sourceId: state.sourceId, generation, context: state.data ? { month: state.data.month, timeZone: state.data.timeZone, weekStart: state.data.weekStart } : context, status: state.status, updatedAt: state.updatedAt, errorCode: state.errorCode, hasData: state.data !== null, eventCount: state.data?.events.length ?? 0 }));
}

// src/data/async.ts
import Gio3 from "gi://Gio";
import GLib from "gi://GLib";
function checkIO(cancel) {
  if (cancel.is_cancelled()) throw new DataCancelled();
}
function gioAsync(start, finish) {
  return new Promise((resolve, reject) => start((_source, result) => {
    try {
      resolve(finish(result));
    } catch (error) {
      reject(error);
    }
  }));
}
async function bounded(cancel, ms, timeoutCode, fn) {
  if (cancel.cancelled) throw new DataCancelled();
  const io = new Gio3.Cancellable();
  let timer = 0, unlink = () => {
  };
  const stop = new Promise((_resolve, reject) => {
    unlink = cancel.onCancel(() => {
      io.cancel();
      reject(new DataCancelled());
    });
    timer = GLib.timeout_add(GLib.PRIORITY_DEFAULT, ms, () => {
      timer = 0;
      io.cancel();
      reject(new DataFailure(timeoutCode));
      return GLib.SOURCE_REMOVE;
    });
  });
  try {
    return await Promise.race([Promise.resolve().then(() => {
      checkIO(io);
      return fn(io);
    }), stop]);
  } finally {
    unlink();
    if (timer) GLib.source_remove(timer);
    io.cancel();
  }
}

// src/calendar/protocol.ts
var CONTROL_LIMIT = 16 * 1024;
var INPUT_LIMIT = 5 * 1024 * 1024;
var REPLY_LIMIT = 512 * 1024;

// src/calendar/workerClient.ts
import Gio7 from "gi://Gio";
import GLib5 from "gi://GLib";

// src/data/busLease.ts
import Gio5 from "gi://Gio";
import GLib3 from "gi://GLib";

// src/calendar/streams.ts
import "gi://Gio";
import GLib4 from "gi://GLib";
function readBytes(stream, size, cancel) {
  return new Promise((resolve, reject) => stream.read_bytes_async(size, GLib4.PRIORITY_DEFAULT, cancel, (source, result) => {
    try {
      resolve(source.read_bytes_finish(result).toArray().slice());
    } catch (e) {
      reject(e);
    }
  }));
}
function closeStream(stream) {
  return new Promise((resolve) => stream.close_async(GLib4.PRIORITY_DEFAULT, null, (source, result) => {
    try {
      source.close_finish(result);
    } catch {
    }
    resolve();
  }));
}

// src/data/providers/mediaArt.ts
var ART_MAX_BYTES = 8 * 1024 * 1024;

// src/data/mpris.ts
import Gio8 from "gi://Gio";
import GLib6 from "gi://GLib";

// src/data/artworkFiles.ts
import Gio10 from "gi://Gio";
import GLib8 from "gi://GLib";

// src/data/files.ts
import Gio9 from "gi://Gio";
import GLib7 from "gi://GLib";

// editions.json
var editions_default = {
  rust: {
    backend: "rust",
    uuid: "liquid-widgets@local",
    schemaId: "org.gnome.shell.extensions.liquid-widgets",
    schemaPath: "/org/gnome/shell/extensions/liquid-widgets/",
    dataDirectory: "liquid-widgets",
    secretApplication: "org.local.LiquidWidgets",
    output: "dist",
    homepage: "https://github.com/NyongCho/gnome-widget"
  },
  gjs: {
    backend: "gjs",
    uuid: "liquid-widgets@nyongcho.github.io",
    schemaId: "org.gnome.shell.extensions.liquid-widgets-public",
    schemaPath: "/org/gnome/shell/extensions/liquid-widgets-public/",
    dataDirectory: "liquid-widgets-public",
    secretApplication: "io.github.NyongCho.LiquidWidgets",
    output: "dist-gjs",
    homepage: "https://github.com/NyongCho/gnome-widget"
  }
};

// src/edition.ts
function getEdition(name) {
  if (name !== "rust" && name !== "gjs") throw new Error("Unknown edition");
  return editions_default[name];
}
var EDITION = typeof define_LIQUID_EDITION_default === "undefined" ? getEdition("rust") : define_LIQUID_EDITION_default;

// src/data/http.ts
import Soup from "gi://Soup?version=3.0";
import "gi://Gio";

// src/data/secrets.ts
import Gio12 from "gi://Gio";
import GLib9 from "gi://GLib";

// src/data/linux.ts
import Gio13 from "gi://Gio";
import GLib10 from "gi://GLib";
var GioLinuxFiles = class {
  constructor(root = "") {
    this.root = root;
    if (root && !GLib10.path_is_absolute(root)) throw new DataFailure("INVALID_DATA");
  }
  root;
  file(path) {
    if (!/^\/(?:proc|sys)\//.test(path) || path.split("/").includes("..") || path.includes("\0")) throw new DataFailure("INVALID_DATA");
    return Gio13.File.new_for_path(`${this.root}${path}`);
  }
  async use(cancel, fn) {
    try {
      return await bounded(cancel, 2e3, "SERVICE_UNAVAILABLE", fn);
    } catch (error) {
      if (error instanceof DataFailure || error instanceof DataCancelled) throw error;
      throw new DataFailure("SERVICE_UNAVAILABLE");
    }
  }
  readText(path, maxBytes, cancel) {
    return this.use(cancel, async (io) => {
      const file = this.file(path), attributes = "standard::type";
      const before = await gioAsync((cb) => file.query_info_async(attributes, Gio13.FileQueryInfoFlags.NONE, 0, io, cb), (r) => file.query_info_finish(r));
      if (before.get_file_type() !== Gio13.FileType.REGULAR) throw new DataFailure("INVALID_DATA");
      checkIO(io);
      const stream = await gioAsync((cb) => file.read_async(0, io, cb), (r) => file.read_finish(r));
      try {
        const opened = await gioAsync((cb) => stream.query_info_async(attributes, 0, io, cb), (r) => stream.query_info_finish(r));
        if (opened.get_file_type() !== Gio13.FileType.REGULAR) throw new DataFailure("INVALID_DATA");
        const chunks = [];
        let length = 0;
        for (; ; ) {
          const bytes = await readBytes(stream, Math.min(65536, maxBytes - length + 1), io);
          if (!bytes.length) break;
          length += bytes.length;
          if (length > maxBytes) throw new DataFailure("PAYLOAD_TOO_LARGE");
          chunks.push(bytes);
        }
        const result = new Uint8Array(length);
        let offset = 0;
        for (const bytes of chunks) {
          result.set(bytes, offset);
          offset += bytes.length;
        }
        try {
          return new TextDecoder("utf-8", { fatal: true }).decode(result);
        } catch {
          throw new DataFailure("INVALID_DATA");
        }
      } finally {
        await closeStream(stream);
      }
    });
  }
  listNames(path, maxEntries, cancel) {
    return this.use(cancel, async (io) => {
      const file = this.file(path), enumerator = await gioAsync((cb) => file.enumerate_children_async("standard::name", Gio13.FileQueryInfoFlags.NONE, 0, io, cb), (r) => file.enumerate_children_finish(r));
      try {
        const names = [];
        while (names.length < maxEntries) {
          const rows = await gioAsync((cb) => enumerator.next_files_async(Math.min(32, maxEntries - names.length), 0, io, cb), (r) => enumerator.next_files_finish(r));
          if (!rows.length) break;
          for (const row of rows) names.push(row.get_name());
        }
        return names.sort();
      } finally {
        await gioAsync((cb) => enumerator.close_async(0, null, cb), (r) => enumerator.close_finish(r)).catch(() => {
        });
      }
    });
  }
};

// src/data/providers/system.ts
var U64 = (1n << 64n) - 1n;
var SAFE = BigInt(Number.MAX_SAFE_INTEGER);

// src/data/providers/network.ts
function validName(name) {
  return /^[a-zA-Z0-9_.:-]{1,15}$/.test(name);
}
async function listNetworkInterfaces(files, cancel) {
  return (await files.listNames("/sys/class/net", 128, cancel)).filter(validName).sort();
}

// src/data/providers/weather.ts
var LIMITS = { maxBytes: 256 * 1024, timeoutMs: 15e3 };

// src/calendar/statusTransport.ts
import Gio15 from "gi://Gio";
import GLib12 from "gi://GLib";

// src/prefs/calendarPreview.ts
import GLib13 from "gi://GLib";

// src/prefs/rustDataSession.ts
import GLib15 from "gi://GLib";

// src/dbus.ts
import Gio16 from "gi://Gio";
import GLib14 from "gi://GLib";
var BUS_NAME = "org.local.LiquidWidgets";
var PATH = "/org/local/LiquidWidgets";
var IFACE = "org.local.LiquidWidgets1";
var signatures = { Subscribe: "(as)", Unsubscribe: "(s)", Refresh: "(s)", SetCalendarContext: "(s)", SetCalendarSecret: "(s)", SearchLocations: "(s)", SetWeatherLocation: "(s)", SetNetworkInterface: "(s)" };
var SessionTransport = class {
  constructor(bus = Gio16.DBus.session) {
    this.bus = bus;
  }
  bus;
  schedule(delay, callback) {
    const id = GLib14.timeout_add(GLib14.PRIORITY_DEFAULT, delay, () => {
      callback();
      return GLib14.SOURCE_REMOVE;
    });
    return () => {
      GLib14.source_remove(id);
    };
  }
  watchOwner(callback) {
    const id = Gio16.bus_watch_name_on_connection(
      this.bus,
      BUS_NAME,
      Gio16.BusNameWatcherFlags.NONE,
      (_bus, _name, owner) => callback(owner),
      () => callback(null)
    );
    return () => Gio16.bus_unwatch_name(id);
  }
  watchChanges(owner, callback) {
    const id = this.bus.signal_subscribe(
      owner,
      IFACE,
      "ProviderChanged",
      PATH,
      null,
      Gio16.DBusSignalFlags.NONE,
      (_bus, _sender, _path, _interface, _signal, parameters) => {
        const [name, revision, payload] = parameters.deep_unpack();
        callback(name, revision, payload);
      }
    );
    return () => this.bus.signal_unsubscribe(id);
  }
  call(owner, method, args, cancel) {
    const cancellable = new Gio16.Cancellable();
    const off = cancel?.onCancel(() => cancellable.cancel());
    return new Promise((resolve, reject) => {
      const signature = signatures[method];
      const parameters = signature ? new GLib14.Variant(signature, args) : null;
      this.bus.call(
        owner,
        PATH,
        IFACE,
        method,
        parameters,
        null,
        Gio16.DBusCallFlags.NO_AUTO_START,
        1e4,
        cancellable,
        (bus, result) => {
          off?.();
          try {
            resolve(bus.call_finish(result).deep_unpack());
          } catch {
            reject(new Error("Service call failed"));
          }
        }
      );
    });
  }
};

// src/prefs/rustDataSession.ts
var RustPreferencesSession = class {
  wire = new SessionTransport();
  store = new ProviderStore();
  client;
  dead = false;
  connected = false;
  listeners = /* @__PURE__ */ new Set();
  requests = /* @__PURE__ */ new Set();
  instance = GLib15.uuid_string_random();
  revision = 0;
  generation = 0;
  key = "";
  constructor() {
    this.client = new DataClient(this.wire, this.store, () => this.publish(), (state) => {
      if (state === "connecting") {
        this.instance = GLib15.uuid_string_random();
        this.revision = 0;
        this.generation = 0;
        this.key = "";
      }
      this.connected = state === "connected";
      this.publish();
    });
  }
  async use(caller, fn) {
    if (this.dead || caller.cancelled) throw new DataCancelled();
    const cancel = new Cancellation(), unlink = caller.onCancel(() => cancel.cancel());
    this.requests.add(cancel);
    try {
      const result = await fn(cancel);
      if (this.dead || cancel.cancelled) throw new DataCancelled();
      return result;
    } finally {
      unlink();
      this.requests.delete(cancel);
    }
  }
  call(method, args, cancel) {
    return this.use(cancel, (c) => this.wire.call(BUS_NAME, method, args, c));
  }
  async getSettings(cancel) {
    return parseSettings(String((await this.call("GetSettings", [], cancel))[0]));
  }
  async setCalendarSecret(url, cancel) {
    await this.call("SetCalendarSecret", [url], cancel);
  }
  async clearCalendarSecret(cancel) {
    await this.call("ClearCalendarSecret", [], cancel);
  }
  async searchLocations(query, cancel) {
    return parseLocationSearchResults(String((await this.call("SearchLocations", [query], cancel))[0]));
  }
  async setWeatherLocation(location, cancel) {
    await this.call("SetWeatherLocation", [JSON.stringify(location)], cancel);
  }
  async setNetworkInterface(name, cancel) {
    await this.call("SetNetworkInterface", [name], cancel);
  }
  listNetworkInterfaces(cancel) {
    return this.use(cancel, (c) => listNetworkInterfaces(new GioLinuxFiles(), c));
  }
  async refreshCalendar(cancel) {
    await this.call("Refresh", ["calendar"], cancel);
  }
  publish() {
    if (this.dead) return;
    const state = this.store.get("calendar"), context = state.data ? { month: state.data.month, timeZone: state.data.timeZone, weekStart: state.data.weekStart } : null, key = JSON.stringify([state.sourceId, context]);
    if (key !== this.key) {
      this.key = key;
      this.generation++;
    }
    const summary = summarizeCalendar(this.instance, ++this.revision, this.generation, state, context);
    for (const listener of this.listeners) listener(summary, this.connected ? "rust" : "unavailable");
  }
  watchCalendar(changed) {
    if (this.dead) return () => {
    };
    this.listeners.add(changed);
    if (this.listeners.size === 1) this.client.start(["calendar"]);
    this.publish();
    let active = true;
    return () => {
      if (!active) return;
      active = false;
      this.listeners.delete(changed);
      if (!this.listeners.size) this.client.stop();
    };
  }
  destroy() {
    if (this.dead) return;
    this.dead = true;
    for (const request of this.requests) request.cancel();
    this.requests.clear();
    this.listeners.clear();
    this.client.stop();
  }
};

// src/prefs/dataSession.ts
function createPreferencesDataSession(extensionPath) {
  return false ? new PublicPreferencesSession(extensionPath) : new RustPreferencesSession();
}

// src/prefs/cards.ts
import Adw5 from "gi://Adw";
import Gtk5 from "gi://Gtk?version=4.0";
import "gi://Gio";

// src/cardSettings.ts
import GLib17 from "gi://GLib";

// src/shared/cards.ts
var CARD_IDS = ["clock", "calendar", "weather", "agenda", "network", "system", "media"];
var DEFAULT_CARD_COLUMNS = { left: ["clock", "calendar", "agenda"], right: ["weather", "system", "network", "media"] };
var sides = ["left", "right"];
function normalizeCardColumns(columns) {
  const result = { left: [], right: [] }, known = new Set(CARD_IDS), seen = /* @__PURE__ */ new Set();
  for (const side of sides) for (const id of columns[side]) {
    if (known.has(id) && !seen.has(id)) {
      result[side].push(id);
      seen.add(id);
    }
  }
  for (const side of sides) for (const id of DEFAULT_CARD_COLUMNS[side]) if (!seen.has(id)) {
    result[side].push(id);
    seen.add(id);
  }
  return result;
}
function moveCard(columns, id, direction) {
  const result = normalizeCardColumns(columns), side = result.left.includes(id) ? "left" : "right";
  const from = result[side].indexOf(id), to = from + direction;
  if (to >= 0 && to < result[side].length) [result[side][from], result[side][to]] = [result[side][to], result[side][from]];
  return result;
}
function transferCard(columns, id, target) {
  const result = normalizeCardColumns(columns);
  if (result[target].includes(id)) return result;
  const origin = target === "left" ? "right" : "left";
  result[origin] = result[origin].filter((value) => value !== id);
  result[target].push(id);
  return result;
}

// src/cardSettings.ts
function saveCardColumns(settings2, columns) {
  const normalized = normalizeCardColumns(columns), next = [normalized.left, normalized.right];
  if (JSON.stringify(settings2.get_value("card-columns").deep_unpack()) !== JSON.stringify(next)) settings2.set_value("card-columns", new GLib17.Variant("aas", next));
}
function initializeCardColumns(settings2) {
  const raw = settings2.get_value("card-columns").deep_unpack();
  const columns = normalizeCardColumns({ left: raw[0] ?? [], right: raw[1] ?? [] });
  saveCardColumns(settings2, columns);
  return columns;
}

// src/prefs/cards.ts
var titles = { clock: "\uB0A0\uC9DC\uC640 \uC2DC\uACC4", calendar: "\uC6D4\uAC04 \uB2EC\uB825", weather: "\uB0A0\uC528", agenda: "\uB2E4\uAC00\uC624\uB294 \uC77C\uC815", network: "\uB124\uD2B8\uC6CC\uD06C", system: "CPU \xB7 \uBA54\uBAA8\uB9AC \xB7 \uC628\uB3C4", media: "\uC74C\uC545" };
function addCardSettings(window, page, settings2, ui) {
  let columns = initializeCardColumns(settings2), updating = false;
  const sides2 = ["left", "right"];
  const lists = {};
  const rows = /* @__PURE__ */ new Map(), ids = /* @__PURE__ */ new Map();
  const sideFor = (id) => columns.left.includes(id) ? "left" : "right";
  for (const side of sides2) {
    const group = ui.bind(new Adw5.PreferencesGroup(), { title: side === "left" ? "\uC67C\uCABD \uC5F4" : "\uC624\uB978\uCABD \uC5F4" });
    if (side === "left") ui.bind(group, { description: "\uAC01 \uC5F4 \uC548\uC5D0\uC11C \uC21C\uC11C\uB97C \uBC14\uAFB8\uAC70\uB098 \uBC18\uB300\uCABD \uC5F4\uB85C \uC62E\uAE38 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uC74C\uC545\uC740 \uC7AC\uC0DD \uC911\uC77C \uB54C\uB9CC \uD45C\uC2DC\uB429\uB2C8\uB2E4." });
    const list = new Gtk5.ListBox({ name: `card-columns-${side}`, selection_mode: Gtk5.SelectionMode.NONE, css_classes: ["boxed-list"] });
    list.set_sort_func((left, right) => columns[side].indexOf(ids.get(left)) - columns[side].indexOf(ids.get(right)));
    lists[side] = list;
    group.add(list);
    page.add(group);
  }
  for (const id of CARD_IDS) {
    const title = titles[id];
    const row = ui.bind(new Adw5.ActionRow({ name: `card-columns-${id}` }), { title });
    const toggle = ui.bind(new Gtk5.Switch({ name: `card-columns-${id}-toggle`, valign: Gtk5.Align.CENTER }), { tooltip_text: title });
    const up = ui.bind(new Gtk5.Button({ name: `card-columns-${id}-up`, icon_name: "go-up-symbolic", valign: Gtk5.Align.CENTER, css_classes: ["flat"] }), { tooltip_text: () => `${ui.t(title)} \xB7 ${ui.t("\uC704\uB85C \uC774\uB3D9")}` });
    const down = ui.bind(new Gtk5.Button({ name: `card-columns-${id}-down`, icon_name: "go-down-symbolic", valign: Gtk5.Align.CENTER, css_classes: ["flat"] }), { tooltip_text: () => `${ui.t(title)} \xB7 ${ui.t("\uC544\uB798\uB85C \uC774\uB3D9")}` });
    const transfer = new Gtk5.Button({ name: `card-columns-${id}-transfer`, valign: Gtk5.Align.CENTER, css_classes: ["flat"] });
    const updateLabels = () => {
      const side = sideFor(id);
      transfer.icon_name = side === "left" ? "go-next-symbolic" : "go-previous-symbolic";
      transfer.tooltip_text = `${ui.t(title)} \xB7 ${ui.t(side === "left" ? "\uC624\uB978\uCABD \uC5F4\uB85C \uC774\uB3D9" : "\uC67C\uCABD \uC5F4\uB85C \uC774\uB3D9")}`;
      toggle.update_property([Gtk5.AccessibleProperty.LABEL], [ui.t(title)]);
      up.update_property([Gtk5.AccessibleProperty.LABEL], [up.tooltip_text]);
      down.update_property([Gtk5.AccessibleProperty.LABEL], [down.tooltip_text]);
      transfer.update_property([Gtk5.AccessibleProperty.LABEL], [transfer.tooltip_text]);
    };
    updateLabels();
    ui.onChange(updateLabels);
    row.add_suffix(up);
    row.add_suffix(down);
    row.add_suffix(transfer);
    row.add_suffix(toggle);
    row.activatable_widget = toggle;
    rows.set(id, { row, toggle, up, down, transfer, updateLabels });
    ids.set(row, id);
    lists[sideFor(id)].append(row);
    up.connect("clicked", () => saveCardColumns(settings2, moveCard(columns, id, -1)));
    down.connect("clicked", () => saveCardColumns(settings2, moveCard(columns, id, 1)));
    transfer.connect("clicked", () => saveCardColumns(settings2, transferCard(columns, id, sideFor(id) === "left" ? "right" : "left")));
    toggle.connect("notify::active", () => {
      if (updating) return;
      const visible = settings2.get_strv("visible").filter((value) => value !== id);
      if (toggle.active) visible.push(id);
      settings2.set_strv("visible", visible);
    });
  }
  const refresh = () => {
    if (updating) return;
    updating = true;
    try {
      const focused = window.get_focus();
      let restoreFocus = null;
      for (const controls of rows.values()) {
        for (const control of [controls.up, controls.down, controls.transfer, controls.toggle]) {
          if (focused === control || focused?.is_ancestor(control)) restoreFocus = control;
        }
      }
      columns = initializeCardColumns(settings2);
      const visible = new Set(settings2.get_strv("visible"));
      for (const [id, { row, toggle, up, down, transfer, updateLabels }] of rows) {
        const side = sideFor(id), index = columns[side].indexOf(id), list = lists[side];
        const parent = row.get_parent();
        if (parent !== list) {
          if (parent instanceof Gtk5.ListBox) parent.remove(row);
          list.append(row);
        }
        toggle.active = visible.has(id);
        up.sensitive = index > 0;
        down.sensitive = index < columns[side].length - 1;
        updateLabels();
        if (restoreFocus === up && !up.sensitive) restoreFocus = down.sensitive ? down : transfer;
        else if (restoreFocus === down && !down.sensitive) restoreFocus = up.sensitive ? up : transfer;
      }
      for (const side of sides2) lists[side].invalidate_sort();
      restoreFocus?.grab_focus();
    } finally {
      updating = false;
    }
  };
  refresh();
  const columnsChanged = settings2.connect("changed::card-columns", refresh);
  const visibleChanged = settings2.connect("changed::visible", refresh);
  onPreferencesClosed(window, () => {
    settings2.disconnect(columnsChanged);
    settings2.disconnect(visibleChanged);
  });
}

// src/prefs/clock.ts
import Adw6 from "gi://Adw";
import Gtk6 from "gi://Gtk?version=4.0";
import "gi://Gio";
var styles = ["digital", "square", "classic", "minimal"];
var labels = ["\uD070 \uB514\uC9C0\uD138", "\uC0AC\uAC01 \uB208\uAE08", "\uD074\uB798\uC2DD \uC6D0\uD615", "\uBBF8\uB2C8\uBA40 \uC544\uB0A0\uB85C\uADF8"];
function addClockSettings(window, page, settings2, ui) {
  const group = ui.bind(new Adw6.PreferencesGroup(), { title: "\uC2DC\uACC4" });
  const row = ui.bind(new Adw6.ComboRow({ name: "clock-style" }), { title: "\uC2DC\uACC4 \uC2A4\uD0C0\uC77C", subtitle: "\uC120\uD0DD\uD55C \uC2A4\uD0C0\uC77C\uC774 \uBC14\uB85C \uC801\uC6A9\uB429\uB2C8\uB2E4." });
  let updating = false;
  const refresh = (translate2 = false) => {
    updating = true;
    try {
      if (translate2) row.model = Gtk6.StringList.new(labels.map((label) => ui.t(label)));
      row.selected = Math.max(0, styles.indexOf(settings2.get_string("clock-style")));
    } finally {
      updating = false;
    }
  };
  refresh(true);
  ui.onChange(() => refresh(true));
  const selectionChanged = row.connect("notify::selected", () => {
    const value = styles[row.selected];
    if (!updating && value && value !== settings2.get_string("clock-style")) settings2.set_string("clock-style", value);
  });
  const styleChanged = settings2.connect("changed::clock-style", () => refresh());
  onPreferencesClosed(window, () => {
    settings2.disconnect(styleChanged);
    row.disconnect(selectionChanged);
  });
  group.add(row);
  page.add(group);
}

// src/prefs/pages.ts
function fillSettingsWindow(window, settings2, extensionPath, session = createPreferencesDataSession(extensionPath)) {
  const ui = preferencesLanguage(window, settings2);
  onPreferencesClosed(window, () => session.destroy());
  window.set_default_size(600, 720);
  const page = ui.bind(new Adw7.PreferencesPage({ name: "widgets", icon_name: "preferences-desktop-display-symbolic" }), { title: "\uC704\uC82F" });
  addLanguageSettings(page, settings2, ui);
  addCardSettings(window, page, settings2, ui);
  addClockSettings(window, page, settings2, ui);
  const appearance = ui.bind(new Adw7.PreferencesGroup(), { title: "\uC720\uB9AC\uC640 \uD06C\uAE30", description: "\uC720\uB9AC \uB18D\uB3C4\uB97C \uB192\uC774\uBA74 \uBC30\uACBD\uC774 \uB354 \uCC28\uBD84\uD574\uC9D1\uB2C8\uB2E4. \uAE00\uC790 \uB300\uBE44\uB294 \uC790\uB3D9\uC73C\uB85C \uC720\uC9C0\uD569\uB2C8\uB2E4." });
  page.add(appearance);
  for (const [key, title, min, max, step] of [["scale", "\uC804\uCCB4 \uD06C\uAE30", 0.75, 1.5, 0.05], ["strength", "\uAD74\uC808 \uAC15\uB3C4", 0, 20, 1], ["opacity", "\uC720\uB9AC \uB18D\uB3C4", 0.05, 0.8, 0.05]]) {
    const row = ui.bind(new Adw7.SpinRow({ adjustment: new Gtk7.Adjustment({ lower: min, upper: max, step_increment: step, page_increment: step * 2 }), digits: 2 }), { title });
    settings2.bind(key, row, "value", Gio19.SettingsBindFlags.DEFAULT);
    appearance.add(row);
  }
  const low = ui.bind(new Adw7.SwitchRow(), { title: "\uC800\uC804\uB825 \uBAA8\uB4DC", subtitle: "\uAD74\uC808 \uB300\uC2E0 \uBC18\uD22C\uBA85 \uBC30\uACBD\uC744 \uC0AC\uC6A9\uD569\uB2C8\uB2E4." });
  settings2.bind("low-power", low, "active", Gio19.SettingsBindFlags.DEFAULT);
  appearance.add(low);
  addDisplaySettings(window, page, settings2, ui);
  const data = ui.bind(new Adw7.PreferencesPage({ name: "data", icon_name: "network-server-symbolic" }), { title: "\uB370\uC774\uD130" });
  addCalendarSettings(window, data, ui, session);
  addWeatherSettings(window, data, ui, session);
  addNetworkSettings(window, data, ui, session);
  window.add(page);
  window.add(data);
}

// src/prefs.ts
var Preferences = class extends ExtensionPreferences {
  async fillPreferencesWindow(window) {
    fillSettingsWindow(window, this.getSettings(), this.path);
  }
};
export {
  Preferences as default
};
