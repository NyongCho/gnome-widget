// generated/validators.js
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var require_formats = __commonJS({
  "node_modules/ajv-formats/dist/formats.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.formatNames = exports.fastFormats = exports.fullFormats = void 0;
    function fmtDef(validate, compare) {
      return { validate, compare };
    }
    exports.fullFormats = {
      // date: http://tools.ietf.org/html/rfc3339#section-5.6
      date: fmtDef(date, compareDate),
      // date-time: http://tools.ietf.org/html/rfc3339#section-5.6
      time: fmtDef(getTime(true), compareTime),
      "date-time": fmtDef(getDateTime(true), compareDateTime),
      "iso-time": fmtDef(getTime(), compareIsoTime),
      "iso-date-time": fmtDef(getDateTime(), compareIsoDateTime),
      // duration: https://tools.ietf.org/html/rfc3339#appendix-A
      duration: /^P(?!$)((\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+S)?)?|(\d+W)?)$/,
      uri,
      "uri-reference": /^(?:[a-z][a-z0-9+\-.]*:)?(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'"()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?(?:\?(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i,
      // uri-template: https://tools.ietf.org/html/rfc6570
      "uri-template": /^(?:(?:[^\x00-\x20"'<>%\\^`{|}]|%[0-9a-f]{2})|\{[+#./;?&=,!@|]?(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?(?:,(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?)*\})*$/i,
      // For the source: https://gist.github.com/dperini/729294
      // For test cases: https://mathiasbynens.be/demo/url-regex
      url: /^(?:https?|ftp):\/\/(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)(?:\.(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)*(?:\.(?:[a-z\u{00a1}-\u{ffff}]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/iu,
      email: /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i,
      hostname: /^(?=.{1,253}\.?$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[-0-9a-z]{0,61}[0-9a-z])?)*\.?$/i,
      // optimized https://www.safaribooksonline.com/library/view/regular-expressions-cookbook/9780596802837/ch07s16.html
      ipv4: /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/,
      ipv6: /^((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))$/i,
      regex,
      // uuid: http://tools.ietf.org/html/rfc4122
      uuid: /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i,
      // JSON-pointer: https://tools.ietf.org/html/rfc6901
      // uri fragment: https://tools.ietf.org/html/rfc3986#appendix-A
      "json-pointer": /^(?:\/(?:[^~/]|~0|~1)*)*$/,
      "json-pointer-uri-fragment": /^#(?:\/(?:[a-z0-9_\-.!$&'()*+,;:=@]|%[0-9a-f]{2}|~0|~1)*)*$/i,
      // relative JSON-pointer: http://tools.ietf.org/html/draft-luff-relative-json-pointer-00
      "relative-json-pointer": /^(?:0|[1-9][0-9]*)(?:#|(?:\/(?:[^~/]|~0|~1)*)*)$/,
      // the following formats are used by the openapi specification: https://spec.openapis.org/oas/v3.0.0#data-types
      // byte: https://github.com/miguelmota/is-base64
      byte,
      // signed 32 bit integer
      int32: { type: "number", validate: validateInt32 },
      // signed 64 bit integer
      int64: { type: "number", validate: validateInt64 },
      // C-type float
      float: { type: "number", validate: validateNumber },
      // C-type double
      double: { type: "number", validate: validateNumber },
      // hint to the UI to hide input strings
      password: true,
      // unchecked string payload
      binary: true
    };
    exports.fastFormats = {
      ...exports.fullFormats,
      date: fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\d$/, compareDate),
      time: fmtDef(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, compareTime),
      "date-time": fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\dt(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, compareDateTime),
      "iso-time": fmtDef(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, compareIsoTime),
      "iso-date-time": fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\d[t\s](?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, compareIsoDateTime),
      // uri: https://github.com/mafintosh/is-my-json-valid/blob/master/formats.js
      uri: /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/)?[^\s]*$/i,
      "uri-reference": /^(?:(?:[a-z][a-z0-9+\-.]*:)?\/?\/)?(?:[^\\\s#][^\s#]*)?(?:#[^\\\s]*)?$/i,
      // email (sources from jsen validator):
      // http://stackoverflow.com/questions/201323/using-a-regular-expression-to-validate-an-email-address#answer-8829363
      // http://www.w3.org/TR/html5/forms.html#valid-e-mail-address (search for 'wilful violation')
      email: /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i
    };
    exports.formatNames = Object.keys(exports.fullFormats);
    function isLeapYear(year) {
      return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    }
    var DATE = /^(\d\d\d\d)-(\d\d)-(\d\d)$/;
    var DAYS = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    function date(str) {
      const matches = DATE.exec(str);
      if (!matches)
        return false;
      const year = +matches[1];
      const month = +matches[2];
      const day = +matches[3];
      return month >= 1 && month <= 12 && day >= 1 && day <= (month === 2 && isLeapYear(year) ? 29 : DAYS[month]);
    }
    function compareDate(d1, d2) {
      if (!(d1 && d2))
        return void 0;
      if (d1 > d2)
        return 1;
      if (d1 < d2)
        return -1;
      return 0;
    }
    var TIME = /^(\d\d):(\d\d):(\d\d(?:\.\d+)?)(z|([+-])(\d\d)(?::?(\d\d))?)?$/i;
    function getTime(strictTimeZone) {
      return function time(str) {
        const matches = TIME.exec(str);
        if (!matches)
          return false;
        const hr = +matches[1];
        const min = +matches[2];
        const sec = +matches[3];
        const tz = matches[4];
        const tzSign = matches[5] === "-" ? -1 : 1;
        const tzH = +(matches[6] || 0);
        const tzM = +(matches[7] || 0);
        if (tzH > 23 || tzM > 59 || strictTimeZone && !tz)
          return false;
        if (hr <= 23 && min <= 59 && sec < 60)
          return true;
        const utcMin = min - tzM * tzSign;
        const utcHr = hr - tzH * tzSign - (utcMin < 0 ? 1 : 0);
        return (utcHr === 23 || utcHr === -1) && (utcMin === 59 || utcMin === -1) && sec < 61;
      };
    }
    function compareTime(s1, s2) {
      if (!(s1 && s2))
        return void 0;
      const t1 = (/* @__PURE__ */ new Date("2020-01-01T" + s1)).valueOf();
      const t2 = (/* @__PURE__ */ new Date("2020-01-01T" + s2)).valueOf();
      if (!(t1 && t2))
        return void 0;
      return t1 - t2;
    }
    function compareIsoTime(t1, t2) {
      if (!(t1 && t2))
        return void 0;
      const a1 = TIME.exec(t1);
      const a2 = TIME.exec(t2);
      if (!(a1 && a2))
        return void 0;
      t1 = a1[1] + a1[2] + a1[3];
      t2 = a2[1] + a2[2] + a2[3];
      if (t1 > t2)
        return 1;
      if (t1 < t2)
        return -1;
      return 0;
    }
    var DATE_TIME_SEPARATOR = /t|\s/i;
    function getDateTime(strictTimeZone) {
      const time = getTime(strictTimeZone);
      return function date_time(str) {
        const dateTime = str.split(DATE_TIME_SEPARATOR);
        return dateTime.length === 2 && date(dateTime[0]) && time(dateTime[1]);
      };
    }
    function compareDateTime(dt1, dt2) {
      if (!(dt1 && dt2))
        return void 0;
      const d1 = new Date(dt1).valueOf();
      const d2 = new Date(dt2).valueOf();
      if (!(d1 && d2))
        return void 0;
      return d1 - d2;
    }
    function compareIsoDateTime(dt1, dt2) {
      if (!(dt1 && dt2))
        return void 0;
      const [d1, t1] = dt1.split(DATE_TIME_SEPARATOR);
      const [d2, t2] = dt2.split(DATE_TIME_SEPARATOR);
      const res = compareDate(d1, d2);
      if (res === void 0)
        return void 0;
      return res || compareTime(t1, t2);
    }
    var NOT_URI_FRAGMENT = /\/|:/;
    var URI = /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)(?:\?(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
    function uri(str) {
      return NOT_URI_FRAGMENT.test(str) && URI.test(str);
    }
    var BYTE = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/gm;
    function byte(str) {
      BYTE.lastIndex = 0;
      return BYTE.test(str);
    }
    var MIN_INT32 = -(2 ** 31);
    var MAX_INT32 = 2 ** 31 - 1;
    function validateInt32(value) {
      return Number.isInteger(value) && value <= MAX_INT32 && value >= MIN_INT32;
    }
    function validateInt64(value) {
      return Number.isInteger(value);
    }
    function validateNumber() {
      return true;
    }
    var Z_ANCHOR = /[^\\]\\Z/;
    function regex(str) {
      if (Z_ANCHOR.test(str))
        return false;
      try {
        new RegExp(str);
        return true;
      } catch (e) {
        return false;
      }
    }
  }
});
var require_ucs2length = __commonJS({
  "node_modules/ajv/dist/runtime/ucs2length.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function ucs2length(str) {
      const len = str.length;
      let length = 0;
      let pos = 0;
      let value;
      while (pos < len) {
        length++;
        value = str.charCodeAt(pos++);
        if (value >= 55296 && value <= 56319 && pos < len) {
          value = str.charCodeAt(pos);
          if ((value & 64512) === 56320)
            pos++;
        }
      }
      return length;
    }
    exports.default = ucs2length;
    ucs2length.code = 'require("ajv/dist/runtime/ucs2length").default';
  }
});
var snapshot = validate20;
var formats0 = require_formats().fullFormats["date-time"];
var func1 = require_ucs2length().default;
var schema32 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/CalendarData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/CalendarData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
var pattern4 = new RegExp("^[0-9]{4}-(0[1-9]|1[0-2])$", "u");
var formats2 = require_formats().fullFormats.date;
function validate22(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate22.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.month === void 0 && (missing0 = "month") || data.timeZone === void 0 && (missing0 = "timeZone") || data.weekStart === void 0 && (missing0 = "weekStart") || data.events === void 0 && (missing0 = "events")) {
        validate22.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors;
        for (const key0 in data) {
          if (!(key0 === "month" || key0 === "timeZone" || key0 === "weekStart" || key0 === "events")) {
            validate22.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors) {
          if (data.month !== void 0) {
            let data0 = data.month;
            const _errs2 = errors;
            if (errors === _errs2) {
              if (typeof data0 === "string") {
                if (func1(data0) > 7) {
                  validate22.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                  return false;
                } else {
                  if (!pattern4.test(data0)) {
                    validate22.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                    return false;
                  }
                }
              } else {
                validate22.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
            var valid0 = _errs2 === errors;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.timeZone !== void 0) {
              let data1 = data.timeZone;
              const _errs4 = errors;
              if (errors === _errs4) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 255) {
                    validate22.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate22.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate22.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs4 === errors;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weekStart !== void 0) {
                let data2 = data.weekStart;
                const _errs6 = errors;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate22.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors === _errs6) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 6 || isNaN(data2)) {
                      validate22.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate22.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs6 === errors;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.events !== void 0) {
                  let data3 = data.events;
                  const _errs8 = errors;
                  if (errors === _errs8) {
                    if (Array.isArray(data3)) {
                      if (data3.length > 1e4) {
                        validate22.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/maxItems", keyword: "maxItems", params: { limit: 1e4 }, message: "must NOT have more than 10000 items" }];
                        return false;
                      } else {
                        var valid1 = true;
                        const len0 = data3.length;
                        for (let i0 = 0; i0 < len0; i0++) {
                          let data4 = data3[i0];
                          const _errs10 = errors;
                          const _errs11 = errors;
                          const _errs14 = errors;
                          let valid4 = true;
                          const _errs15 = errors;
                          if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                            if (data4.allDay !== void 0) {
                              if (true !== data4.allDay) {
                                const err0 = {};
                                if (vErrors === null) {
                                  vErrors = [err0];
                                } else {
                                  vErrors.push(err0);
                                }
                                errors++;
                              }
                            }
                          }
                          var _valid0 = _errs15 === errors;
                          errors = _errs14;
                          if (vErrors !== null) {
                            if (_errs14) {
                              vErrors.length = _errs14;
                            } else {
                              vErrors = null;
                            }
                          }
                          let ifClause0;
                          if (_valid0) {
                            const _errs17 = errors;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data6 = data4.start;
                                const _errs18 = errors;
                                if (errors === _errs18) {
                                  if (errors === _errs18) {
                                    if (typeof data6 === "string") {
                                      if (func1(data6) > 10) {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                        return false;
                                      } else {
                                        if (!formats2.validate(data6)) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid6 = _errs18 === errors;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.end !== void 0) {
                                  let data7 = data4.end;
                                  const _errs20 = errors;
                                  if (errors === _errs20) {
                                    if (errors === _errs20) {
                                      if (typeof data7 === "string") {
                                        if (func1(data7) > 10) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                          return false;
                                        } else {
                                          if (!formats2.validate(data7)) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid6 = _errs20 === errors;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                            var _valid0 = _errs17 === errors;
                            valid4 = _valid0;
                            if (valid4) {
                              var props0 = {};
                              props0.start = true;
                              props0.end = true;
                              props0.allDay = true;
                            }
                            ifClause0 = "then";
                          } else {
                            const _errs22 = errors;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data8 = data4.start;
                                const _errs23 = errors;
                                if (errors === _errs23) {
                                  if (errors === _errs23) {
                                    if (typeof data8 === "string") {
                                      if (func1(data8) > 64) {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                        return false;
                                      } else {
                                        if (!formats0.validate(data8)) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid7 = _errs23 === errors;
                              } else {
                                var valid7 = true;
                              }
                              if (valid7) {
                                if (data4.end !== void 0) {
                                  let data9 = data4.end;
                                  const _errs25 = errors;
                                  if (errors === _errs25) {
                                    if (errors === _errs25) {
                                      if (typeof data9 === "string") {
                                        if (func1(data9) > 64) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                          return false;
                                        } else {
                                          if (!formats0.validate(data9)) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid7 = _errs25 === errors;
                                } else {
                                  var valid7 = true;
                                }
                              }
                            }
                            var _valid0 = _errs22 === errors;
                            valid4 = _valid0;
                            if (valid4) {
                              if (props0 !== true) {
                                props0 = props0 || {};
                                props0.start = true;
                                props0.end = true;
                              }
                            }
                            ifClause0 = "else";
                          }
                          if (!valid4) {
                            const err1 = { instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/allOf/0/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
                            if (vErrors === null) {
                              vErrors = [err1];
                            } else {
                              vErrors.push(err1);
                            }
                            errors++;
                            validate22.errors = vErrors;
                            return false;
                          }
                          if (errors === _errs11) {
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              let missing1;
                              if (data4.uid === void 0 && (missing1 = "uid") || data4.occurrenceKey === void 0 && (missing1 = "occurrenceKey") || data4.title === void 0 && (missing1 = "title") || data4.start === void 0 && (missing1 = "start") || data4.end === void 0 && (missing1 = "end") || data4.allDay === void 0 && (missing1 = "allDay")) {
                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                return false;
                              } else {
                                const _errs27 = errors;
                                for (const key1 in data4) {
                                  if (!(key1 === "uid" || key1 === "occurrenceKey" || key1 === "title" || key1 === "start" || key1 === "end" || key1 === "allDay")) {
                                    validate22.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                    return false;
                                    break;
                                  }
                                }
                                if (_errs27 === errors) {
                                  if (data4.uid !== void 0) {
                                    let data10 = data4.uid;
                                    const _errs28 = errors;
                                    if (errors === _errs28) {
                                      if (typeof data10 === "string") {
                                        if (func1(data10) > 2048) {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/maxLength", keyword: "maxLength", params: { limit: 2048 }, message: "must NOT have more than 2048 characters" }];
                                          return false;
                                        } else {
                                          if (func1(data10) < 1) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                    var valid8 = _errs28 === errors;
                                  } else {
                                    var valid8 = true;
                                  }
                                  if (valid8) {
                                    if (data4.occurrenceKey !== void 0) {
                                      let data11 = data4.occurrenceKey;
                                      const _errs30 = errors;
                                      if (errors === _errs30) {
                                        if (typeof data11 === "string") {
                                          if (func1(data11) > 64) {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                            return false;
                                          } else {
                                            if (func1(data11) < 1) {
                                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                              return false;
                                            }
                                          }
                                        } else {
                                          validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                          return false;
                                        }
                                      }
                                      var valid8 = _errs30 === errors;
                                    } else {
                                      var valid8 = true;
                                    }
                                    if (valid8) {
                                      if (data4.title !== void 0) {
                                        let data12 = data4.title;
                                        const _errs32 = errors;
                                        if (errors === _errs32) {
                                          if (typeof data12 === "string") {
                                            if (func1(data12) > 4096) {
                                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                                              return false;
                                            }
                                          } else {
                                            validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                            return false;
                                          }
                                        }
                                        var valid8 = _errs32 === errors;
                                      } else {
                                        var valid8 = true;
                                      }
                                      if (valid8) {
                                        if (data4.start !== void 0) {
                                          let data13 = data4.start;
                                          const _errs34 = errors;
                                          if (errors === _errs34) {
                                            if (typeof data13 === "string") {
                                              if (func1(data13) > 64) {
                                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                return false;
                                              }
                                            } else {
                                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                              return false;
                                            }
                                          }
                                          var valid8 = _errs34 === errors;
                                        } else {
                                          var valid8 = true;
                                        }
                                        if (valid8) {
                                          if (data4.end !== void 0) {
                                            let data14 = data4.end;
                                            const _errs36 = errors;
                                            if (errors === _errs36) {
                                              if (typeof data14 === "string") {
                                                if (func1(data14) > 64) {
                                                  validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                }
                                              } else {
                                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                            var valid8 = _errs36 === errors;
                                          } else {
                                            var valid8 = true;
                                          }
                                          if (valid8) {
                                            if (data4.allDay !== void 0) {
                                              const _errs38 = errors;
                                              if (typeof data4.allDay !== "boolean") {
                                                validate22.errors = [{ instancePath: instancePath + "/events/" + i0 + "/allDay", schemaPath: "#/$defs/CalendarEvent/properties/allDay/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                                                return false;
                                              }
                                              var valid8 = _errs38 === errors;
                                            } else {
                                              var valid8 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            } else {
                              validate22.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                              return false;
                            }
                          }
                          var valid1 = _errs10 === errors;
                          if (!valid1) {
                            break;
                          }
                        }
                      }
                    } else {
                      validate22.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                      return false;
                    }
                  }
                  var valid0 = _errs8 === errors;
                } else {
                  var valid0 = true;
                }
              }
            }
          }
        }
      }
    } else {
      validate22.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate22.errors = vErrors;
  return errors === 0;
}
validate22.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var pattern5 = new RegExp("^[A-Za-z0-9_-]+$", "u");
function validate21(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate21.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors;
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        const _errs6 = errors;
        if (!validate22(data.data, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
          vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
          errors = vErrors.length;
        }
        var valid3 = _errs6 === errors;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data2 = data.updatedAt;
          const _errs7 = errors;
          if (errors === _errs7) {
            if (errors === _errs7) {
              if (typeof data2 === "string") {
                if (func1(data2) > 64) {
                  validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data2)) {
                    validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs7 === errors;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err1 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err1];
    } else {
      vErrors.push(err1);
    }
    errors++;
    validate21.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors;
  if (valid0) {
    const _errs9 = errors;
    const _errs10 = errors;
    let valid4 = true;
    const _errs11 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data3 = data.status;
        if (!(data3 === "unconfigured" || data3 === "unavailable")) {
          const err2 = {};
          if (vErrors === null) {
            vErrors = [err2];
          } else {
            vErrors.push(err2);
          }
          errors++;
        }
      }
    }
    var _valid1 = _errs11 === errors;
    errors = _errs10;
    if (vErrors !== null) {
      if (_errs10) {
        vErrors.length = _errs10;
      } else {
        vErrors = null;
      }
    }
    if (_valid1) {
      const _errs13 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs14 = errors;
          if (data.data !== null) {
            validate21.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid6 = _errs14 === errors;
        } else {
          var valid6 = true;
        }
        if (valid6) {
          if (data.updatedAt !== void 0) {
            const _errs16 = errors;
            if (data.updatedAt !== null) {
              validate21.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid6 = _errs16 === errors;
          } else {
            var valid6 = true;
          }
        }
      }
      var _valid1 = _errs13 === errors;
      valid4 = _valid1;
      if (valid4) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid4) {
      const err3 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors++;
      validate21.errors = vErrors;
      return false;
    }
    var valid0 = _errs9 === errors;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs18 = errors;
      const _errs19 = errors;
      let valid7 = true;
      const _errs20 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data6 = data.status;
          if (!(data6 === "ok" || data6 === "unconfigured" || data6 === "loading")) {
            const err4 = {};
            if (vErrors === null) {
              vErrors = [err4];
            } else {
              vErrors.push(err4);
            }
            errors++;
          }
        }
      }
      var _valid2 = _errs20 === errors;
      errors = _errs19;
      if (vErrors !== null) {
        if (_errs19) {
          vErrors.length = _errs19;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid2) {
        const _errs22 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate21.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid2 = _errs22 === errors;
        valid7 = _valid2;
        if (valid7) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs25 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data8 = data.errorCode;
            if (!(data8 === "NETWORK_ERROR" || data8 === "INVALID_DATA" || data8 === "PAYLOAD_TOO_LARGE" || data8 === "EXPANSION_LIMIT" || data8 === "UNSUPPORTED_CALENDAR" || data8 === "UNKNOWN_TIME_ZONE" || data8 === "KEYRING_LOCKED" || data8 === "SECRET_DELETION_FAILED" || data8 === "AUTH_ERROR" || data8 === "RATE_LIMITED" || data8 === "NO_PLAYER" || data8 === "NO_INTERFACE" || data8 === "SERVICE_UNAVAILABLE" || data8 === "INTERNAL_ERROR")) {
              validate21.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema32.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid2 = _errs25 === errors;
        valid7 = _valid2;
        if (valid7) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid7) {
        const err5 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err5];
        } else {
          vErrors.push(err5);
        }
        errors++;
        validate21.errors = vErrors;
        return false;
      }
      var valid0 = _errs18 === errors;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.status === void 0 && (missing0 = "status") || data.sourceId === void 0 && (missing0 = "sourceId") || data.updatedAt === void 0 && (missing0 = "updatedAt") || data.data === void 0 && (missing0 = "data") || data.errorCode === void 0 && (missing0 = "errorCode")) {
        validate21.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs27 = errors;
        for (const key0 in data) {
          if (!(key0 === "status" || key0 === "sourceId" || key0 === "updatedAt" || key0 === "data" || key0 === "errorCode")) {
            validate21.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs27 === errors) {
          if (data.status !== void 0) {
            let data9 = data.status;
            const _errs28 = errors;
            if (!(data9 === "loading" || data9 === "ok" || data9 === "stale" || data9 === "unconfigured" || data9 === "unavailable")) {
              validate21.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema32.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid11 = _errs28 === errors;
          } else {
            var valid11 = true;
          }
          if (valid11) {
            if (data.sourceId !== void 0) {
              let data10 = data.sourceId;
              const _errs29 = errors;
              const _errs30 = errors;
              let valid12 = false;
              const _errs31 = errors;
              if (errors === _errs31) {
                if (typeof data10 === "string") {
                  if (func1(data10) > 128) {
                    const err6 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err6];
                    } else {
                      vErrors.push(err6);
                    }
                    errors++;
                  } else {
                    if (func1(data10) < 1) {
                      const err7 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err7];
                      } else {
                        vErrors.push(err7);
                      }
                      errors++;
                    } else {
                      if (!pattern5.test(data10)) {
                        const err8 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors++;
                      }
                    }
                  }
                } else {
                  const err9 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err9];
                  } else {
                    vErrors.push(err9);
                  }
                  errors++;
                }
              }
              var _valid3 = _errs31 === errors;
              valid12 = valid12 || _valid3;
              const _errs33 = errors;
              if (data10 !== null) {
                const err10 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err10];
                } else {
                  vErrors.push(err10);
                }
                errors++;
              }
              var _valid3 = _errs33 === errors;
              valid12 = valid12 || _valid3;
              if (!valid12) {
                const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err11];
                } else {
                  vErrors.push(err11);
                }
                errors++;
                validate21.errors = vErrors;
                return false;
              } else {
                errors = _errs30;
                if (vErrors !== null) {
                  if (_errs30) {
                    vErrors.length = _errs30;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid11 = _errs29 === errors;
            } else {
              var valid11 = true;
            }
            if (valid11) {
              if (data.updatedAt !== void 0) {
                let data11 = data.updatedAt;
                const _errs35 = errors;
                const _errs36 = errors;
                let valid13 = false;
                const _errs37 = errors;
                if (errors === _errs37) {
                  if (errors === _errs37) {
                    if (typeof data11 === "string") {
                      if (func1(data11) > 64) {
                        const err12 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err12];
                        } else {
                          vErrors.push(err12);
                        }
                        errors++;
                      } else {
                        if (!formats0.validate(data11)) {
                          const err13 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err13];
                          } else {
                            vErrors.push(err13);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err14 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err14];
                      } else {
                        vErrors.push(err14);
                      }
                      errors++;
                    }
                  }
                }
                var _valid4 = _errs37 === errors;
                valid13 = valid13 || _valid4;
                const _errs39 = errors;
                if (data11 !== null) {
                  const err15 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err15];
                  } else {
                    vErrors.push(err15);
                  }
                  errors++;
                }
                var _valid4 = _errs39 === errors;
                valid13 = valid13 || _valid4;
                if (!valid13) {
                  const err16 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err16];
                  } else {
                    vErrors.push(err16);
                  }
                  errors++;
                  validate21.errors = vErrors;
                  return false;
                } else {
                  errors = _errs36;
                  if (vErrors !== null) {
                    if (_errs36) {
                      vErrors.length = _errs36;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid11 = _errs35 === errors;
              } else {
                var valid11 = true;
              }
              if (valid11) {
                if (data.data !== void 0) {
                  let data12 = data.data;
                  const _errs41 = errors;
                  const _errs42 = errors;
                  let valid14 = false;
                  const _errs43 = errors;
                  if (!validate22(data12, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
                    vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
                    errors = vErrors.length;
                  }
                  var _valid5 = _errs43 === errors;
                  valid14 = valid14 || _valid5;
                  const _errs44 = errors;
                  if (data12 !== null) {
                    const err17 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors++;
                  }
                  var _valid5 = _errs44 === errors;
                  valid14 = valid14 || _valid5;
                  if (!valid14) {
                    const err18 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err18];
                    } else {
                      vErrors.push(err18);
                    }
                    errors++;
                    validate21.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs42;
                    if (vErrors !== null) {
                      if (_errs42) {
                        vErrors.length = _errs42;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid11 = _errs41 === errors;
                } else {
                  var valid11 = true;
                }
                if (valid11) {
                  if (data.errorCode !== void 0) {
                    let data13 = data.errorCode;
                    const _errs46 = errors;
                    const _errs47 = errors;
                    let valid15 = false;
                    const _errs48 = errors;
                    if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
                      const err19 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema32.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors++;
                    }
                    var _valid6 = _errs48 === errors;
                    valid15 = valid15 || _valid6;
                    const _errs49 = errors;
                    if (data13 !== null) {
                      const err20 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err20];
                      } else {
                        vErrors.push(err20);
                      }
                      errors++;
                    }
                    var _valid6 = _errs49 === errors;
                    valid15 = valid15 || _valid6;
                    if (!valid15) {
                      const err21 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err21];
                      } else {
                        vErrors.push(err21);
                      }
                      errors++;
                      validate21.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs47;
                      if (vErrors !== null) {
                        if (_errs47) {
                          vErrors.length = _errs47;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid11 = _errs46 === errors;
                  } else {
                    var valid11 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate21.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate21.errors = vErrors;
  return errors === 0;
}
validate21.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema35 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/WeatherData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/WeatherData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
var pattern6 = new RegExp("^https://", "u");
function validate26(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate26.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors;
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors;
        const _errs7 = errors;
        if (errors === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.location === void 0 && (missing0 = "location") || data1.timeZone === void 0 && (missing0 = "timeZone") || data1.current === void 0 && (missing0 = "current") || data1.hourly === void 0 && (missing0 = "hourly") || data1.attributionUrl === void 0 && (missing0 = "attributionUrl")) {
              validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors;
              for (const key0 in data1) {
                if (!(key0 === "location" || key0 === "timeZone" || key0 === "current" || key0 === "hourly" || key0 === "attributionUrl")) {
                  validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors) {
                if (data1.location !== void 0) {
                  let data2 = data1.location;
                  const _errs10 = errors;
                  if (errors === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 512) {
                        validate26.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                        return false;
                      }
                    } else {
                      validate26.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.timeZone !== void 0) {
                    let data3 = data1.timeZone;
                    const _errs12 = errors;
                    if (errors === _errs12) {
                      if (typeof data3 === "string") {
                        if (func1(data3) > 255) {
                          validate26.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                          return false;
                        } else {
                          if (func1(data3) < 1) {
                            validate26.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          }
                        }
                      } else {
                        validate26.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid5 = _errs12 === errors;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.current !== void 0) {
                      let data4 = data1.current;
                      const _errs14 = errors;
                      if (errors === _errs14) {
                        if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                          let missing1;
                          if (data4.temperatureC === void 0 && (missing1 = "temperatureC") || data4.code === void 0 && (missing1 = "code")) {
                            validate26.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                            return false;
                          } else {
                            const _errs16 = errors;
                            for (const key1 in data4) {
                              if (!(key1 === "temperatureC" || key1 === "code")) {
                                validate26.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                return false;
                                break;
                              }
                            }
                            if (_errs16 === errors) {
                              if (data4.temperatureC !== void 0) {
                                let data5 = data4.temperatureC;
                                const _errs17 = errors;
                                const _errs18 = errors;
                                let valid7 = false;
                                const _errs19 = errors;
                                if (!(typeof data5 == "number" && isFinite(data5))) {
                                  const err1 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err1];
                                  } else {
                                    vErrors.push(err1);
                                  }
                                  errors++;
                                }
                                var _valid1 = _errs19 === errors;
                                valid7 = valid7 || _valid1;
                                const _errs21 = errors;
                                if (data5 !== null) {
                                  const err2 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors++;
                                }
                                var _valid1 = _errs21 === errors;
                                valid7 = valid7 || _valid1;
                                if (!valid7) {
                                  const err3 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err3];
                                  } else {
                                    vErrors.push(err3);
                                  }
                                  errors++;
                                  validate26.errors = vErrors;
                                  return false;
                                } else {
                                  errors = _errs18;
                                  if (vErrors !== null) {
                                    if (_errs18) {
                                      vErrors.length = _errs18;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid6 = _errs17 === errors;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.code !== void 0) {
                                  let data6 = data4.code;
                                  const _errs23 = errors;
                                  const _errs24 = errors;
                                  let valid8 = false;
                                  const _errs25 = errors;
                                  if (!(typeof data6 == "number" && (!(data6 % 1) && !isNaN(data6)) && isFinite(data6))) {
                                    const err4 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err4];
                                    } else {
                                      vErrors.push(err4);
                                    }
                                    errors++;
                                  }
                                  if (errors === _errs25) {
                                    if (typeof data6 == "number" && isFinite(data6)) {
                                      if (data6 > 99 || isNaN(data6)) {
                                        const err5 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                        if (vErrors === null) {
                                          vErrors = [err5];
                                        } else {
                                          vErrors.push(err5);
                                        }
                                        errors++;
                                      } else {
                                        if (data6 < 0 || isNaN(data6)) {
                                          const err6 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                          if (vErrors === null) {
                                            vErrors = [err6];
                                          } else {
                                            vErrors.push(err6);
                                          }
                                          errors++;
                                        }
                                      }
                                    }
                                  }
                                  var _valid2 = _errs25 === errors;
                                  valid8 = valid8 || _valid2;
                                  const _errs27 = errors;
                                  if (data6 !== null) {
                                    const err7 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err7];
                                    } else {
                                      vErrors.push(err7);
                                    }
                                    errors++;
                                  }
                                  var _valid2 = _errs27 === errors;
                                  valid8 = valid8 || _valid2;
                                  if (!valid8) {
                                    const err8 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors++;
                                    validate26.errors = vErrors;
                                    return false;
                                  } else {
                                    errors = _errs24;
                                    if (vErrors !== null) {
                                      if (_errs24) {
                                        vErrors.length = _errs24;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid6 = _errs23 === errors;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                          }
                        } else {
                          validate26.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                          return false;
                        }
                      }
                      var valid5 = _errs14 === errors;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.hourly !== void 0) {
                        let data7 = data1.hourly;
                        const _errs29 = errors;
                        if (errors === _errs29) {
                          if (Array.isArray(data7)) {
                            if (data7.length > 6) {
                              validate26.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" }];
                              return false;
                            } else {
                              var valid9 = true;
                              const len0 = data7.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data8 = data7[i0];
                                const _errs31 = errors;
                                if (errors === _errs31) {
                                  if (data8 && typeof data8 == "object" && !Array.isArray(data8)) {
                                    let missing2;
                                    if (data8.at === void 0 && (missing2 = "at") || data8.temperatureC === void 0 && (missing2 = "temperatureC") || data8.precipitationProbability === void 0 && (missing2 = "precipitationProbability")) {
                                      validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
                                      return false;
                                    } else {
                                      const _errs33 = errors;
                                      for (const key2 in data8) {
                                        if (!(key2 === "at" || key2 === "temperatureC" || key2 === "precipitationProbability")) {
                                          validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs33 === errors) {
                                        if (data8.at !== void 0) {
                                          let data9 = data8.at;
                                          const _errs34 = errors;
                                          if (errors === _errs34) {
                                            if (errors === _errs34) {
                                              if (typeof data9 === "string") {
                                                if (func1(data9) > 64) {
                                                  validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data9)) {
                                                    validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid10 = _errs34 === errors;
                                        } else {
                                          var valid10 = true;
                                        }
                                        if (valid10) {
                                          if (data8.temperatureC !== void 0) {
                                            let data10 = data8.temperatureC;
                                            const _errs36 = errors;
                                            const _errs37 = errors;
                                            let valid11 = false;
                                            const _errs38 = errors;
                                            if (!(typeof data10 == "number" && isFinite(data10))) {
                                              const err9 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                              if (vErrors === null) {
                                                vErrors = [err9];
                                              } else {
                                                vErrors.push(err9);
                                              }
                                              errors++;
                                            }
                                            var _valid3 = _errs38 === errors;
                                            valid11 = valid11 || _valid3;
                                            const _errs40 = errors;
                                            if (data10 !== null) {
                                              const err10 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err10];
                                              } else {
                                                vErrors.push(err10);
                                              }
                                              errors++;
                                            }
                                            var _valid3 = _errs40 === errors;
                                            valid11 = valid11 || _valid3;
                                            if (!valid11) {
                                              const err11 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err11];
                                              } else {
                                                vErrors.push(err11);
                                              }
                                              errors++;
                                              validate26.errors = vErrors;
                                              return false;
                                            } else {
                                              errors = _errs37;
                                              if (vErrors !== null) {
                                                if (_errs37) {
                                                  vErrors.length = _errs37;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid10 = _errs36 === errors;
                                          } else {
                                            var valid10 = true;
                                          }
                                          if (valid10) {
                                            if (data8.precipitationProbability !== void 0) {
                                              let data11 = data8.precipitationProbability;
                                              const _errs42 = errors;
                                              const _errs43 = errors;
                                              let valid12 = false;
                                              const _errs44 = errors;
                                              if (errors === _errs44) {
                                                if (typeof data11 == "number" && isFinite(data11)) {
                                                  if (data11 > 100 || isNaN(data11)) {
                                                    const err12 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                    if (vErrors === null) {
                                                      vErrors = [err12];
                                                    } else {
                                                      vErrors.push(err12);
                                                    }
                                                    errors++;
                                                  } else {
                                                    if (data11 < 0 || isNaN(data11)) {
                                                      const err13 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                      if (vErrors === null) {
                                                        vErrors = [err13];
                                                      } else {
                                                        vErrors.push(err13);
                                                      }
                                                      errors++;
                                                    }
                                                  }
                                                } else {
                                                  const err14 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                  if (vErrors === null) {
                                                    vErrors = [err14];
                                                  } else {
                                                    vErrors.push(err14);
                                                  }
                                                  errors++;
                                                }
                                              }
                                              var _valid4 = _errs44 === errors;
                                              valid12 = valid12 || _valid4;
                                              const _errs46 = errors;
                                              if (data11 !== null) {
                                                const err15 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                if (vErrors === null) {
                                                  vErrors = [err15];
                                                } else {
                                                  vErrors.push(err15);
                                                }
                                                errors++;
                                              }
                                              var _valid4 = _errs46 === errors;
                                              valid12 = valid12 || _valid4;
                                              if (!valid12) {
                                                const err16 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                if (vErrors === null) {
                                                  vErrors = [err16];
                                                } else {
                                                  vErrors.push(err16);
                                                }
                                                errors++;
                                                validate26.errors = vErrors;
                                                return false;
                                              } else {
                                                errors = _errs43;
                                                if (vErrors !== null) {
                                                  if (_errs43) {
                                                    vErrors.length = _errs43;
                                                  } else {
                                                    vErrors = null;
                                                  }
                                                }
                                              }
                                              var valid10 = _errs42 === errors;
                                            } else {
                                              var valid10 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate26.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid9 = _errs31 === errors;
                                if (!valid9) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate26.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs29 === errors;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.attributionUrl !== void 0) {
                          let data12 = data1.attributionUrl;
                          const _errs48 = errors;
                          if (errors === _errs48) {
                            if (typeof data12 === "string") {
                              if (func1(data12) > 512) {
                                validate26.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                                return false;
                              } else {
                                if (!pattern6.test(data12)) {
                                  validate26.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' }];
                                  return false;
                                }
                              }
                            } else {
                              validate26.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                              return false;
                            }
                          }
                          var valid5 = _errs48 === errors;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data13 = data.updatedAt;
          const _errs50 = errors;
          if (errors === _errs50) {
            if (errors === _errs50) {
              if (typeof data13 === "string") {
                if (func1(data13) > 64) {
                  validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data13)) {
                    validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs50 === errors;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err17 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err17];
    } else {
      vErrors.push(err17);
    }
    errors++;
    validate26.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors;
  if (valid0) {
    const _errs52 = errors;
    const _errs53 = errors;
    let valid13 = true;
    const _errs54 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data14 = data.status;
        if (!(data14 === "unconfigured" || data14 === "unavailable")) {
          const err18 = {};
          if (vErrors === null) {
            vErrors = [err18];
          } else {
            vErrors.push(err18);
          }
          errors++;
        }
      }
    }
    var _valid5 = _errs54 === errors;
    errors = _errs53;
    if (vErrors !== null) {
      if (_errs53) {
        vErrors.length = _errs53;
      } else {
        vErrors = null;
      }
    }
    if (_valid5) {
      const _errs56 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs57 = errors;
          if (data.data !== null) {
            validate26.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid15 = _errs57 === errors;
        } else {
          var valid15 = true;
        }
        if (valid15) {
          if (data.updatedAt !== void 0) {
            const _errs59 = errors;
            if (data.updatedAt !== null) {
              validate26.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid15 = _errs59 === errors;
          } else {
            var valid15 = true;
          }
        }
      }
      var _valid5 = _errs56 === errors;
      valid13 = _valid5;
      if (valid13) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid13) {
      const err19 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err19];
      } else {
        vErrors.push(err19);
      }
      errors++;
      validate26.errors = vErrors;
      return false;
    }
    var valid0 = _errs52 === errors;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs61 = errors;
      const _errs62 = errors;
      let valid16 = true;
      const _errs63 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data17 = data.status;
          if (!(data17 === "ok" || data17 === "unconfigured" || data17 === "loading")) {
            const err20 = {};
            if (vErrors === null) {
              vErrors = [err20];
            } else {
              vErrors.push(err20);
            }
            errors++;
          }
        }
      }
      var _valid6 = _errs63 === errors;
      errors = _errs62;
      if (vErrors !== null) {
        if (_errs62) {
          vErrors.length = _errs62;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid6) {
        const _errs65 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate26.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid6 = _errs65 === errors;
        valid16 = _valid6;
        if (valid16) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs68 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data19 = data.errorCode;
            if (!(data19 === "NETWORK_ERROR" || data19 === "INVALID_DATA" || data19 === "PAYLOAD_TOO_LARGE" || data19 === "EXPANSION_LIMIT" || data19 === "UNSUPPORTED_CALENDAR" || data19 === "UNKNOWN_TIME_ZONE" || data19 === "KEYRING_LOCKED" || data19 === "SECRET_DELETION_FAILED" || data19 === "AUTH_ERROR" || data19 === "RATE_LIMITED" || data19 === "NO_PLAYER" || data19 === "NO_INTERFACE" || data19 === "SERVICE_UNAVAILABLE" || data19 === "INTERNAL_ERROR")) {
              validate26.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema35.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid6 = _errs68 === errors;
        valid16 = _valid6;
        if (valid16) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid16) {
        const err21 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err21];
        } else {
          vErrors.push(err21);
        }
        errors++;
        validate26.errors = vErrors;
        return false;
      }
      var valid0 = _errs61 === errors;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing3;
      if (data.status === void 0 && (missing3 = "status") || data.sourceId === void 0 && (missing3 = "sourceId") || data.updatedAt === void 0 && (missing3 = "updatedAt") || data.data === void 0 && (missing3 = "data") || data.errorCode === void 0 && (missing3 = "errorCode")) {
        validate26.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" }];
        return false;
      } else {
        const _errs70 = errors;
        for (const key3 in data) {
          if (!(key3 === "status" || key3 === "sourceId" || key3 === "updatedAt" || key3 === "data" || key3 === "errorCode")) {
            validate26.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs70 === errors) {
          if (data.status !== void 0) {
            let data20 = data.status;
            const _errs71 = errors;
            if (!(data20 === "loading" || data20 === "ok" || data20 === "stale" || data20 === "unconfigured" || data20 === "unavailable")) {
              validate26.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema35.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid20 = _errs71 === errors;
          } else {
            var valid20 = true;
          }
          if (valid20) {
            if (data.sourceId !== void 0) {
              let data21 = data.sourceId;
              const _errs72 = errors;
              const _errs73 = errors;
              let valid21 = false;
              const _errs74 = errors;
              if (errors === _errs74) {
                if (typeof data21 === "string") {
                  if (func1(data21) > 128) {
                    const err22 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err22];
                    } else {
                      vErrors.push(err22);
                    }
                    errors++;
                  } else {
                    if (func1(data21) < 1) {
                      const err23 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err23];
                      } else {
                        vErrors.push(err23);
                      }
                      errors++;
                    } else {
                      if (!pattern5.test(data21)) {
                        const err24 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err24];
                        } else {
                          vErrors.push(err24);
                        }
                        errors++;
                      }
                    }
                  }
                } else {
                  const err25 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err25];
                  } else {
                    vErrors.push(err25);
                  }
                  errors++;
                }
              }
              var _valid7 = _errs74 === errors;
              valid21 = valid21 || _valid7;
              const _errs76 = errors;
              if (data21 !== null) {
                const err26 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err26];
                } else {
                  vErrors.push(err26);
                }
                errors++;
              }
              var _valid7 = _errs76 === errors;
              valid21 = valid21 || _valid7;
              if (!valid21) {
                const err27 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err27];
                } else {
                  vErrors.push(err27);
                }
                errors++;
                validate26.errors = vErrors;
                return false;
              } else {
                errors = _errs73;
                if (vErrors !== null) {
                  if (_errs73) {
                    vErrors.length = _errs73;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid20 = _errs72 === errors;
            } else {
              var valid20 = true;
            }
            if (valid20) {
              if (data.updatedAt !== void 0) {
                let data22 = data.updatedAt;
                const _errs78 = errors;
                const _errs79 = errors;
                let valid22 = false;
                const _errs80 = errors;
                if (errors === _errs80) {
                  if (errors === _errs80) {
                    if (typeof data22 === "string") {
                      if (func1(data22) > 64) {
                        const err28 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err28];
                        } else {
                          vErrors.push(err28);
                        }
                        errors++;
                      } else {
                        if (!formats0.validate(data22)) {
                          const err29 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err29];
                          } else {
                            vErrors.push(err29);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err30 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err30];
                      } else {
                        vErrors.push(err30);
                      }
                      errors++;
                    }
                  }
                }
                var _valid8 = _errs80 === errors;
                valid22 = valid22 || _valid8;
                const _errs82 = errors;
                if (data22 !== null) {
                  const err31 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err31];
                  } else {
                    vErrors.push(err31);
                  }
                  errors++;
                }
                var _valid8 = _errs82 === errors;
                valid22 = valid22 || _valid8;
                if (!valid22) {
                  const err32 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err32];
                  } else {
                    vErrors.push(err32);
                  }
                  errors++;
                  validate26.errors = vErrors;
                  return false;
                } else {
                  errors = _errs79;
                  if (vErrors !== null) {
                    if (_errs79) {
                      vErrors.length = _errs79;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid20 = _errs78 === errors;
              } else {
                var valid20 = true;
              }
              if (valid20) {
                if (data.data !== void 0) {
                  let data23 = data.data;
                  const _errs84 = errors;
                  const _errs85 = errors;
                  let valid23 = false;
                  const _errs86 = errors;
                  const _errs87 = errors;
                  if (errors === _errs87) {
                    if (data23 && typeof data23 == "object" && !Array.isArray(data23)) {
                      let missing4;
                      if (data23.location === void 0 && (missing4 = "location") || data23.timeZone === void 0 && (missing4 = "timeZone") || data23.current === void 0 && (missing4 = "current") || data23.hourly === void 0 && (missing4 = "hourly") || data23.attributionUrl === void 0 && (missing4 = "attributionUrl")) {
                        const err33 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                        if (vErrors === null) {
                          vErrors = [err33];
                        } else {
                          vErrors.push(err33);
                        }
                        errors++;
                      } else {
                        const _errs89 = errors;
                        for (const key4 in data23) {
                          if (!(key4 === "location" || key4 === "timeZone" || key4 === "current" || key4 === "hourly" || key4 === "attributionUrl")) {
                            const err34 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err34];
                            } else {
                              vErrors.push(err34);
                            }
                            errors++;
                            break;
                          }
                        }
                        if (_errs89 === errors) {
                          if (data23.location !== void 0) {
                            let data24 = data23.location;
                            const _errs90 = errors;
                            if (errors === _errs90) {
                              if (typeof data24 === "string") {
                                if (func1(data24) > 512) {
                                  const err35 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors++;
                                }
                              } else {
                                const err36 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err36];
                                } else {
                                  vErrors.push(err36);
                                }
                                errors++;
                              }
                            }
                            var valid25 = _errs90 === errors;
                          } else {
                            var valid25 = true;
                          }
                          if (valid25) {
                            if (data23.timeZone !== void 0) {
                              let data25 = data23.timeZone;
                              const _errs92 = errors;
                              if (errors === _errs92) {
                                if (typeof data25 === "string") {
                                  if (func1(data25) > 255) {
                                    const err37 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err37];
                                    } else {
                                      vErrors.push(err37);
                                    }
                                    errors++;
                                  } else {
                                    if (func1(data25) < 1) {
                                      const err38 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err38];
                                      } else {
                                        vErrors.push(err38);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err39 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err39];
                                  } else {
                                    vErrors.push(err39);
                                  }
                                  errors++;
                                }
                              }
                              var valid25 = _errs92 === errors;
                            } else {
                              var valid25 = true;
                            }
                            if (valid25) {
                              if (data23.current !== void 0) {
                                let data26 = data23.current;
                                const _errs94 = errors;
                                if (errors === _errs94) {
                                  if (data26 && typeof data26 == "object" && !Array.isArray(data26)) {
                                    let missing5;
                                    if (data26.temperatureC === void 0 && (missing5 = "temperatureC") || data26.code === void 0 && (missing5 = "code")) {
                                      const err40 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing5 }, message: "must have required property '" + missing5 + "'" };
                                      if (vErrors === null) {
                                        vErrors = [err40];
                                      } else {
                                        vErrors.push(err40);
                                      }
                                      errors++;
                                    } else {
                                      const _errs96 = errors;
                                      for (const key5 in data26) {
                                        if (!(key5 === "temperatureC" || key5 === "code")) {
                                          const err41 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                                          if (vErrors === null) {
                                            vErrors = [err41];
                                          } else {
                                            vErrors.push(err41);
                                          }
                                          errors++;
                                          break;
                                        }
                                      }
                                      if (_errs96 === errors) {
                                        if (data26.temperatureC !== void 0) {
                                          let data27 = data26.temperatureC;
                                          const _errs97 = errors;
                                          const _errs98 = errors;
                                          let valid27 = false;
                                          const _errs99 = errors;
                                          if (!(typeof data27 == "number" && isFinite(data27))) {
                                            const err42 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                            if (vErrors === null) {
                                              vErrors = [err42];
                                            } else {
                                              vErrors.push(err42);
                                            }
                                            errors++;
                                          }
                                          var _valid10 = _errs99 === errors;
                                          valid27 = valid27 || _valid10;
                                          const _errs101 = errors;
                                          if (data27 !== null) {
                                            const err43 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                            if (vErrors === null) {
                                              vErrors = [err43];
                                            } else {
                                              vErrors.push(err43);
                                            }
                                            errors++;
                                          }
                                          var _valid10 = _errs101 === errors;
                                          valid27 = valid27 || _valid10;
                                          if (!valid27) {
                                            const err44 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                            if (vErrors === null) {
                                              vErrors = [err44];
                                            } else {
                                              vErrors.push(err44);
                                            }
                                            errors++;
                                          } else {
                                            errors = _errs98;
                                            if (vErrors !== null) {
                                              if (_errs98) {
                                                vErrors.length = _errs98;
                                              } else {
                                                vErrors = null;
                                              }
                                            }
                                          }
                                          var valid26 = _errs97 === errors;
                                        } else {
                                          var valid26 = true;
                                        }
                                        if (valid26) {
                                          if (data26.code !== void 0) {
                                            let data28 = data26.code;
                                            const _errs103 = errors;
                                            const _errs104 = errors;
                                            let valid28 = false;
                                            const _errs105 = errors;
                                            if (!(typeof data28 == "number" && (!(data28 % 1) && !isNaN(data28)) && isFinite(data28))) {
                                              const err45 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                              if (vErrors === null) {
                                                vErrors = [err45];
                                              } else {
                                                vErrors.push(err45);
                                              }
                                              errors++;
                                            }
                                            if (errors === _errs105) {
                                              if (typeof data28 == "number" && isFinite(data28)) {
                                                if (data28 > 99 || isNaN(data28)) {
                                                  const err46 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                                  if (vErrors === null) {
                                                    vErrors = [err46];
                                                  } else {
                                                    vErrors.push(err46);
                                                  }
                                                  errors++;
                                                } else {
                                                  if (data28 < 0 || isNaN(data28)) {
                                                    const err47 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                    if (vErrors === null) {
                                                      vErrors = [err47];
                                                    } else {
                                                      vErrors.push(err47);
                                                    }
                                                    errors++;
                                                  }
                                                }
                                              }
                                            }
                                            var _valid11 = _errs105 === errors;
                                            valid28 = valid28 || _valid11;
                                            const _errs107 = errors;
                                            if (data28 !== null) {
                                              const err48 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors++;
                                            }
                                            var _valid11 = _errs107 === errors;
                                            valid28 = valid28 || _valid11;
                                            if (!valid28) {
                                              const err49 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err49];
                                              } else {
                                                vErrors.push(err49);
                                              }
                                              errors++;
                                            } else {
                                              errors = _errs104;
                                              if (vErrors !== null) {
                                                if (_errs104) {
                                                  vErrors.length = _errs104;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid26 = _errs103 === errors;
                                          } else {
                                            var valid26 = true;
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    const err50 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                    if (vErrors === null) {
                                      vErrors = [err50];
                                    } else {
                                      vErrors.push(err50);
                                    }
                                    errors++;
                                  }
                                }
                                var valid25 = _errs94 === errors;
                              } else {
                                var valid25 = true;
                              }
                              if (valid25) {
                                if (data23.hourly !== void 0) {
                                  let data29 = data23.hourly;
                                  const _errs109 = errors;
                                  if (errors === _errs109) {
                                    if (Array.isArray(data29)) {
                                      if (data29.length > 6) {
                                        const err51 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" };
                                        if (vErrors === null) {
                                          vErrors = [err51];
                                        } else {
                                          vErrors.push(err51);
                                        }
                                        errors++;
                                      } else {
                                        var valid29 = true;
                                        const len1 = data29.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data30 = data29[i1];
                                          const _errs111 = errors;
                                          if (errors === _errs111) {
                                            if (data30 && typeof data30 == "object" && !Array.isArray(data30)) {
                                              let missing6;
                                              if (data30.at === void 0 && (missing6 = "at") || data30.temperatureC === void 0 && (missing6 = "temperatureC") || data30.precipitationProbability === void 0 && (missing6 = "precipitationProbability")) {
                                                const err52 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing6 }, message: "must have required property '" + missing6 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err52];
                                                } else {
                                                  vErrors.push(err52);
                                                }
                                                errors++;
                                              } else {
                                                const _errs113 = errors;
                                                for (const key6 in data30) {
                                                  if (!(key6 === "at" || key6 === "temperatureC" || key6 === "precipitationProbability")) {
                                                    const err53 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err53];
                                                    } else {
                                                      vErrors.push(err53);
                                                    }
                                                    errors++;
                                                    break;
                                                  }
                                                }
                                                if (_errs113 === errors) {
                                                  if (data30.at !== void 0) {
                                                    let data31 = data30.at;
                                                    const _errs114 = errors;
                                                    if (errors === _errs114) {
                                                      if (errors === _errs114) {
                                                        if (typeof data31 === "string") {
                                                          if (func1(data31) > 64) {
                                                            const err54 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err54];
                                                            } else {
                                                              vErrors.push(err54);
                                                            }
                                                            errors++;
                                                          } else {
                                                            if (!formats0.validate(data31)) {
                                                              const err55 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err55];
                                                              } else {
                                                                vErrors.push(err55);
                                                              }
                                                              errors++;
                                                            }
                                                          }
                                                        } else {
                                                          const err56 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err56];
                                                          } else {
                                                            vErrors.push(err56);
                                                          }
                                                          errors++;
                                                        }
                                                      }
                                                    }
                                                    var valid30 = _errs114 === errors;
                                                  } else {
                                                    var valid30 = true;
                                                  }
                                                  if (valid30) {
                                                    if (data30.temperatureC !== void 0) {
                                                      let data32 = data30.temperatureC;
                                                      const _errs116 = errors;
                                                      const _errs117 = errors;
                                                      let valid31 = false;
                                                      const _errs118 = errors;
                                                      if (!(typeof data32 == "number" && isFinite(data32))) {
                                                        const err57 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                        if (vErrors === null) {
                                                          vErrors = [err57];
                                                        } else {
                                                          vErrors.push(err57);
                                                        }
                                                        errors++;
                                                      }
                                                      var _valid12 = _errs118 === errors;
                                                      valid31 = valid31 || _valid12;
                                                      const _errs120 = errors;
                                                      if (data32 !== null) {
                                                        const err58 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                        if (vErrors === null) {
                                                          vErrors = [err58];
                                                        } else {
                                                          vErrors.push(err58);
                                                        }
                                                        errors++;
                                                      }
                                                      var _valid12 = _errs120 === errors;
                                                      valid31 = valid31 || _valid12;
                                                      if (!valid31) {
                                                        const err59 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                        if (vErrors === null) {
                                                          vErrors = [err59];
                                                        } else {
                                                          vErrors.push(err59);
                                                        }
                                                        errors++;
                                                      } else {
                                                        errors = _errs117;
                                                        if (vErrors !== null) {
                                                          if (_errs117) {
                                                            vErrors.length = _errs117;
                                                          } else {
                                                            vErrors = null;
                                                          }
                                                        }
                                                      }
                                                      var valid30 = _errs116 === errors;
                                                    } else {
                                                      var valid30 = true;
                                                    }
                                                    if (valid30) {
                                                      if (data30.precipitationProbability !== void 0) {
                                                        let data33 = data30.precipitationProbability;
                                                        const _errs122 = errors;
                                                        const _errs123 = errors;
                                                        let valid32 = false;
                                                        const _errs124 = errors;
                                                        if (errors === _errs124) {
                                                          if (typeof data33 == "number" && isFinite(data33)) {
                                                            if (data33 > 100 || isNaN(data33)) {
                                                              const err60 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                              if (vErrors === null) {
                                                                vErrors = [err60];
                                                              } else {
                                                                vErrors.push(err60);
                                                              }
                                                              errors++;
                                                            } else {
                                                              if (data33 < 0 || isNaN(data33)) {
                                                                const err61 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                                if (vErrors === null) {
                                                                  vErrors = [err61];
                                                                } else {
                                                                  vErrors.push(err61);
                                                                }
                                                                errors++;
                                                              }
                                                            }
                                                          } else {
                                                            const err62 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err62];
                                                            } else {
                                                              vErrors.push(err62);
                                                            }
                                                            errors++;
                                                          }
                                                        }
                                                        var _valid13 = _errs124 === errors;
                                                        valid32 = valid32 || _valid13;
                                                        const _errs126 = errors;
                                                        if (data33 !== null) {
                                                          const err63 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                          if (vErrors === null) {
                                                            vErrors = [err63];
                                                          } else {
                                                            vErrors.push(err63);
                                                          }
                                                          errors++;
                                                        }
                                                        var _valid13 = _errs126 === errors;
                                                        valid32 = valid32 || _valid13;
                                                        if (!valid32) {
                                                          const err64 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                          if (vErrors === null) {
                                                            vErrors = [err64];
                                                          } else {
                                                            vErrors.push(err64);
                                                          }
                                                          errors++;
                                                        } else {
                                                          errors = _errs123;
                                                          if (vErrors !== null) {
                                                            if (_errs123) {
                                                              vErrors.length = _errs123;
                                                            } else {
                                                              vErrors = null;
                                                            }
                                                          }
                                                        }
                                                        var valid30 = _errs122 === errors;
                                                      } else {
                                                        var valid30 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err65 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err65];
                                              } else {
                                                vErrors.push(err65);
                                              }
                                              errors++;
                                            }
                                          }
                                          var valid29 = _errs111 === errors;
                                          if (!valid29) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err66 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err66];
                                      } else {
                                        vErrors.push(err66);
                                      }
                                      errors++;
                                    }
                                  }
                                  var valid25 = _errs109 === errors;
                                } else {
                                  var valid25 = true;
                                }
                                if (valid25) {
                                  if (data23.attributionUrl !== void 0) {
                                    let data34 = data23.attributionUrl;
                                    const _errs128 = errors;
                                    if (errors === _errs128) {
                                      if (typeof data34 === "string") {
                                        if (func1(data34) > 512) {
                                          const err67 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err67];
                                          } else {
                                            vErrors.push(err67);
                                          }
                                          errors++;
                                        } else {
                                          if (!pattern6.test(data34)) {
                                            const err68 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' };
                                            if (vErrors === null) {
                                              vErrors = [err68];
                                            } else {
                                              vErrors.push(err68);
                                            }
                                            errors++;
                                          }
                                        }
                                      } else {
                                        const err69 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err69];
                                        } else {
                                          vErrors.push(err69);
                                        }
                                        errors++;
                                      }
                                    }
                                    var valid25 = _errs128 === errors;
                                  } else {
                                    var valid25 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err70 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err70];
                      } else {
                        vErrors.push(err70);
                      }
                      errors++;
                    }
                  }
                  var _valid9 = _errs86 === errors;
                  valid23 = valid23 || _valid9;
                  const _errs130 = errors;
                  if (data23 !== null) {
                    const err71 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err71];
                    } else {
                      vErrors.push(err71);
                    }
                    errors++;
                  }
                  var _valid9 = _errs130 === errors;
                  valid23 = valid23 || _valid9;
                  if (!valid23) {
                    const err72 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err72];
                    } else {
                      vErrors.push(err72);
                    }
                    errors++;
                    validate26.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs85;
                    if (vErrors !== null) {
                      if (_errs85) {
                        vErrors.length = _errs85;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid20 = _errs84 === errors;
                } else {
                  var valid20 = true;
                }
                if (valid20) {
                  if (data.errorCode !== void 0) {
                    let data35 = data.errorCode;
                    const _errs132 = errors;
                    const _errs133 = errors;
                    let valid33 = false;
                    const _errs134 = errors;
                    if (!(data35 === "NETWORK_ERROR" || data35 === "INVALID_DATA" || data35 === "PAYLOAD_TOO_LARGE" || data35 === "EXPANSION_LIMIT" || data35 === "UNSUPPORTED_CALENDAR" || data35 === "UNKNOWN_TIME_ZONE" || data35 === "KEYRING_LOCKED" || data35 === "SECRET_DELETION_FAILED" || data35 === "AUTH_ERROR" || data35 === "RATE_LIMITED" || data35 === "NO_PLAYER" || data35 === "NO_INTERFACE" || data35 === "SERVICE_UNAVAILABLE" || data35 === "INTERNAL_ERROR")) {
                      const err73 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema35.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err73];
                      } else {
                        vErrors.push(err73);
                      }
                      errors++;
                    }
                    var _valid14 = _errs134 === errors;
                    valid33 = valid33 || _valid14;
                    const _errs135 = errors;
                    if (data35 !== null) {
                      const err74 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err74];
                      } else {
                        vErrors.push(err74);
                      }
                      errors++;
                    }
                    var _valid14 = _errs135 === errors;
                    valid33 = valid33 || _valid14;
                    if (!valid33) {
                      const err75 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err75];
                      } else {
                        vErrors.push(err75);
                      }
                      errors++;
                      validate26.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs133;
                      if (vErrors !== null) {
                        if (_errs133) {
                          vErrors.length = _errs133;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid20 = _errs132 === errors;
                  } else {
                    var valid20 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate26.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate26.errors = vErrors;
  return errors === 0;
}
validate26.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema38 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/SystemData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/SystemData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
function validate28(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate28.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors;
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors;
        const _errs7 = errors;
        if (errors === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.cpuPercent === void 0 && (missing0 = "cpuPercent") || data1.memoryUsedBytes === void 0 && (missing0 = "memoryUsedBytes") || data1.memoryTotalBytes === void 0 && (missing0 = "memoryTotalBytes") || data1.temperatureC === void 0 && (missing0 = "temperatureC")) {
              validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors;
              for (const key0 in data1) {
                if (!(key0 === "cpuPercent" || key0 === "memoryUsedBytes" || key0 === "memoryTotalBytes" || key0 === "temperatureC")) {
                  validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors) {
                if (data1.cpuPercent !== void 0) {
                  let data2 = data1.cpuPercent;
                  const _errs10 = errors;
                  const _errs11 = errors;
                  let valid6 = false;
                  const _errs12 = errors;
                  if (errors === _errs12) {
                    if (typeof data2 == "number" && isFinite(data2)) {
                      if (data2 > 100 || isNaN(data2)) {
                        const err1 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                        if (vErrors === null) {
                          vErrors = [err1];
                        } else {
                          vErrors.push(err1);
                        }
                        errors++;
                      } else {
                        if (data2 < 0 || isNaN(data2)) {
                          const err2 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err2];
                          } else {
                            vErrors.push(err2);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err3 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors++;
                    }
                  }
                  var _valid1 = _errs12 === errors;
                  valid6 = valid6 || _valid1;
                  const _errs14 = errors;
                  if (data2 !== null) {
                    const err4 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err4];
                    } else {
                      vErrors.push(err4);
                    }
                    errors++;
                  }
                  var _valid1 = _errs14 === errors;
                  valid6 = valid6 || _valid1;
                  if (!valid6) {
                    const err5 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err5];
                    } else {
                      vErrors.push(err5);
                    }
                    errors++;
                    validate28.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs11;
                    if (vErrors !== null) {
                      if (_errs11) {
                        vErrors.length = _errs11;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid5 = _errs10 === errors;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.memoryUsedBytes !== void 0) {
                    let data3 = data1.memoryUsedBytes;
                    const _errs16 = errors;
                    if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                      validate28.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                      return false;
                    }
                    if (errors === _errs16) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 > 9007199254740991 || isNaN(data3)) {
                          validate28.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                          return false;
                        } else {
                          if (data3 < 0 || isNaN(data3)) {
                            validate28.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                            return false;
                          }
                        }
                      }
                    }
                    var valid5 = _errs16 === errors;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.memoryTotalBytes !== void 0) {
                      let data4 = data1.memoryTotalBytes;
                      const _errs18 = errors;
                      if (!(typeof data4 == "number" && (!(data4 % 1) && !isNaN(data4)) && isFinite(data4))) {
                        validate28.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                        return false;
                      }
                      if (errors === _errs18) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 > 9007199254740991 || isNaN(data4)) {
                            validate28.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                            return false;
                          } else {
                            if (data4 < 0 || isNaN(data4)) {
                              validate28.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                              return false;
                            }
                          }
                        }
                      }
                      var valid5 = _errs18 === errors;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.temperatureC !== void 0) {
                        let data5 = data1.temperatureC;
                        const _errs20 = errors;
                        const _errs21 = errors;
                        let valid7 = false;
                        const _errs22 = errors;
                        if (!(typeof data5 == "number" && isFinite(data5))) {
                          const err6 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors++;
                        }
                        var _valid2 = _errs22 === errors;
                        valid7 = valid7 || _valid2;
                        const _errs24 = errors;
                        if (data5 !== null) {
                          const err7 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                          if (vErrors === null) {
                            vErrors = [err7];
                          } else {
                            vErrors.push(err7);
                          }
                          errors++;
                        }
                        var _valid2 = _errs24 === errors;
                        valid7 = valid7 || _valid2;
                        if (!valid7) {
                          const err8 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                          if (vErrors === null) {
                            vErrors = [err8];
                          } else {
                            vErrors.push(err8);
                          }
                          errors++;
                          validate28.errors = vErrors;
                          return false;
                        } else {
                          errors = _errs21;
                          if (vErrors !== null) {
                            if (_errs21) {
                              vErrors.length = _errs21;
                            } else {
                              vErrors = null;
                            }
                          }
                        }
                        var valid5 = _errs20 === errors;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data6 = data.updatedAt;
          const _errs26 = errors;
          if (errors === _errs26) {
            if (errors === _errs26) {
              if (typeof data6 === "string") {
                if (func1(data6) > 64) {
                  validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data6)) {
                    validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs26 === errors;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors++;
    validate28.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors;
  if (valid0) {
    const _errs28 = errors;
    const _errs29 = errors;
    let valid8 = true;
    const _errs30 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data7 = data.status;
        if (!(data7 === "unconfigured" || data7 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors++;
        }
      }
    }
    var _valid3 = _errs30 === errors;
    errors = _errs29;
    if (vErrors !== null) {
      if (_errs29) {
        vErrors.length = _errs29;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs32 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs33 = errors;
          if (data.data !== null) {
            validate28.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid10 = _errs33 === errors;
        } else {
          var valid10 = true;
        }
        if (valid10) {
          if (data.updatedAt !== void 0) {
            const _errs35 = errors;
            if (data.updatedAt !== null) {
              validate28.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid10 = _errs35 === errors;
          } else {
            var valid10 = true;
          }
        }
      }
      var _valid3 = _errs32 === errors;
      valid8 = _valid3;
      if (valid8) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid8) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors++;
      validate28.errors = vErrors;
      return false;
    }
    var valid0 = _errs28 === errors;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs37 = errors;
      const _errs38 = errors;
      let valid11 = true;
      const _errs39 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data10 = data.status;
          if (!(data10 === "ok" || data10 === "unconfigured" || data10 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors++;
          }
        }
      }
      var _valid4 = _errs39 === errors;
      errors = _errs38;
      if (vErrors !== null) {
        if (_errs38) {
          vErrors.length = _errs38;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs41 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate28.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs41 === errors;
        valid11 = _valid4;
        if (valid11) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs44 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data12 = data.errorCode;
            if (!(data12 === "NETWORK_ERROR" || data12 === "INVALID_DATA" || data12 === "PAYLOAD_TOO_LARGE" || data12 === "EXPANSION_LIMIT" || data12 === "UNSUPPORTED_CALENDAR" || data12 === "UNKNOWN_TIME_ZONE" || data12 === "KEYRING_LOCKED" || data12 === "SECRET_DELETION_FAILED" || data12 === "AUTH_ERROR" || data12 === "RATE_LIMITED" || data12 === "NO_PLAYER" || data12 === "NO_INTERFACE" || data12 === "SERVICE_UNAVAILABLE" || data12 === "INTERNAL_ERROR")) {
              validate28.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema38.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs44 === errors;
        valid11 = _valid4;
        if (valid11) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid11) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors++;
        validate28.errors = vErrors;
        return false;
      }
      var valid0 = _errs37 === errors;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate28.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs46 = errors;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate28.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs46 === errors) {
          if (data.status !== void 0) {
            let data13 = data.status;
            const _errs47 = errors;
            if (!(data13 === "loading" || data13 === "ok" || data13 === "stale" || data13 === "unconfigured" || data13 === "unavailable")) {
              validate28.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema38.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid15 = _errs47 === errors;
          } else {
            var valid15 = true;
          }
          if (valid15) {
            if (data.sourceId !== void 0) {
              let data14 = data.sourceId;
              const _errs48 = errors;
              const _errs49 = errors;
              let valid16 = false;
              const _errs50 = errors;
              if (errors === _errs50) {
                if (typeof data14 === "string") {
                  if (func1(data14) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors++;
                  } else {
                    if (func1(data14) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors++;
                    } else {
                      if (!pattern5.test(data14)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors++;
                }
              }
              var _valid5 = _errs50 === errors;
              valid16 = valid16 || _valid5;
              const _errs52 = errors;
              if (data14 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors++;
              }
              var _valid5 = _errs52 === errors;
              valid16 = valid16 || _valid5;
              if (!valid16) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors++;
                validate28.errors = vErrors;
                return false;
              } else {
                errors = _errs49;
                if (vErrors !== null) {
                  if (_errs49) {
                    vErrors.length = _errs49;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid15 = _errs48 === errors;
            } else {
              var valid15 = true;
            }
            if (valid15) {
              if (data.updatedAt !== void 0) {
                let data15 = data.updatedAt;
                const _errs54 = errors;
                const _errs55 = errors;
                let valid17 = false;
                const _errs56 = errors;
                if (errors === _errs56) {
                  if (errors === _errs56) {
                    if (typeof data15 === "string") {
                      if (func1(data15) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors++;
                      } else {
                        if (!formats0.validate(data15)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors++;
                    }
                  }
                }
                var _valid6 = _errs56 === errors;
                valid17 = valid17 || _valid6;
                const _errs58 = errors;
                if (data15 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors++;
                }
                var _valid6 = _errs58 === errors;
                valid17 = valid17 || _valid6;
                if (!valid17) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors++;
                  validate28.errors = vErrors;
                  return false;
                } else {
                  errors = _errs55;
                  if (vErrors !== null) {
                    if (_errs55) {
                      vErrors.length = _errs55;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid15 = _errs54 === errors;
              } else {
                var valid15 = true;
              }
              if (valid15) {
                if (data.data !== void 0) {
                  let data16 = data.data;
                  const _errs60 = errors;
                  const _errs61 = errors;
                  let valid18 = false;
                  const _errs62 = errors;
                  const _errs63 = errors;
                  if (errors === _errs63) {
                    if (data16 && typeof data16 == "object" && !Array.isArray(data16)) {
                      let missing2;
                      if (data16.cpuPercent === void 0 && (missing2 = "cpuPercent") || data16.memoryUsedBytes === void 0 && (missing2 = "memoryUsedBytes") || data16.memoryTotalBytes === void 0 && (missing2 = "memoryTotalBytes") || data16.temperatureC === void 0 && (missing2 = "temperatureC")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors++;
                      } else {
                        const _errs65 = errors;
                        for (const key2 in data16) {
                          if (!(key2 === "cpuPercent" || key2 === "memoryUsedBytes" || key2 === "memoryTotalBytes" || key2 === "temperatureC")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors++;
                            break;
                          }
                        }
                        if (_errs65 === errors) {
                          if (data16.cpuPercent !== void 0) {
                            let data17 = data16.cpuPercent;
                            const _errs66 = errors;
                            const _errs67 = errors;
                            let valid21 = false;
                            const _errs68 = errors;
                            if (errors === _errs68) {
                              if (typeof data17 == "number" && isFinite(data17)) {
                                if (data17 > 100 || isNaN(data17)) {
                                  const err27 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors++;
                                } else {
                                  if (data17 < 0 || isNaN(data17)) {
                                    const err28 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors++;
                              }
                            }
                            var _valid8 = _errs68 === errors;
                            valid21 = valid21 || _valid8;
                            const _errs70 = errors;
                            if (data17 !== null) {
                              const err30 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                              if (vErrors === null) {
                                vErrors = [err30];
                              } else {
                                vErrors.push(err30);
                              }
                              errors++;
                            }
                            var _valid8 = _errs70 === errors;
                            valid21 = valid21 || _valid8;
                            if (!valid21) {
                              const err31 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                              if (vErrors === null) {
                                vErrors = [err31];
                              } else {
                                vErrors.push(err31);
                              }
                              errors++;
                            } else {
                              errors = _errs67;
                              if (vErrors !== null) {
                                if (_errs67) {
                                  vErrors.length = _errs67;
                                } else {
                                  vErrors = null;
                                }
                              }
                            }
                            var valid20 = _errs66 === errors;
                          } else {
                            var valid20 = true;
                          }
                          if (valid20) {
                            if (data16.memoryUsedBytes !== void 0) {
                              let data18 = data16.memoryUsedBytes;
                              const _errs72 = errors;
                              if (!(typeof data18 == "number" && (!(data18 % 1) && !isNaN(data18)) && isFinite(data18))) {
                                const err32 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors++;
                              }
                              if (errors === _errs72) {
                                if (typeof data18 == "number" && isFinite(data18)) {
                                  if (data18 > 9007199254740991 || isNaN(data18)) {
                                    const err33 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                    if (vErrors === null) {
                                      vErrors = [err33];
                                    } else {
                                      vErrors.push(err33);
                                    }
                                    errors++;
                                  } else {
                                    if (data18 < 0 || isNaN(data18)) {
                                      const err34 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors++;
                                    }
                                  }
                                }
                              }
                              var valid20 = _errs72 === errors;
                            } else {
                              var valid20 = true;
                            }
                            if (valid20) {
                              if (data16.memoryTotalBytes !== void 0) {
                                let data19 = data16.memoryTotalBytes;
                                const _errs74 = errors;
                                if (!(typeof data19 == "number" && (!(data19 % 1) && !isNaN(data19)) && isFinite(data19))) {
                                  const err35 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors++;
                                }
                                if (errors === _errs74) {
                                  if (typeof data19 == "number" && isFinite(data19)) {
                                    if (data19 > 9007199254740991 || isNaN(data19)) {
                                      const err36 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors++;
                                    } else {
                                      if (data19 < 0 || isNaN(data19)) {
                                        const err37 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                        if (vErrors === null) {
                                          vErrors = [err37];
                                        } else {
                                          vErrors.push(err37);
                                        }
                                        errors++;
                                      }
                                    }
                                  }
                                }
                                var valid20 = _errs74 === errors;
                              } else {
                                var valid20 = true;
                              }
                              if (valid20) {
                                if (data16.temperatureC !== void 0) {
                                  let data20 = data16.temperatureC;
                                  const _errs76 = errors;
                                  const _errs77 = errors;
                                  let valid22 = false;
                                  const _errs78 = errors;
                                  if (!(typeof data20 == "number" && isFinite(data20))) {
                                    const err38 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err38];
                                    } else {
                                      vErrors.push(err38);
                                    }
                                    errors++;
                                  }
                                  var _valid9 = _errs78 === errors;
                                  valid22 = valid22 || _valid9;
                                  const _errs80 = errors;
                                  if (data20 !== null) {
                                    const err39 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err39];
                                    } else {
                                      vErrors.push(err39);
                                    }
                                    errors++;
                                  }
                                  var _valid9 = _errs80 === errors;
                                  valid22 = valid22 || _valid9;
                                  if (!valid22) {
                                    const err40 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err40];
                                    } else {
                                      vErrors.push(err40);
                                    }
                                    errors++;
                                  } else {
                                    errors = _errs77;
                                    if (vErrors !== null) {
                                      if (_errs77) {
                                        vErrors.length = _errs77;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid20 = _errs76 === errors;
                                } else {
                                  var valid20 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err41 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors++;
                    }
                  }
                  var _valid7 = _errs62 === errors;
                  valid18 = valid18 || _valid7;
                  const _errs82 = errors;
                  if (data16 !== null) {
                    const err42 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err42];
                    } else {
                      vErrors.push(err42);
                    }
                    errors++;
                  }
                  var _valid7 = _errs82 === errors;
                  valid18 = valid18 || _valid7;
                  if (!valid18) {
                    const err43 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err43];
                    } else {
                      vErrors.push(err43);
                    }
                    errors++;
                    validate28.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs61;
                    if (vErrors !== null) {
                      if (_errs61) {
                        vErrors.length = _errs61;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid15 = _errs60 === errors;
                } else {
                  var valid15 = true;
                }
                if (valid15) {
                  if (data.errorCode !== void 0) {
                    let data21 = data.errorCode;
                    const _errs84 = errors;
                    const _errs85 = errors;
                    let valid23 = false;
                    const _errs86 = errors;
                    if (!(data21 === "NETWORK_ERROR" || data21 === "INVALID_DATA" || data21 === "PAYLOAD_TOO_LARGE" || data21 === "EXPANSION_LIMIT" || data21 === "UNSUPPORTED_CALENDAR" || data21 === "UNKNOWN_TIME_ZONE" || data21 === "KEYRING_LOCKED" || data21 === "SECRET_DELETION_FAILED" || data21 === "AUTH_ERROR" || data21 === "RATE_LIMITED" || data21 === "NO_PLAYER" || data21 === "NO_INTERFACE" || data21 === "SERVICE_UNAVAILABLE" || data21 === "INTERNAL_ERROR")) {
                      const err44 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema38.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err44];
                      } else {
                        vErrors.push(err44);
                      }
                      errors++;
                    }
                    var _valid10 = _errs86 === errors;
                    valid23 = valid23 || _valid10;
                    const _errs87 = errors;
                    if (data21 !== null) {
                      const err45 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err45];
                      } else {
                        vErrors.push(err45);
                      }
                      errors++;
                    }
                    var _valid10 = _errs87 === errors;
                    valid23 = valid23 || _valid10;
                    if (!valid23) {
                      const err46 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err46];
                      } else {
                        vErrors.push(err46);
                      }
                      errors++;
                      validate28.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs85;
                      if (vErrors !== null) {
                        if (_errs85) {
                          vErrors.length = _errs85;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid15 = _errs84 === errors;
                  } else {
                    var valid15 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate28.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate28.errors = vErrors;
  return errors === 0;
}
validate28.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema41 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/NetworkData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/NetworkData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
function validate30(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate30.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors;
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors;
        const _errs7 = errors;
        if (errors === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.interface === void 0 && (missing0 = "interface") || data1.rxBytesPerSec === void 0 && (missing0 = "rxBytesPerSec") || data1.txBytesPerSec === void 0 && (missing0 = "txBytesPerSec") || data1.history === void 0 && (missing0 = "history")) {
              validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors;
              for (const key0 in data1) {
                if (!(key0 === "interface" || key0 === "rxBytesPerSec" || key0 === "txBytesPerSec" || key0 === "history")) {
                  validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors) {
                if (data1.interface !== void 0) {
                  let data2 = data1.interface;
                  const _errs10 = errors;
                  if (errors === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 64) {
                        validate30.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate30.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate30.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.rxBytesPerSec !== void 0) {
                    let data3 = data1.rxBytesPerSec;
                    const _errs12 = errors;
                    const _errs13 = errors;
                    let valid6 = false;
                    const _errs14 = errors;
                    if (errors === _errs14) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 < 0 || isNaN(data3)) {
                          const err1 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err1];
                          } else {
                            vErrors.push(err1);
                          }
                          errors++;
                        }
                      } else {
                        const err2 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err2];
                        } else {
                          vErrors.push(err2);
                        }
                        errors++;
                      }
                    }
                    var _valid1 = _errs14 === errors;
                    valid6 = valid6 || _valid1;
                    const _errs16 = errors;
                    if (data3 !== null) {
                      const err3 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors++;
                    }
                    var _valid1 = _errs16 === errors;
                    valid6 = valid6 || _valid1;
                    if (!valid6) {
                      const err4 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err4];
                      } else {
                        vErrors.push(err4);
                      }
                      errors++;
                      validate30.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs13;
                      if (vErrors !== null) {
                        if (_errs13) {
                          vErrors.length = _errs13;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid5 = _errs12 === errors;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.txBytesPerSec !== void 0) {
                      let data4 = data1.txBytesPerSec;
                      const _errs18 = errors;
                      const _errs19 = errors;
                      let valid7 = false;
                      const _errs20 = errors;
                      if (errors === _errs20) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 < 0 || isNaN(data4)) {
                            const err5 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors++;
                          }
                        } else {
                          const err6 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors++;
                        }
                      }
                      var _valid2 = _errs20 === errors;
                      valid7 = valid7 || _valid2;
                      const _errs22 = errors;
                      if (data4 !== null) {
                        const err7 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                        if (vErrors === null) {
                          vErrors = [err7];
                        } else {
                          vErrors.push(err7);
                        }
                        errors++;
                      }
                      var _valid2 = _errs22 === errors;
                      valid7 = valid7 || _valid2;
                      if (!valid7) {
                        const err8 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors++;
                        validate30.errors = vErrors;
                        return false;
                      } else {
                        errors = _errs19;
                        if (vErrors !== null) {
                          if (_errs19) {
                            vErrors.length = _errs19;
                          } else {
                            vErrors = null;
                          }
                        }
                      }
                      var valid5 = _errs18 === errors;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.history !== void 0) {
                        let data5 = data1.history;
                        const _errs24 = errors;
                        if (errors === _errs24) {
                          if (Array.isArray(data5)) {
                            if (data5.length > 60) {
                              validate30.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" }];
                              return false;
                            } else {
                              var valid8 = true;
                              const len0 = data5.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data6 = data5[i0];
                                const _errs26 = errors;
                                if (errors === _errs26) {
                                  if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
                                    let missing1;
                                    if (data6.at === void 0 && (missing1 = "at") || data6.rx === void 0 && (missing1 = "rx") || data6.tx === void 0 && (missing1 = "tx")) {
                                      validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                      return false;
                                    } else {
                                      const _errs28 = errors;
                                      for (const key1 in data6) {
                                        if (!(key1 === "at" || key1 === "rx" || key1 === "tx")) {
                                          validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs28 === errors) {
                                        if (data6.at !== void 0) {
                                          let data7 = data6.at;
                                          const _errs29 = errors;
                                          if (errors === _errs29) {
                                            if (errors === _errs29) {
                                              if (typeof data7 === "string") {
                                                if (func1(data7) > 64) {
                                                  validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data7)) {
                                                    validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid9 = _errs29 === errors;
                                        } else {
                                          var valid9 = true;
                                        }
                                        if (valid9) {
                                          if (data6.rx !== void 0) {
                                            let data8 = data6.rx;
                                            const _errs31 = errors;
                                            if (errors === _errs31) {
                                              if (typeof data8 == "number" && isFinite(data8)) {
                                                if (data8 < 0 || isNaN(data8)) {
                                                  validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                  return false;
                                                }
                                              } else {
                                                validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                return false;
                                              }
                                            }
                                            var valid9 = _errs31 === errors;
                                          } else {
                                            var valid9 = true;
                                          }
                                          if (valid9) {
                                            if (data6.tx !== void 0) {
                                              let data9 = data6.tx;
                                              const _errs33 = errors;
                                              if (errors === _errs33) {
                                                if (typeof data9 == "number" && isFinite(data9)) {
                                                  if (data9 < 0 || isNaN(data9)) {
                                                    validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                    return false;
                                                  }
                                                } else {
                                                  validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                  return false;
                                                }
                                              }
                                              var valid9 = _errs33 === errors;
                                            } else {
                                              var valid9 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate30.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid8 = _errs26 === errors;
                                if (!valid8) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate30.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs24 === errors;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data10 = data.updatedAt;
          const _errs35 = errors;
          if (errors === _errs35) {
            if (errors === _errs35) {
              if (typeof data10 === "string") {
                if (func1(data10) > 64) {
                  validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data10)) {
                    validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs35 === errors;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors++;
    validate30.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors;
  if (valid0) {
    const _errs37 = errors;
    const _errs38 = errors;
    let valid10 = true;
    const _errs39 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data11 = data.status;
        if (!(data11 === "unconfigured" || data11 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors++;
        }
      }
    }
    var _valid3 = _errs39 === errors;
    errors = _errs38;
    if (vErrors !== null) {
      if (_errs38) {
        vErrors.length = _errs38;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs41 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs42 = errors;
          if (data.data !== null) {
            validate30.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid12 = _errs42 === errors;
        } else {
          var valid12 = true;
        }
        if (valid12) {
          if (data.updatedAt !== void 0) {
            const _errs44 = errors;
            if (data.updatedAt !== null) {
              validate30.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid12 = _errs44 === errors;
          } else {
            var valid12 = true;
          }
        }
      }
      var _valid3 = _errs41 === errors;
      valid10 = _valid3;
      if (valid10) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid10) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors++;
      validate30.errors = vErrors;
      return false;
    }
    var valid0 = _errs37 === errors;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs46 = errors;
      const _errs47 = errors;
      let valid13 = true;
      const _errs48 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data14 = data.status;
          if (!(data14 === "ok" || data14 === "unconfigured" || data14 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors++;
          }
        }
      }
      var _valid4 = _errs48 === errors;
      errors = _errs47;
      if (vErrors !== null) {
        if (_errs47) {
          vErrors.length = _errs47;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs50 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate30.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs50 === errors;
        valid13 = _valid4;
        if (valid13) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs53 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data16 = data.errorCode;
            if (!(data16 === "NETWORK_ERROR" || data16 === "INVALID_DATA" || data16 === "PAYLOAD_TOO_LARGE" || data16 === "EXPANSION_LIMIT" || data16 === "UNSUPPORTED_CALENDAR" || data16 === "UNKNOWN_TIME_ZONE" || data16 === "KEYRING_LOCKED" || data16 === "SECRET_DELETION_FAILED" || data16 === "AUTH_ERROR" || data16 === "RATE_LIMITED" || data16 === "NO_PLAYER" || data16 === "NO_INTERFACE" || data16 === "SERVICE_UNAVAILABLE" || data16 === "INTERNAL_ERROR")) {
              validate30.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema41.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs53 === errors;
        valid13 = _valid4;
        if (valid13) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid13) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors++;
        validate30.errors = vErrors;
        return false;
      }
      var valid0 = _errs46 === errors;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing2;
      if (data.status === void 0 && (missing2 = "status") || data.sourceId === void 0 && (missing2 = "sourceId") || data.updatedAt === void 0 && (missing2 = "updatedAt") || data.data === void 0 && (missing2 = "data") || data.errorCode === void 0 && (missing2 = "errorCode")) {
        validate30.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
        return false;
      } else {
        const _errs55 = errors;
        for (const key2 in data) {
          if (!(key2 === "status" || key2 === "sourceId" || key2 === "updatedAt" || key2 === "data" || key2 === "errorCode")) {
            validate30.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs55 === errors) {
          if (data.status !== void 0) {
            let data17 = data.status;
            const _errs56 = errors;
            if (!(data17 === "loading" || data17 === "ok" || data17 === "stale" || data17 === "unconfigured" || data17 === "unavailable")) {
              validate30.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema41.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid17 = _errs56 === errors;
          } else {
            var valid17 = true;
          }
          if (valid17) {
            if (data.sourceId !== void 0) {
              let data18 = data.sourceId;
              const _errs57 = errors;
              const _errs58 = errors;
              let valid18 = false;
              const _errs59 = errors;
              if (errors === _errs59) {
                if (typeof data18 === "string") {
                  if (func1(data18) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors++;
                  } else {
                    if (func1(data18) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors++;
                    } else {
                      if (!pattern5.test(data18)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors++;
                }
              }
              var _valid5 = _errs59 === errors;
              valid18 = valid18 || _valid5;
              const _errs61 = errors;
              if (data18 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors++;
              }
              var _valid5 = _errs61 === errors;
              valid18 = valid18 || _valid5;
              if (!valid18) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors++;
                validate30.errors = vErrors;
                return false;
              } else {
                errors = _errs58;
                if (vErrors !== null) {
                  if (_errs58) {
                    vErrors.length = _errs58;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid17 = _errs57 === errors;
            } else {
              var valid17 = true;
            }
            if (valid17) {
              if (data.updatedAt !== void 0) {
                let data19 = data.updatedAt;
                const _errs63 = errors;
                const _errs64 = errors;
                let valid19 = false;
                const _errs65 = errors;
                if (errors === _errs65) {
                  if (errors === _errs65) {
                    if (typeof data19 === "string") {
                      if (func1(data19) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors++;
                      } else {
                        if (!formats0.validate(data19)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors++;
                    }
                  }
                }
                var _valid6 = _errs65 === errors;
                valid19 = valid19 || _valid6;
                const _errs67 = errors;
                if (data19 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors++;
                }
                var _valid6 = _errs67 === errors;
                valid19 = valid19 || _valid6;
                if (!valid19) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors++;
                  validate30.errors = vErrors;
                  return false;
                } else {
                  errors = _errs64;
                  if (vErrors !== null) {
                    if (_errs64) {
                      vErrors.length = _errs64;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid17 = _errs63 === errors;
              } else {
                var valid17 = true;
              }
              if (valid17) {
                if (data.data !== void 0) {
                  let data20 = data.data;
                  const _errs69 = errors;
                  const _errs70 = errors;
                  let valid20 = false;
                  const _errs71 = errors;
                  const _errs72 = errors;
                  if (errors === _errs72) {
                    if (data20 && typeof data20 == "object" && !Array.isArray(data20)) {
                      let missing3;
                      if (data20.interface === void 0 && (missing3 = "interface") || data20.rxBytesPerSec === void 0 && (missing3 = "rxBytesPerSec") || data20.txBytesPerSec === void 0 && (missing3 = "txBytesPerSec") || data20.history === void 0 && (missing3 = "history")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors++;
                      } else {
                        const _errs74 = errors;
                        for (const key3 in data20) {
                          if (!(key3 === "interface" || key3 === "rxBytesPerSec" || key3 === "txBytesPerSec" || key3 === "history")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors++;
                            break;
                          }
                        }
                        if (_errs74 === errors) {
                          if (data20.interface !== void 0) {
                            let data21 = data20.interface;
                            const _errs75 = errors;
                            if (errors === _errs75) {
                              if (typeof data21 === "string") {
                                if (func1(data21) > 64) {
                                  const err27 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors++;
                                } else {
                                  if (func1(data21) < 1) {
                                    const err28 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors++;
                              }
                            }
                            var valid22 = _errs75 === errors;
                          } else {
                            var valid22 = true;
                          }
                          if (valid22) {
                            if (data20.rxBytesPerSec !== void 0) {
                              let data22 = data20.rxBytesPerSec;
                              const _errs77 = errors;
                              const _errs78 = errors;
                              let valid23 = false;
                              const _errs79 = errors;
                              if (errors === _errs79) {
                                if (typeof data22 == "number" && isFinite(data22)) {
                                  if (data22 < 0 || isNaN(data22)) {
                                    const err30 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err30];
                                    } else {
                                      vErrors.push(err30);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err31 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err31];
                                  } else {
                                    vErrors.push(err31);
                                  }
                                  errors++;
                                }
                              }
                              var _valid8 = _errs79 === errors;
                              valid23 = valid23 || _valid8;
                              const _errs81 = errors;
                              if (data22 !== null) {
                                const err32 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors++;
                              }
                              var _valid8 = _errs81 === errors;
                              valid23 = valid23 || _valid8;
                              if (!valid23) {
                                const err33 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err33];
                                } else {
                                  vErrors.push(err33);
                                }
                                errors++;
                              } else {
                                errors = _errs78;
                                if (vErrors !== null) {
                                  if (_errs78) {
                                    vErrors.length = _errs78;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid22 = _errs77 === errors;
                            } else {
                              var valid22 = true;
                            }
                            if (valid22) {
                              if (data20.txBytesPerSec !== void 0) {
                                let data23 = data20.txBytesPerSec;
                                const _errs83 = errors;
                                const _errs84 = errors;
                                let valid24 = false;
                                const _errs85 = errors;
                                if (errors === _errs85) {
                                  if (typeof data23 == "number" && isFinite(data23)) {
                                    if (data23 < 0 || isNaN(data23)) {
                                      const err34 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err35 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err35];
                                    } else {
                                      vErrors.push(err35);
                                    }
                                    errors++;
                                  }
                                }
                                var _valid9 = _errs85 === errors;
                                valid24 = valid24 || _valid9;
                                const _errs87 = errors;
                                if (data23 !== null) {
                                  const err36 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err36];
                                  } else {
                                    vErrors.push(err36);
                                  }
                                  errors++;
                                }
                                var _valid9 = _errs87 === errors;
                                valid24 = valid24 || _valid9;
                                if (!valid24) {
                                  const err37 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err37];
                                  } else {
                                    vErrors.push(err37);
                                  }
                                  errors++;
                                } else {
                                  errors = _errs84;
                                  if (vErrors !== null) {
                                    if (_errs84) {
                                      vErrors.length = _errs84;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid22 = _errs83 === errors;
                              } else {
                                var valid22 = true;
                              }
                              if (valid22) {
                                if (data20.history !== void 0) {
                                  let data24 = data20.history;
                                  const _errs89 = errors;
                                  if (errors === _errs89) {
                                    if (Array.isArray(data24)) {
                                      if (data24.length > 60) {
                                        const err38 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" };
                                        if (vErrors === null) {
                                          vErrors = [err38];
                                        } else {
                                          vErrors.push(err38);
                                        }
                                        errors++;
                                      } else {
                                        var valid25 = true;
                                        const len1 = data24.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data25 = data24[i1];
                                          const _errs91 = errors;
                                          if (errors === _errs91) {
                                            if (data25 && typeof data25 == "object" && !Array.isArray(data25)) {
                                              let missing4;
                                              if (data25.at === void 0 && (missing4 = "at") || data25.rx === void 0 && (missing4 = "rx") || data25.tx === void 0 && (missing4 = "tx")) {
                                                const err39 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err39];
                                                } else {
                                                  vErrors.push(err39);
                                                }
                                                errors++;
                                              } else {
                                                const _errs93 = errors;
                                                for (const key4 in data25) {
                                                  if (!(key4 === "at" || key4 === "rx" || key4 === "tx")) {
                                                    const err40 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err40];
                                                    } else {
                                                      vErrors.push(err40);
                                                    }
                                                    errors++;
                                                    break;
                                                  }
                                                }
                                                if (_errs93 === errors) {
                                                  if (data25.at !== void 0) {
                                                    let data26 = data25.at;
                                                    const _errs94 = errors;
                                                    if (errors === _errs94) {
                                                      if (errors === _errs94) {
                                                        if (typeof data26 === "string") {
                                                          if (func1(data26) > 64) {
                                                            const err41 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err41];
                                                            } else {
                                                              vErrors.push(err41);
                                                            }
                                                            errors++;
                                                          } else {
                                                            if (!formats0.validate(data26)) {
                                                              const err42 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err42];
                                                              } else {
                                                                vErrors.push(err42);
                                                              }
                                                              errors++;
                                                            }
                                                          }
                                                        } else {
                                                          const err43 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err43];
                                                          } else {
                                                            vErrors.push(err43);
                                                          }
                                                          errors++;
                                                        }
                                                      }
                                                    }
                                                    var valid26 = _errs94 === errors;
                                                  } else {
                                                    var valid26 = true;
                                                  }
                                                  if (valid26) {
                                                    if (data25.rx !== void 0) {
                                                      let data27 = data25.rx;
                                                      const _errs96 = errors;
                                                      if (errors === _errs96) {
                                                        if (typeof data27 == "number" && isFinite(data27)) {
                                                          if (data27 < 0 || isNaN(data27)) {
                                                            const err44 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                            if (vErrors === null) {
                                                              vErrors = [err44];
                                                            } else {
                                                              vErrors.push(err44);
                                                            }
                                                            errors++;
                                                          }
                                                        } else {
                                                          const err45 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                          if (vErrors === null) {
                                                            vErrors = [err45];
                                                          } else {
                                                            vErrors.push(err45);
                                                          }
                                                          errors++;
                                                        }
                                                      }
                                                      var valid26 = _errs96 === errors;
                                                    } else {
                                                      var valid26 = true;
                                                    }
                                                    if (valid26) {
                                                      if (data25.tx !== void 0) {
                                                        let data28 = data25.tx;
                                                        const _errs98 = errors;
                                                        if (errors === _errs98) {
                                                          if (typeof data28 == "number" && isFinite(data28)) {
                                                            if (data28 < 0 || isNaN(data28)) {
                                                              const err46 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                              if (vErrors === null) {
                                                                vErrors = [err46];
                                                              } else {
                                                                vErrors.push(err46);
                                                              }
                                                              errors++;
                                                            }
                                                          } else {
                                                            const err47 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err47];
                                                            } else {
                                                              vErrors.push(err47);
                                                            }
                                                            errors++;
                                                          }
                                                        }
                                                        var valid26 = _errs98 === errors;
                                                      } else {
                                                        var valid26 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err48 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors++;
                                            }
                                          }
                                          var valid25 = _errs91 === errors;
                                          if (!valid25) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err49 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err49];
                                      } else {
                                        vErrors.push(err49);
                                      }
                                      errors++;
                                    }
                                  }
                                  var valid22 = _errs89 === errors;
                                } else {
                                  var valid22 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err50 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err50];
                      } else {
                        vErrors.push(err50);
                      }
                      errors++;
                    }
                  }
                  var _valid7 = _errs71 === errors;
                  valid20 = valid20 || _valid7;
                  const _errs100 = errors;
                  if (data20 !== null) {
                    const err51 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err51];
                    } else {
                      vErrors.push(err51);
                    }
                    errors++;
                  }
                  var _valid7 = _errs100 === errors;
                  valid20 = valid20 || _valid7;
                  if (!valid20) {
                    const err52 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err52];
                    } else {
                      vErrors.push(err52);
                    }
                    errors++;
                    validate30.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs70;
                    if (vErrors !== null) {
                      if (_errs70) {
                        vErrors.length = _errs70;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid17 = _errs69 === errors;
                } else {
                  var valid17 = true;
                }
                if (valid17) {
                  if (data.errorCode !== void 0) {
                    let data29 = data.errorCode;
                    const _errs102 = errors;
                    const _errs103 = errors;
                    let valid27 = false;
                    const _errs104 = errors;
                    if (!(data29 === "NETWORK_ERROR" || data29 === "INVALID_DATA" || data29 === "PAYLOAD_TOO_LARGE" || data29 === "EXPANSION_LIMIT" || data29 === "UNSUPPORTED_CALENDAR" || data29 === "UNKNOWN_TIME_ZONE" || data29 === "KEYRING_LOCKED" || data29 === "SECRET_DELETION_FAILED" || data29 === "AUTH_ERROR" || data29 === "RATE_LIMITED" || data29 === "NO_PLAYER" || data29 === "NO_INTERFACE" || data29 === "SERVICE_UNAVAILABLE" || data29 === "INTERNAL_ERROR")) {
                      const err53 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema41.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err53];
                      } else {
                        vErrors.push(err53);
                      }
                      errors++;
                    }
                    var _valid10 = _errs104 === errors;
                    valid27 = valid27 || _valid10;
                    const _errs105 = errors;
                    if (data29 !== null) {
                      const err54 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err54];
                      } else {
                        vErrors.push(err54);
                      }
                      errors++;
                    }
                    var _valid10 = _errs105 === errors;
                    valid27 = valid27 || _valid10;
                    if (!valid27) {
                      const err55 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err55];
                      } else {
                        vErrors.push(err55);
                      }
                      errors++;
                      validate30.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs103;
                      if (vErrors !== null) {
                        if (_errs103) {
                          vErrors.length = _errs103;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid17 = _errs102 === errors;
                  } else {
                    var valid17 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate30.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate30.errors = vErrors;
  return errors === 0;
}
validate30.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema44 = { "type": "object", "additionalProperties": false, "required": ["status", "sourceId", "updatedAt", "data", "errorCode"], "properties": { "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "data": { "anyOf": [{ "$ref": "#/$defs/MediaData" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "allOf": [{ "if": { "properties": { "status": { "enum": ["ok", "stale"] } } }, "then": { "properties": { "data": { "$ref": "#/$defs/MediaData" }, "updatedAt": { "type": "string", "maxLength": 64, "format": "date-time" } } } }, { "if": { "properties": { "status": { "enum": ["unconfigured", "unavailable"] } } }, "then": { "properties": { "data": { "type": "null" }, "updatedAt": { "type": "null" } } } }, { "if": { "properties": { "status": { "enum": ["ok", "unconfigured", "loading"] } } }, "then": { "properties": { "errorCode": { "type": "null" } } }, "else": { "properties": { "errorCode": { "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] } } } }] };
var schema45 = { "type": "object", "additionalProperties": false, "required": ["player", "status", "title", "artist", "artUri"], "properties": { "player": { "type": "string", "maxLength": 255, "minLength": 1 }, "status": { "enum": ["playing", "paused", "stopped"] }, "title": { "type": "string", "maxLength": 4096 }, "artist": { "type": "string", "maxLength": 4096 }, "artUri": { "anyOf": [{ "type": "string", "maxLength": 4096, "pattern": "^file:///" }, { "type": "null" }] } } };
var pattern11 = new RegExp("^file:///", "u");
function validate32(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate32.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors;
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors;
        const _errs7 = errors;
        if (errors === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.player === void 0 && (missing0 = "player") || data1.status === void 0 && (missing0 = "status") || data1.title === void 0 && (missing0 = "title") || data1.artist === void 0 && (missing0 = "artist") || data1.artUri === void 0 && (missing0 = "artUri")) {
              validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors;
              for (const key0 in data1) {
                if (!(key0 === "player" || key0 === "status" || key0 === "title" || key0 === "artist" || key0 === "artUri")) {
                  validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors) {
                if (data1.player !== void 0) {
                  let data2 = data1.player;
                  const _errs10 = errors;
                  if (errors === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 255) {
                        validate32.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate32.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate32.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.status !== void 0) {
                    let data3 = data1.status;
                    const _errs12 = errors;
                    if (!(data3 === "playing" || data3 === "paused" || data3 === "stopped")) {
                      validate32.errors = [{ instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" }];
                      return false;
                    }
                    var valid5 = _errs12 === errors;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.title !== void 0) {
                      let data4 = data1.title;
                      const _errs13 = errors;
                      if (errors === _errs13) {
                        if (typeof data4 === "string") {
                          if (func1(data4) > 4096) {
                            validate32.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                            return false;
                          }
                        } else {
                          validate32.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                          return false;
                        }
                      }
                      var valid5 = _errs13 === errors;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.artist !== void 0) {
                        let data5 = data1.artist;
                        const _errs15 = errors;
                        if (errors === _errs15) {
                          if (typeof data5 === "string") {
                            if (func1(data5) > 4096) {
                              validate32.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                              return false;
                            }
                          } else {
                            validate32.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                            return false;
                          }
                        }
                        var valid5 = _errs15 === errors;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.artUri !== void 0) {
                          let data6 = data1.artUri;
                          const _errs17 = errors;
                          const _errs18 = errors;
                          let valid6 = false;
                          const _errs19 = errors;
                          if (errors === _errs19) {
                            if (typeof data6 === "string") {
                              if (func1(data6) > 4096) {
                                const err1 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                if (vErrors === null) {
                                  vErrors = [err1];
                                } else {
                                  vErrors.push(err1);
                                }
                                errors++;
                              } else {
                                if (!pattern11.test(data6)) {
                                  const err2 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err3 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err3];
                              } else {
                                vErrors.push(err3);
                              }
                              errors++;
                            }
                          }
                          var _valid1 = _errs19 === errors;
                          valid6 = valid6 || _valid1;
                          const _errs21 = errors;
                          if (data6 !== null) {
                            const err4 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err4];
                            } else {
                              vErrors.push(err4);
                            }
                            errors++;
                          }
                          var _valid1 = _errs21 === errors;
                          valid6 = valid6 || _valid1;
                          if (!valid6) {
                            const err5 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors++;
                            validate32.errors = vErrors;
                            return false;
                          } else {
                            errors = _errs18;
                            if (vErrors !== null) {
                              if (_errs18) {
                                vErrors.length = _errs18;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid5 = _errs17 === errors;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data7 = data.updatedAt;
          const _errs23 = errors;
          if (errors === _errs23) {
            if (errors === _errs23) {
              if (typeof data7 === "string") {
                if (func1(data7) > 64) {
                  validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data7)) {
                    validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs23 === errors;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err6 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err6];
    } else {
      vErrors.push(err6);
    }
    errors++;
    validate32.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors;
  if (valid0) {
    const _errs25 = errors;
    const _errs26 = errors;
    let valid7 = true;
    const _errs27 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data8 = data.status;
        if (!(data8 === "unconfigured" || data8 === "unavailable")) {
          const err7 = {};
          if (vErrors === null) {
            vErrors = [err7];
          } else {
            vErrors.push(err7);
          }
          errors++;
        }
      }
    }
    var _valid2 = _errs27 === errors;
    errors = _errs26;
    if (vErrors !== null) {
      if (_errs26) {
        vErrors.length = _errs26;
      } else {
        vErrors = null;
      }
    }
    if (_valid2) {
      const _errs29 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs30 = errors;
          if (data.data !== null) {
            validate32.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid9 = _errs30 === errors;
        } else {
          var valid9 = true;
        }
        if (valid9) {
          if (data.updatedAt !== void 0) {
            const _errs32 = errors;
            if (data.updatedAt !== null) {
              validate32.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid9 = _errs32 === errors;
          } else {
            var valid9 = true;
          }
        }
      }
      var _valid2 = _errs29 === errors;
      valid7 = _valid2;
      if (valid7) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid7) {
      const err8 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors++;
      validate32.errors = vErrors;
      return false;
    }
    var valid0 = _errs25 === errors;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs34 = errors;
      const _errs35 = errors;
      let valid10 = true;
      const _errs36 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data11 = data.status;
          if (!(data11 === "ok" || data11 === "unconfigured" || data11 === "loading")) {
            const err9 = {};
            if (vErrors === null) {
              vErrors = [err9];
            } else {
              vErrors.push(err9);
            }
            errors++;
          }
        }
      }
      var _valid3 = _errs36 === errors;
      errors = _errs35;
      if (vErrors !== null) {
        if (_errs35) {
          vErrors.length = _errs35;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid3) {
        const _errs38 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate32.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid3 = _errs38 === errors;
        valid10 = _valid3;
        if (valid10) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs41 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data13 = data.errorCode;
            if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
              validate32.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema44.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid3 = _errs41 === errors;
        valid10 = _valid3;
        if (valid10) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid10) {
        const err10 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err10];
        } else {
          vErrors.push(err10);
        }
        errors++;
        validate32.errors = vErrors;
        return false;
      }
      var valid0 = _errs34 === errors;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate32.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs43 = errors;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate32.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs43 === errors) {
          if (data.status !== void 0) {
            let data14 = data.status;
            const _errs44 = errors;
            if (!(data14 === "loading" || data14 === "ok" || data14 === "stale" || data14 === "unconfigured" || data14 === "unavailable")) {
              validate32.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema44.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid14 = _errs44 === errors;
          } else {
            var valid14 = true;
          }
          if (valid14) {
            if (data.sourceId !== void 0) {
              let data15 = data.sourceId;
              const _errs45 = errors;
              const _errs46 = errors;
              let valid15 = false;
              const _errs47 = errors;
              if (errors === _errs47) {
                if (typeof data15 === "string") {
                  if (func1(data15) > 128) {
                    const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err11];
                    } else {
                      vErrors.push(err11);
                    }
                    errors++;
                  } else {
                    if (func1(data15) < 1) {
                      const err12 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors++;
                    } else {
                      if (!pattern5.test(data15)) {
                        const err13 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err13];
                        } else {
                          vErrors.push(err13);
                        }
                        errors++;
                      }
                    }
                  }
                } else {
                  const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err14];
                  } else {
                    vErrors.push(err14);
                  }
                  errors++;
                }
              }
              var _valid4 = _errs47 === errors;
              valid15 = valid15 || _valid4;
              const _errs49 = errors;
              if (data15 !== null) {
                const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err15];
                } else {
                  vErrors.push(err15);
                }
                errors++;
              }
              var _valid4 = _errs49 === errors;
              valid15 = valid15 || _valid4;
              if (!valid15) {
                const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err16];
                } else {
                  vErrors.push(err16);
                }
                errors++;
                validate32.errors = vErrors;
                return false;
              } else {
                errors = _errs46;
                if (vErrors !== null) {
                  if (_errs46) {
                    vErrors.length = _errs46;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid14 = _errs45 === errors;
            } else {
              var valid14 = true;
            }
            if (valid14) {
              if (data.updatedAt !== void 0) {
                let data16 = data.updatedAt;
                const _errs51 = errors;
                const _errs52 = errors;
                let valid16 = false;
                const _errs53 = errors;
                if (errors === _errs53) {
                  if (errors === _errs53) {
                    if (typeof data16 === "string") {
                      if (func1(data16) > 64) {
                        const err17 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err17];
                        } else {
                          vErrors.push(err17);
                        }
                        errors++;
                      } else {
                        if (!formats0.validate(data16)) {
                          const err18 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err18];
                          } else {
                            vErrors.push(err18);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err19 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors++;
                    }
                  }
                }
                var _valid5 = _errs53 === errors;
                valid16 = valid16 || _valid5;
                const _errs55 = errors;
                if (data16 !== null) {
                  const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err20];
                  } else {
                    vErrors.push(err20);
                  }
                  errors++;
                }
                var _valid5 = _errs55 === errors;
                valid16 = valid16 || _valid5;
                if (!valid16) {
                  const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err21];
                  } else {
                    vErrors.push(err21);
                  }
                  errors++;
                  validate32.errors = vErrors;
                  return false;
                } else {
                  errors = _errs52;
                  if (vErrors !== null) {
                    if (_errs52) {
                      vErrors.length = _errs52;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid14 = _errs51 === errors;
              } else {
                var valid14 = true;
              }
              if (valid14) {
                if (data.data !== void 0) {
                  let data17 = data.data;
                  const _errs57 = errors;
                  const _errs58 = errors;
                  let valid17 = false;
                  const _errs59 = errors;
                  const _errs60 = errors;
                  if (errors === _errs60) {
                    if (data17 && typeof data17 == "object" && !Array.isArray(data17)) {
                      let missing2;
                      if (data17.player === void 0 && (missing2 = "player") || data17.status === void 0 && (missing2 = "status") || data17.title === void 0 && (missing2 = "title") || data17.artist === void 0 && (missing2 = "artist") || data17.artUri === void 0 && (missing2 = "artUri")) {
                        const err22 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err22];
                        } else {
                          vErrors.push(err22);
                        }
                        errors++;
                      } else {
                        const _errs62 = errors;
                        for (const key2 in data17) {
                          if (!(key2 === "player" || key2 === "status" || key2 === "title" || key2 === "artist" || key2 === "artUri")) {
                            const err23 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err23];
                            } else {
                              vErrors.push(err23);
                            }
                            errors++;
                            break;
                          }
                        }
                        if (_errs62 === errors) {
                          if (data17.player !== void 0) {
                            let data18 = data17.player;
                            const _errs63 = errors;
                            if (errors === _errs63) {
                              if (typeof data18 === "string") {
                                if (func1(data18) > 255) {
                                  const err24 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err24];
                                  } else {
                                    vErrors.push(err24);
                                  }
                                  errors++;
                                } else {
                                  if (func1(data18) < 1) {
                                    const err25 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err25];
                                    } else {
                                      vErrors.push(err25);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err26 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err26];
                                } else {
                                  vErrors.push(err26);
                                }
                                errors++;
                              }
                            }
                            var valid19 = _errs63 === errors;
                          } else {
                            var valid19 = true;
                          }
                          if (valid19) {
                            if (data17.status !== void 0) {
                              let data19 = data17.status;
                              const _errs65 = errors;
                              if (!(data19 === "playing" || data19 === "paused" || data19 === "stopped")) {
                                const err27 = { instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" };
                                if (vErrors === null) {
                                  vErrors = [err27];
                                } else {
                                  vErrors.push(err27);
                                }
                                errors++;
                              }
                              var valid19 = _errs65 === errors;
                            } else {
                              var valid19 = true;
                            }
                            if (valid19) {
                              if (data17.title !== void 0) {
                                let data20 = data17.title;
                                const _errs66 = errors;
                                if (errors === _errs66) {
                                  if (typeof data20 === "string") {
                                    if (func1(data20) > 4096) {
                                      const err28 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err28];
                                      } else {
                                        vErrors.push(err28);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err29 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err29];
                                    } else {
                                      vErrors.push(err29);
                                    }
                                    errors++;
                                  }
                                }
                                var valid19 = _errs66 === errors;
                              } else {
                                var valid19 = true;
                              }
                              if (valid19) {
                                if (data17.artist !== void 0) {
                                  let data21 = data17.artist;
                                  const _errs68 = errors;
                                  if (errors === _errs68) {
                                    if (typeof data21 === "string") {
                                      if (func1(data21) > 4096) {
                                        const err30 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err30];
                                        } else {
                                          vErrors.push(err30);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err31 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err31];
                                      } else {
                                        vErrors.push(err31);
                                      }
                                      errors++;
                                    }
                                  }
                                  var valid19 = _errs68 === errors;
                                } else {
                                  var valid19 = true;
                                }
                                if (valid19) {
                                  if (data17.artUri !== void 0) {
                                    let data22 = data17.artUri;
                                    const _errs70 = errors;
                                    const _errs71 = errors;
                                    let valid20 = false;
                                    const _errs72 = errors;
                                    if (errors === _errs72) {
                                      if (typeof data22 === "string") {
                                        if (func1(data22) > 4096) {
                                          const err32 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err32];
                                          } else {
                                            vErrors.push(err32);
                                          }
                                          errors++;
                                        } else {
                                          if (!pattern11.test(data22)) {
                                            const err33 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                            if (vErrors === null) {
                                              vErrors = [err33];
                                            } else {
                                              vErrors.push(err33);
                                            }
                                            errors++;
                                          }
                                        }
                                      } else {
                                        const err34 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err34];
                                        } else {
                                          vErrors.push(err34);
                                        }
                                        errors++;
                                      }
                                    }
                                    var _valid7 = _errs72 === errors;
                                    valid20 = valid20 || _valid7;
                                    const _errs74 = errors;
                                    if (data22 !== null) {
                                      const err35 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                      if (vErrors === null) {
                                        vErrors = [err35];
                                      } else {
                                        vErrors.push(err35);
                                      }
                                      errors++;
                                    }
                                    var _valid7 = _errs74 === errors;
                                    valid20 = valid20 || _valid7;
                                    if (!valid20) {
                                      const err36 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors++;
                                    } else {
                                      errors = _errs71;
                                      if (vErrors !== null) {
                                        if (_errs71) {
                                          vErrors.length = _errs71;
                                        } else {
                                          vErrors = null;
                                        }
                                      }
                                    }
                                    var valid19 = _errs70 === errors;
                                  } else {
                                    var valid19 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err37 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err37];
                      } else {
                        vErrors.push(err37);
                      }
                      errors++;
                    }
                  }
                  var _valid6 = _errs59 === errors;
                  valid17 = valid17 || _valid6;
                  const _errs76 = errors;
                  if (data17 !== null) {
                    const err38 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err38];
                    } else {
                      vErrors.push(err38);
                    }
                    errors++;
                  }
                  var _valid6 = _errs76 === errors;
                  valid17 = valid17 || _valid6;
                  if (!valid17) {
                    const err39 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err39];
                    } else {
                      vErrors.push(err39);
                    }
                    errors++;
                    validate32.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs58;
                    if (vErrors !== null) {
                      if (_errs58) {
                        vErrors.length = _errs58;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid14 = _errs57 === errors;
                } else {
                  var valid14 = true;
                }
                if (valid14) {
                  if (data.errorCode !== void 0) {
                    let data23 = data.errorCode;
                    const _errs78 = errors;
                    const _errs79 = errors;
                    let valid21 = false;
                    const _errs80 = errors;
                    if (!(data23 === "NETWORK_ERROR" || data23 === "INVALID_DATA" || data23 === "PAYLOAD_TOO_LARGE" || data23 === "EXPANSION_LIMIT" || data23 === "UNSUPPORTED_CALENDAR" || data23 === "UNKNOWN_TIME_ZONE" || data23 === "KEYRING_LOCKED" || data23 === "SECRET_DELETION_FAILED" || data23 === "AUTH_ERROR" || data23 === "RATE_LIMITED" || data23 === "NO_PLAYER" || data23 === "NO_INTERFACE" || data23 === "SERVICE_UNAVAILABLE" || data23 === "INTERNAL_ERROR")) {
                      const err40 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema44.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err40];
                      } else {
                        vErrors.push(err40);
                      }
                      errors++;
                    }
                    var _valid8 = _errs80 === errors;
                    valid21 = valid21 || _valid8;
                    const _errs81 = errors;
                    if (data23 !== null) {
                      const err41 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors++;
                    }
                    var _valid8 = _errs81 === errors;
                    valid21 = valid21 || _valid8;
                    if (!valid21) {
                      const err42 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err42];
                      } else {
                        vErrors.push(err42);
                      }
                      errors++;
                      validate32.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs79;
                      if (vErrors !== null) {
                        if (_errs79) {
                          vErrors.length = _errs79;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid14 = _errs78 === errors;
                  } else {
                    var valid14 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate32.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate32.errors = vErrors;
  return errors === 0;
}
validate32.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate20(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate20.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.schemaVersion === void 0 && (missing0 = "schemaVersion") || data.generatedAt === void 0 && (missing0 = "generatedAt") || data.revisions === void 0 && (missing0 = "revisions") || data.calendar === void 0 && (missing0 = "calendar") || data.weather === void 0 && (missing0 = "weather") || data.system === void 0 && (missing0 = "system") || data.network === void 0 && (missing0 = "network") || data.media === void 0 && (missing0 = "media")) {
        validate20.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors;
        for (const key0 in data) {
          if (!(key0 === "schemaVersion" || key0 === "generatedAt" || key0 === "revisions" || key0 === "calendar" || key0 === "weather" || key0 === "system" || key0 === "network" || key0 === "media")) {
            validate20.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors) {
          if (data.schemaVersion !== void 0) {
            const _errs2 = errors;
            if (1 !== data.schemaVersion) {
              validate20.errors = [{ instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.generatedAt !== void 0) {
              let data1 = data.generatedAt;
              const _errs3 = errors;
              if (errors === _errs3) {
                if (errors === _errs3) {
                  if (typeof data1 === "string") {
                    if (func1(data1) > 64) {
                      validate20.errors = [{ instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                      return false;
                    } else {
                      if (!formats0.validate(data1)) {
                        validate20.errors = [{ instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                        return false;
                      }
                    }
                  } else {
                    validate20.errors = [{ instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
              }
              var valid0 = _errs3 === errors;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.revisions !== void 0) {
                let data2 = data.revisions;
                const _errs5 = errors;
                if (errors === _errs5) {
                  if (data2 && typeof data2 == "object" && !Array.isArray(data2)) {
                    let missing1;
                    if (data2.calendar === void 0 && (missing1 = "calendar") || data2.weather === void 0 && (missing1 = "weather") || data2.system === void 0 && (missing1 = "system") || data2.network === void 0 && (missing1 = "network") || data2.media === void 0 && (missing1 = "media")) {
                      validate20.errors = [{ instancePath: instancePath + "/revisions", schemaPath: "#/properties/revisions/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                      return false;
                    } else {
                      const _errs7 = errors;
                      for (const key1 in data2) {
                        if (!(key1 === "calendar" || key1 === "weather" || key1 === "system" || key1 === "network" || key1 === "media")) {
                          validate20.errors = [{ instancePath: instancePath + "/revisions", schemaPath: "#/properties/revisions/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                          return false;
                          break;
                        }
                      }
                      if (_errs7 === errors) {
                        if (data2.calendar !== void 0) {
                          let data3 = data2.calendar;
                          const _errs8 = errors;
                          if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                            validate20.errors = [{ instancePath: instancePath + "/revisions/calendar", schemaPath: "#/properties/revisions/properties/calendar/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                            return false;
                          }
                          if (errors === _errs8) {
                            if (typeof data3 == "number" && isFinite(data3)) {
                              if (data3 > 4294967295 || isNaN(data3)) {
                                validate20.errors = [{ instancePath: instancePath + "/revisions/calendar", schemaPath: "#/properties/revisions/properties/calendar/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                return false;
                              } else {
                                if (data3 < 0 || isNaN(data3)) {
                                  validate20.errors = [{ instancePath: instancePath + "/revisions/calendar", schemaPath: "#/properties/revisions/properties/calendar/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                  return false;
                                }
                              }
                            }
                          }
                          var valid1 = _errs8 === errors;
                        } else {
                          var valid1 = true;
                        }
                        if (valid1) {
                          if (data2.weather !== void 0) {
                            let data4 = data2.weather;
                            const _errs10 = errors;
                            if (!(typeof data4 == "number" && (!(data4 % 1) && !isNaN(data4)) && isFinite(data4))) {
                              validate20.errors = [{ instancePath: instancePath + "/revisions/weather", schemaPath: "#/properties/revisions/properties/weather/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                              return false;
                            }
                            if (errors === _errs10) {
                              if (typeof data4 == "number" && isFinite(data4)) {
                                if (data4 > 4294967295 || isNaN(data4)) {
                                  validate20.errors = [{ instancePath: instancePath + "/revisions/weather", schemaPath: "#/properties/revisions/properties/weather/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                  return false;
                                } else {
                                  if (data4 < 0 || isNaN(data4)) {
                                    validate20.errors = [{ instancePath: instancePath + "/revisions/weather", schemaPath: "#/properties/revisions/properties/weather/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                    return false;
                                  }
                                }
                              }
                            }
                            var valid1 = _errs10 === errors;
                          } else {
                            var valid1 = true;
                          }
                          if (valid1) {
                            if (data2.system !== void 0) {
                              let data5 = data2.system;
                              const _errs12 = errors;
                              if (!(typeof data5 == "number" && (!(data5 % 1) && !isNaN(data5)) && isFinite(data5))) {
                                validate20.errors = [{ instancePath: instancePath + "/revisions/system", schemaPath: "#/properties/revisions/properties/system/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                return false;
                              }
                              if (errors === _errs12) {
                                if (typeof data5 == "number" && isFinite(data5)) {
                                  if (data5 > 4294967295 || isNaN(data5)) {
                                    validate20.errors = [{ instancePath: instancePath + "/revisions/system", schemaPath: "#/properties/revisions/properties/system/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                    return false;
                                  } else {
                                    if (data5 < 0 || isNaN(data5)) {
                                      validate20.errors = [{ instancePath: instancePath + "/revisions/system", schemaPath: "#/properties/revisions/properties/system/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                      return false;
                                    }
                                  }
                                }
                              }
                              var valid1 = _errs12 === errors;
                            } else {
                              var valid1 = true;
                            }
                            if (valid1) {
                              if (data2.network !== void 0) {
                                let data6 = data2.network;
                                const _errs14 = errors;
                                if (!(typeof data6 == "number" && (!(data6 % 1) && !isNaN(data6)) && isFinite(data6))) {
                                  validate20.errors = [{ instancePath: instancePath + "/revisions/network", schemaPath: "#/properties/revisions/properties/network/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                  return false;
                                }
                                if (errors === _errs14) {
                                  if (typeof data6 == "number" && isFinite(data6)) {
                                    if (data6 > 4294967295 || isNaN(data6)) {
                                      validate20.errors = [{ instancePath: instancePath + "/revisions/network", schemaPath: "#/properties/revisions/properties/network/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                      return false;
                                    } else {
                                      if (data6 < 0 || isNaN(data6)) {
                                        validate20.errors = [{ instancePath: instancePath + "/revisions/network", schemaPath: "#/properties/revisions/properties/network/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                        return false;
                                      }
                                    }
                                  }
                                }
                                var valid1 = _errs14 === errors;
                              } else {
                                var valid1 = true;
                              }
                              if (valid1) {
                                if (data2.media !== void 0) {
                                  let data7 = data2.media;
                                  const _errs16 = errors;
                                  if (!(typeof data7 == "number" && (!(data7 % 1) && !isNaN(data7)) && isFinite(data7))) {
                                    validate20.errors = [{ instancePath: instancePath + "/revisions/media", schemaPath: "#/properties/revisions/properties/media/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                    return false;
                                  }
                                  if (errors === _errs16) {
                                    if (typeof data7 == "number" && isFinite(data7)) {
                                      if (data7 > 4294967295 || isNaN(data7)) {
                                        validate20.errors = [{ instancePath: instancePath + "/revisions/media", schemaPath: "#/properties/revisions/properties/media/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                                        return false;
                                      } else {
                                        if (data7 < 0 || isNaN(data7)) {
                                          validate20.errors = [{ instancePath: instancePath + "/revisions/media", schemaPath: "#/properties/revisions/properties/media/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                          return false;
                                        }
                                      }
                                    }
                                  }
                                  var valid1 = _errs16 === errors;
                                } else {
                                  var valid1 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    validate20.errors = [{ instancePath: instancePath + "/revisions", schemaPath: "#/properties/revisions/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                    return false;
                  }
                }
                var valid0 = _errs5 === errors;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.calendar !== void 0) {
                  const _errs18 = errors;
                  if (!validate21(data.calendar, { instancePath: instancePath + "/calendar", parentData: data, parentDataProperty: "calendar", rootData, dynamicAnchors })) {
                    vErrors = vErrors === null ? validate21.errors : vErrors.concat(validate21.errors);
                    errors = vErrors.length;
                  }
                  var valid0 = _errs18 === errors;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.weather !== void 0) {
                    const _errs19 = errors;
                    if (!validate26(data.weather, { instancePath: instancePath + "/weather", parentData: data, parentDataProperty: "weather", rootData, dynamicAnchors })) {
                      vErrors = vErrors === null ? validate26.errors : vErrors.concat(validate26.errors);
                      errors = vErrors.length;
                    }
                    var valid0 = _errs19 === errors;
                  } else {
                    var valid0 = true;
                  }
                  if (valid0) {
                    if (data.system !== void 0) {
                      const _errs20 = errors;
                      if (!validate28(data.system, { instancePath: instancePath + "/system", parentData: data, parentDataProperty: "system", rootData, dynamicAnchors })) {
                        vErrors = vErrors === null ? validate28.errors : vErrors.concat(validate28.errors);
                        errors = vErrors.length;
                      }
                      var valid0 = _errs20 === errors;
                    } else {
                      var valid0 = true;
                    }
                    if (valid0) {
                      if (data.network !== void 0) {
                        const _errs21 = errors;
                        if (!validate30(data.network, { instancePath: instancePath + "/network", parentData: data, parentDataProperty: "network", rootData, dynamicAnchors })) {
                          vErrors = vErrors === null ? validate30.errors : vErrors.concat(validate30.errors);
                          errors = vErrors.length;
                        }
                        var valid0 = _errs21 === errors;
                      } else {
                        var valid0 = true;
                      }
                      if (valid0) {
                        if (data.media !== void 0) {
                          const _errs22 = errors;
                          if (!validate32(data.media, { instancePath: instancePath + "/media", parentData: data, parentDataProperty: "media", rootData, dynamicAnchors })) {
                            vErrors = vErrors === null ? validate32.errors : vErrors.concat(validate32.errors);
                            errors = vErrors.length;
                          }
                          var valid0 = _errs22 === errors;
                        } else {
                          var valid0 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate20.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate20.errors = vErrors;
  return errors === 0;
}
validate20.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate34(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate34.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.calendarEnabled === void 0 && (missing0 = "calendarEnabled") || data.calendarSecretDeletionPending === void 0 && (missing0 = "calendarSecretDeletionPending") || data.weatherLocation === void 0 && (missing0 = "weatherLocation") || data.networkInterface === void 0 && (missing0 = "networkInterface")) {
        validate34.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors;
        for (const key0 in data) {
          if (!(key0 === "calendarEnabled" || key0 === "calendarSecretDeletionPending" || key0 === "weatherLocation" || key0 === "networkInterface")) {
            validate34.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors) {
          if (data.calendarEnabled !== void 0) {
            const _errs2 = errors;
            if (typeof data.calendarEnabled !== "boolean") {
              validate34.errors = [{ instancePath: instancePath + "/calendarEnabled", schemaPath: "#/properties/calendarEnabled/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
              return false;
            }
            var valid0 = _errs2 === errors;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.calendarSecretDeletionPending !== void 0) {
              const _errs4 = errors;
              if (typeof data.calendarSecretDeletionPending !== "boolean") {
                validate34.errors = [{ instancePath: instancePath + "/calendarSecretDeletionPending", schemaPath: "#/properties/calendarSecretDeletionPending/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                return false;
              }
              var valid0 = _errs4 === errors;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weatherLocation !== void 0) {
                let data2 = data.weatherLocation;
                const _errs6 = errors;
                const _errs7 = errors;
                let valid1 = false;
                const _errs8 = errors;
                const _errs9 = errors;
                if (errors === _errs9) {
                  if (data2 && typeof data2 == "object" && !Array.isArray(data2)) {
                    let missing1;
                    if (data2.id === void 0 && (missing1 = "id") || data2.label === void 0 && (missing1 = "label") || data2.latitude === void 0 && (missing1 = "latitude") || data2.longitude === void 0 && (missing1 = "longitude") || data2.timeZone === void 0 && (missing1 = "timeZone")) {
                      const err0 = { instancePath: instancePath + "/weatherLocation", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" };
                      if (vErrors === null) {
                        vErrors = [err0];
                      } else {
                        vErrors.push(err0);
                      }
                      errors++;
                    } else {
                      const _errs11 = errors;
                      for (const key1 in data2) {
                        if (!(key1 === "id" || key1 === "label" || key1 === "latitude" || key1 === "longitude" || key1 === "timeZone")) {
                          const err1 = { instancePath: instancePath + "/weatherLocation", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
                          if (vErrors === null) {
                            vErrors = [err1];
                          } else {
                            vErrors.push(err1);
                          }
                          errors++;
                          break;
                        }
                      }
                      if (_errs11 === errors) {
                        if (data2.id !== void 0) {
                          let data3 = data2.id;
                          const _errs12 = errors;
                          if (errors === _errs12) {
                            if (typeof data3 === "string") {
                              if (func1(data3) > 128) {
                                const err2 = { instancePath: instancePath + "/weatherLocation/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                                if (vErrors === null) {
                                  vErrors = [err2];
                                } else {
                                  vErrors.push(err2);
                                }
                                errors++;
                              } else {
                                if (func1(data3) < 1) {
                                  const err3 = { instancePath: instancePath + "/weatherLocation/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err3];
                                  } else {
                                    vErrors.push(err3);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err4 = { instancePath: instancePath + "/weatherLocation/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err4];
                              } else {
                                vErrors.push(err4);
                              }
                              errors++;
                            }
                          }
                          var valid3 = _errs12 === errors;
                        } else {
                          var valid3 = true;
                        }
                        if (valid3) {
                          if (data2.label !== void 0) {
                            let data4 = data2.label;
                            const _errs14 = errors;
                            if (errors === _errs14) {
                              if (typeof data4 === "string") {
                                if (func1(data4) > 512) {
                                  const err5 = { instancePath: instancePath + "/weatherLocation/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err5];
                                  } else {
                                    vErrors.push(err5);
                                  }
                                  errors++;
                                } else {
                                  if (func1(data4) < 1) {
                                    const err6 = { instancePath: instancePath + "/weatherLocation/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err6];
                                    } else {
                                      vErrors.push(err6);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err7 = { instancePath: instancePath + "/weatherLocation/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err7];
                                } else {
                                  vErrors.push(err7);
                                }
                                errors++;
                              }
                            }
                            var valid3 = _errs14 === errors;
                          } else {
                            var valid3 = true;
                          }
                          if (valid3) {
                            if (data2.latitude !== void 0) {
                              let data5 = data2.latitude;
                              const _errs16 = errors;
                              if (errors === _errs16) {
                                if (typeof data5 == "number" && isFinite(data5)) {
                                  if (data5 > 90 || isNaN(data5)) {
                                    const err8 = { instancePath: instancePath + "/weatherLocation/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors++;
                                  } else {
                                    if (data5 < -90 || isNaN(data5)) {
                                      const err9 = { instancePath: instancePath + "/weatherLocation/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" };
                                      if (vErrors === null) {
                                        vErrors = [err9];
                                      } else {
                                        vErrors.push(err9);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err10 = { instancePath: instancePath + "/weatherLocation/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err10];
                                  } else {
                                    vErrors.push(err10);
                                  }
                                  errors++;
                                }
                              }
                              var valid3 = _errs16 === errors;
                            } else {
                              var valid3 = true;
                            }
                            if (valid3) {
                              if (data2.longitude !== void 0) {
                                let data6 = data2.longitude;
                                const _errs18 = errors;
                                if (errors === _errs18) {
                                  if (typeof data6 == "number" && isFinite(data6)) {
                                    if (data6 > 180 || isNaN(data6)) {
                                      const err11 = { instancePath: instancePath + "/weatherLocation/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" };
                                      if (vErrors === null) {
                                        vErrors = [err11];
                                      } else {
                                        vErrors.push(err11);
                                      }
                                      errors++;
                                    } else {
                                      if (data6 < -180 || isNaN(data6)) {
                                        const err12 = { instancePath: instancePath + "/weatherLocation/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" };
                                        if (vErrors === null) {
                                          vErrors = [err12];
                                        } else {
                                          vErrors.push(err12);
                                        }
                                        errors++;
                                      }
                                    }
                                  } else {
                                    const err13 = { instancePath: instancePath + "/weatherLocation/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err13];
                                    } else {
                                      vErrors.push(err13);
                                    }
                                    errors++;
                                  }
                                }
                                var valid3 = _errs18 === errors;
                              } else {
                                var valid3 = true;
                              }
                              if (valid3) {
                                if (data2.timeZone !== void 0) {
                                  let data7 = data2.timeZone;
                                  const _errs20 = errors;
                                  if (errors === _errs20) {
                                    if (typeof data7 === "string") {
                                      if (func1(data7) > 255) {
                                        const err14 = { instancePath: instancePath + "/weatherLocation/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err14];
                                        } else {
                                          vErrors.push(err14);
                                        }
                                        errors++;
                                      } else {
                                        if (func1(data7) < 1) {
                                          const err15 = { instancePath: instancePath + "/weatherLocation/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err15];
                                          } else {
                                            vErrors.push(err15);
                                          }
                                          errors++;
                                        }
                                      }
                                    } else {
                                      const err16 = { instancePath: instancePath + "/weatherLocation/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err16];
                                      } else {
                                        vErrors.push(err16);
                                      }
                                      errors++;
                                    }
                                  }
                                  var valid3 = _errs20 === errors;
                                } else {
                                  var valid3 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    const err17 = { instancePath: instancePath + "/weatherLocation", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors++;
                  }
                }
                var _valid0 = _errs8 === errors;
                valid1 = valid1 || _valid0;
                const _errs22 = errors;
                if (data2 !== null) {
                  const err18 = { instancePath: instancePath + "/weatherLocation", schemaPath: "#/properties/weatherLocation/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err18];
                  } else {
                    vErrors.push(err18);
                  }
                  errors++;
                }
                var _valid0 = _errs22 === errors;
                valid1 = valid1 || _valid0;
                if (!valid1) {
                  const err19 = { instancePath: instancePath + "/weatherLocation", schemaPath: "#/properties/weatherLocation/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err19];
                  } else {
                    vErrors.push(err19);
                  }
                  errors++;
                  validate34.errors = vErrors;
                  return false;
                } else {
                  errors = _errs7;
                  if (vErrors !== null) {
                    if (_errs7) {
                      vErrors.length = _errs7;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid0 = _errs6 === errors;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.networkInterface !== void 0) {
                  let data8 = data.networkInterface;
                  const _errs24 = errors;
                  if (errors === _errs24) {
                    if (typeof data8 === "string") {
                      if (func1(data8) > 64) {
                        validate34.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                        return false;
                      } else {
                        if (func1(data8) < 1) {
                          validate34.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate34.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid0 = _errs24 === errors;
                } else {
                  var valid0 = true;
                }
              }
            }
          }
        }
      }
    } else {
      validate34.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate34.errors = vErrors;
  return errors === 0;
}
validate34.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate35(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate35.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.month === void 0 && (missing0 = "month") || data.timeZone === void 0 && (missing0 = "timeZone") || data.weekStart === void 0 && (missing0 = "weekStart")) {
        validate35.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors;
        for (const key0 in data) {
          if (!(key0 === "month" || key0 === "timeZone" || key0 === "weekStart")) {
            validate35.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors) {
          if (data.month !== void 0) {
            let data0 = data.month;
            const _errs2 = errors;
            if (errors === _errs2) {
              if (typeof data0 === "string") {
                if (func1(data0) > 7) {
                  validate35.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                  return false;
                } else {
                  if (!pattern4.test(data0)) {
                    validate35.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                    return false;
                  }
                }
              } else {
                validate35.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
            var valid0 = _errs2 === errors;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.timeZone !== void 0) {
              let data1 = data.timeZone;
              const _errs4 = errors;
              if (errors === _errs4) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 255) {
                    validate35.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate35.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate35.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs4 === errors;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weekStart !== void 0) {
                let data2 = data.weekStart;
                const _errs6 = errors;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate35.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors === _errs6) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 6 || isNaN(data2)) {
                      validate35.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate35.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs6 === errors;
              } else {
                var valid0 = true;
              }
            }
          }
        }
      }
    } else {
      validate35.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate35.errors = vErrors;
  return errors === 0;
}
validate35.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate36(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate36.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs0 = errors;
  let valid0 = false;
  const _errs1 = errors;
  const _errs2 = errors;
  if (errors === _errs2) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.id === void 0 && (missing0 = "id") || data.label === void 0 && (missing0 = "label") || data.latitude === void 0 && (missing0 = "latitude") || data.longitude === void 0 && (missing0 = "longitude") || data.timeZone === void 0 && (missing0 = "timeZone")) {
        const err0 = { instancePath, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" };
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      } else {
        const _errs4 = errors;
        for (const key0 in data) {
          if (!(key0 === "id" || key0 === "label" || key0 === "latitude" || key0 === "longitude" || key0 === "timeZone")) {
            const err1 = { instancePath, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err1];
            } else {
              vErrors.push(err1);
            }
            errors++;
            break;
          }
        }
        if (_errs4 === errors) {
          if (data.id !== void 0) {
            let data0 = data.id;
            const _errs5 = errors;
            if (errors === _errs5) {
              if (typeof data0 === "string") {
                if (func1(data0) > 128) {
                  const err2 = { instancePath: instancePath + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                  if (vErrors === null) {
                    vErrors = [err2];
                  } else {
                    vErrors.push(err2);
                  }
                  errors++;
                } else {
                  if (func1(data0) < 1) {
                    const err3 = { instancePath: instancePath + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                    if (vErrors === null) {
                      vErrors = [err3];
                    } else {
                      vErrors.push(err3);
                    }
                    errors++;
                  }
                }
              } else {
                const err4 = { instancePath: instancePath + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err4];
                } else {
                  vErrors.push(err4);
                }
                errors++;
              }
            }
            var valid2 = _errs5 === errors;
          } else {
            var valid2 = true;
          }
          if (valid2) {
            if (data.label !== void 0) {
              let data1 = data.label;
              const _errs7 = errors;
              if (errors === _errs7) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 512) {
                    const err5 = { instancePath: instancePath + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                    if (vErrors === null) {
                      vErrors = [err5];
                    } else {
                      vErrors.push(err5);
                    }
                    errors++;
                  } else {
                    if (func1(data1) < 1) {
                      const err6 = { instancePath: instancePath + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err6];
                      } else {
                        vErrors.push(err6);
                      }
                      errors++;
                    }
                  }
                } else {
                  const err7 = { instancePath: instancePath + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err7];
                  } else {
                    vErrors.push(err7);
                  }
                  errors++;
                }
              }
              var valid2 = _errs7 === errors;
            } else {
              var valid2 = true;
            }
            if (valid2) {
              if (data.latitude !== void 0) {
                let data2 = data.latitude;
                const _errs9 = errors;
                if (errors === _errs9) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 90 || isNaN(data2)) {
                      const err8 = { instancePath: instancePath + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" };
                      if (vErrors === null) {
                        vErrors = [err8];
                      } else {
                        vErrors.push(err8);
                      }
                      errors++;
                    } else {
                      if (data2 < -90 || isNaN(data2)) {
                        const err9 = { instancePath: instancePath + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" };
                        if (vErrors === null) {
                          vErrors = [err9];
                        } else {
                          vErrors.push(err9);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err10 = { instancePath: instancePath + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                    if (vErrors === null) {
                      vErrors = [err10];
                    } else {
                      vErrors.push(err10);
                    }
                    errors++;
                  }
                }
                var valid2 = _errs9 === errors;
              } else {
                var valid2 = true;
              }
              if (valid2) {
                if (data.longitude !== void 0) {
                  let data3 = data.longitude;
                  const _errs11 = errors;
                  if (errors === _errs11) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 180 || isNaN(data3)) {
                        const err11 = { instancePath: instancePath + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" };
                        if (vErrors === null) {
                          vErrors = [err11];
                        } else {
                          vErrors.push(err11);
                        }
                        errors++;
                      } else {
                        if (data3 < -180 || isNaN(data3)) {
                          const err12 = { instancePath: instancePath + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" };
                          if (vErrors === null) {
                            vErrors = [err12];
                          } else {
                            vErrors.push(err12);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err13 = { instancePath: instancePath + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                      if (vErrors === null) {
                        vErrors = [err13];
                      } else {
                        vErrors.push(err13);
                      }
                      errors++;
                    }
                  }
                  var valid2 = _errs11 === errors;
                } else {
                  var valid2 = true;
                }
                if (valid2) {
                  if (data.timeZone !== void 0) {
                    let data4 = data.timeZone;
                    const _errs13 = errors;
                    if (errors === _errs13) {
                      if (typeof data4 === "string") {
                        if (func1(data4) > 255) {
                          const err14 = { instancePath: instancePath + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                          if (vErrors === null) {
                            vErrors = [err14];
                          } else {
                            vErrors.push(err14);
                          }
                          errors++;
                        } else {
                          if (func1(data4) < 1) {
                            const err15 = { instancePath: instancePath + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err15];
                            } else {
                              vErrors.push(err15);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err16 = { instancePath: instancePath + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors++;
                      }
                    }
                    var valid2 = _errs13 === errors;
                  } else {
                    var valid2 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      const err17 = { instancePath, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" };
      if (vErrors === null) {
        vErrors = [err17];
      } else {
        vErrors.push(err17);
      }
      errors++;
    }
  }
  var _valid0 = _errs1 === errors;
  valid0 = valid0 || _valid0;
  if (_valid0) {
    var props0 = true;
  }
  const _errs15 = errors;
  if (data !== null) {
    const err18 = { instancePath, schemaPath: "#/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
    if (vErrors === null) {
      vErrors = [err18];
    } else {
      vErrors.push(err18);
    }
    errors++;
  }
  var _valid0 = _errs15 === errors;
  valid0 = valid0 || _valid0;
  if (!valid0) {
    const err19 = { instancePath, schemaPath: "#/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
    if (vErrors === null) {
      vErrors = [err19];
    } else {
      vErrors.push(err19);
    }
    errors++;
    validate36.errors = vErrors;
    return false;
  } else {
    errors = _errs0;
    if (vErrors !== null) {
      if (_errs0) {
        vErrors.length = _errs0;
      } else {
        vErrors = null;
      }
    }
  }
  validate36.errors = vErrors;
  evaluated0.props = props0;
  return errors === 0;
}
validate36.evaluated = { "dynamicProps": true, "dynamicItems": false };
function validate37(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate37.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors === 0) {
    if (Array.isArray(data)) {
      if (data.length > 20) {
        validate37.errors = [{ instancePath, schemaPath: "#/maxItems", keyword: "maxItems", params: { limit: 20 }, message: "must NOT have more than 20 items" }];
        return false;
      } else {
        var valid0 = true;
        const len0 = data.length;
        for (let i0 = 0; i0 < len0; i0++) {
          let data0 = data[i0];
          const _errs1 = errors;
          const _errs2 = errors;
          if (errors === _errs2) {
            if (data0 && typeof data0 == "object" && !Array.isArray(data0)) {
              let missing0;
              if (data0.id === void 0 && (missing0 = "id") || data0.label === void 0 && (missing0 = "label") || data0.latitude === void 0 && (missing0 = "latitude") || data0.longitude === void 0 && (missing0 = "longitude") || data0.timeZone === void 0 && (missing0 = "timeZone")) {
                validate37.errors = [{ instancePath: instancePath + "/" + i0, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
                return false;
              } else {
                const _errs4 = errors;
                for (const key0 in data0) {
                  if (!(key0 === "id" || key0 === "label" || key0 === "latitude" || key0 === "longitude" || key0 === "timeZone")) {
                    validate37.errors = [{ instancePath: instancePath + "/" + i0, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                    return false;
                    break;
                  }
                }
                if (_errs4 === errors) {
                  if (data0.id !== void 0) {
                    let data1 = data0.id;
                    const _errs5 = errors;
                    if (errors === _errs5) {
                      if (typeof data1 === "string") {
                        if (func1(data1) > 128) {
                          validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" }];
                          return false;
                        } else {
                          if (func1(data1) < 1) {
                            validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          }
                        }
                      } else {
                        validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid2 = _errs5 === errors;
                  } else {
                    var valid2 = true;
                  }
                  if (valid2) {
                    if (data0.label !== void 0) {
                      let data2 = data0.label;
                      const _errs7 = errors;
                      if (errors === _errs7) {
                        if (typeof data2 === "string") {
                          if (func1(data2) > 512) {
                            validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                            return false;
                          } else {
                            if (func1(data2) < 1) {
                              validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                              return false;
                            }
                          }
                        } else {
                          validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                          return false;
                        }
                      }
                      var valid2 = _errs7 === errors;
                    } else {
                      var valid2 = true;
                    }
                    if (valid2) {
                      if (data0.latitude !== void 0) {
                        let data3 = data0.latitude;
                        const _errs9 = errors;
                        if (errors === _errs9) {
                          if (typeof data3 == "number" && isFinite(data3)) {
                            if (data3 > 90 || isNaN(data3)) {
                              validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" }];
                              return false;
                            } else {
                              if (data3 < -90 || isNaN(data3)) {
                                validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" }];
                                return false;
                              }
                            }
                          } else {
                            validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                            return false;
                          }
                        }
                        var valid2 = _errs9 === errors;
                      } else {
                        var valid2 = true;
                      }
                      if (valid2) {
                        if (data0.longitude !== void 0) {
                          let data4 = data0.longitude;
                          const _errs11 = errors;
                          if (errors === _errs11) {
                            if (typeof data4 == "number" && isFinite(data4)) {
                              if (data4 > 180 || isNaN(data4)) {
                                validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" }];
                                return false;
                              } else {
                                if (data4 < -180 || isNaN(data4)) {
                                  validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" }];
                                  return false;
                                }
                              }
                            } else {
                              validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                              return false;
                            }
                          }
                          var valid2 = _errs11 === errors;
                        } else {
                          var valid2 = true;
                        }
                        if (valid2) {
                          if (data0.timeZone !== void 0) {
                            let data5 = data0.timeZone;
                            const _errs13 = errors;
                            if (errors === _errs13) {
                              if (typeof data5 === "string") {
                                if (func1(data5) > 255) {
                                  validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                                  return false;
                                } else {
                                  if (func1(data5) < 1) {
                                    validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                    return false;
                                  }
                                }
                              } else {
                                validate37.errors = [{ instancePath: instancePath + "/" + i0 + "/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                return false;
                              }
                            }
                            var valid2 = _errs13 === errors;
                          } else {
                            var valid2 = true;
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              validate37.errors = [{ instancePath: instancePath + "/" + i0, schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
              return false;
            }
          }
          var valid0 = _errs1 === errors;
          if (!valid0) {
            break;
          }
        }
      }
    } else {
      validate37.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
      return false;
    }
  }
  validate37.errors = vErrors;
  return errors === 0;
}
validate37.evaluated = { "items": true, "dynamicProps": false, "dynamicItems": false };
var calendar = validate38;
function validate38(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate38.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors;
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        const _errs6 = errors;
        if (!validate22(data.data, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
          vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
          errors = vErrors.length;
        }
        var valid3 = _errs6 === errors;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data2 = data.updatedAt;
          const _errs7 = errors;
          if (errors === _errs7) {
            if (errors === _errs7) {
              if (typeof data2 === "string") {
                if (func1(data2) > 64) {
                  validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data2)) {
                    validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs7 === errors;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err1 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err1];
    } else {
      vErrors.push(err1);
    }
    errors++;
    validate38.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors;
  if (valid0) {
    const _errs9 = errors;
    const _errs10 = errors;
    let valid4 = true;
    const _errs11 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data3 = data.status;
        if (!(data3 === "unconfigured" || data3 === "unavailable")) {
          const err2 = {};
          if (vErrors === null) {
            vErrors = [err2];
          } else {
            vErrors.push(err2);
          }
          errors++;
        }
      }
    }
    var _valid1 = _errs11 === errors;
    errors = _errs10;
    if (vErrors !== null) {
      if (_errs10) {
        vErrors.length = _errs10;
      } else {
        vErrors = null;
      }
    }
    if (_valid1) {
      const _errs13 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs14 = errors;
          if (data.data !== null) {
            validate38.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid6 = _errs14 === errors;
        } else {
          var valid6 = true;
        }
        if (valid6) {
          if (data.updatedAt !== void 0) {
            const _errs16 = errors;
            if (data.updatedAt !== null) {
              validate38.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid6 = _errs16 === errors;
          } else {
            var valid6 = true;
          }
        }
      }
      var _valid1 = _errs13 === errors;
      valid4 = _valid1;
      if (valid4) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid4) {
      const err3 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors++;
      validate38.errors = vErrors;
      return false;
    }
    var valid0 = _errs9 === errors;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs18 = errors;
      const _errs19 = errors;
      let valid7 = true;
      const _errs20 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data6 = data.status;
          if (!(data6 === "ok" || data6 === "unconfigured" || data6 === "loading")) {
            const err4 = {};
            if (vErrors === null) {
              vErrors = [err4];
            } else {
              vErrors.push(err4);
            }
            errors++;
          }
        }
      }
      var _valid2 = _errs20 === errors;
      errors = _errs19;
      if (vErrors !== null) {
        if (_errs19) {
          vErrors.length = _errs19;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid2) {
        const _errs22 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate38.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid2 = _errs22 === errors;
        valid7 = _valid2;
        if (valid7) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs25 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data8 = data.errorCode;
            if (!(data8 === "NETWORK_ERROR" || data8 === "INVALID_DATA" || data8 === "PAYLOAD_TOO_LARGE" || data8 === "EXPANSION_LIMIT" || data8 === "UNSUPPORTED_CALENDAR" || data8 === "UNKNOWN_TIME_ZONE" || data8 === "KEYRING_LOCKED" || data8 === "SECRET_DELETION_FAILED" || data8 === "AUTH_ERROR" || data8 === "RATE_LIMITED" || data8 === "NO_PLAYER" || data8 === "NO_INTERFACE" || data8 === "SERVICE_UNAVAILABLE" || data8 === "INTERNAL_ERROR")) {
              validate38.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema32.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid2 = _errs25 === errors;
        valid7 = _valid2;
        if (valid7) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid7) {
        const err5 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err5];
        } else {
          vErrors.push(err5);
        }
        errors++;
        validate38.errors = vErrors;
        return false;
      }
      var valid0 = _errs18 === errors;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.status === void 0 && (missing0 = "status") || data.sourceId === void 0 && (missing0 = "sourceId") || data.updatedAt === void 0 && (missing0 = "updatedAt") || data.data === void 0 && (missing0 = "data") || data.errorCode === void 0 && (missing0 = "errorCode")) {
        validate38.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs27 = errors;
        for (const key0 in data) {
          if (!(key0 === "status" || key0 === "sourceId" || key0 === "updatedAt" || key0 === "data" || key0 === "errorCode")) {
            validate38.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs27 === errors) {
          if (data.status !== void 0) {
            let data9 = data.status;
            const _errs28 = errors;
            if (!(data9 === "loading" || data9 === "ok" || data9 === "stale" || data9 === "unconfigured" || data9 === "unavailable")) {
              validate38.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema32.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid11 = _errs28 === errors;
          } else {
            var valid11 = true;
          }
          if (valid11) {
            if (data.sourceId !== void 0) {
              let data10 = data.sourceId;
              const _errs29 = errors;
              const _errs30 = errors;
              let valid12 = false;
              const _errs31 = errors;
              if (errors === _errs31) {
                if (typeof data10 === "string") {
                  if (func1(data10) > 128) {
                    const err6 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err6];
                    } else {
                      vErrors.push(err6);
                    }
                    errors++;
                  } else {
                    if (func1(data10) < 1) {
                      const err7 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err7];
                      } else {
                        vErrors.push(err7);
                      }
                      errors++;
                    } else {
                      if (!pattern5.test(data10)) {
                        const err8 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors++;
                      }
                    }
                  }
                } else {
                  const err9 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err9];
                  } else {
                    vErrors.push(err9);
                  }
                  errors++;
                }
              }
              var _valid3 = _errs31 === errors;
              valid12 = valid12 || _valid3;
              const _errs33 = errors;
              if (data10 !== null) {
                const err10 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err10];
                } else {
                  vErrors.push(err10);
                }
                errors++;
              }
              var _valid3 = _errs33 === errors;
              valid12 = valid12 || _valid3;
              if (!valid12) {
                const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err11];
                } else {
                  vErrors.push(err11);
                }
                errors++;
                validate38.errors = vErrors;
                return false;
              } else {
                errors = _errs30;
                if (vErrors !== null) {
                  if (_errs30) {
                    vErrors.length = _errs30;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid11 = _errs29 === errors;
            } else {
              var valid11 = true;
            }
            if (valid11) {
              if (data.updatedAt !== void 0) {
                let data11 = data.updatedAt;
                const _errs35 = errors;
                const _errs36 = errors;
                let valid13 = false;
                const _errs37 = errors;
                if (errors === _errs37) {
                  if (errors === _errs37) {
                    if (typeof data11 === "string") {
                      if (func1(data11) > 64) {
                        const err12 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err12];
                        } else {
                          vErrors.push(err12);
                        }
                        errors++;
                      } else {
                        if (!formats0.validate(data11)) {
                          const err13 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err13];
                          } else {
                            vErrors.push(err13);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err14 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err14];
                      } else {
                        vErrors.push(err14);
                      }
                      errors++;
                    }
                  }
                }
                var _valid4 = _errs37 === errors;
                valid13 = valid13 || _valid4;
                const _errs39 = errors;
                if (data11 !== null) {
                  const err15 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err15];
                  } else {
                    vErrors.push(err15);
                  }
                  errors++;
                }
                var _valid4 = _errs39 === errors;
                valid13 = valid13 || _valid4;
                if (!valid13) {
                  const err16 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err16];
                  } else {
                    vErrors.push(err16);
                  }
                  errors++;
                  validate38.errors = vErrors;
                  return false;
                } else {
                  errors = _errs36;
                  if (vErrors !== null) {
                    if (_errs36) {
                      vErrors.length = _errs36;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid11 = _errs35 === errors;
              } else {
                var valid11 = true;
              }
              if (valid11) {
                if (data.data !== void 0) {
                  let data12 = data.data;
                  const _errs41 = errors;
                  const _errs42 = errors;
                  let valid14 = false;
                  const _errs43 = errors;
                  if (!validate22(data12, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
                    vErrors = vErrors === null ? validate22.errors : vErrors.concat(validate22.errors);
                    errors = vErrors.length;
                  }
                  var _valid5 = _errs43 === errors;
                  valid14 = valid14 || _valid5;
                  const _errs44 = errors;
                  if (data12 !== null) {
                    const err17 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors++;
                  }
                  var _valid5 = _errs44 === errors;
                  valid14 = valid14 || _valid5;
                  if (!valid14) {
                    const err18 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err18];
                    } else {
                      vErrors.push(err18);
                    }
                    errors++;
                    validate38.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs42;
                    if (vErrors !== null) {
                      if (_errs42) {
                        vErrors.length = _errs42;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid11 = _errs41 === errors;
                } else {
                  var valid11 = true;
                }
                if (valid11) {
                  if (data.errorCode !== void 0) {
                    let data13 = data.errorCode;
                    const _errs46 = errors;
                    const _errs47 = errors;
                    let valid15 = false;
                    const _errs48 = errors;
                    if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
                      const err19 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema32.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors++;
                    }
                    var _valid6 = _errs48 === errors;
                    valid15 = valid15 || _valid6;
                    const _errs49 = errors;
                    if (data13 !== null) {
                      const err20 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err20];
                      } else {
                        vErrors.push(err20);
                      }
                      errors++;
                    }
                    var _valid6 = _errs49 === errors;
                    valid15 = valid15 || _valid6;
                    if (!valid15) {
                      const err21 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err21];
                      } else {
                        vErrors.push(err21);
                      }
                      errors++;
                      validate38.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs47;
                      if (vErrors !== null) {
                        if (_errs47) {
                          vErrors.length = _errs47;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid11 = _errs46 === errors;
                  } else {
                    var valid11 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate38.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate38.errors = vErrors;
  return errors === 0;
}
validate38.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var weather = validate41;
function validate41(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate41.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors;
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors;
        const _errs7 = errors;
        if (errors === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.location === void 0 && (missing0 = "location") || data1.timeZone === void 0 && (missing0 = "timeZone") || data1.current === void 0 && (missing0 = "current") || data1.hourly === void 0 && (missing0 = "hourly") || data1.attributionUrl === void 0 && (missing0 = "attributionUrl")) {
              validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors;
              for (const key0 in data1) {
                if (!(key0 === "location" || key0 === "timeZone" || key0 === "current" || key0 === "hourly" || key0 === "attributionUrl")) {
                  validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors) {
                if (data1.location !== void 0) {
                  let data2 = data1.location;
                  const _errs10 = errors;
                  if (errors === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 512) {
                        validate41.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                        return false;
                      }
                    } else {
                      validate41.errors = [{ instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.timeZone !== void 0) {
                    let data3 = data1.timeZone;
                    const _errs12 = errors;
                    if (errors === _errs12) {
                      if (typeof data3 === "string") {
                        if (func1(data3) > 255) {
                          validate41.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                          return false;
                        } else {
                          if (func1(data3) < 1) {
                            validate41.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          }
                        }
                      } else {
                        validate41.errors = [{ instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid5 = _errs12 === errors;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.current !== void 0) {
                      let data4 = data1.current;
                      const _errs14 = errors;
                      if (errors === _errs14) {
                        if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                          let missing1;
                          if (data4.temperatureC === void 0 && (missing1 = "temperatureC") || data4.code === void 0 && (missing1 = "code")) {
                            validate41.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                            return false;
                          } else {
                            const _errs16 = errors;
                            for (const key1 in data4) {
                              if (!(key1 === "temperatureC" || key1 === "code")) {
                                validate41.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                return false;
                                break;
                              }
                            }
                            if (_errs16 === errors) {
                              if (data4.temperatureC !== void 0) {
                                let data5 = data4.temperatureC;
                                const _errs17 = errors;
                                const _errs18 = errors;
                                let valid7 = false;
                                const _errs19 = errors;
                                if (!(typeof data5 == "number" && isFinite(data5))) {
                                  const err1 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err1];
                                  } else {
                                    vErrors.push(err1);
                                  }
                                  errors++;
                                }
                                var _valid1 = _errs19 === errors;
                                valid7 = valid7 || _valid1;
                                const _errs21 = errors;
                                if (data5 !== null) {
                                  const err2 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors++;
                                }
                                var _valid1 = _errs21 === errors;
                                valid7 = valid7 || _valid1;
                                if (!valid7) {
                                  const err3 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err3];
                                  } else {
                                    vErrors.push(err3);
                                  }
                                  errors++;
                                  validate41.errors = vErrors;
                                  return false;
                                } else {
                                  errors = _errs18;
                                  if (vErrors !== null) {
                                    if (_errs18) {
                                      vErrors.length = _errs18;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid6 = _errs17 === errors;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.code !== void 0) {
                                  let data6 = data4.code;
                                  const _errs23 = errors;
                                  const _errs24 = errors;
                                  let valid8 = false;
                                  const _errs25 = errors;
                                  if (!(typeof data6 == "number" && (!(data6 % 1) && !isNaN(data6)) && isFinite(data6))) {
                                    const err4 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err4];
                                    } else {
                                      vErrors.push(err4);
                                    }
                                    errors++;
                                  }
                                  if (errors === _errs25) {
                                    if (typeof data6 == "number" && isFinite(data6)) {
                                      if (data6 > 99 || isNaN(data6)) {
                                        const err5 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                        if (vErrors === null) {
                                          vErrors = [err5];
                                        } else {
                                          vErrors.push(err5);
                                        }
                                        errors++;
                                      } else {
                                        if (data6 < 0 || isNaN(data6)) {
                                          const err6 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                          if (vErrors === null) {
                                            vErrors = [err6];
                                          } else {
                                            vErrors.push(err6);
                                          }
                                          errors++;
                                        }
                                      }
                                    }
                                  }
                                  var _valid2 = _errs25 === errors;
                                  valid8 = valid8 || _valid2;
                                  const _errs27 = errors;
                                  if (data6 !== null) {
                                    const err7 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err7];
                                    } else {
                                      vErrors.push(err7);
                                    }
                                    errors++;
                                  }
                                  var _valid2 = _errs27 === errors;
                                  valid8 = valid8 || _valid2;
                                  if (!valid8) {
                                    const err8 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors++;
                                    validate41.errors = vErrors;
                                    return false;
                                  } else {
                                    errors = _errs24;
                                    if (vErrors !== null) {
                                      if (_errs24) {
                                        vErrors.length = _errs24;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid6 = _errs23 === errors;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                          }
                        } else {
                          validate41.errors = [{ instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                          return false;
                        }
                      }
                      var valid5 = _errs14 === errors;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.hourly !== void 0) {
                        let data7 = data1.hourly;
                        const _errs29 = errors;
                        if (errors === _errs29) {
                          if (Array.isArray(data7)) {
                            if (data7.length > 6) {
                              validate41.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" }];
                              return false;
                            } else {
                              var valid9 = true;
                              const len0 = data7.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data8 = data7[i0];
                                const _errs31 = errors;
                                if (errors === _errs31) {
                                  if (data8 && typeof data8 == "object" && !Array.isArray(data8)) {
                                    let missing2;
                                    if (data8.at === void 0 && (missing2 = "at") || data8.temperatureC === void 0 && (missing2 = "temperatureC") || data8.precipitationProbability === void 0 && (missing2 = "precipitationProbability")) {
                                      validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
                                      return false;
                                    } else {
                                      const _errs33 = errors;
                                      for (const key2 in data8) {
                                        if (!(key2 === "at" || key2 === "temperatureC" || key2 === "precipitationProbability")) {
                                          validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs33 === errors) {
                                        if (data8.at !== void 0) {
                                          let data9 = data8.at;
                                          const _errs34 = errors;
                                          if (errors === _errs34) {
                                            if (errors === _errs34) {
                                              if (typeof data9 === "string") {
                                                if (func1(data9) > 64) {
                                                  validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data9)) {
                                                    validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid10 = _errs34 === errors;
                                        } else {
                                          var valid10 = true;
                                        }
                                        if (valid10) {
                                          if (data8.temperatureC !== void 0) {
                                            let data10 = data8.temperatureC;
                                            const _errs36 = errors;
                                            const _errs37 = errors;
                                            let valid11 = false;
                                            const _errs38 = errors;
                                            if (!(typeof data10 == "number" && isFinite(data10))) {
                                              const err9 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                              if (vErrors === null) {
                                                vErrors = [err9];
                                              } else {
                                                vErrors.push(err9);
                                              }
                                              errors++;
                                            }
                                            var _valid3 = _errs38 === errors;
                                            valid11 = valid11 || _valid3;
                                            const _errs40 = errors;
                                            if (data10 !== null) {
                                              const err10 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err10];
                                              } else {
                                                vErrors.push(err10);
                                              }
                                              errors++;
                                            }
                                            var _valid3 = _errs40 === errors;
                                            valid11 = valid11 || _valid3;
                                            if (!valid11) {
                                              const err11 = { instancePath: instancePath + "/data/hourly/" + i0 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err11];
                                              } else {
                                                vErrors.push(err11);
                                              }
                                              errors++;
                                              validate41.errors = vErrors;
                                              return false;
                                            } else {
                                              errors = _errs37;
                                              if (vErrors !== null) {
                                                if (_errs37) {
                                                  vErrors.length = _errs37;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid10 = _errs36 === errors;
                                          } else {
                                            var valid10 = true;
                                          }
                                          if (valid10) {
                                            if (data8.precipitationProbability !== void 0) {
                                              let data11 = data8.precipitationProbability;
                                              const _errs42 = errors;
                                              const _errs43 = errors;
                                              let valid12 = false;
                                              const _errs44 = errors;
                                              if (errors === _errs44) {
                                                if (typeof data11 == "number" && isFinite(data11)) {
                                                  if (data11 > 100 || isNaN(data11)) {
                                                    const err12 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                    if (vErrors === null) {
                                                      vErrors = [err12];
                                                    } else {
                                                      vErrors.push(err12);
                                                    }
                                                    errors++;
                                                  } else {
                                                    if (data11 < 0 || isNaN(data11)) {
                                                      const err13 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                      if (vErrors === null) {
                                                        vErrors = [err13];
                                                      } else {
                                                        vErrors.push(err13);
                                                      }
                                                      errors++;
                                                    }
                                                  }
                                                } else {
                                                  const err14 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                  if (vErrors === null) {
                                                    vErrors = [err14];
                                                  } else {
                                                    vErrors.push(err14);
                                                  }
                                                  errors++;
                                                }
                                              }
                                              var _valid4 = _errs44 === errors;
                                              valid12 = valid12 || _valid4;
                                              const _errs46 = errors;
                                              if (data11 !== null) {
                                                const err15 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                if (vErrors === null) {
                                                  vErrors = [err15];
                                                } else {
                                                  vErrors.push(err15);
                                                }
                                                errors++;
                                              }
                                              var _valid4 = _errs46 === errors;
                                              valid12 = valid12 || _valid4;
                                              if (!valid12) {
                                                const err16 = { instancePath: instancePath + "/data/hourly/" + i0 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                if (vErrors === null) {
                                                  vErrors = [err16];
                                                } else {
                                                  vErrors.push(err16);
                                                }
                                                errors++;
                                                validate41.errors = vErrors;
                                                return false;
                                              } else {
                                                errors = _errs43;
                                                if (vErrors !== null) {
                                                  if (_errs43) {
                                                    vErrors.length = _errs43;
                                                  } else {
                                                    vErrors = null;
                                                  }
                                                }
                                              }
                                              var valid10 = _errs42 === errors;
                                            } else {
                                              var valid10 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate41.errors = [{ instancePath: instancePath + "/data/hourly/" + i0, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid9 = _errs31 === errors;
                                if (!valid9) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate41.errors = [{ instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs29 === errors;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.attributionUrl !== void 0) {
                          let data12 = data1.attributionUrl;
                          const _errs48 = errors;
                          if (errors === _errs48) {
                            if (typeof data12 === "string") {
                              if (func1(data12) > 512) {
                                validate41.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" }];
                                return false;
                              } else {
                                if (!pattern6.test(data12)) {
                                  validate41.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' }];
                                  return false;
                                }
                              }
                            } else {
                              validate41.errors = [{ instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                              return false;
                            }
                          }
                          var valid5 = _errs48 === errors;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data13 = data.updatedAt;
          const _errs50 = errors;
          if (errors === _errs50) {
            if (errors === _errs50) {
              if (typeof data13 === "string") {
                if (func1(data13) > 64) {
                  validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data13)) {
                    validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs50 === errors;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err17 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err17];
    } else {
      vErrors.push(err17);
    }
    errors++;
    validate41.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors;
  if (valid0) {
    const _errs52 = errors;
    const _errs53 = errors;
    let valid13 = true;
    const _errs54 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data14 = data.status;
        if (!(data14 === "unconfigured" || data14 === "unavailable")) {
          const err18 = {};
          if (vErrors === null) {
            vErrors = [err18];
          } else {
            vErrors.push(err18);
          }
          errors++;
        }
      }
    }
    var _valid5 = _errs54 === errors;
    errors = _errs53;
    if (vErrors !== null) {
      if (_errs53) {
        vErrors.length = _errs53;
      } else {
        vErrors = null;
      }
    }
    if (_valid5) {
      const _errs56 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs57 = errors;
          if (data.data !== null) {
            validate41.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid15 = _errs57 === errors;
        } else {
          var valid15 = true;
        }
        if (valid15) {
          if (data.updatedAt !== void 0) {
            const _errs59 = errors;
            if (data.updatedAt !== null) {
              validate41.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid15 = _errs59 === errors;
          } else {
            var valid15 = true;
          }
        }
      }
      var _valid5 = _errs56 === errors;
      valid13 = _valid5;
      if (valid13) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid13) {
      const err19 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err19];
      } else {
        vErrors.push(err19);
      }
      errors++;
      validate41.errors = vErrors;
      return false;
    }
    var valid0 = _errs52 === errors;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs61 = errors;
      const _errs62 = errors;
      let valid16 = true;
      const _errs63 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data17 = data.status;
          if (!(data17 === "ok" || data17 === "unconfigured" || data17 === "loading")) {
            const err20 = {};
            if (vErrors === null) {
              vErrors = [err20];
            } else {
              vErrors.push(err20);
            }
            errors++;
          }
        }
      }
      var _valid6 = _errs63 === errors;
      errors = _errs62;
      if (vErrors !== null) {
        if (_errs62) {
          vErrors.length = _errs62;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid6) {
        const _errs65 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate41.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid6 = _errs65 === errors;
        valid16 = _valid6;
        if (valid16) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs68 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data19 = data.errorCode;
            if (!(data19 === "NETWORK_ERROR" || data19 === "INVALID_DATA" || data19 === "PAYLOAD_TOO_LARGE" || data19 === "EXPANSION_LIMIT" || data19 === "UNSUPPORTED_CALENDAR" || data19 === "UNKNOWN_TIME_ZONE" || data19 === "KEYRING_LOCKED" || data19 === "SECRET_DELETION_FAILED" || data19 === "AUTH_ERROR" || data19 === "RATE_LIMITED" || data19 === "NO_PLAYER" || data19 === "NO_INTERFACE" || data19 === "SERVICE_UNAVAILABLE" || data19 === "INTERNAL_ERROR")) {
              validate41.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema35.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid6 = _errs68 === errors;
        valid16 = _valid6;
        if (valid16) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid16) {
        const err21 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err21];
        } else {
          vErrors.push(err21);
        }
        errors++;
        validate41.errors = vErrors;
        return false;
      }
      var valid0 = _errs61 === errors;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing3;
      if (data.status === void 0 && (missing3 = "status") || data.sourceId === void 0 && (missing3 = "sourceId") || data.updatedAt === void 0 && (missing3 = "updatedAt") || data.data === void 0 && (missing3 = "data") || data.errorCode === void 0 && (missing3 = "errorCode")) {
        validate41.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" }];
        return false;
      } else {
        const _errs70 = errors;
        for (const key3 in data) {
          if (!(key3 === "status" || key3 === "sourceId" || key3 === "updatedAt" || key3 === "data" || key3 === "errorCode")) {
            validate41.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs70 === errors) {
          if (data.status !== void 0) {
            let data20 = data.status;
            const _errs71 = errors;
            if (!(data20 === "loading" || data20 === "ok" || data20 === "stale" || data20 === "unconfigured" || data20 === "unavailable")) {
              validate41.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema35.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid20 = _errs71 === errors;
          } else {
            var valid20 = true;
          }
          if (valid20) {
            if (data.sourceId !== void 0) {
              let data21 = data.sourceId;
              const _errs72 = errors;
              const _errs73 = errors;
              let valid21 = false;
              const _errs74 = errors;
              if (errors === _errs74) {
                if (typeof data21 === "string") {
                  if (func1(data21) > 128) {
                    const err22 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err22];
                    } else {
                      vErrors.push(err22);
                    }
                    errors++;
                  } else {
                    if (func1(data21) < 1) {
                      const err23 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err23];
                      } else {
                        vErrors.push(err23);
                      }
                      errors++;
                    } else {
                      if (!pattern5.test(data21)) {
                        const err24 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err24];
                        } else {
                          vErrors.push(err24);
                        }
                        errors++;
                      }
                    }
                  }
                } else {
                  const err25 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err25];
                  } else {
                    vErrors.push(err25);
                  }
                  errors++;
                }
              }
              var _valid7 = _errs74 === errors;
              valid21 = valid21 || _valid7;
              const _errs76 = errors;
              if (data21 !== null) {
                const err26 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err26];
                } else {
                  vErrors.push(err26);
                }
                errors++;
              }
              var _valid7 = _errs76 === errors;
              valid21 = valid21 || _valid7;
              if (!valid21) {
                const err27 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err27];
                } else {
                  vErrors.push(err27);
                }
                errors++;
                validate41.errors = vErrors;
                return false;
              } else {
                errors = _errs73;
                if (vErrors !== null) {
                  if (_errs73) {
                    vErrors.length = _errs73;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid20 = _errs72 === errors;
            } else {
              var valid20 = true;
            }
            if (valid20) {
              if (data.updatedAt !== void 0) {
                let data22 = data.updatedAt;
                const _errs78 = errors;
                const _errs79 = errors;
                let valid22 = false;
                const _errs80 = errors;
                if (errors === _errs80) {
                  if (errors === _errs80) {
                    if (typeof data22 === "string") {
                      if (func1(data22) > 64) {
                        const err28 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err28];
                        } else {
                          vErrors.push(err28);
                        }
                        errors++;
                      } else {
                        if (!formats0.validate(data22)) {
                          const err29 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err29];
                          } else {
                            vErrors.push(err29);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err30 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err30];
                      } else {
                        vErrors.push(err30);
                      }
                      errors++;
                    }
                  }
                }
                var _valid8 = _errs80 === errors;
                valid22 = valid22 || _valid8;
                const _errs82 = errors;
                if (data22 !== null) {
                  const err31 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err31];
                  } else {
                    vErrors.push(err31);
                  }
                  errors++;
                }
                var _valid8 = _errs82 === errors;
                valid22 = valid22 || _valid8;
                if (!valid22) {
                  const err32 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err32];
                  } else {
                    vErrors.push(err32);
                  }
                  errors++;
                  validate41.errors = vErrors;
                  return false;
                } else {
                  errors = _errs79;
                  if (vErrors !== null) {
                    if (_errs79) {
                      vErrors.length = _errs79;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid20 = _errs78 === errors;
              } else {
                var valid20 = true;
              }
              if (valid20) {
                if (data.data !== void 0) {
                  let data23 = data.data;
                  const _errs84 = errors;
                  const _errs85 = errors;
                  let valid23 = false;
                  const _errs86 = errors;
                  const _errs87 = errors;
                  if (errors === _errs87) {
                    if (data23 && typeof data23 == "object" && !Array.isArray(data23)) {
                      let missing4;
                      if (data23.location === void 0 && (missing4 = "location") || data23.timeZone === void 0 && (missing4 = "timeZone") || data23.current === void 0 && (missing4 = "current") || data23.hourly === void 0 && (missing4 = "hourly") || data23.attributionUrl === void 0 && (missing4 = "attributionUrl")) {
                        const err33 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                        if (vErrors === null) {
                          vErrors = [err33];
                        } else {
                          vErrors.push(err33);
                        }
                        errors++;
                      } else {
                        const _errs89 = errors;
                        for (const key4 in data23) {
                          if (!(key4 === "location" || key4 === "timeZone" || key4 === "current" || key4 === "hourly" || key4 === "attributionUrl")) {
                            const err34 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err34];
                            } else {
                              vErrors.push(err34);
                            }
                            errors++;
                            break;
                          }
                        }
                        if (_errs89 === errors) {
                          if (data23.location !== void 0) {
                            let data24 = data23.location;
                            const _errs90 = errors;
                            if (errors === _errs90) {
                              if (typeof data24 === "string") {
                                if (func1(data24) > 512) {
                                  const err35 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors++;
                                }
                              } else {
                                const err36 = { instancePath: instancePath + "/data/location", schemaPath: "#/$defs/WeatherData/properties/location/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err36];
                                } else {
                                  vErrors.push(err36);
                                }
                                errors++;
                              }
                            }
                            var valid25 = _errs90 === errors;
                          } else {
                            var valid25 = true;
                          }
                          if (valid25) {
                            if (data23.timeZone !== void 0) {
                              let data25 = data23.timeZone;
                              const _errs92 = errors;
                              if (errors === _errs92) {
                                if (typeof data25 === "string") {
                                  if (func1(data25) > 255) {
                                    const err37 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err37];
                                    } else {
                                      vErrors.push(err37);
                                    }
                                    errors++;
                                  } else {
                                    if (func1(data25) < 1) {
                                      const err38 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err38];
                                      } else {
                                        vErrors.push(err38);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err39 = { instancePath: instancePath + "/data/timeZone", schemaPath: "#/$defs/WeatherData/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err39];
                                  } else {
                                    vErrors.push(err39);
                                  }
                                  errors++;
                                }
                              }
                              var valid25 = _errs92 === errors;
                            } else {
                              var valid25 = true;
                            }
                            if (valid25) {
                              if (data23.current !== void 0) {
                                let data26 = data23.current;
                                const _errs94 = errors;
                                if (errors === _errs94) {
                                  if (data26 && typeof data26 == "object" && !Array.isArray(data26)) {
                                    let missing5;
                                    if (data26.temperatureC === void 0 && (missing5 = "temperatureC") || data26.code === void 0 && (missing5 = "code")) {
                                      const err40 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/required", keyword: "required", params: { missingProperty: missing5 }, message: "must have required property '" + missing5 + "'" };
                                      if (vErrors === null) {
                                        vErrors = [err40];
                                      } else {
                                        vErrors.push(err40);
                                      }
                                      errors++;
                                    } else {
                                      const _errs96 = errors;
                                      for (const key5 in data26) {
                                        if (!(key5 === "temperatureC" || key5 === "code")) {
                                          const err41 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                                          if (vErrors === null) {
                                            vErrors = [err41];
                                          } else {
                                            vErrors.push(err41);
                                          }
                                          errors++;
                                          break;
                                        }
                                      }
                                      if (_errs96 === errors) {
                                        if (data26.temperatureC !== void 0) {
                                          let data27 = data26.temperatureC;
                                          const _errs97 = errors;
                                          const _errs98 = errors;
                                          let valid27 = false;
                                          const _errs99 = errors;
                                          if (!(typeof data27 == "number" && isFinite(data27))) {
                                            const err42 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                            if (vErrors === null) {
                                              vErrors = [err42];
                                            } else {
                                              vErrors.push(err42);
                                            }
                                            errors++;
                                          }
                                          var _valid10 = _errs99 === errors;
                                          valid27 = valid27 || _valid10;
                                          const _errs101 = errors;
                                          if (data27 !== null) {
                                            const err43 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                            if (vErrors === null) {
                                              vErrors = [err43];
                                            } else {
                                              vErrors.push(err43);
                                            }
                                            errors++;
                                          }
                                          var _valid10 = _errs101 === errors;
                                          valid27 = valid27 || _valid10;
                                          if (!valid27) {
                                            const err44 = { instancePath: instancePath + "/data/current/temperatureC", schemaPath: "#/$defs/WeatherData/properties/current/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                            if (vErrors === null) {
                                              vErrors = [err44];
                                            } else {
                                              vErrors.push(err44);
                                            }
                                            errors++;
                                          } else {
                                            errors = _errs98;
                                            if (vErrors !== null) {
                                              if (_errs98) {
                                                vErrors.length = _errs98;
                                              } else {
                                                vErrors = null;
                                              }
                                            }
                                          }
                                          var valid26 = _errs97 === errors;
                                        } else {
                                          var valid26 = true;
                                        }
                                        if (valid26) {
                                          if (data26.code !== void 0) {
                                            let data28 = data26.code;
                                            const _errs103 = errors;
                                            const _errs104 = errors;
                                            let valid28 = false;
                                            const _errs105 = errors;
                                            if (!(typeof data28 == "number" && (!(data28 % 1) && !isNaN(data28)) && isFinite(data28))) {
                                              const err45 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                              if (vErrors === null) {
                                                vErrors = [err45];
                                              } else {
                                                vErrors.push(err45);
                                              }
                                              errors++;
                                            }
                                            if (errors === _errs105) {
                                              if (typeof data28 == "number" && isFinite(data28)) {
                                                if (data28 > 99 || isNaN(data28)) {
                                                  const err46 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 99 }, message: "must be <= 99" };
                                                  if (vErrors === null) {
                                                    vErrors = [err46];
                                                  } else {
                                                    vErrors.push(err46);
                                                  }
                                                  errors++;
                                                } else {
                                                  if (data28 < 0 || isNaN(data28)) {
                                                    const err47 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                    if (vErrors === null) {
                                                      vErrors = [err47];
                                                    } else {
                                                      vErrors.push(err47);
                                                    }
                                                    errors++;
                                                  }
                                                }
                                              }
                                            }
                                            var _valid11 = _errs105 === errors;
                                            valid28 = valid28 || _valid11;
                                            const _errs107 = errors;
                                            if (data28 !== null) {
                                              const err48 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors++;
                                            }
                                            var _valid11 = _errs107 === errors;
                                            valid28 = valid28 || _valid11;
                                            if (!valid28) {
                                              const err49 = { instancePath: instancePath + "/data/current/code", schemaPath: "#/$defs/WeatherData/properties/current/properties/code/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                              if (vErrors === null) {
                                                vErrors = [err49];
                                              } else {
                                                vErrors.push(err49);
                                              }
                                              errors++;
                                            } else {
                                              errors = _errs104;
                                              if (vErrors !== null) {
                                                if (_errs104) {
                                                  vErrors.length = _errs104;
                                                } else {
                                                  vErrors = null;
                                                }
                                              }
                                            }
                                            var valid26 = _errs103 === errors;
                                          } else {
                                            var valid26 = true;
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    const err50 = { instancePath: instancePath + "/data/current", schemaPath: "#/$defs/WeatherData/properties/current/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                    if (vErrors === null) {
                                      vErrors = [err50];
                                    } else {
                                      vErrors.push(err50);
                                    }
                                    errors++;
                                  }
                                }
                                var valid25 = _errs94 === errors;
                              } else {
                                var valid25 = true;
                              }
                              if (valid25) {
                                if (data23.hourly !== void 0) {
                                  let data29 = data23.hourly;
                                  const _errs109 = errors;
                                  if (errors === _errs109) {
                                    if (Array.isArray(data29)) {
                                      if (data29.length > 6) {
                                        const err51 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/maxItems", keyword: "maxItems", params: { limit: 6 }, message: "must NOT have more than 6 items" };
                                        if (vErrors === null) {
                                          vErrors = [err51];
                                        } else {
                                          vErrors.push(err51);
                                        }
                                        errors++;
                                      } else {
                                        var valid29 = true;
                                        const len1 = data29.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data30 = data29[i1];
                                          const _errs111 = errors;
                                          if (errors === _errs111) {
                                            if (data30 && typeof data30 == "object" && !Array.isArray(data30)) {
                                              let missing6;
                                              if (data30.at === void 0 && (missing6 = "at") || data30.temperatureC === void 0 && (missing6 = "temperatureC") || data30.precipitationProbability === void 0 && (missing6 = "precipitationProbability")) {
                                                const err52 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/required", keyword: "required", params: { missingProperty: missing6 }, message: "must have required property '" + missing6 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err52];
                                                } else {
                                                  vErrors.push(err52);
                                                }
                                                errors++;
                                              } else {
                                                const _errs113 = errors;
                                                for (const key6 in data30) {
                                                  if (!(key6 === "at" || key6 === "temperatureC" || key6 === "precipitationProbability")) {
                                                    const err53 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err53];
                                                    } else {
                                                      vErrors.push(err53);
                                                    }
                                                    errors++;
                                                    break;
                                                  }
                                                }
                                                if (_errs113 === errors) {
                                                  if (data30.at !== void 0) {
                                                    let data31 = data30.at;
                                                    const _errs114 = errors;
                                                    if (errors === _errs114) {
                                                      if (errors === _errs114) {
                                                        if (typeof data31 === "string") {
                                                          if (func1(data31) > 64) {
                                                            const err54 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err54];
                                                            } else {
                                                              vErrors.push(err54);
                                                            }
                                                            errors++;
                                                          } else {
                                                            if (!formats0.validate(data31)) {
                                                              const err55 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err55];
                                                              } else {
                                                                vErrors.push(err55);
                                                              }
                                                              errors++;
                                                            }
                                                          }
                                                        } else {
                                                          const err56 = { instancePath: instancePath + "/data/hourly/" + i1 + "/at", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err56];
                                                          } else {
                                                            vErrors.push(err56);
                                                          }
                                                          errors++;
                                                        }
                                                      }
                                                    }
                                                    var valid30 = _errs114 === errors;
                                                  } else {
                                                    var valid30 = true;
                                                  }
                                                  if (valid30) {
                                                    if (data30.temperatureC !== void 0) {
                                                      let data32 = data30.temperatureC;
                                                      const _errs116 = errors;
                                                      const _errs117 = errors;
                                                      let valid31 = false;
                                                      const _errs118 = errors;
                                                      if (!(typeof data32 == "number" && isFinite(data32))) {
                                                        const err57 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                        if (vErrors === null) {
                                                          vErrors = [err57];
                                                        } else {
                                                          vErrors.push(err57);
                                                        }
                                                        errors++;
                                                      }
                                                      var _valid12 = _errs118 === errors;
                                                      valid31 = valid31 || _valid12;
                                                      const _errs120 = errors;
                                                      if (data32 !== null) {
                                                        const err58 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                        if (vErrors === null) {
                                                          vErrors = [err58];
                                                        } else {
                                                          vErrors.push(err58);
                                                        }
                                                        errors++;
                                                      }
                                                      var _valid12 = _errs120 === errors;
                                                      valid31 = valid31 || _valid12;
                                                      if (!valid31) {
                                                        const err59 = { instancePath: instancePath + "/data/hourly/" + i1 + "/temperatureC", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                        if (vErrors === null) {
                                                          vErrors = [err59];
                                                        } else {
                                                          vErrors.push(err59);
                                                        }
                                                        errors++;
                                                      } else {
                                                        errors = _errs117;
                                                        if (vErrors !== null) {
                                                          if (_errs117) {
                                                            vErrors.length = _errs117;
                                                          } else {
                                                            vErrors = null;
                                                          }
                                                        }
                                                      }
                                                      var valid30 = _errs116 === errors;
                                                    } else {
                                                      var valid30 = true;
                                                    }
                                                    if (valid30) {
                                                      if (data30.precipitationProbability !== void 0) {
                                                        let data33 = data30.precipitationProbability;
                                                        const _errs122 = errors;
                                                        const _errs123 = errors;
                                                        let valid32 = false;
                                                        const _errs124 = errors;
                                                        if (errors === _errs124) {
                                                          if (typeof data33 == "number" && isFinite(data33)) {
                                                            if (data33 > 100 || isNaN(data33)) {
                                                              const err60 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                                              if (vErrors === null) {
                                                                vErrors = [err60];
                                                              } else {
                                                                vErrors.push(err60);
                                                              }
                                                              errors++;
                                                            } else {
                                                              if (data33 < 0 || isNaN(data33)) {
                                                                const err61 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                                if (vErrors === null) {
                                                                  vErrors = [err61];
                                                                } else {
                                                                  vErrors.push(err61);
                                                                }
                                                                errors++;
                                                              }
                                                            }
                                                          } else {
                                                            const err62 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err62];
                                                            } else {
                                                              vErrors.push(err62);
                                                            }
                                                            errors++;
                                                          }
                                                        }
                                                        var _valid13 = _errs124 === errors;
                                                        valid32 = valid32 || _valid13;
                                                        const _errs126 = errors;
                                                        if (data33 !== null) {
                                                          const err63 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                                          if (vErrors === null) {
                                                            vErrors = [err63];
                                                          } else {
                                                            vErrors.push(err63);
                                                          }
                                                          errors++;
                                                        }
                                                        var _valid13 = _errs126 === errors;
                                                        valid32 = valid32 || _valid13;
                                                        if (!valid32) {
                                                          const err64 = { instancePath: instancePath + "/data/hourly/" + i1 + "/precipitationProbability", schemaPath: "#/$defs/WeatherData/properties/hourly/items/properties/precipitationProbability/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                                          if (vErrors === null) {
                                                            vErrors = [err64];
                                                          } else {
                                                            vErrors.push(err64);
                                                          }
                                                          errors++;
                                                        } else {
                                                          errors = _errs123;
                                                          if (vErrors !== null) {
                                                            if (_errs123) {
                                                              vErrors.length = _errs123;
                                                            } else {
                                                              vErrors = null;
                                                            }
                                                          }
                                                        }
                                                        var valid30 = _errs122 === errors;
                                                      } else {
                                                        var valid30 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err65 = { instancePath: instancePath + "/data/hourly/" + i1, schemaPath: "#/$defs/WeatherData/properties/hourly/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err65];
                                              } else {
                                                vErrors.push(err65);
                                              }
                                              errors++;
                                            }
                                          }
                                          var valid29 = _errs111 === errors;
                                          if (!valid29) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err66 = { instancePath: instancePath + "/data/hourly", schemaPath: "#/$defs/WeatherData/properties/hourly/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err66];
                                      } else {
                                        vErrors.push(err66);
                                      }
                                      errors++;
                                    }
                                  }
                                  var valid25 = _errs109 === errors;
                                } else {
                                  var valid25 = true;
                                }
                                if (valid25) {
                                  if (data23.attributionUrl !== void 0) {
                                    let data34 = data23.attributionUrl;
                                    const _errs128 = errors;
                                    if (errors === _errs128) {
                                      if (typeof data34 === "string") {
                                        if (func1(data34) > 512) {
                                          const err67 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err67];
                                          } else {
                                            vErrors.push(err67);
                                          }
                                          errors++;
                                        } else {
                                          if (!pattern6.test(data34)) {
                                            const err68 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/pattern", keyword: "pattern", params: { pattern: "^https://" }, message: 'must match pattern "^https://"' };
                                            if (vErrors === null) {
                                              vErrors = [err68];
                                            } else {
                                              vErrors.push(err68);
                                            }
                                            errors++;
                                          }
                                        }
                                      } else {
                                        const err69 = { instancePath: instancePath + "/data/attributionUrl", schemaPath: "#/$defs/WeatherData/properties/attributionUrl/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err69];
                                        } else {
                                          vErrors.push(err69);
                                        }
                                        errors++;
                                      }
                                    }
                                    var valid25 = _errs128 === errors;
                                  } else {
                                    var valid25 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err70 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/WeatherData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err70];
                      } else {
                        vErrors.push(err70);
                      }
                      errors++;
                    }
                  }
                  var _valid9 = _errs86 === errors;
                  valid23 = valid23 || _valid9;
                  const _errs130 = errors;
                  if (data23 !== null) {
                    const err71 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err71];
                    } else {
                      vErrors.push(err71);
                    }
                    errors++;
                  }
                  var _valid9 = _errs130 === errors;
                  valid23 = valid23 || _valid9;
                  if (!valid23) {
                    const err72 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err72];
                    } else {
                      vErrors.push(err72);
                    }
                    errors++;
                    validate41.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs85;
                    if (vErrors !== null) {
                      if (_errs85) {
                        vErrors.length = _errs85;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid20 = _errs84 === errors;
                } else {
                  var valid20 = true;
                }
                if (valid20) {
                  if (data.errorCode !== void 0) {
                    let data35 = data.errorCode;
                    const _errs132 = errors;
                    const _errs133 = errors;
                    let valid33 = false;
                    const _errs134 = errors;
                    if (!(data35 === "NETWORK_ERROR" || data35 === "INVALID_DATA" || data35 === "PAYLOAD_TOO_LARGE" || data35 === "EXPANSION_LIMIT" || data35 === "UNSUPPORTED_CALENDAR" || data35 === "UNKNOWN_TIME_ZONE" || data35 === "KEYRING_LOCKED" || data35 === "SECRET_DELETION_FAILED" || data35 === "AUTH_ERROR" || data35 === "RATE_LIMITED" || data35 === "NO_PLAYER" || data35 === "NO_INTERFACE" || data35 === "SERVICE_UNAVAILABLE" || data35 === "INTERNAL_ERROR")) {
                      const err73 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema35.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err73];
                      } else {
                        vErrors.push(err73);
                      }
                      errors++;
                    }
                    var _valid14 = _errs134 === errors;
                    valid33 = valid33 || _valid14;
                    const _errs135 = errors;
                    if (data35 !== null) {
                      const err74 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err74];
                      } else {
                        vErrors.push(err74);
                      }
                      errors++;
                    }
                    var _valid14 = _errs135 === errors;
                    valid33 = valid33 || _valid14;
                    if (!valid33) {
                      const err75 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err75];
                      } else {
                        vErrors.push(err75);
                      }
                      errors++;
                      validate41.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs133;
                      if (vErrors !== null) {
                        if (_errs133) {
                          vErrors.length = _errs133;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid20 = _errs132 === errors;
                  } else {
                    var valid20 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate41.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate41.errors = vErrors;
  return errors === 0;
}
validate41.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var system = validate42;
function validate42(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate42.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors;
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors;
        const _errs7 = errors;
        if (errors === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.cpuPercent === void 0 && (missing0 = "cpuPercent") || data1.memoryUsedBytes === void 0 && (missing0 = "memoryUsedBytes") || data1.memoryTotalBytes === void 0 && (missing0 = "memoryTotalBytes") || data1.temperatureC === void 0 && (missing0 = "temperatureC")) {
              validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors;
              for (const key0 in data1) {
                if (!(key0 === "cpuPercent" || key0 === "memoryUsedBytes" || key0 === "memoryTotalBytes" || key0 === "temperatureC")) {
                  validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors) {
                if (data1.cpuPercent !== void 0) {
                  let data2 = data1.cpuPercent;
                  const _errs10 = errors;
                  const _errs11 = errors;
                  let valid6 = false;
                  const _errs12 = errors;
                  if (errors === _errs12) {
                    if (typeof data2 == "number" && isFinite(data2)) {
                      if (data2 > 100 || isNaN(data2)) {
                        const err1 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                        if (vErrors === null) {
                          vErrors = [err1];
                        } else {
                          vErrors.push(err1);
                        }
                        errors++;
                      } else {
                        if (data2 < 0 || isNaN(data2)) {
                          const err2 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err2];
                          } else {
                            vErrors.push(err2);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err3 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors++;
                    }
                  }
                  var _valid1 = _errs12 === errors;
                  valid6 = valid6 || _valid1;
                  const _errs14 = errors;
                  if (data2 !== null) {
                    const err4 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err4];
                    } else {
                      vErrors.push(err4);
                    }
                    errors++;
                  }
                  var _valid1 = _errs14 === errors;
                  valid6 = valid6 || _valid1;
                  if (!valid6) {
                    const err5 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err5];
                    } else {
                      vErrors.push(err5);
                    }
                    errors++;
                    validate42.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs11;
                    if (vErrors !== null) {
                      if (_errs11) {
                        vErrors.length = _errs11;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid5 = _errs10 === errors;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.memoryUsedBytes !== void 0) {
                    let data3 = data1.memoryUsedBytes;
                    const _errs16 = errors;
                    if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                      validate42.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                      return false;
                    }
                    if (errors === _errs16) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 > 9007199254740991 || isNaN(data3)) {
                          validate42.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                          return false;
                        } else {
                          if (data3 < 0 || isNaN(data3)) {
                            validate42.errors = [{ instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                            return false;
                          }
                        }
                      }
                    }
                    var valid5 = _errs16 === errors;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.memoryTotalBytes !== void 0) {
                      let data4 = data1.memoryTotalBytes;
                      const _errs18 = errors;
                      if (!(typeof data4 == "number" && (!(data4 % 1) && !isNaN(data4)) && isFinite(data4))) {
                        validate42.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                        return false;
                      }
                      if (errors === _errs18) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 > 9007199254740991 || isNaN(data4)) {
                            validate42.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" }];
                            return false;
                          } else {
                            if (data4 < 0 || isNaN(data4)) {
                              validate42.errors = [{ instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                              return false;
                            }
                          }
                        }
                      }
                      var valid5 = _errs18 === errors;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.temperatureC !== void 0) {
                        let data5 = data1.temperatureC;
                        const _errs20 = errors;
                        const _errs21 = errors;
                        let valid7 = false;
                        const _errs22 = errors;
                        if (!(typeof data5 == "number" && isFinite(data5))) {
                          const err6 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors++;
                        }
                        var _valid2 = _errs22 === errors;
                        valid7 = valid7 || _valid2;
                        const _errs24 = errors;
                        if (data5 !== null) {
                          const err7 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                          if (vErrors === null) {
                            vErrors = [err7];
                          } else {
                            vErrors.push(err7);
                          }
                          errors++;
                        }
                        var _valid2 = _errs24 === errors;
                        valid7 = valid7 || _valid2;
                        if (!valid7) {
                          const err8 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                          if (vErrors === null) {
                            vErrors = [err8];
                          } else {
                            vErrors.push(err8);
                          }
                          errors++;
                          validate42.errors = vErrors;
                          return false;
                        } else {
                          errors = _errs21;
                          if (vErrors !== null) {
                            if (_errs21) {
                              vErrors.length = _errs21;
                            } else {
                              vErrors = null;
                            }
                          }
                        }
                        var valid5 = _errs20 === errors;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data6 = data.updatedAt;
          const _errs26 = errors;
          if (errors === _errs26) {
            if (errors === _errs26) {
              if (typeof data6 === "string") {
                if (func1(data6) > 64) {
                  validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data6)) {
                    validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs26 === errors;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors++;
    validate42.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors;
  if (valid0) {
    const _errs28 = errors;
    const _errs29 = errors;
    let valid8 = true;
    const _errs30 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data7 = data.status;
        if (!(data7 === "unconfigured" || data7 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors++;
        }
      }
    }
    var _valid3 = _errs30 === errors;
    errors = _errs29;
    if (vErrors !== null) {
      if (_errs29) {
        vErrors.length = _errs29;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs32 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs33 = errors;
          if (data.data !== null) {
            validate42.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid10 = _errs33 === errors;
        } else {
          var valid10 = true;
        }
        if (valid10) {
          if (data.updatedAt !== void 0) {
            const _errs35 = errors;
            if (data.updatedAt !== null) {
              validate42.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid10 = _errs35 === errors;
          } else {
            var valid10 = true;
          }
        }
      }
      var _valid3 = _errs32 === errors;
      valid8 = _valid3;
      if (valid8) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid8) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors++;
      validate42.errors = vErrors;
      return false;
    }
    var valid0 = _errs28 === errors;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs37 = errors;
      const _errs38 = errors;
      let valid11 = true;
      const _errs39 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data10 = data.status;
          if (!(data10 === "ok" || data10 === "unconfigured" || data10 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors++;
          }
        }
      }
      var _valid4 = _errs39 === errors;
      errors = _errs38;
      if (vErrors !== null) {
        if (_errs38) {
          vErrors.length = _errs38;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs41 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate42.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs41 === errors;
        valid11 = _valid4;
        if (valid11) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs44 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data12 = data.errorCode;
            if (!(data12 === "NETWORK_ERROR" || data12 === "INVALID_DATA" || data12 === "PAYLOAD_TOO_LARGE" || data12 === "EXPANSION_LIMIT" || data12 === "UNSUPPORTED_CALENDAR" || data12 === "UNKNOWN_TIME_ZONE" || data12 === "KEYRING_LOCKED" || data12 === "SECRET_DELETION_FAILED" || data12 === "AUTH_ERROR" || data12 === "RATE_LIMITED" || data12 === "NO_PLAYER" || data12 === "NO_INTERFACE" || data12 === "SERVICE_UNAVAILABLE" || data12 === "INTERNAL_ERROR")) {
              validate42.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema38.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs44 === errors;
        valid11 = _valid4;
        if (valid11) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid11) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors++;
        validate42.errors = vErrors;
        return false;
      }
      var valid0 = _errs37 === errors;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate42.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs46 = errors;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate42.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs46 === errors) {
          if (data.status !== void 0) {
            let data13 = data.status;
            const _errs47 = errors;
            if (!(data13 === "loading" || data13 === "ok" || data13 === "stale" || data13 === "unconfigured" || data13 === "unavailable")) {
              validate42.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema38.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid15 = _errs47 === errors;
          } else {
            var valid15 = true;
          }
          if (valid15) {
            if (data.sourceId !== void 0) {
              let data14 = data.sourceId;
              const _errs48 = errors;
              const _errs49 = errors;
              let valid16 = false;
              const _errs50 = errors;
              if (errors === _errs50) {
                if (typeof data14 === "string") {
                  if (func1(data14) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors++;
                  } else {
                    if (func1(data14) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors++;
                    } else {
                      if (!pattern5.test(data14)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors++;
                }
              }
              var _valid5 = _errs50 === errors;
              valid16 = valid16 || _valid5;
              const _errs52 = errors;
              if (data14 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors++;
              }
              var _valid5 = _errs52 === errors;
              valid16 = valid16 || _valid5;
              if (!valid16) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors++;
                validate42.errors = vErrors;
                return false;
              } else {
                errors = _errs49;
                if (vErrors !== null) {
                  if (_errs49) {
                    vErrors.length = _errs49;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid15 = _errs48 === errors;
            } else {
              var valid15 = true;
            }
            if (valid15) {
              if (data.updatedAt !== void 0) {
                let data15 = data.updatedAt;
                const _errs54 = errors;
                const _errs55 = errors;
                let valid17 = false;
                const _errs56 = errors;
                if (errors === _errs56) {
                  if (errors === _errs56) {
                    if (typeof data15 === "string") {
                      if (func1(data15) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors++;
                      } else {
                        if (!formats0.validate(data15)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors++;
                    }
                  }
                }
                var _valid6 = _errs56 === errors;
                valid17 = valid17 || _valid6;
                const _errs58 = errors;
                if (data15 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors++;
                }
                var _valid6 = _errs58 === errors;
                valid17 = valid17 || _valid6;
                if (!valid17) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors++;
                  validate42.errors = vErrors;
                  return false;
                } else {
                  errors = _errs55;
                  if (vErrors !== null) {
                    if (_errs55) {
                      vErrors.length = _errs55;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid15 = _errs54 === errors;
              } else {
                var valid15 = true;
              }
              if (valid15) {
                if (data.data !== void 0) {
                  let data16 = data.data;
                  const _errs60 = errors;
                  const _errs61 = errors;
                  let valid18 = false;
                  const _errs62 = errors;
                  const _errs63 = errors;
                  if (errors === _errs63) {
                    if (data16 && typeof data16 == "object" && !Array.isArray(data16)) {
                      let missing2;
                      if (data16.cpuPercent === void 0 && (missing2 = "cpuPercent") || data16.memoryUsedBytes === void 0 && (missing2 = "memoryUsedBytes") || data16.memoryTotalBytes === void 0 && (missing2 = "memoryTotalBytes") || data16.temperatureC === void 0 && (missing2 = "temperatureC")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors++;
                      } else {
                        const _errs65 = errors;
                        for (const key2 in data16) {
                          if (!(key2 === "cpuPercent" || key2 === "memoryUsedBytes" || key2 === "memoryTotalBytes" || key2 === "temperatureC")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors++;
                            break;
                          }
                        }
                        if (_errs65 === errors) {
                          if (data16.cpuPercent !== void 0) {
                            let data17 = data16.cpuPercent;
                            const _errs66 = errors;
                            const _errs67 = errors;
                            let valid21 = false;
                            const _errs68 = errors;
                            if (errors === _errs68) {
                              if (typeof data17 == "number" && isFinite(data17)) {
                                if (data17 > 100 || isNaN(data17)) {
                                  const err27 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors++;
                                } else {
                                  if (data17 < 0 || isNaN(data17)) {
                                    const err28 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors++;
                              }
                            }
                            var _valid8 = _errs68 === errors;
                            valid21 = valid21 || _valid8;
                            const _errs70 = errors;
                            if (data17 !== null) {
                              const err30 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                              if (vErrors === null) {
                                vErrors = [err30];
                              } else {
                                vErrors.push(err30);
                              }
                              errors++;
                            }
                            var _valid8 = _errs70 === errors;
                            valid21 = valid21 || _valid8;
                            if (!valid21) {
                              const err31 = { instancePath: instancePath + "/data/cpuPercent", schemaPath: "#/$defs/SystemData/properties/cpuPercent/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                              if (vErrors === null) {
                                vErrors = [err31];
                              } else {
                                vErrors.push(err31);
                              }
                              errors++;
                            } else {
                              errors = _errs67;
                              if (vErrors !== null) {
                                if (_errs67) {
                                  vErrors.length = _errs67;
                                } else {
                                  vErrors = null;
                                }
                              }
                            }
                            var valid20 = _errs66 === errors;
                          } else {
                            var valid20 = true;
                          }
                          if (valid20) {
                            if (data16.memoryUsedBytes !== void 0) {
                              let data18 = data16.memoryUsedBytes;
                              const _errs72 = errors;
                              if (!(typeof data18 == "number" && (!(data18 % 1) && !isNaN(data18)) && isFinite(data18))) {
                                const err32 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors++;
                              }
                              if (errors === _errs72) {
                                if (typeof data18 == "number" && isFinite(data18)) {
                                  if (data18 > 9007199254740991 || isNaN(data18)) {
                                    const err33 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                    if (vErrors === null) {
                                      vErrors = [err33];
                                    } else {
                                      vErrors.push(err33);
                                    }
                                    errors++;
                                  } else {
                                    if (data18 < 0 || isNaN(data18)) {
                                      const err34 = { instancePath: instancePath + "/data/memoryUsedBytes", schemaPath: "#/$defs/SystemData/properties/memoryUsedBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors++;
                                    }
                                  }
                                }
                              }
                              var valid20 = _errs72 === errors;
                            } else {
                              var valid20 = true;
                            }
                            if (valid20) {
                              if (data16.memoryTotalBytes !== void 0) {
                                let data19 = data16.memoryTotalBytes;
                                const _errs74 = errors;
                                if (!(typeof data19 == "number" && (!(data19 % 1) && !isNaN(data19)) && isFinite(data19))) {
                                  const err35 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                  if (vErrors === null) {
                                    vErrors = [err35];
                                  } else {
                                    vErrors.push(err35);
                                  }
                                  errors++;
                                }
                                if (errors === _errs74) {
                                  if (typeof data19 == "number" && isFinite(data19)) {
                                    if (data19 > 9007199254740991 || isNaN(data19)) {
                                      const err36 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/maximum", keyword: "maximum", params: { comparison: "<=", limit: 9007199254740991 }, message: "must be <= 9007199254740991" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors++;
                                    } else {
                                      if (data19 < 0 || isNaN(data19)) {
                                        const err37 = { instancePath: instancePath + "/data/memoryTotalBytes", schemaPath: "#/$defs/SystemData/properties/memoryTotalBytes/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                        if (vErrors === null) {
                                          vErrors = [err37];
                                        } else {
                                          vErrors.push(err37);
                                        }
                                        errors++;
                                      }
                                    }
                                  }
                                }
                                var valid20 = _errs74 === errors;
                              } else {
                                var valid20 = true;
                              }
                              if (valid20) {
                                if (data16.temperatureC !== void 0) {
                                  let data20 = data16.temperatureC;
                                  const _errs76 = errors;
                                  const _errs77 = errors;
                                  let valid22 = false;
                                  const _errs78 = errors;
                                  if (!(typeof data20 == "number" && isFinite(data20))) {
                                    const err38 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err38];
                                    } else {
                                      vErrors.push(err38);
                                    }
                                    errors++;
                                  }
                                  var _valid9 = _errs78 === errors;
                                  valid22 = valid22 || _valid9;
                                  const _errs80 = errors;
                                  if (data20 !== null) {
                                    const err39 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                    if (vErrors === null) {
                                      vErrors = [err39];
                                    } else {
                                      vErrors.push(err39);
                                    }
                                    errors++;
                                  }
                                  var _valid9 = _errs80 === errors;
                                  valid22 = valid22 || _valid9;
                                  if (!valid22) {
                                    const err40 = { instancePath: instancePath + "/data/temperatureC", schemaPath: "#/$defs/SystemData/properties/temperatureC/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                    if (vErrors === null) {
                                      vErrors = [err40];
                                    } else {
                                      vErrors.push(err40);
                                    }
                                    errors++;
                                  } else {
                                    errors = _errs77;
                                    if (vErrors !== null) {
                                      if (_errs77) {
                                        vErrors.length = _errs77;
                                      } else {
                                        vErrors = null;
                                      }
                                    }
                                  }
                                  var valid20 = _errs76 === errors;
                                } else {
                                  var valid20 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err41 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/SystemData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors++;
                    }
                  }
                  var _valid7 = _errs62 === errors;
                  valid18 = valid18 || _valid7;
                  const _errs82 = errors;
                  if (data16 !== null) {
                    const err42 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err42];
                    } else {
                      vErrors.push(err42);
                    }
                    errors++;
                  }
                  var _valid7 = _errs82 === errors;
                  valid18 = valid18 || _valid7;
                  if (!valid18) {
                    const err43 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err43];
                    } else {
                      vErrors.push(err43);
                    }
                    errors++;
                    validate42.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs61;
                    if (vErrors !== null) {
                      if (_errs61) {
                        vErrors.length = _errs61;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid15 = _errs60 === errors;
                } else {
                  var valid15 = true;
                }
                if (valid15) {
                  if (data.errorCode !== void 0) {
                    let data21 = data.errorCode;
                    const _errs84 = errors;
                    const _errs85 = errors;
                    let valid23 = false;
                    const _errs86 = errors;
                    if (!(data21 === "NETWORK_ERROR" || data21 === "INVALID_DATA" || data21 === "PAYLOAD_TOO_LARGE" || data21 === "EXPANSION_LIMIT" || data21 === "UNSUPPORTED_CALENDAR" || data21 === "UNKNOWN_TIME_ZONE" || data21 === "KEYRING_LOCKED" || data21 === "SECRET_DELETION_FAILED" || data21 === "AUTH_ERROR" || data21 === "RATE_LIMITED" || data21 === "NO_PLAYER" || data21 === "NO_INTERFACE" || data21 === "SERVICE_UNAVAILABLE" || data21 === "INTERNAL_ERROR")) {
                      const err44 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema38.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err44];
                      } else {
                        vErrors.push(err44);
                      }
                      errors++;
                    }
                    var _valid10 = _errs86 === errors;
                    valid23 = valid23 || _valid10;
                    const _errs87 = errors;
                    if (data21 !== null) {
                      const err45 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err45];
                      } else {
                        vErrors.push(err45);
                      }
                      errors++;
                    }
                    var _valid10 = _errs87 === errors;
                    valid23 = valid23 || _valid10;
                    if (!valid23) {
                      const err46 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err46];
                      } else {
                        vErrors.push(err46);
                      }
                      errors++;
                      validate42.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs85;
                      if (vErrors !== null) {
                        if (_errs85) {
                          vErrors.length = _errs85;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid15 = _errs84 === errors;
                  } else {
                    var valid15 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate42.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate42.errors = vErrors;
  return errors === 0;
}
validate42.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var network = validate43;
function validate43(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate43.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors;
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors;
        const _errs7 = errors;
        if (errors === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.interface === void 0 && (missing0 = "interface") || data1.rxBytesPerSec === void 0 && (missing0 = "rxBytesPerSec") || data1.txBytesPerSec === void 0 && (missing0 = "txBytesPerSec") || data1.history === void 0 && (missing0 = "history")) {
              validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors;
              for (const key0 in data1) {
                if (!(key0 === "interface" || key0 === "rxBytesPerSec" || key0 === "txBytesPerSec" || key0 === "history")) {
                  validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors) {
                if (data1.interface !== void 0) {
                  let data2 = data1.interface;
                  const _errs10 = errors;
                  if (errors === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 64) {
                        validate43.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate43.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate43.errors = [{ instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.rxBytesPerSec !== void 0) {
                    let data3 = data1.rxBytesPerSec;
                    const _errs12 = errors;
                    const _errs13 = errors;
                    let valid6 = false;
                    const _errs14 = errors;
                    if (errors === _errs14) {
                      if (typeof data3 == "number" && isFinite(data3)) {
                        if (data3 < 0 || isNaN(data3)) {
                          const err1 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err1];
                          } else {
                            vErrors.push(err1);
                          }
                          errors++;
                        }
                      } else {
                        const err2 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err2];
                        } else {
                          vErrors.push(err2);
                        }
                        errors++;
                      }
                    }
                    var _valid1 = _errs14 === errors;
                    valid6 = valid6 || _valid1;
                    const _errs16 = errors;
                    if (data3 !== null) {
                      const err3 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err3];
                      } else {
                        vErrors.push(err3);
                      }
                      errors++;
                    }
                    var _valid1 = _errs16 === errors;
                    valid6 = valid6 || _valid1;
                    if (!valid6) {
                      const err4 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err4];
                      } else {
                        vErrors.push(err4);
                      }
                      errors++;
                      validate43.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs13;
                      if (vErrors !== null) {
                        if (_errs13) {
                          vErrors.length = _errs13;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid5 = _errs12 === errors;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.txBytesPerSec !== void 0) {
                      let data4 = data1.txBytesPerSec;
                      const _errs18 = errors;
                      const _errs19 = errors;
                      let valid7 = false;
                      const _errs20 = errors;
                      if (errors === _errs20) {
                        if (typeof data4 == "number" && isFinite(data4)) {
                          if (data4 < 0 || isNaN(data4)) {
                            const err5 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors++;
                          }
                        } else {
                          const err6 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err6];
                          } else {
                            vErrors.push(err6);
                          }
                          errors++;
                        }
                      }
                      var _valid2 = _errs20 === errors;
                      valid7 = valid7 || _valid2;
                      const _errs22 = errors;
                      if (data4 !== null) {
                        const err7 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                        if (vErrors === null) {
                          vErrors = [err7];
                        } else {
                          vErrors.push(err7);
                        }
                        errors++;
                      }
                      var _valid2 = _errs22 === errors;
                      valid7 = valid7 || _valid2;
                      if (!valid7) {
                        const err8 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                        if (vErrors === null) {
                          vErrors = [err8];
                        } else {
                          vErrors.push(err8);
                        }
                        errors++;
                        validate43.errors = vErrors;
                        return false;
                      } else {
                        errors = _errs19;
                        if (vErrors !== null) {
                          if (_errs19) {
                            vErrors.length = _errs19;
                          } else {
                            vErrors = null;
                          }
                        }
                      }
                      var valid5 = _errs18 === errors;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.history !== void 0) {
                        let data5 = data1.history;
                        const _errs24 = errors;
                        if (errors === _errs24) {
                          if (Array.isArray(data5)) {
                            if (data5.length > 60) {
                              validate43.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" }];
                              return false;
                            } else {
                              var valid8 = true;
                              const len0 = data5.length;
                              for (let i0 = 0; i0 < len0; i0++) {
                                let data6 = data5[i0];
                                const _errs26 = errors;
                                if (errors === _errs26) {
                                  if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
                                    let missing1;
                                    if (data6.at === void 0 && (missing1 = "at") || data6.rx === void 0 && (missing1 = "rx") || data6.tx === void 0 && (missing1 = "tx")) {
                                      validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                      return false;
                                    } else {
                                      const _errs28 = errors;
                                      for (const key1 in data6) {
                                        if (!(key1 === "at" || key1 === "rx" || key1 === "tx")) {
                                          validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                          return false;
                                          break;
                                        }
                                      }
                                      if (_errs28 === errors) {
                                        if (data6.at !== void 0) {
                                          let data7 = data6.at;
                                          const _errs29 = errors;
                                          if (errors === _errs29) {
                                            if (errors === _errs29) {
                                              if (typeof data7 === "string") {
                                                if (func1(data7) > 64) {
                                                  validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                } else {
                                                  if (!formats0.validate(data7)) {
                                                    validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                                    return false;
                                                  }
                                                }
                                              } else {
                                                validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                          }
                                          var valid9 = _errs29 === errors;
                                        } else {
                                          var valid9 = true;
                                        }
                                        if (valid9) {
                                          if (data6.rx !== void 0) {
                                            let data8 = data6.rx;
                                            const _errs31 = errors;
                                            if (errors === _errs31) {
                                              if (typeof data8 == "number" && isFinite(data8)) {
                                                if (data8 < 0 || isNaN(data8)) {
                                                  validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                  return false;
                                                }
                                              } else {
                                                validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                return false;
                                              }
                                            }
                                            var valid9 = _errs31 === errors;
                                          } else {
                                            var valid9 = true;
                                          }
                                          if (valid9) {
                                            if (data6.tx !== void 0) {
                                              let data9 = data6.tx;
                                              const _errs33 = errors;
                                              if (errors === _errs33) {
                                                if (typeof data9 == "number" && isFinite(data9)) {
                                                  if (data9 < 0 || isNaN(data9)) {
                                                    validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                                    return false;
                                                  }
                                                } else {
                                                  validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" }];
                                                  return false;
                                                }
                                              }
                                              var valid9 = _errs33 === errors;
                                            } else {
                                              var valid9 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  } else {
                                    validate43.errors = [{ instancePath: instancePath + "/data/history/" + i0, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                                    return false;
                                  }
                                }
                                var valid8 = _errs26 === errors;
                                if (!valid8) {
                                  break;
                                }
                              }
                            }
                          } else {
                            validate43.errors = [{ instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                            return false;
                          }
                        }
                        var valid5 = _errs24 === errors;
                      } else {
                        var valid5 = true;
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data10 = data.updatedAt;
          const _errs35 = errors;
          if (errors === _errs35) {
            if (errors === _errs35) {
              if (typeof data10 === "string") {
                if (func1(data10) > 64) {
                  validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data10)) {
                    validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs35 === errors;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err9 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err9];
    } else {
      vErrors.push(err9);
    }
    errors++;
    validate43.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors;
  if (valid0) {
    const _errs37 = errors;
    const _errs38 = errors;
    let valid10 = true;
    const _errs39 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data11 = data.status;
        if (!(data11 === "unconfigured" || data11 === "unavailable")) {
          const err10 = {};
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors++;
        }
      }
    }
    var _valid3 = _errs39 === errors;
    errors = _errs38;
    if (vErrors !== null) {
      if (_errs38) {
        vErrors.length = _errs38;
      } else {
        vErrors = null;
      }
    }
    if (_valid3) {
      const _errs41 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs42 = errors;
          if (data.data !== null) {
            validate43.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid12 = _errs42 === errors;
        } else {
          var valid12 = true;
        }
        if (valid12) {
          if (data.updatedAt !== void 0) {
            const _errs44 = errors;
            if (data.updatedAt !== null) {
              validate43.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid12 = _errs44 === errors;
          } else {
            var valid12 = true;
          }
        }
      }
      var _valid3 = _errs41 === errors;
      valid10 = _valid3;
      if (valid10) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid10) {
      const err11 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors++;
      validate43.errors = vErrors;
      return false;
    }
    var valid0 = _errs37 === errors;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs46 = errors;
      const _errs47 = errors;
      let valid13 = true;
      const _errs48 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data14 = data.status;
          if (!(data14 === "ok" || data14 === "unconfigured" || data14 === "loading")) {
            const err12 = {};
            if (vErrors === null) {
              vErrors = [err12];
            } else {
              vErrors.push(err12);
            }
            errors++;
          }
        }
      }
      var _valid4 = _errs48 === errors;
      errors = _errs47;
      if (vErrors !== null) {
        if (_errs47) {
          vErrors.length = _errs47;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid4) {
        const _errs50 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate43.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid4 = _errs50 === errors;
        valid13 = _valid4;
        if (valid13) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs53 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data16 = data.errorCode;
            if (!(data16 === "NETWORK_ERROR" || data16 === "INVALID_DATA" || data16 === "PAYLOAD_TOO_LARGE" || data16 === "EXPANSION_LIMIT" || data16 === "UNSUPPORTED_CALENDAR" || data16 === "UNKNOWN_TIME_ZONE" || data16 === "KEYRING_LOCKED" || data16 === "SECRET_DELETION_FAILED" || data16 === "AUTH_ERROR" || data16 === "RATE_LIMITED" || data16 === "NO_PLAYER" || data16 === "NO_INTERFACE" || data16 === "SERVICE_UNAVAILABLE" || data16 === "INTERNAL_ERROR")) {
              validate43.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema41.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid4 = _errs53 === errors;
        valid13 = _valid4;
        if (valid13) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid13) {
        const err13 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors++;
        validate43.errors = vErrors;
        return false;
      }
      var valid0 = _errs46 === errors;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing2;
      if (data.status === void 0 && (missing2 = "status") || data.sourceId === void 0 && (missing2 = "sourceId") || data.updatedAt === void 0 && (missing2 = "updatedAt") || data.data === void 0 && (missing2 = "data") || data.errorCode === void 0 && (missing2 = "errorCode")) {
        validate43.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
        return false;
      } else {
        const _errs55 = errors;
        for (const key2 in data) {
          if (!(key2 === "status" || key2 === "sourceId" || key2 === "updatedAt" || key2 === "data" || key2 === "errorCode")) {
            validate43.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs55 === errors) {
          if (data.status !== void 0) {
            let data17 = data.status;
            const _errs56 = errors;
            if (!(data17 === "loading" || data17 === "ok" || data17 === "stale" || data17 === "unconfigured" || data17 === "unavailable")) {
              validate43.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema41.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid17 = _errs56 === errors;
          } else {
            var valid17 = true;
          }
          if (valid17) {
            if (data.sourceId !== void 0) {
              let data18 = data.sourceId;
              const _errs57 = errors;
              const _errs58 = errors;
              let valid18 = false;
              const _errs59 = errors;
              if (errors === _errs59) {
                if (typeof data18 === "string") {
                  if (func1(data18) > 128) {
                    const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err14];
                    } else {
                      vErrors.push(err14);
                    }
                    errors++;
                  } else {
                    if (func1(data18) < 1) {
                      const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err15];
                      } else {
                        vErrors.push(err15);
                      }
                      errors++;
                    } else {
                      if (!pattern5.test(data18)) {
                        const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err16];
                        } else {
                          vErrors.push(err16);
                        }
                        errors++;
                      }
                    }
                  }
                } else {
                  const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err17];
                  } else {
                    vErrors.push(err17);
                  }
                  errors++;
                }
              }
              var _valid5 = _errs59 === errors;
              valid18 = valid18 || _valid5;
              const _errs61 = errors;
              if (data18 !== null) {
                const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err18];
                } else {
                  vErrors.push(err18);
                }
                errors++;
              }
              var _valid5 = _errs61 === errors;
              valid18 = valid18 || _valid5;
              if (!valid18) {
                const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err19];
                } else {
                  vErrors.push(err19);
                }
                errors++;
                validate43.errors = vErrors;
                return false;
              } else {
                errors = _errs58;
                if (vErrors !== null) {
                  if (_errs58) {
                    vErrors.length = _errs58;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid17 = _errs57 === errors;
            } else {
              var valid17 = true;
            }
            if (valid17) {
              if (data.updatedAt !== void 0) {
                let data19 = data.updatedAt;
                const _errs63 = errors;
                const _errs64 = errors;
                let valid19 = false;
                const _errs65 = errors;
                if (errors === _errs65) {
                  if (errors === _errs65) {
                    if (typeof data19 === "string") {
                      if (func1(data19) > 64) {
                        const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err20];
                        } else {
                          vErrors.push(err20);
                        }
                        errors++;
                      } else {
                        if (!formats0.validate(data19)) {
                          const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err21];
                          } else {
                            vErrors.push(err21);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err22];
                      } else {
                        vErrors.push(err22);
                      }
                      errors++;
                    }
                  }
                }
                var _valid6 = _errs65 === errors;
                valid19 = valid19 || _valid6;
                const _errs67 = errors;
                if (data19 !== null) {
                  const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors++;
                }
                var _valid6 = _errs67 === errors;
                valid19 = valid19 || _valid6;
                if (!valid19) {
                  const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err24];
                  } else {
                    vErrors.push(err24);
                  }
                  errors++;
                  validate43.errors = vErrors;
                  return false;
                } else {
                  errors = _errs64;
                  if (vErrors !== null) {
                    if (_errs64) {
                      vErrors.length = _errs64;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid17 = _errs63 === errors;
              } else {
                var valid17 = true;
              }
              if (valid17) {
                if (data.data !== void 0) {
                  let data20 = data.data;
                  const _errs69 = errors;
                  const _errs70 = errors;
                  let valid20 = false;
                  const _errs71 = errors;
                  const _errs72 = errors;
                  if (errors === _errs72) {
                    if (data20 && typeof data20 == "object" && !Array.isArray(data20)) {
                      let missing3;
                      if (data20.interface === void 0 && (missing3 = "interface") || data20.rxBytesPerSec === void 0 && (missing3 = "rxBytesPerSec") || data20.txBytesPerSec === void 0 && (missing3 = "txBytesPerSec") || data20.history === void 0 && (missing3 = "history")) {
                        const err25 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" };
                        if (vErrors === null) {
                          vErrors = [err25];
                        } else {
                          vErrors.push(err25);
                        }
                        errors++;
                      } else {
                        const _errs74 = errors;
                        for (const key3 in data20) {
                          if (!(key3 === "interface" || key3 === "rxBytesPerSec" || key3 === "txBytesPerSec" || key3 === "history")) {
                            const err26 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err26];
                            } else {
                              vErrors.push(err26);
                            }
                            errors++;
                            break;
                          }
                        }
                        if (_errs74 === errors) {
                          if (data20.interface !== void 0) {
                            let data21 = data20.interface;
                            const _errs75 = errors;
                            if (errors === _errs75) {
                              if (typeof data21 === "string") {
                                if (func1(data21) > 64) {
                                  const err27 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors++;
                                } else {
                                  if (func1(data21) < 1) {
                                    const err28 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err28];
                                    } else {
                                      vErrors.push(err28);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err29 = { instancePath: instancePath + "/data/interface", schemaPath: "#/$defs/NetworkData/properties/interface/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err29];
                                } else {
                                  vErrors.push(err29);
                                }
                                errors++;
                              }
                            }
                            var valid22 = _errs75 === errors;
                          } else {
                            var valid22 = true;
                          }
                          if (valid22) {
                            if (data20.rxBytesPerSec !== void 0) {
                              let data22 = data20.rxBytesPerSec;
                              const _errs77 = errors;
                              const _errs78 = errors;
                              let valid23 = false;
                              const _errs79 = errors;
                              if (errors === _errs79) {
                                if (typeof data22 == "number" && isFinite(data22)) {
                                  if (data22 < 0 || isNaN(data22)) {
                                    const err30 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                    if (vErrors === null) {
                                      vErrors = [err30];
                                    } else {
                                      vErrors.push(err30);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err31 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err31];
                                  } else {
                                    vErrors.push(err31);
                                  }
                                  errors++;
                                }
                              }
                              var _valid8 = _errs79 === errors;
                              valid23 = valid23 || _valid8;
                              const _errs81 = errors;
                              if (data22 !== null) {
                                const err32 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err32];
                                } else {
                                  vErrors.push(err32);
                                }
                                errors++;
                              }
                              var _valid8 = _errs81 === errors;
                              valid23 = valid23 || _valid8;
                              if (!valid23) {
                                const err33 = { instancePath: instancePath + "/data/rxBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/rxBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err33];
                                } else {
                                  vErrors.push(err33);
                                }
                                errors++;
                              } else {
                                errors = _errs78;
                                if (vErrors !== null) {
                                  if (_errs78) {
                                    vErrors.length = _errs78;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid22 = _errs77 === errors;
                            } else {
                              var valid22 = true;
                            }
                            if (valid22) {
                              if (data20.txBytesPerSec !== void 0) {
                                let data23 = data20.txBytesPerSec;
                                const _errs83 = errors;
                                const _errs84 = errors;
                                let valid24 = false;
                                const _errs85 = errors;
                                if (errors === _errs85) {
                                  if (typeof data23 == "number" && isFinite(data23)) {
                                    if (data23 < 0 || isNaN(data23)) {
                                      const err34 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                      if (vErrors === null) {
                                        vErrors = [err34];
                                      } else {
                                        vErrors.push(err34);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err35 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/0/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err35];
                                    } else {
                                      vErrors.push(err35);
                                    }
                                    errors++;
                                  }
                                }
                                var _valid9 = _errs85 === errors;
                                valid24 = valid24 || _valid9;
                                const _errs87 = errors;
                                if (data23 !== null) {
                                  const err36 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err36];
                                  } else {
                                    vErrors.push(err36);
                                  }
                                  errors++;
                                }
                                var _valid9 = _errs87 === errors;
                                valid24 = valid24 || _valid9;
                                if (!valid24) {
                                  const err37 = { instancePath: instancePath + "/data/txBytesPerSec", schemaPath: "#/$defs/NetworkData/properties/txBytesPerSec/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err37];
                                  } else {
                                    vErrors.push(err37);
                                  }
                                  errors++;
                                } else {
                                  errors = _errs84;
                                  if (vErrors !== null) {
                                    if (_errs84) {
                                      vErrors.length = _errs84;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid22 = _errs83 === errors;
                              } else {
                                var valid22 = true;
                              }
                              if (valid22) {
                                if (data20.history !== void 0) {
                                  let data24 = data20.history;
                                  const _errs89 = errors;
                                  if (errors === _errs89) {
                                    if (Array.isArray(data24)) {
                                      if (data24.length > 60) {
                                        const err38 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/maxItems", keyword: "maxItems", params: { limit: 60 }, message: "must NOT have more than 60 items" };
                                        if (vErrors === null) {
                                          vErrors = [err38];
                                        } else {
                                          vErrors.push(err38);
                                        }
                                        errors++;
                                      } else {
                                        var valid25 = true;
                                        const len1 = data24.length;
                                        for (let i1 = 0; i1 < len1; i1++) {
                                          let data25 = data24[i1];
                                          const _errs91 = errors;
                                          if (errors === _errs91) {
                                            if (data25 && typeof data25 == "object" && !Array.isArray(data25)) {
                                              let missing4;
                                              if (data25.at === void 0 && (missing4 = "at") || data25.rx === void 0 && (missing4 = "rx") || data25.tx === void 0 && (missing4 = "tx")) {
                                                const err39 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/required", keyword: "required", params: { missingProperty: missing4 }, message: "must have required property '" + missing4 + "'" };
                                                if (vErrors === null) {
                                                  vErrors = [err39];
                                                } else {
                                                  vErrors.push(err39);
                                                }
                                                errors++;
                                              } else {
                                                const _errs93 = errors;
                                                for (const key4 in data25) {
                                                  if (!(key4 === "at" || key4 === "rx" || key4 === "tx")) {
                                                    const err40 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                                                    if (vErrors === null) {
                                                      vErrors = [err40];
                                                    } else {
                                                      vErrors.push(err40);
                                                    }
                                                    errors++;
                                                    break;
                                                  }
                                                }
                                                if (_errs93 === errors) {
                                                  if (data25.at !== void 0) {
                                                    let data26 = data25.at;
                                                    const _errs94 = errors;
                                                    if (errors === _errs94) {
                                                      if (errors === _errs94) {
                                                        if (typeof data26 === "string") {
                                                          if (func1(data26) > 64) {
                                                            const err41 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                                            if (vErrors === null) {
                                                              vErrors = [err41];
                                                            } else {
                                                              vErrors.push(err41);
                                                            }
                                                            errors++;
                                                          } else {
                                                            if (!formats0.validate(data26)) {
                                                              const err42 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                                              if (vErrors === null) {
                                                                vErrors = [err42];
                                                              } else {
                                                                vErrors.push(err42);
                                                              }
                                                              errors++;
                                                            }
                                                          }
                                                        } else {
                                                          const err43 = { instancePath: instancePath + "/data/history/" + i1 + "/at", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/at/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                          if (vErrors === null) {
                                                            vErrors = [err43];
                                                          } else {
                                                            vErrors.push(err43);
                                                          }
                                                          errors++;
                                                        }
                                                      }
                                                    }
                                                    var valid26 = _errs94 === errors;
                                                  } else {
                                                    var valid26 = true;
                                                  }
                                                  if (valid26) {
                                                    if (data25.rx !== void 0) {
                                                      let data27 = data25.rx;
                                                      const _errs96 = errors;
                                                      if (errors === _errs96) {
                                                        if (typeof data27 == "number" && isFinite(data27)) {
                                                          if (data27 < 0 || isNaN(data27)) {
                                                            const err44 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                            if (vErrors === null) {
                                                              vErrors = [err44];
                                                            } else {
                                                              vErrors.push(err44);
                                                            }
                                                            errors++;
                                                          }
                                                        } else {
                                                          const err45 = { instancePath: instancePath + "/data/history/" + i1 + "/rx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/rx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                          if (vErrors === null) {
                                                            vErrors = [err45];
                                                          } else {
                                                            vErrors.push(err45);
                                                          }
                                                          errors++;
                                                        }
                                                      }
                                                      var valid26 = _errs96 === errors;
                                                    } else {
                                                      var valid26 = true;
                                                    }
                                                    if (valid26) {
                                                      if (data25.tx !== void 0) {
                                                        let data28 = data25.tx;
                                                        const _errs98 = errors;
                                                        if (errors === _errs98) {
                                                          if (typeof data28 == "number" && isFinite(data28)) {
                                                            if (data28 < 0 || isNaN(data28)) {
                                                              const err46 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                                              if (vErrors === null) {
                                                                vErrors = [err46];
                                                              } else {
                                                                vErrors.push(err46);
                                                              }
                                                              errors++;
                                                            }
                                                          } else {
                                                            const err47 = { instancePath: instancePath + "/data/history/" + i1 + "/tx", schemaPath: "#/$defs/NetworkData/properties/history/items/properties/tx/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                            if (vErrors === null) {
                                                              vErrors = [err47];
                                                            } else {
                                                              vErrors.push(err47);
                                                            }
                                                            errors++;
                                                          }
                                                        }
                                                        var valid26 = _errs98 === errors;
                                                      } else {
                                                        var valid26 = true;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            } else {
                                              const err48 = { instancePath: instancePath + "/data/history/" + i1, schemaPath: "#/$defs/NetworkData/properties/history/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                              if (vErrors === null) {
                                                vErrors = [err48];
                                              } else {
                                                vErrors.push(err48);
                                              }
                                              errors++;
                                            }
                                          }
                                          var valid25 = _errs91 === errors;
                                          if (!valid25) {
                                            break;
                                          }
                                        }
                                      }
                                    } else {
                                      const err49 = { instancePath: instancePath + "/data/history", schemaPath: "#/$defs/NetworkData/properties/history/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err49];
                                      } else {
                                        vErrors.push(err49);
                                      }
                                      errors++;
                                    }
                                  }
                                  var valid22 = _errs89 === errors;
                                } else {
                                  var valid22 = true;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err50 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/NetworkData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err50];
                      } else {
                        vErrors.push(err50);
                      }
                      errors++;
                    }
                  }
                  var _valid7 = _errs71 === errors;
                  valid20 = valid20 || _valid7;
                  const _errs100 = errors;
                  if (data20 !== null) {
                    const err51 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err51];
                    } else {
                      vErrors.push(err51);
                    }
                    errors++;
                  }
                  var _valid7 = _errs100 === errors;
                  valid20 = valid20 || _valid7;
                  if (!valid20) {
                    const err52 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err52];
                    } else {
                      vErrors.push(err52);
                    }
                    errors++;
                    validate43.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs70;
                    if (vErrors !== null) {
                      if (_errs70) {
                        vErrors.length = _errs70;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid17 = _errs69 === errors;
                } else {
                  var valid17 = true;
                }
                if (valid17) {
                  if (data.errorCode !== void 0) {
                    let data29 = data.errorCode;
                    const _errs102 = errors;
                    const _errs103 = errors;
                    let valid27 = false;
                    const _errs104 = errors;
                    if (!(data29 === "NETWORK_ERROR" || data29 === "INVALID_DATA" || data29 === "PAYLOAD_TOO_LARGE" || data29 === "EXPANSION_LIMIT" || data29 === "UNSUPPORTED_CALENDAR" || data29 === "UNKNOWN_TIME_ZONE" || data29 === "KEYRING_LOCKED" || data29 === "SECRET_DELETION_FAILED" || data29 === "AUTH_ERROR" || data29 === "RATE_LIMITED" || data29 === "NO_PLAYER" || data29 === "NO_INTERFACE" || data29 === "SERVICE_UNAVAILABLE" || data29 === "INTERNAL_ERROR")) {
                      const err53 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema41.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err53];
                      } else {
                        vErrors.push(err53);
                      }
                      errors++;
                    }
                    var _valid10 = _errs104 === errors;
                    valid27 = valid27 || _valid10;
                    const _errs105 = errors;
                    if (data29 !== null) {
                      const err54 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err54];
                      } else {
                        vErrors.push(err54);
                      }
                      errors++;
                    }
                    var _valid10 = _errs105 === errors;
                    valid27 = valid27 || _valid10;
                    if (!valid27) {
                      const err55 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err55];
                      } else {
                        vErrors.push(err55);
                      }
                      errors++;
                      validate43.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs103;
                      if (vErrors !== null) {
                        if (_errs103) {
                          vErrors.length = _errs103;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid17 = _errs102 === errors;
                  } else {
                    var valid17 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate43.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate43.errors = vErrors;
  return errors === 0;
}
validate43.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var media = validate44;
function validate44(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate44.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs1 = errors;
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      let data0 = data.status;
      if (!(data0 === "ok" || data0 === "stale")) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.data !== void 0) {
        let data1 = data.data;
        const _errs6 = errors;
        const _errs7 = errors;
        if (errors === _errs7) {
          if (data1 && typeof data1 == "object" && !Array.isArray(data1)) {
            let missing0;
            if (data1.player === void 0 && (missing0 = "player") || data1.status === void 0 && (missing0 = "status") || data1.title === void 0 && (missing0 = "title") || data1.artist === void 0 && (missing0 = "artist") || data1.artUri === void 0 && (missing0 = "artUri")) {
              validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
              return false;
            } else {
              const _errs9 = errors;
              for (const key0 in data1) {
                if (!(key0 === "player" || key0 === "status" || key0 === "title" || key0 === "artist" || key0 === "artUri")) {
                  validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
                  return false;
                  break;
                }
              }
              if (_errs9 === errors) {
                if (data1.player !== void 0) {
                  let data2 = data1.player;
                  const _errs10 = errors;
                  if (errors === _errs10) {
                    if (typeof data2 === "string") {
                      if (func1(data2) > 255) {
                        validate44.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                        return false;
                      } else {
                        if (func1(data2) < 1) {
                          validate44.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                          return false;
                        }
                      }
                    } else {
                      validate44.errors = [{ instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                      return false;
                    }
                  }
                  var valid5 = _errs10 === errors;
                } else {
                  var valid5 = true;
                }
                if (valid5) {
                  if (data1.status !== void 0) {
                    let data3 = data1.status;
                    const _errs12 = errors;
                    if (!(data3 === "playing" || data3 === "paused" || data3 === "stopped")) {
                      validate44.errors = [{ instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" }];
                      return false;
                    }
                    var valid5 = _errs12 === errors;
                  } else {
                    var valid5 = true;
                  }
                  if (valid5) {
                    if (data1.title !== void 0) {
                      let data4 = data1.title;
                      const _errs13 = errors;
                      if (errors === _errs13) {
                        if (typeof data4 === "string") {
                          if (func1(data4) > 4096) {
                            validate44.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                            return false;
                          }
                        } else {
                          validate44.errors = [{ instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                          return false;
                        }
                      }
                      var valid5 = _errs13 === errors;
                    } else {
                      var valid5 = true;
                    }
                    if (valid5) {
                      if (data1.artist !== void 0) {
                        let data5 = data1.artist;
                        const _errs15 = errors;
                        if (errors === _errs15) {
                          if (typeof data5 === "string") {
                            if (func1(data5) > 4096) {
                              validate44.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                              return false;
                            }
                          } else {
                            validate44.errors = [{ instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                            return false;
                          }
                        }
                        var valid5 = _errs15 === errors;
                      } else {
                        var valid5 = true;
                      }
                      if (valid5) {
                        if (data1.artUri !== void 0) {
                          let data6 = data1.artUri;
                          const _errs17 = errors;
                          const _errs18 = errors;
                          let valid6 = false;
                          const _errs19 = errors;
                          if (errors === _errs19) {
                            if (typeof data6 === "string") {
                              if (func1(data6) > 4096) {
                                const err1 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                if (vErrors === null) {
                                  vErrors = [err1];
                                } else {
                                  vErrors.push(err1);
                                }
                                errors++;
                              } else {
                                if (!pattern11.test(data6)) {
                                  const err2 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                  if (vErrors === null) {
                                    vErrors = [err2];
                                  } else {
                                    vErrors.push(err2);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err3 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err3];
                              } else {
                                vErrors.push(err3);
                              }
                              errors++;
                            }
                          }
                          var _valid1 = _errs19 === errors;
                          valid6 = valid6 || _valid1;
                          const _errs21 = errors;
                          if (data6 !== null) {
                            const err4 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err4];
                            } else {
                              vErrors.push(err4);
                            }
                            errors++;
                          }
                          var _valid1 = _errs21 === errors;
                          valid6 = valid6 || _valid1;
                          if (!valid6) {
                            const err5 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err5];
                            } else {
                              vErrors.push(err5);
                            }
                            errors++;
                            validate44.errors = vErrors;
                            return false;
                          } else {
                            errors = _errs18;
                            if (vErrors !== null) {
                              if (_errs18) {
                                vErrors.length = _errs18;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid5 = _errs17 === errors;
                        } else {
                          var valid5 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
            return false;
          }
        }
        var valid3 = _errs6 === errors;
      } else {
        var valid3 = true;
      }
      if (valid3) {
        if (data.updatedAt !== void 0) {
          let data7 = data.updatedAt;
          const _errs23 = errors;
          if (errors === _errs23) {
            if (errors === _errs23) {
              if (typeof data7 === "string") {
                if (func1(data7) > 64) {
                  validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                  return false;
                } else {
                  if (!formats0.validate(data7)) {
                    validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                    return false;
                  }
                }
              } else {
                validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/0/then/properties/updatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
          }
          var valid3 = _errs23 === errors;
        } else {
          var valid3 = true;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.data = true;
      props0.updatedAt = true;
      props0.status = true;
    }
  }
  if (!valid1) {
    const err6 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err6];
    } else {
      vErrors.push(err6);
    }
    errors++;
    validate44.errors = vErrors;
    return false;
  }
  var valid0 = _errs1 === errors;
  if (valid0) {
    const _errs25 = errors;
    const _errs26 = errors;
    let valid7 = true;
    const _errs27 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.status !== void 0) {
        let data8 = data.status;
        if (!(data8 === "unconfigured" || data8 === "unavailable")) {
          const err7 = {};
          if (vErrors === null) {
            vErrors = [err7];
          } else {
            vErrors.push(err7);
          }
          errors++;
        }
      }
    }
    var _valid2 = _errs27 === errors;
    errors = _errs26;
    if (vErrors !== null) {
      if (_errs26) {
        vErrors.length = _errs26;
      } else {
        vErrors = null;
      }
    }
    if (_valid2) {
      const _errs29 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.data !== void 0) {
          const _errs30 = errors;
          if (data.data !== null) {
            validate44.errors = [{ instancePath: instancePath + "/data", schemaPath: "#/allOf/1/then/properties/data/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
            return false;
          }
          var valid9 = _errs30 === errors;
        } else {
          var valid9 = true;
        }
        if (valid9) {
          if (data.updatedAt !== void 0) {
            const _errs32 = errors;
            if (data.updatedAt !== null) {
              validate44.errors = [{ instancePath: instancePath + "/updatedAt", schemaPath: "#/allOf/1/then/properties/updatedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
            var valid9 = _errs32 === errors;
          } else {
            var valid9 = true;
          }
        }
      }
      var _valid2 = _errs29 === errors;
      valid7 = _valid2;
      if (valid7) {
        var props1 = {};
        props1.data = true;
        props1.updatedAt = true;
        props1.status = true;
      }
    }
    if (!valid7) {
      const err8 = { instancePath, schemaPath: "#/allOf/1/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors++;
      validate44.errors = vErrors;
      return false;
    }
    var valid0 = _errs25 === errors;
    if (valid0) {
      if (props0 !== true && props1 !== void 0) {
        if (props1 === true) {
          props0 = true;
        } else {
          props0 = props0 || {};
          Object.assign(props0, props1);
        }
      }
      const _errs34 = errors;
      const _errs35 = errors;
      let valid10 = true;
      const _errs36 = errors;
      if (data && typeof data == "object" && !Array.isArray(data)) {
        if (data.status !== void 0) {
          let data11 = data.status;
          if (!(data11 === "ok" || data11 === "unconfigured" || data11 === "loading")) {
            const err9 = {};
            if (vErrors === null) {
              vErrors = [err9];
            } else {
              vErrors.push(err9);
            }
            errors++;
          }
        }
      }
      var _valid3 = _errs36 === errors;
      errors = _errs35;
      if (vErrors !== null) {
        if (_errs35) {
          vErrors.length = _errs35;
        } else {
          vErrors = null;
        }
      }
      let ifClause0;
      if (_valid3) {
        const _errs38 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            if (data.errorCode !== null) {
              validate44.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/then/properties/errorCode/type", keyword: "type", params: { type: "null" }, message: "must be null" }];
              return false;
            }
          }
        }
        var _valid3 = _errs38 === errors;
        valid10 = _valid3;
        if (valid10) {
          var props2 = {};
          props2.errorCode = true;
          props2.status = true;
        }
        ifClause0 = "then";
      } else {
        const _errs41 = errors;
        if (data && typeof data == "object" && !Array.isArray(data)) {
          if (data.errorCode !== void 0) {
            let data13 = data.errorCode;
            if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
              validate44.errors = [{ instancePath: instancePath + "/errorCode", schemaPath: "#/allOf/2/else/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema44.allOf[2].else.properties.errorCode.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
          }
        }
        var _valid3 = _errs41 === errors;
        valid10 = _valid3;
        if (valid10) {
          if (props2 !== true) {
            props2 = props2 || {};
            props2.errorCode = true;
          }
        }
        ifClause0 = "else";
      }
      if (!valid10) {
        const err10 = { instancePath, schemaPath: "#/allOf/2/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
        if (vErrors === null) {
          vErrors = [err10];
        } else {
          vErrors.push(err10);
        }
        errors++;
        validate44.errors = vErrors;
        return false;
      }
      var valid0 = _errs34 === errors;
      if (valid0) {
        if (props0 !== true && props2 !== void 0) {
          if (props2 === true) {
            props0 = true;
          } else {
            props0 = props0 || {};
            Object.assign(props0, props2);
          }
        }
      }
    }
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.status === void 0 && (missing1 = "status") || data.sourceId === void 0 && (missing1 = "sourceId") || data.updatedAt === void 0 && (missing1 = "updatedAt") || data.data === void 0 && (missing1 = "data") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        validate44.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
        return false;
      } else {
        const _errs43 = errors;
        for (const key1 in data) {
          if (!(key1 === "status" || key1 === "sourceId" || key1 === "updatedAt" || key1 === "data" || key1 === "errorCode")) {
            validate44.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs43 === errors) {
          if (data.status !== void 0) {
            let data14 = data.status;
            const _errs44 = errors;
            if (!(data14 === "loading" || data14 === "ok" || data14 === "stale" || data14 === "unconfigured" || data14 === "unavailable")) {
              validate44.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema44.properties.status.enum }, message: "must be equal to one of the allowed values" }];
              return false;
            }
            var valid14 = _errs44 === errors;
          } else {
            var valid14 = true;
          }
          if (valid14) {
            if (data.sourceId !== void 0) {
              let data15 = data.sourceId;
              const _errs45 = errors;
              const _errs46 = errors;
              let valid15 = false;
              const _errs47 = errors;
              if (errors === _errs47) {
                if (typeof data15 === "string") {
                  if (func1(data15) > 128) {
                    const err11 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err11];
                    } else {
                      vErrors.push(err11);
                    }
                    errors++;
                  } else {
                    if (func1(data15) < 1) {
                      const err12 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors++;
                    } else {
                      if (!pattern5.test(data15)) {
                        const err13 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                        if (vErrors === null) {
                          vErrors = [err13];
                        } else {
                          vErrors.push(err13);
                        }
                        errors++;
                      }
                    }
                  }
                } else {
                  const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err14];
                  } else {
                    vErrors.push(err14);
                  }
                  errors++;
                }
              }
              var _valid4 = _errs47 === errors;
              valid15 = valid15 || _valid4;
              const _errs49 = errors;
              if (data15 !== null) {
                const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                if (vErrors === null) {
                  vErrors = [err15];
                } else {
                  vErrors.push(err15);
                }
                errors++;
              }
              var _valid4 = _errs49 === errors;
              valid15 = valid15 || _valid4;
              if (!valid15) {
                const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                if (vErrors === null) {
                  vErrors = [err16];
                } else {
                  vErrors.push(err16);
                }
                errors++;
                validate44.errors = vErrors;
                return false;
              } else {
                errors = _errs46;
                if (vErrors !== null) {
                  if (_errs46) {
                    vErrors.length = _errs46;
                  } else {
                    vErrors = null;
                  }
                }
              }
              var valid14 = _errs45 === errors;
            } else {
              var valid14 = true;
            }
            if (valid14) {
              if (data.updatedAt !== void 0) {
                let data16 = data.updatedAt;
                const _errs51 = errors;
                const _errs52 = errors;
                let valid16 = false;
                const _errs53 = errors;
                if (errors === _errs53) {
                  if (errors === _errs53) {
                    if (typeof data16 === "string") {
                      if (func1(data16) > 64) {
                        const err17 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                        if (vErrors === null) {
                          vErrors = [err17];
                        } else {
                          vErrors.push(err17);
                        }
                        errors++;
                      } else {
                        if (!formats0.validate(data16)) {
                          const err18 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                          if (vErrors === null) {
                            vErrors = [err18];
                          } else {
                            vErrors.push(err18);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err19 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err19];
                      } else {
                        vErrors.push(err19);
                      }
                      errors++;
                    }
                  }
                }
                var _valid5 = _errs53 === errors;
                valid16 = valid16 || _valid5;
                const _errs55 = errors;
                if (data16 !== null) {
                  const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                  if (vErrors === null) {
                    vErrors = [err20];
                  } else {
                    vErrors.push(err20);
                  }
                  errors++;
                }
                var _valid5 = _errs55 === errors;
                valid16 = valid16 || _valid5;
                if (!valid16) {
                  const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                  if (vErrors === null) {
                    vErrors = [err21];
                  } else {
                    vErrors.push(err21);
                  }
                  errors++;
                  validate44.errors = vErrors;
                  return false;
                } else {
                  errors = _errs52;
                  if (vErrors !== null) {
                    if (_errs52) {
                      vErrors.length = _errs52;
                    } else {
                      vErrors = null;
                    }
                  }
                }
                var valid14 = _errs51 === errors;
              } else {
                var valid14 = true;
              }
              if (valid14) {
                if (data.data !== void 0) {
                  let data17 = data.data;
                  const _errs57 = errors;
                  const _errs58 = errors;
                  let valid17 = false;
                  const _errs59 = errors;
                  const _errs60 = errors;
                  if (errors === _errs60) {
                    if (data17 && typeof data17 == "object" && !Array.isArray(data17)) {
                      let missing2;
                      if (data17.player === void 0 && (missing2 = "player") || data17.status === void 0 && (missing2 = "status") || data17.title === void 0 && (missing2 = "title") || data17.artist === void 0 && (missing2 = "artist") || data17.artUri === void 0 && (missing2 = "artUri")) {
                        const err22 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" };
                        if (vErrors === null) {
                          vErrors = [err22];
                        } else {
                          vErrors.push(err22);
                        }
                        errors++;
                      } else {
                        const _errs62 = errors;
                        for (const key2 in data17) {
                          if (!(key2 === "player" || key2 === "status" || key2 === "title" || key2 === "artist" || key2 === "artUri")) {
                            const err23 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err23];
                            } else {
                              vErrors.push(err23);
                            }
                            errors++;
                            break;
                          }
                        }
                        if (_errs62 === errors) {
                          if (data17.player !== void 0) {
                            let data18 = data17.player;
                            const _errs63 = errors;
                            if (errors === _errs63) {
                              if (typeof data18 === "string") {
                                if (func1(data18) > 255) {
                                  const err24 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err24];
                                  } else {
                                    vErrors.push(err24);
                                  }
                                  errors++;
                                } else {
                                  if (func1(data18) < 1) {
                                    const err25 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err25];
                                    } else {
                                      vErrors.push(err25);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err26 = { instancePath: instancePath + "/data/player", schemaPath: "#/$defs/MediaData/properties/player/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err26];
                                } else {
                                  vErrors.push(err26);
                                }
                                errors++;
                              }
                            }
                            var valid19 = _errs63 === errors;
                          } else {
                            var valid19 = true;
                          }
                          if (valid19) {
                            if (data17.status !== void 0) {
                              let data19 = data17.status;
                              const _errs65 = errors;
                              if (!(data19 === "playing" || data19 === "paused" || data19 === "stopped")) {
                                const err27 = { instancePath: instancePath + "/data/status", schemaPath: "#/$defs/MediaData/properties/status/enum", keyword: "enum", params: { allowedValues: schema45.properties.status.enum }, message: "must be equal to one of the allowed values" };
                                if (vErrors === null) {
                                  vErrors = [err27];
                                } else {
                                  vErrors.push(err27);
                                }
                                errors++;
                              }
                              var valid19 = _errs65 === errors;
                            } else {
                              var valid19 = true;
                            }
                            if (valid19) {
                              if (data17.title !== void 0) {
                                let data20 = data17.title;
                                const _errs66 = errors;
                                if (errors === _errs66) {
                                  if (typeof data20 === "string") {
                                    if (func1(data20) > 4096) {
                                      const err28 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err28];
                                      } else {
                                        vErrors.push(err28);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err29 = { instancePath: instancePath + "/data/title", schemaPath: "#/$defs/MediaData/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err29];
                                    } else {
                                      vErrors.push(err29);
                                    }
                                    errors++;
                                  }
                                }
                                var valid19 = _errs66 === errors;
                              } else {
                                var valid19 = true;
                              }
                              if (valid19) {
                                if (data17.artist !== void 0) {
                                  let data21 = data17.artist;
                                  const _errs68 = errors;
                                  if (errors === _errs68) {
                                    if (typeof data21 === "string") {
                                      if (func1(data21) > 4096) {
                                        const err30 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err30];
                                        } else {
                                          vErrors.push(err30);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err31 = { instancePath: instancePath + "/data/artist", schemaPath: "#/$defs/MediaData/properties/artist/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err31];
                                      } else {
                                        vErrors.push(err31);
                                      }
                                      errors++;
                                    }
                                  }
                                  var valid19 = _errs68 === errors;
                                } else {
                                  var valid19 = true;
                                }
                                if (valid19) {
                                  if (data17.artUri !== void 0) {
                                    let data22 = data17.artUri;
                                    const _errs70 = errors;
                                    const _errs71 = errors;
                                    let valid20 = false;
                                    const _errs72 = errors;
                                    if (errors === _errs72) {
                                      if (typeof data22 === "string") {
                                        if (func1(data22) > 4096) {
                                          const err32 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err32];
                                          } else {
                                            vErrors.push(err32);
                                          }
                                          errors++;
                                        } else {
                                          if (!pattern11.test(data22)) {
                                            const err33 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^file:///" }, message: 'must match pattern "^file:///"' };
                                            if (vErrors === null) {
                                              vErrors = [err33];
                                            } else {
                                              vErrors.push(err33);
                                            }
                                            errors++;
                                          }
                                        }
                                      } else {
                                        const err34 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err34];
                                        } else {
                                          vErrors.push(err34);
                                        }
                                        errors++;
                                      }
                                    }
                                    var _valid7 = _errs72 === errors;
                                    valid20 = valid20 || _valid7;
                                    const _errs74 = errors;
                                    if (data22 !== null) {
                                      const err35 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                      if (vErrors === null) {
                                        vErrors = [err35];
                                      } else {
                                        vErrors.push(err35);
                                      }
                                      errors++;
                                    }
                                    var _valid7 = _errs74 === errors;
                                    valid20 = valid20 || _valid7;
                                    if (!valid20) {
                                      const err36 = { instancePath: instancePath + "/data/artUri", schemaPath: "#/$defs/MediaData/properties/artUri/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                      if (vErrors === null) {
                                        vErrors = [err36];
                                      } else {
                                        vErrors.push(err36);
                                      }
                                      errors++;
                                    } else {
                                      errors = _errs71;
                                      if (vErrors !== null) {
                                        if (_errs71) {
                                          vErrors.length = _errs71;
                                        } else {
                                          vErrors = null;
                                        }
                                      }
                                    }
                                    var valid19 = _errs70 === errors;
                                  } else {
                                    var valid19 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      const err37 = { instancePath: instancePath + "/data", schemaPath: "#/$defs/MediaData/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err37];
                      } else {
                        vErrors.push(err37);
                      }
                      errors++;
                    }
                  }
                  var _valid6 = _errs59 === errors;
                  valid17 = valid17 || _valid6;
                  const _errs76 = errors;
                  if (data17 !== null) {
                    const err38 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                    if (vErrors === null) {
                      vErrors = [err38];
                    } else {
                      vErrors.push(err38);
                    }
                    errors++;
                  }
                  var _valid6 = _errs76 === errors;
                  valid17 = valid17 || _valid6;
                  if (!valid17) {
                    const err39 = { instancePath: instancePath + "/data", schemaPath: "#/properties/data/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                    if (vErrors === null) {
                      vErrors = [err39];
                    } else {
                      vErrors.push(err39);
                    }
                    errors++;
                    validate44.errors = vErrors;
                    return false;
                  } else {
                    errors = _errs58;
                    if (vErrors !== null) {
                      if (_errs58) {
                        vErrors.length = _errs58;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                  var valid14 = _errs57 === errors;
                } else {
                  var valid14 = true;
                }
                if (valid14) {
                  if (data.errorCode !== void 0) {
                    let data23 = data.errorCode;
                    const _errs78 = errors;
                    const _errs79 = errors;
                    let valid21 = false;
                    const _errs80 = errors;
                    if (!(data23 === "NETWORK_ERROR" || data23 === "INVALID_DATA" || data23 === "PAYLOAD_TOO_LARGE" || data23 === "EXPANSION_LIMIT" || data23 === "UNSUPPORTED_CALENDAR" || data23 === "UNKNOWN_TIME_ZONE" || data23 === "KEYRING_LOCKED" || data23 === "SECRET_DELETION_FAILED" || data23 === "AUTH_ERROR" || data23 === "RATE_LIMITED" || data23 === "NO_PLAYER" || data23 === "NO_INTERFACE" || data23 === "SERVICE_UNAVAILABLE" || data23 === "INTERNAL_ERROR")) {
                      const err40 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema44.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                      if (vErrors === null) {
                        vErrors = [err40];
                      } else {
                        vErrors.push(err40);
                      }
                      errors++;
                    }
                    var _valid8 = _errs80 === errors;
                    valid21 = valid21 || _valid8;
                    const _errs81 = errors;
                    if (data23 !== null) {
                      const err41 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err41];
                      } else {
                        vErrors.push(err41);
                      }
                      errors++;
                    }
                    var _valid8 = _errs81 === errors;
                    valid21 = valid21 || _valid8;
                    if (!valid21) {
                      const err42 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err42];
                      } else {
                        vErrors.push(err42);
                      }
                      errors++;
                      validate44.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs79;
                      if (vErrors !== null) {
                        if (_errs79) {
                          vErrors.length = _errs79;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid14 = _errs78 === errors;
                  } else {
                    var valid14 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate44.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate44.errors = vErrors;
  return errors === 0;
}
validate44.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate46(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate46.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.jobId === void 0 && (missing0 = "jobId") || data.sourceId === void 0 && (missing0 = "sourceId") || data.generation === void 0 && (missing0 = "generation") || data.context === void 0 && (missing0 = "context") || data.now === void 0 && (missing0 = "now")) {
        validate46.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors;
        for (const key0 in data) {
          if (!(key0 === "version" || key0 === "jobId" || key0 === "sourceId" || key0 === "generation" || key0 === "context" || key0 === "now")) {
            validate46.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors) {
          if (data.version !== void 0) {
            const _errs2 = errors;
            if (1 !== data.version) {
              validate46.errors = [{ instancePath: instancePath + "/version", schemaPath: "#/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.jobId !== void 0) {
              let data1 = data.jobId;
              const _errs3 = errors;
              if (errors === _errs3) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 128) {
                    validate46.errors = [{ instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate46.errors = [{ instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate46.errors = [{ instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs3 === errors;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.sourceId !== void 0) {
                let data2 = data.sourceId;
                const _errs5 = errors;
                if (errors === _errs5) {
                  if (typeof data2 === "string") {
                    if (func1(data2) > 128) {
                      validate46.errors = [{ instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" }];
                      return false;
                    } else {
                      if (func1(data2) < 1) {
                        validate46.errors = [{ instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                        return false;
                      }
                    }
                  } else {
                    validate46.errors = [{ instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
                var valid0 = _errs5 === errors;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.generation !== void 0) {
                  let data3 = data.generation;
                  const _errs7 = errors;
                  if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                    validate46.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                    return false;
                  }
                  if (errors === _errs7) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 4294967295 || isNaN(data3)) {
                        validate46.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                        return false;
                      } else {
                        if (data3 < 0 || isNaN(data3)) {
                          validate46.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                          return false;
                        }
                      }
                    }
                  }
                  var valid0 = _errs7 === errors;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.context !== void 0) {
                    let data4 = data.context;
                    const _errs9 = errors;
                    const _errs10 = errors;
                    if (errors === _errs10) {
                      if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                        let missing1;
                        if (data4.month === void 0 && (missing1 = "month") || data4.timeZone === void 0 && (missing1 = "timeZone") || data4.weekStart === void 0 && (missing1 = "weekStart")) {
                          validate46.errors = [{ instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                          return false;
                        } else {
                          const _errs12 = errors;
                          for (const key1 in data4) {
                            if (!(key1 === "month" || key1 === "timeZone" || key1 === "weekStart")) {
                              validate46.errors = [{ instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                              return false;
                              break;
                            }
                          }
                          if (_errs12 === errors) {
                            if (data4.month !== void 0) {
                              let data5 = data4.month;
                              const _errs13 = errors;
                              if (errors === _errs13) {
                                if (typeof data5 === "string") {
                                  if (func1(data5) > 7) {
                                    validate46.errors = [{ instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                                    return false;
                                  } else {
                                    if (!pattern4.test(data5)) {
                                      validate46.errors = [{ instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                                      return false;
                                    }
                                  }
                                } else {
                                  validate46.errors = [{ instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                  return false;
                                }
                              }
                              var valid2 = _errs13 === errors;
                            } else {
                              var valid2 = true;
                            }
                            if (valid2) {
                              if (data4.timeZone !== void 0) {
                                let data6 = data4.timeZone;
                                const _errs15 = errors;
                                if (errors === _errs15) {
                                  if (typeof data6 === "string") {
                                    if (func1(data6) > 255) {
                                      validate46.errors = [{ instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                                      return false;
                                    } else {
                                      if (func1(data6) < 1) {
                                        validate46.errors = [{ instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                        return false;
                                      }
                                    }
                                  } else {
                                    validate46.errors = [{ instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                    return false;
                                  }
                                }
                                var valid2 = _errs15 === errors;
                              } else {
                                var valid2 = true;
                              }
                              if (valid2) {
                                if (data4.weekStart !== void 0) {
                                  let data7 = data4.weekStart;
                                  const _errs17 = errors;
                                  if (!(typeof data7 == "number" && (!(data7 % 1) && !isNaN(data7)) && isFinite(data7))) {
                                    validate46.errors = [{ instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                                    return false;
                                  }
                                  if (errors === _errs17) {
                                    if (typeof data7 == "number" && isFinite(data7)) {
                                      if (data7 > 6 || isNaN(data7)) {
                                        validate46.errors = [{ instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                                        return false;
                                      } else {
                                        if (data7 < 0 || isNaN(data7)) {
                                          validate46.errors = [{ instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                          return false;
                                        }
                                      }
                                    }
                                  }
                                  var valid2 = _errs17 === errors;
                                } else {
                                  var valid2 = true;
                                }
                              }
                            }
                          }
                        }
                      } else {
                        validate46.errors = [{ instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                        return false;
                      }
                    }
                    var valid0 = _errs9 === errors;
                  } else {
                    var valid0 = true;
                  }
                  if (valid0) {
                    if (data.now !== void 0) {
                      let data8 = data.now;
                      const _errs19 = errors;
                      if (errors === _errs19) {
                        if (errors === _errs19) {
                          if (typeof data8 === "string") {
                            if (func1(data8) > 64) {
                              validate46.errors = [{ instancePath: instancePath + "/now", schemaPath: "#/properties/now/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                              return false;
                            } else {
                              if (!formats0.validate(data8)) {
                                validate46.errors = [{ instancePath: instancePath + "/now", schemaPath: "#/properties/now/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                return false;
                              }
                            }
                          } else {
                            validate46.errors = [{ instancePath: instancePath + "/now", schemaPath: "#/properties/now/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                            return false;
                          }
                        }
                      }
                      var valid0 = _errs19 === errors;
                    } else {
                      var valid0 = true;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate46.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate46.errors = vErrors;
  return errors === 0;
}
validate46.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema70 = { "type": "object", "additionalProperties": false, "required": ["version", "state"], "properties": { "version": { "const": 1 }, "state": { "enum": ["ready", "busy"] } } };
function validate47(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate47.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.state === void 0 && (missing0 = "state")) {
        validate47.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors;
        for (const key0 in data) {
          if (!(key0 === "version" || key0 === "state")) {
            validate47.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors) {
          if (data.version !== void 0) {
            const _errs2 = errors;
            if (1 !== data.version) {
              validate47.errors = [{ instancePath: instancePath + "/version", schemaPath: "#/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.state !== void 0) {
              let data1 = data.state;
              const _errs3 = errors;
              if (!(data1 === "ready" || data1 === "busy")) {
                validate47.errors = [{ instancePath: instancePath + "/state", schemaPath: "#/properties/state/enum", keyword: "enum", params: { allowedValues: schema70.properties.state.enum }, message: "must be equal to one of the allowed values" }];
                return false;
              }
              var valid0 = _errs3 === errors;
            } else {
              var valid0 = true;
            }
          }
        }
      }
    } else {
      validate47.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate47.errors = vErrors;
  return errors === 0;
}
validate47.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema71 = { "oneOf": [{ "type": "object", "additionalProperties": false, "required": ["version", "jobId", "sourceId", "generation", "ok", "data"], "properties": { "version": { "const": 1 }, "jobId": { "type": "string", "minLength": 1, "maxLength": 128 }, "sourceId": { "type": "string", "minLength": 1, "maxLength": 128 }, "generation": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "ok": { "const": true }, "data": { "$ref": "urn:liquid-widgets:snapshot:v1#/$defs/CalendarData" } } }, { "type": "object", "additionalProperties": false, "required": ["version", "jobId", "sourceId", "generation", "ok", "errorCode"], "properties": { "version": { "const": 1 }, "jobId": { "type": "string", "minLength": 1, "maxLength": 128 }, "sourceId": { "type": "string", "minLength": 1, "maxLength": 128 }, "generation": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "ok": { "const": false }, "errorCode": { "enum": ["INVALID_DATA", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT"] } } }] };
function validate49(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate49.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.month === void 0 && (missing0 = "month") || data.timeZone === void 0 && (missing0 = "timeZone") || data.weekStart === void 0 && (missing0 = "weekStart") || data.events === void 0 && (missing0 = "events")) {
        validate49.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors;
        for (const key0 in data) {
          if (!(key0 === "month" || key0 === "timeZone" || key0 === "weekStart" || key0 === "events")) {
            validate49.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors) {
          if (data.month !== void 0) {
            let data0 = data.month;
            const _errs2 = errors;
            if (errors === _errs2) {
              if (typeof data0 === "string") {
                if (func1(data0) > 7) {
                  validate49.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" }];
                  return false;
                } else {
                  if (!pattern4.test(data0)) {
                    validate49.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' }];
                    return false;
                  }
                }
              } else {
                validate49.errors = [{ instancePath: instancePath + "/month", schemaPath: "#/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                return false;
              }
            }
            var valid0 = _errs2 === errors;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.timeZone !== void 0) {
              let data1 = data.timeZone;
              const _errs4 = errors;
              if (errors === _errs4) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 255) {
                    validate49.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" }];
                    return false;
                  } else {
                    if (func1(data1) < 1) {
                      validate49.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                      return false;
                    }
                  }
                } else {
                  validate49.errors = [{ instancePath: instancePath + "/timeZone", schemaPath: "#/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                  return false;
                }
              }
              var valid0 = _errs4 === errors;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.weekStart !== void 0) {
                let data2 = data.weekStart;
                const _errs6 = errors;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate49.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors === _errs6) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 6 || isNaN(data2)) {
                      validate49.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate49.errors = [{ instancePath: instancePath + "/weekStart", schemaPath: "#/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs6 === errors;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.events !== void 0) {
                  let data3 = data.events;
                  const _errs8 = errors;
                  if (errors === _errs8) {
                    if (Array.isArray(data3)) {
                      if (data3.length > 1e4) {
                        validate49.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/maxItems", keyword: "maxItems", params: { limit: 1e4 }, message: "must NOT have more than 10000 items" }];
                        return false;
                      } else {
                        var valid1 = true;
                        const len0 = data3.length;
                        for (let i0 = 0; i0 < len0; i0++) {
                          let data4 = data3[i0];
                          const _errs10 = errors;
                          const _errs11 = errors;
                          const _errs14 = errors;
                          let valid4 = true;
                          const _errs15 = errors;
                          if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                            if (data4.allDay !== void 0) {
                              if (true !== data4.allDay) {
                                const err0 = {};
                                if (vErrors === null) {
                                  vErrors = [err0];
                                } else {
                                  vErrors.push(err0);
                                }
                                errors++;
                              }
                            }
                          }
                          var _valid0 = _errs15 === errors;
                          errors = _errs14;
                          if (vErrors !== null) {
                            if (_errs14) {
                              vErrors.length = _errs14;
                            } else {
                              vErrors = null;
                            }
                          }
                          let ifClause0;
                          if (_valid0) {
                            const _errs17 = errors;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data6 = data4.start;
                                const _errs18 = errors;
                                if (errors === _errs18) {
                                  if (errors === _errs18) {
                                    if (typeof data6 === "string") {
                                      if (func1(data6) > 10) {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                        return false;
                                      } else {
                                        if (!formats2.validate(data6)) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid6 = _errs18 === errors;
                              } else {
                                var valid6 = true;
                              }
                              if (valid6) {
                                if (data4.end !== void 0) {
                                  let data7 = data4.end;
                                  const _errs20 = errors;
                                  if (errors === _errs20) {
                                    if (errors === _errs20) {
                                      if (typeof data7 === "string") {
                                        if (func1(data7) > 10) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/maxLength", keyword: "maxLength", params: { limit: 10 }, message: "must NOT have more than 10 characters" }];
                                          return false;
                                        } else {
                                          if (!formats2.validate(data7)) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/format", keyword: "format", params: { format: "date" }, message: 'must match format "date"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/then/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid6 = _errs20 === errors;
                                } else {
                                  var valid6 = true;
                                }
                              }
                            }
                            var _valid0 = _errs17 === errors;
                            valid4 = _valid0;
                            if (valid4) {
                              var props0 = {};
                              props0.start = true;
                              props0.end = true;
                              props0.allDay = true;
                            }
                            ifClause0 = "then";
                          } else {
                            const _errs22 = errors;
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              if (data4.start !== void 0) {
                                let data8 = data4.start;
                                const _errs23 = errors;
                                if (errors === _errs23) {
                                  if (errors === _errs23) {
                                    if (typeof data8 === "string") {
                                      if (func1(data8) > 64) {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                        return false;
                                      } else {
                                        if (!formats0.validate(data8)) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                          return false;
                                        }
                                      }
                                    } else {
                                      validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                      return false;
                                    }
                                  }
                                }
                                var valid7 = _errs23 === errors;
                              } else {
                                var valid7 = true;
                              }
                              if (valid7) {
                                if (data4.end !== void 0) {
                                  let data9 = data4.end;
                                  const _errs25 = errors;
                                  if (errors === _errs25) {
                                    if (errors === _errs25) {
                                      if (typeof data9 === "string") {
                                        if (func1(data9) > 64) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                          return false;
                                        } else {
                                          if (!formats0.validate(data9)) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/allOf/0/else/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                  }
                                  var valid7 = _errs25 === errors;
                                } else {
                                  var valid7 = true;
                                }
                              }
                            }
                            var _valid0 = _errs22 === errors;
                            valid4 = _valid0;
                            if (valid4) {
                              if (props0 !== true) {
                                props0 = props0 || {};
                                props0.start = true;
                                props0.end = true;
                              }
                            }
                            ifClause0 = "else";
                          }
                          if (!valid4) {
                            const err1 = { instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/allOf/0/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
                            if (vErrors === null) {
                              vErrors = [err1];
                            } else {
                              vErrors.push(err1);
                            }
                            errors++;
                            validate49.errors = vErrors;
                            return false;
                          }
                          if (errors === _errs11) {
                            if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                              let missing1;
                              if (data4.uid === void 0 && (missing1 = "uid") || data4.occurrenceKey === void 0 && (missing1 = "occurrenceKey") || data4.title === void 0 && (missing1 = "title") || data4.start === void 0 && (missing1 = "start") || data4.end === void 0 && (missing1 = "end") || data4.allDay === void 0 && (missing1 = "allDay")) {
                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                                return false;
                              } else {
                                const _errs27 = errors;
                                for (const key1 in data4) {
                                  if (!(key1 === "uid" || key1 === "occurrenceKey" || key1 === "title" || key1 === "start" || key1 === "end" || key1 === "allDay")) {
                                    validate49.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                                    return false;
                                    break;
                                  }
                                }
                                if (_errs27 === errors) {
                                  if (data4.uid !== void 0) {
                                    let data10 = data4.uid;
                                    const _errs28 = errors;
                                    if (errors === _errs28) {
                                      if (typeof data10 === "string") {
                                        if (func1(data10) > 2048) {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/maxLength", keyword: "maxLength", params: { limit: 2048 }, message: "must NOT have more than 2048 characters" }];
                                          return false;
                                        } else {
                                          if (func1(data10) < 1) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                            return false;
                                          }
                                        }
                                      } else {
                                        validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/uid", schemaPath: "#/$defs/CalendarEvent/properties/uid/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                        return false;
                                      }
                                    }
                                    var valid8 = _errs28 === errors;
                                  } else {
                                    var valid8 = true;
                                  }
                                  if (valid8) {
                                    if (data4.occurrenceKey !== void 0) {
                                      let data11 = data4.occurrenceKey;
                                      const _errs30 = errors;
                                      if (errors === _errs30) {
                                        if (typeof data11 === "string") {
                                          if (func1(data11) > 64) {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                            return false;
                                          } else {
                                            if (func1(data11) < 1) {
                                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                                              return false;
                                            }
                                          }
                                        } else {
                                          validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/occurrenceKey", schemaPath: "#/$defs/CalendarEvent/properties/occurrenceKey/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                          return false;
                                        }
                                      }
                                      var valid8 = _errs30 === errors;
                                    } else {
                                      var valid8 = true;
                                    }
                                    if (valid8) {
                                      if (data4.title !== void 0) {
                                        let data12 = data4.title;
                                        const _errs32 = errors;
                                        if (errors === _errs32) {
                                          if (typeof data12 === "string") {
                                            if (func1(data12) > 4096) {
                                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/maxLength", keyword: "maxLength", params: { limit: 4096 }, message: "must NOT have more than 4096 characters" }];
                                              return false;
                                            }
                                          } else {
                                            validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/title", schemaPath: "#/$defs/CalendarEvent/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                            return false;
                                          }
                                        }
                                        var valid8 = _errs32 === errors;
                                      } else {
                                        var valid8 = true;
                                      }
                                      if (valid8) {
                                        if (data4.start !== void 0) {
                                          let data13 = data4.start;
                                          const _errs34 = errors;
                                          if (errors === _errs34) {
                                            if (typeof data13 === "string") {
                                              if (func1(data13) > 64) {
                                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                return false;
                                              }
                                            } else {
                                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/start", schemaPath: "#/$defs/CalendarEvent/properties/start/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                              return false;
                                            }
                                          }
                                          var valid8 = _errs34 === errors;
                                        } else {
                                          var valid8 = true;
                                        }
                                        if (valid8) {
                                          if (data4.end !== void 0) {
                                            let data14 = data4.end;
                                            const _errs36 = errors;
                                            if (errors === _errs36) {
                                              if (typeof data14 === "string") {
                                                if (func1(data14) > 64) {
                                                  validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                                                  return false;
                                                }
                                              } else {
                                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/end", schemaPath: "#/$defs/CalendarEvent/properties/end/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                                                return false;
                                              }
                                            }
                                            var valid8 = _errs36 === errors;
                                          } else {
                                            var valid8 = true;
                                          }
                                          if (valid8) {
                                            if (data4.allDay !== void 0) {
                                              const _errs38 = errors;
                                              if (typeof data4.allDay !== "boolean") {
                                                validate49.errors = [{ instancePath: instancePath + "/events/" + i0 + "/allDay", schemaPath: "#/$defs/CalendarEvent/properties/allDay/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                                                return false;
                                              }
                                              var valid8 = _errs38 === errors;
                                            } else {
                                              var valid8 = true;
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            } else {
                              validate49.errors = [{ instancePath: instancePath + "/events/" + i0, schemaPath: "#/$defs/CalendarEvent/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                              return false;
                            }
                          }
                          var valid1 = _errs10 === errors;
                          if (!valid1) {
                            break;
                          }
                        }
                      }
                    } else {
                      validate49.errors = [{ instancePath: instancePath + "/events", schemaPath: "#/properties/events/type", keyword: "type", params: { type: "array" }, message: "must be array" }];
                      return false;
                    }
                  }
                  var valid0 = _errs8 === errors;
                } else {
                  var valid0 = true;
                }
              }
            }
          }
        }
      }
    } else {
      validate49.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate49.errors = vErrors;
  return errors === 0;
}
validate49.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
function validate48(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate48.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs0 = errors;
  let valid0 = false;
  let passing0 = null;
  const _errs1 = errors;
  if (errors === _errs1) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.jobId === void 0 && (missing0 = "jobId") || data.sourceId === void 0 && (missing0 = "sourceId") || data.generation === void 0 && (missing0 = "generation") || data.ok === void 0 && (missing0 = "ok") || data.data === void 0 && (missing0 = "data")) {
        const err0 = { instancePath, schemaPath: "#/oneOf/0/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" };
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      } else {
        const _errs3 = errors;
        for (const key0 in data) {
          if (!(key0 === "version" || key0 === "jobId" || key0 === "sourceId" || key0 === "generation" || key0 === "ok" || key0 === "data")) {
            const err1 = { instancePath, schemaPath: "#/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err1];
            } else {
              vErrors.push(err1);
            }
            errors++;
            break;
          }
        }
        if (_errs3 === errors) {
          if (data.version !== void 0) {
            const _errs4 = errors;
            if (1 !== data.version) {
              const err2 = { instancePath: instancePath + "/version", schemaPath: "#/oneOf/0/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" };
              if (vErrors === null) {
                vErrors = [err2];
              } else {
                vErrors.push(err2);
              }
              errors++;
            }
            var valid1 = _errs4 === errors;
          } else {
            var valid1 = true;
          }
          if (valid1) {
            if (data.jobId !== void 0) {
              let data1 = data.jobId;
              const _errs5 = errors;
              if (errors === _errs5) {
                if (typeof data1 === "string") {
                  if (func1(data1) > 128) {
                    const err3 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/0/properties/jobId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err3];
                    } else {
                      vErrors.push(err3);
                    }
                    errors++;
                  } else {
                    if (func1(data1) < 1) {
                      const err4 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/0/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err4];
                      } else {
                        vErrors.push(err4);
                      }
                      errors++;
                    }
                  }
                } else {
                  const err5 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/0/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err5];
                  } else {
                    vErrors.push(err5);
                  }
                  errors++;
                }
              }
              var valid1 = _errs5 === errors;
            } else {
              var valid1 = true;
            }
            if (valid1) {
              if (data.sourceId !== void 0) {
                let data2 = data.sourceId;
                const _errs7 = errors;
                if (errors === _errs7) {
                  if (typeof data2 === "string") {
                    if (func1(data2) > 128) {
                      const err6 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/0/properties/sourceId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                      if (vErrors === null) {
                        vErrors = [err6];
                      } else {
                        vErrors.push(err6);
                      }
                      errors++;
                    } else {
                      if (func1(data2) < 1) {
                        const err7 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/0/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err7];
                        } else {
                          vErrors.push(err7);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err8 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/0/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err8];
                    } else {
                      vErrors.push(err8);
                    }
                    errors++;
                  }
                }
                var valid1 = _errs7 === errors;
              } else {
                var valid1 = true;
              }
              if (valid1) {
                if (data.generation !== void 0) {
                  let data3 = data.generation;
                  const _errs9 = errors;
                  if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                    const err9 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/0/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                    if (vErrors === null) {
                      vErrors = [err9];
                    } else {
                      vErrors.push(err9);
                    }
                    errors++;
                  }
                  if (errors === _errs9) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 4294967295 || isNaN(data3)) {
                        const err10 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/0/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" };
                        if (vErrors === null) {
                          vErrors = [err10];
                        } else {
                          vErrors.push(err10);
                        }
                        errors++;
                      } else {
                        if (data3 < 0 || isNaN(data3)) {
                          const err11 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/0/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err11];
                          } else {
                            vErrors.push(err11);
                          }
                          errors++;
                        }
                      }
                    }
                  }
                  var valid1 = _errs9 === errors;
                } else {
                  var valid1 = true;
                }
                if (valid1) {
                  if (data.ok !== void 0) {
                    const _errs11 = errors;
                    if (true !== data.ok) {
                      const err12 = { instancePath: instancePath + "/ok", schemaPath: "#/oneOf/0/properties/ok/const", keyword: "const", params: { allowedValue: true }, message: "must be equal to constant" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors++;
                    }
                    var valid1 = _errs11 === errors;
                  } else {
                    var valid1 = true;
                  }
                  if (valid1) {
                    if (data.data !== void 0) {
                      const _errs12 = errors;
                      if (!validate49(data.data, { instancePath: instancePath + "/data", parentData: data, parentDataProperty: "data", rootData, dynamicAnchors })) {
                        vErrors = vErrors === null ? validate49.errors : vErrors.concat(validate49.errors);
                        errors = vErrors.length;
                      }
                      var valid1 = _errs12 === errors;
                    } else {
                      var valid1 = true;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      const err13 = { instancePath, schemaPath: "#/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
      if (vErrors === null) {
        vErrors = [err13];
      } else {
        vErrors.push(err13);
      }
      errors++;
    }
  }
  var _valid0 = _errs1 === errors;
  if (_valid0) {
    valid0 = true;
    passing0 = 0;
    var props0 = true;
  }
  const _errs13 = errors;
  if (errors === _errs13) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing1;
      if (data.version === void 0 && (missing1 = "version") || data.jobId === void 0 && (missing1 = "jobId") || data.sourceId === void 0 && (missing1 = "sourceId") || data.generation === void 0 && (missing1 = "generation") || data.ok === void 0 && (missing1 = "ok") || data.errorCode === void 0 && (missing1 = "errorCode")) {
        const err14 = { instancePath, schemaPath: "#/oneOf/1/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" };
        if (vErrors === null) {
          vErrors = [err14];
        } else {
          vErrors.push(err14);
        }
        errors++;
      } else {
        const _errs15 = errors;
        for (const key1 in data) {
          if (!(key1 === "version" || key1 === "jobId" || key1 === "sourceId" || key1 === "generation" || key1 === "ok" || key1 === "errorCode")) {
            const err15 = { instancePath, schemaPath: "#/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err15];
            } else {
              vErrors.push(err15);
            }
            errors++;
            break;
          }
        }
        if (_errs15 === errors) {
          if (data.version !== void 0) {
            const _errs16 = errors;
            if (1 !== data.version) {
              const err16 = { instancePath: instancePath + "/version", schemaPath: "#/oneOf/1/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" };
              if (vErrors === null) {
                vErrors = [err16];
              } else {
                vErrors.push(err16);
              }
              errors++;
            }
            var valid2 = _errs16 === errors;
          } else {
            var valid2 = true;
          }
          if (valid2) {
            if (data.jobId !== void 0) {
              let data7 = data.jobId;
              const _errs17 = errors;
              if (errors === _errs17) {
                if (typeof data7 === "string") {
                  if (func1(data7) > 128) {
                    const err17 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/1/properties/jobId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                    if (vErrors === null) {
                      vErrors = [err17];
                    } else {
                      vErrors.push(err17);
                    }
                    errors++;
                  } else {
                    if (func1(data7) < 1) {
                      const err18 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/1/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err18];
                      } else {
                        vErrors.push(err18);
                      }
                      errors++;
                    }
                  }
                } else {
                  const err19 = { instancePath: instancePath + "/jobId", schemaPath: "#/oneOf/1/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err19];
                  } else {
                    vErrors.push(err19);
                  }
                  errors++;
                }
              }
              var valid2 = _errs17 === errors;
            } else {
              var valid2 = true;
            }
            if (valid2) {
              if (data.sourceId !== void 0) {
                let data8 = data.sourceId;
                const _errs19 = errors;
                if (errors === _errs19) {
                  if (typeof data8 === "string") {
                    if (func1(data8) > 128) {
                      const err20 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/1/properties/sourceId/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                      if (vErrors === null) {
                        vErrors = [err20];
                      } else {
                        vErrors.push(err20);
                      }
                      errors++;
                    } else {
                      if (func1(data8) < 1) {
                        const err21 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/1/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err21];
                        } else {
                          vErrors.push(err21);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err22 = { instancePath: instancePath + "/sourceId", schemaPath: "#/oneOf/1/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err22];
                    } else {
                      vErrors.push(err22);
                    }
                    errors++;
                  }
                }
                var valid2 = _errs19 === errors;
              } else {
                var valid2 = true;
              }
              if (valid2) {
                if (data.generation !== void 0) {
                  let data9 = data.generation;
                  const _errs21 = errors;
                  if (!(typeof data9 == "number" && (!(data9 % 1) && !isNaN(data9)) && isFinite(data9))) {
                    const err23 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/1/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                    if (vErrors === null) {
                      vErrors = [err23];
                    } else {
                      vErrors.push(err23);
                    }
                    errors++;
                  }
                  if (errors === _errs21) {
                    if (typeof data9 == "number" && isFinite(data9)) {
                      if (data9 > 4294967295 || isNaN(data9)) {
                        const err24 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/1/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" };
                        if (vErrors === null) {
                          vErrors = [err24];
                        } else {
                          vErrors.push(err24);
                        }
                        errors++;
                      } else {
                        if (data9 < 0 || isNaN(data9)) {
                          const err25 = { instancePath: instancePath + "/generation", schemaPath: "#/oneOf/1/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                          if (vErrors === null) {
                            vErrors = [err25];
                          } else {
                            vErrors.push(err25);
                          }
                          errors++;
                        }
                      }
                    }
                  }
                  var valid2 = _errs21 === errors;
                } else {
                  var valid2 = true;
                }
                if (valid2) {
                  if (data.ok !== void 0) {
                    const _errs23 = errors;
                    if (false !== data.ok) {
                      const err26 = { instancePath: instancePath + "/ok", schemaPath: "#/oneOf/1/properties/ok/const", keyword: "const", params: { allowedValue: false }, message: "must be equal to constant" };
                      if (vErrors === null) {
                        vErrors = [err26];
                      } else {
                        vErrors.push(err26);
                      }
                      errors++;
                    }
                    var valid2 = _errs23 === errors;
                  } else {
                    var valid2 = true;
                  }
                  if (valid2) {
                    if (data.errorCode !== void 0) {
                      let data11 = data.errorCode;
                      const _errs24 = errors;
                      if (!(data11 === "INVALID_DATA" || data11 === "UNSUPPORTED_CALENDAR" || data11 === "UNKNOWN_TIME_ZONE" || data11 === "PAYLOAD_TOO_LARGE" || data11 === "EXPANSION_LIMIT")) {
                        const err27 = { instancePath: instancePath + "/errorCode", schemaPath: "#/oneOf/1/properties/errorCode/enum", keyword: "enum", params: { allowedValues: schema71.oneOf[1].properties.errorCode.enum }, message: "must be equal to one of the allowed values" };
                        if (vErrors === null) {
                          vErrors = [err27];
                        } else {
                          vErrors.push(err27);
                        }
                        errors++;
                      }
                      var valid2 = _errs24 === errors;
                    } else {
                      var valid2 = true;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      const err28 = { instancePath, schemaPath: "#/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
      if (vErrors === null) {
        vErrors = [err28];
      } else {
        vErrors.push(err28);
      }
      errors++;
    }
  }
  var _valid0 = _errs13 === errors;
  if (_valid0 && valid0) {
    valid0 = false;
    passing0 = [passing0, 1];
  } else {
    if (_valid0) {
      valid0 = true;
      passing0 = 1;
      if (props0 !== true) {
        props0 = true;
      }
    }
  }
  if (!valid0) {
    const err29 = { instancePath, schemaPath: "#/oneOf", keyword: "oneOf", params: { passingSchemas: passing0 }, message: "must match exactly one schema in oneOf" };
    if (vErrors === null) {
      vErrors = [err29];
    } else {
      vErrors.push(err29);
    }
    errors++;
    validate48.errors = vErrors;
    return false;
  } else {
    errors = _errs0;
    if (vErrors !== null) {
      if (_errs0) {
        vErrors.length = _errs0;
      } else {
        vErrors = null;
      }
    }
  }
  validate48.errors = vErrors;
  evaluated0.props = props0;
  return errors === 0;
}
validate48.evaluated = { "dynamicProps": true, "dynamicItems": false };
var formats76 = /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
var pattern26 = new RegExp("^[^/\\s\\x00-\\x1f]+$", "u");
function validate51(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate51.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.schemaVersion === void 0 && (missing0 = "schemaVersion") || data.revision === void 0 && (missing0 = "revision") || data.calendar === void 0 && (missing0 = "calendar") || data.weather === void 0 && (missing0 = "weather") || data.networkInterface === void 0 && (missing0 = "networkInterface")) {
        validate51.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors;
        for (const key0 in data) {
          if (!(key0 === "schemaVersion" || key0 === "revision" || key0 === "calendar" || key0 === "weather" || key0 === "networkInterface")) {
            validate51.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors) {
          if (data.schemaVersion !== void 0) {
            const _errs2 = errors;
            if (1 !== data.schemaVersion) {
              validate51.errors = [{ instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.revision !== void 0) {
              let data1 = data.revision;
              const _errs3 = errors;
              if (errors === _errs3) {
                if (errors === _errs3) {
                  if (typeof data1 === "string") {
                    if (!formats76.test(data1)) {
                      validate51.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' }];
                      return false;
                    }
                  } else {
                    validate51.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
              }
              var valid0 = _errs3 === errors;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.calendar !== void 0) {
                let data2 = data.calendar;
                const _errs5 = errors;
                if (errors === _errs5) {
                  if (data2 && typeof data2 == "object" && !Array.isArray(data2)) {
                    let missing1;
                    if (data2.sourceId === void 0 && (missing1 = "sourceId") || data2.enabled === void 0 && (missing1 = "enabled") || data2.deletionPending === void 0 && (missing1 = "deletionPending")) {
                      validate51.errors = [{ instancePath: instancePath + "/calendar", schemaPath: "#/properties/calendar/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" }];
                      return false;
                    } else {
                      const _errs7 = errors;
                      for (const key1 in data2) {
                        if (!(key1 === "sourceId" || key1 === "enabled" || key1 === "deletionPending")) {
                          validate51.errors = [{ instancePath: instancePath + "/calendar", schemaPath: "#/properties/calendar/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" }];
                          return false;
                          break;
                        }
                      }
                      if (_errs7 === errors) {
                        if (data2.sourceId !== void 0) {
                          let data3 = data2.sourceId;
                          const _errs8 = errors;
                          const _errs9 = errors;
                          let valid2 = false;
                          const _errs10 = errors;
                          if (errors === _errs10) {
                            if (errors === _errs10) {
                              if (typeof data3 === "string") {
                                if (!formats76.test(data3)) {
                                  const err0 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf/0/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' };
                                  if (vErrors === null) {
                                    vErrors = [err0];
                                  } else {
                                    vErrors.push(err0);
                                  }
                                  errors++;
                                }
                              } else {
                                const err1 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err1];
                                } else {
                                  vErrors.push(err1);
                                }
                                errors++;
                              }
                            }
                          }
                          var _valid0 = _errs10 === errors;
                          valid2 = valid2 || _valid0;
                          const _errs12 = errors;
                          if (data3 !== null) {
                            const err2 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err2];
                            } else {
                              vErrors.push(err2);
                            }
                            errors++;
                          }
                          var _valid0 = _errs12 === errors;
                          valid2 = valid2 || _valid0;
                          if (!valid2) {
                            const err3 = { instancePath: instancePath + "/calendar/sourceId", schemaPath: "#/properties/calendar/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err3];
                            } else {
                              vErrors.push(err3);
                            }
                            errors++;
                            validate51.errors = vErrors;
                            return false;
                          } else {
                            errors = _errs9;
                            if (vErrors !== null) {
                              if (_errs9) {
                                vErrors.length = _errs9;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid1 = _errs8 === errors;
                        } else {
                          var valid1 = true;
                        }
                        if (valid1) {
                          if (data2.enabled !== void 0) {
                            const _errs14 = errors;
                            if (typeof data2.enabled !== "boolean") {
                              validate51.errors = [{ instancePath: instancePath + "/calendar/enabled", schemaPath: "#/properties/calendar/properties/enabled/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                              return false;
                            }
                            var valid1 = _errs14 === errors;
                          } else {
                            var valid1 = true;
                          }
                          if (valid1) {
                            if (data2.deletionPending !== void 0) {
                              const _errs16 = errors;
                              if (typeof data2.deletionPending !== "boolean") {
                                validate51.errors = [{ instancePath: instancePath + "/calendar/deletionPending", schemaPath: "#/properties/calendar/properties/deletionPending/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                                return false;
                              }
                              var valid1 = _errs16 === errors;
                            } else {
                              var valid1 = true;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    validate51.errors = [{ instancePath: instancePath + "/calendar", schemaPath: "#/properties/calendar/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                    return false;
                  }
                }
                var valid0 = _errs5 === errors;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.weather !== void 0) {
                  let data6 = data.weather;
                  const _errs18 = errors;
                  if (errors === _errs18) {
                    if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
                      let missing2;
                      if (data6.sourceId === void 0 && (missing2 = "sourceId") || data6.location === void 0 && (missing2 = "location")) {
                        validate51.errors = [{ instancePath: instancePath + "/weather", schemaPath: "#/properties/weather/required", keyword: "required", params: { missingProperty: missing2 }, message: "must have required property '" + missing2 + "'" }];
                        return false;
                      } else {
                        const _errs20 = errors;
                        for (const key2 in data6) {
                          if (!(key2 === "sourceId" || key2 === "location")) {
                            validate51.errors = [{ instancePath: instancePath + "/weather", schemaPath: "#/properties/weather/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" }];
                            return false;
                            break;
                          }
                        }
                        if (_errs20 === errors) {
                          if (data6.sourceId !== void 0) {
                            let data7 = data6.sourceId;
                            const _errs21 = errors;
                            const _errs22 = errors;
                            let valid4 = false;
                            const _errs23 = errors;
                            if (errors === _errs23) {
                              if (errors === _errs23) {
                                if (typeof data7 === "string") {
                                  if (!formats76.test(data7)) {
                                    const err4 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf/0/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' };
                                    if (vErrors === null) {
                                      vErrors = [err4];
                                    } else {
                                      vErrors.push(err4);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err5 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err5];
                                  } else {
                                    vErrors.push(err5);
                                  }
                                  errors++;
                                }
                              }
                            }
                            var _valid1 = _errs23 === errors;
                            valid4 = valid4 || _valid1;
                            const _errs25 = errors;
                            if (data7 !== null) {
                              const err6 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                              if (vErrors === null) {
                                vErrors = [err6];
                              } else {
                                vErrors.push(err6);
                              }
                              errors++;
                            }
                            var _valid1 = _errs25 === errors;
                            valid4 = valid4 || _valid1;
                            if (!valid4) {
                              const err7 = { instancePath: instancePath + "/weather/sourceId", schemaPath: "#/properties/weather/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                              if (vErrors === null) {
                                vErrors = [err7];
                              } else {
                                vErrors.push(err7);
                              }
                              errors++;
                              validate51.errors = vErrors;
                              return false;
                            } else {
                              errors = _errs22;
                              if (vErrors !== null) {
                                if (_errs22) {
                                  vErrors.length = _errs22;
                                } else {
                                  vErrors = null;
                                }
                              }
                            }
                            var valid3 = _errs21 === errors;
                          } else {
                            var valid3 = true;
                          }
                          if (valid3) {
                            if (data6.location !== void 0) {
                              let data8 = data6.location;
                              const _errs27 = errors;
                              const _errs28 = errors;
                              let valid5 = false;
                              const _errs29 = errors;
                              const _errs30 = errors;
                              if (errors === _errs30) {
                                if (data8 && typeof data8 == "object" && !Array.isArray(data8)) {
                                  let missing3;
                                  if (data8.id === void 0 && (missing3 = "id") || data8.label === void 0 && (missing3 = "label") || data8.latitude === void 0 && (missing3 = "latitude") || data8.longitude === void 0 && (missing3 = "longitude") || data8.timeZone === void 0 && (missing3 = "timeZone")) {
                                    const err8 = { instancePath: instancePath + "/weather/location", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/required", keyword: "required", params: { missingProperty: missing3 }, message: "must have required property '" + missing3 + "'" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors++;
                                  } else {
                                    const _errs32 = errors;
                                    for (const key3 in data8) {
                                      if (!(key3 === "id" || key3 === "label" || key3 === "latitude" || key3 === "longitude" || key3 === "timeZone")) {
                                        const err9 = { instancePath: instancePath + "/weather/location", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                                        if (vErrors === null) {
                                          vErrors = [err9];
                                        } else {
                                          vErrors.push(err9);
                                        }
                                        errors++;
                                        break;
                                      }
                                    }
                                    if (_errs32 === errors) {
                                      if (data8.id !== void 0) {
                                        let data9 = data8.id;
                                        const _errs33 = errors;
                                        if (errors === _errs33) {
                                          if (typeof data9 === "string") {
                                            if (func1(data9) > 128) {
                                              const err10 = { instancePath: instancePath + "/weather/location/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                                              if (vErrors === null) {
                                                vErrors = [err10];
                                              } else {
                                                vErrors.push(err10);
                                              }
                                              errors++;
                                            } else {
                                              if (func1(data9) < 1) {
                                                const err11 = { instancePath: instancePath + "/weather/location/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                                if (vErrors === null) {
                                                  vErrors = [err11];
                                                } else {
                                                  vErrors.push(err11);
                                                }
                                                errors++;
                                              }
                                            }
                                          } else {
                                            const err12 = { instancePath: instancePath + "/weather/location/id", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                            if (vErrors === null) {
                                              vErrors = [err12];
                                            } else {
                                              vErrors.push(err12);
                                            }
                                            errors++;
                                          }
                                        }
                                        var valid7 = _errs33 === errors;
                                      } else {
                                        var valid7 = true;
                                      }
                                      if (valid7) {
                                        if (data8.label !== void 0) {
                                          let data10 = data8.label;
                                          const _errs35 = errors;
                                          if (errors === _errs35) {
                                            if (typeof data10 === "string") {
                                              if (func1(data10) > 512) {
                                                const err13 = { instancePath: instancePath + "/weather/location/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/maxLength", keyword: "maxLength", params: { limit: 512 }, message: "must NOT have more than 512 characters" };
                                                if (vErrors === null) {
                                                  vErrors = [err13];
                                                } else {
                                                  vErrors.push(err13);
                                                }
                                                errors++;
                                              } else {
                                                if (func1(data10) < 1) {
                                                  const err14 = { instancePath: instancePath + "/weather/location/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                                  if (vErrors === null) {
                                                    vErrors = [err14];
                                                  } else {
                                                    vErrors.push(err14);
                                                  }
                                                  errors++;
                                                }
                                              }
                                            } else {
                                              const err15 = { instancePath: instancePath + "/weather/location/label", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                              if (vErrors === null) {
                                                vErrors = [err15];
                                              } else {
                                                vErrors.push(err15);
                                              }
                                              errors++;
                                            }
                                          }
                                          var valid7 = _errs35 === errors;
                                        } else {
                                          var valid7 = true;
                                        }
                                        if (valid7) {
                                          if (data8.latitude !== void 0) {
                                            let data11 = data8.latitude;
                                            const _errs37 = errors;
                                            if (errors === _errs37) {
                                              if (typeof data11 == "number" && isFinite(data11)) {
                                                if (data11 > 90 || isNaN(data11)) {
                                                  const err16 = { instancePath: instancePath + "/weather/location/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 90 }, message: "must be <= 90" };
                                                  if (vErrors === null) {
                                                    vErrors = [err16];
                                                  } else {
                                                    vErrors.push(err16);
                                                  }
                                                  errors++;
                                                } else {
                                                  if (data11 < -90 || isNaN(data11)) {
                                                    const err17 = { instancePath: instancePath + "/weather/location/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -90 }, message: "must be >= -90" };
                                                    if (vErrors === null) {
                                                      vErrors = [err17];
                                                    } else {
                                                      vErrors.push(err17);
                                                    }
                                                    errors++;
                                                  }
                                                }
                                              } else {
                                                const err18 = { instancePath: instancePath + "/weather/location/latitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/latitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                if (vErrors === null) {
                                                  vErrors = [err18];
                                                } else {
                                                  vErrors.push(err18);
                                                }
                                                errors++;
                                              }
                                            }
                                            var valid7 = _errs37 === errors;
                                          } else {
                                            var valid7 = true;
                                          }
                                          if (valid7) {
                                            if (data8.longitude !== void 0) {
                                              let data12 = data8.longitude;
                                              const _errs39 = errors;
                                              if (errors === _errs39) {
                                                if (typeof data12 == "number" && isFinite(data12)) {
                                                  if (data12 > 180 || isNaN(data12)) {
                                                    const err19 = { instancePath: instancePath + "/weather/location/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/maximum", keyword: "maximum", params: { comparison: "<=", limit: 180 }, message: "must be <= 180" };
                                                    if (vErrors === null) {
                                                      vErrors = [err19];
                                                    } else {
                                                      vErrors.push(err19);
                                                    }
                                                    errors++;
                                                  } else {
                                                    if (data12 < -180 || isNaN(data12)) {
                                                      const err20 = { instancePath: instancePath + "/weather/location/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/minimum", keyword: "minimum", params: { comparison: ">=", limit: -180 }, message: "must be >= -180" };
                                                      if (vErrors === null) {
                                                        vErrors = [err20];
                                                      } else {
                                                        vErrors.push(err20);
                                                      }
                                                      errors++;
                                                    }
                                                  }
                                                } else {
                                                  const err21 = { instancePath: instancePath + "/weather/location/longitude", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/longitude/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                                  if (vErrors === null) {
                                                    vErrors = [err21];
                                                  } else {
                                                    vErrors.push(err21);
                                                  }
                                                  errors++;
                                                }
                                              }
                                              var valid7 = _errs39 === errors;
                                            } else {
                                              var valid7 = true;
                                            }
                                            if (valid7) {
                                              if (data8.timeZone !== void 0) {
                                                let data13 = data8.timeZone;
                                                const _errs41 = errors;
                                                if (errors === _errs41) {
                                                  if (typeof data13 === "string") {
                                                    if (func1(data13) > 255) {
                                                      const err22 = { instancePath: instancePath + "/weather/location/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                                      if (vErrors === null) {
                                                        vErrors = [err22];
                                                      } else {
                                                        vErrors.push(err22);
                                                      }
                                                      errors++;
                                                    } else {
                                                      if (func1(data13) < 1) {
                                                        const err23 = { instancePath: instancePath + "/weather/location/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                                        if (vErrors === null) {
                                                          vErrors = [err23];
                                                        } else {
                                                          vErrors.push(err23);
                                                        }
                                                        errors++;
                                                      }
                                                    }
                                                  } else {
                                                    const err24 = { instancePath: instancePath + "/weather/location/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                                    if (vErrors === null) {
                                                      vErrors = [err24];
                                                    } else {
                                                      vErrors.push(err24);
                                                    }
                                                    errors++;
                                                  }
                                                }
                                                var valid7 = _errs41 === errors;
                                              } else {
                                                var valid7 = true;
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                } else {
                                  const err25 = { instancePath: instancePath + "/weather/location", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/WeatherLocation/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                  if (vErrors === null) {
                                    vErrors = [err25];
                                  } else {
                                    vErrors.push(err25);
                                  }
                                  errors++;
                                }
                              }
                              var _valid2 = _errs29 === errors;
                              valid5 = valid5 || _valid2;
                              const _errs43 = errors;
                              if (data8 !== null) {
                                const err26 = { instancePath: instancePath + "/weather/location", schemaPath: "#/properties/weather/properties/location/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err26];
                                } else {
                                  vErrors.push(err26);
                                }
                                errors++;
                              }
                              var _valid2 = _errs43 === errors;
                              valid5 = valid5 || _valid2;
                              if (!valid5) {
                                const err27 = { instancePath: instancePath + "/weather/location", schemaPath: "#/properties/weather/properties/location/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err27];
                                } else {
                                  vErrors.push(err27);
                                }
                                errors++;
                                validate51.errors = vErrors;
                                return false;
                              } else {
                                errors = _errs28;
                                if (vErrors !== null) {
                                  if (_errs28) {
                                    vErrors.length = _errs28;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid3 = _errs27 === errors;
                            } else {
                              var valid3 = true;
                            }
                          }
                        }
                      }
                    } else {
                      validate51.errors = [{ instancePath: instancePath + "/weather", schemaPath: "#/properties/weather/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
                      return false;
                    }
                  }
                  var valid0 = _errs18 === errors;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.networkInterface !== void 0) {
                    let data14 = data.networkInterface;
                    const _errs45 = errors;
                    if (errors === _errs45) {
                      if (typeof data14 === "string") {
                        if (func1(data14) > 64) {
                          validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" }];
                          return false;
                        } else {
                          if (func1(data14) < 1) {
                            validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" }];
                            return false;
                          } else {
                            if (!pattern26.test(data14)) {
                              validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/pattern", keyword: "pattern", params: { pattern: "^[^/\\s\\x00-\\x1f]+$" }, message: 'must match pattern "^[^/\\s\\x00-\\x1f]+$"' }];
                              return false;
                            }
                          }
                        }
                      } else {
                        validate51.errors = [{ instancePath: instancePath + "/networkInterface", schemaPath: "#/properties/networkInterface/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                        return false;
                      }
                    }
                    var valid0 = _errs45 === errors;
                  } else {
                    var valid0 = true;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate51.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate51.errors = vErrors;
  return errors === 0;
}
validate51.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var schema76 = { "$schema": "https://json-schema.org/draft/2020-12/schema", "$id": "urn:liquid-widgets:calendar-status:v1", "type": "object", "additionalProperties": false, "properties": { "version": { "const": 1 }, "instanceId": { "type": "string", "format": "uuid" }, "revision": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "generation": { "type": "integer", "minimum": 0, "maximum": 4294967295 }, "context": { "anyOf": [{ "$ref": "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext" }, { "type": "null" }] }, "hasData": { "type": "boolean" }, "eventCount": { "type": "integer", "minimum": 0, "maximum": 1e4 }, "sourceId": { "anyOf": [{ "type": "string", "maxLength": 128, "minLength": 1, "pattern": "^[A-Za-z0-9_-]+$" }, { "type": "null" }] }, "status": { "enum": ["loading", "ok", "stale", "unconfigured", "unavailable"] }, "updatedAt": { "anyOf": [{ "type": "string", "maxLength": 64, "format": "date-time" }, { "type": "null" }] }, "errorCode": { "anyOf": [{ "enum": ["NETWORK_ERROR", "INVALID_DATA", "PAYLOAD_TOO_LARGE", "EXPANSION_LIMIT", "UNSUPPORTED_CALENDAR", "UNKNOWN_TIME_ZONE", "KEYRING_LOCKED", "SECRET_DELETION_FAILED", "AUTH_ERROR", "RATE_LIMITED", "NO_PLAYER", "NO_INTERFACE", "SERVICE_UNAVAILABLE", "INTERNAL_ERROR"] }, { "type": "null" }] } }, "required": ["version", "instanceId", "revision", "generation", "context", "hasData", "eventCount", "sourceId", "status", "updatedAt", "errorCode"] };
var func169 = Object.prototype.hasOwnProperty;
function validate52(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  ;
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate52.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (errors === 0) {
    if (data && typeof data == "object" && !Array.isArray(data)) {
      let missing0;
      if (data.version === void 0 && (missing0 = "version") || data.instanceId === void 0 && (missing0 = "instanceId") || data.revision === void 0 && (missing0 = "revision") || data.generation === void 0 && (missing0 = "generation") || data.context === void 0 && (missing0 = "context") || data.hasData === void 0 && (missing0 = "hasData") || data.eventCount === void 0 && (missing0 = "eventCount") || data.sourceId === void 0 && (missing0 = "sourceId") || data.status === void 0 && (missing0 = "status") || data.updatedAt === void 0 && (missing0 = "updatedAt") || data.errorCode === void 0 && (missing0 = "errorCode")) {
        validate52.errors = [{ instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: missing0 }, message: "must have required property '" + missing0 + "'" }];
        return false;
      } else {
        const _errs1 = errors;
        for (const key0 in data) {
          if (!func169.call(schema76.properties, key0)) {
            validate52.errors = [{ instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" }];
            return false;
            break;
          }
        }
        if (_errs1 === errors) {
          if (data.version !== void 0) {
            const _errs2 = errors;
            if (1 !== data.version) {
              validate52.errors = [{ instancePath: instancePath + "/version", schemaPath: "#/properties/version/const", keyword: "const", params: { allowedValue: 1 }, message: "must be equal to constant" }];
              return false;
            }
            var valid0 = _errs2 === errors;
          } else {
            var valid0 = true;
          }
          if (valid0) {
            if (data.instanceId !== void 0) {
              let data1 = data.instanceId;
              const _errs3 = errors;
              if (errors === _errs3) {
                if (errors === _errs3) {
                  if (typeof data1 === "string") {
                    if (!formats76.test(data1)) {
                      validate52.errors = [{ instancePath: instancePath + "/instanceId", schemaPath: "#/properties/instanceId/format", keyword: "format", params: { format: "uuid" }, message: 'must match format "uuid"' }];
                      return false;
                    }
                  } else {
                    validate52.errors = [{ instancePath: instancePath + "/instanceId", schemaPath: "#/properties/instanceId/type", keyword: "type", params: { type: "string" }, message: "must be string" }];
                    return false;
                  }
                }
              }
              var valid0 = _errs3 === errors;
            } else {
              var valid0 = true;
            }
            if (valid0) {
              if (data.revision !== void 0) {
                let data2 = data.revision;
                const _errs5 = errors;
                if (!(typeof data2 == "number" && (!(data2 % 1) && !isNaN(data2)) && isFinite(data2))) {
                  validate52.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                  return false;
                }
                if (errors === _errs5) {
                  if (typeof data2 == "number" && isFinite(data2)) {
                    if (data2 > 4294967295 || isNaN(data2)) {
                      validate52.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                      return false;
                    } else {
                      if (data2 < 0 || isNaN(data2)) {
                        validate52.errors = [{ instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                        return false;
                      }
                    }
                  }
                }
                var valid0 = _errs5 === errors;
              } else {
                var valid0 = true;
              }
              if (valid0) {
                if (data.generation !== void 0) {
                  let data3 = data.generation;
                  const _errs7 = errors;
                  if (!(typeof data3 == "number" && (!(data3 % 1) && !isNaN(data3)) && isFinite(data3))) {
                    validate52.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                    return false;
                  }
                  if (errors === _errs7) {
                    if (typeof data3 == "number" && isFinite(data3)) {
                      if (data3 > 4294967295 || isNaN(data3)) {
                        validate52.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/maximum", keyword: "maximum", params: { comparison: "<=", limit: 4294967295 }, message: "must be <= 4294967295" }];
                        return false;
                      } else {
                        if (data3 < 0 || isNaN(data3)) {
                          validate52.errors = [{ instancePath: instancePath + "/generation", schemaPath: "#/properties/generation/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                          return false;
                        }
                      }
                    }
                  }
                  var valid0 = _errs7 === errors;
                } else {
                  var valid0 = true;
                }
                if (valid0) {
                  if (data.context !== void 0) {
                    let data4 = data.context;
                    const _errs9 = errors;
                    const _errs10 = errors;
                    let valid1 = false;
                    const _errs11 = errors;
                    const _errs12 = errors;
                    if (errors === _errs12) {
                      if (data4 && typeof data4 == "object" && !Array.isArray(data4)) {
                        let missing1;
                        if (data4.month === void 0 && (missing1 = "month") || data4.timeZone === void 0 && (missing1 = "timeZone") || data4.weekStart === void 0 && (missing1 = "weekStart")) {
                          const err0 = { instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/required", keyword: "required", params: { missingProperty: missing1 }, message: "must have required property '" + missing1 + "'" };
                          if (vErrors === null) {
                            vErrors = [err0];
                          } else {
                            vErrors.push(err0);
                          }
                          errors++;
                        } else {
                          const _errs14 = errors;
                          for (const key1 in data4) {
                            if (!(key1 === "month" || key1 === "timeZone" || key1 === "weekStart")) {
                              const err1 = { instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
                              if (vErrors === null) {
                                vErrors = [err1];
                              } else {
                                vErrors.push(err1);
                              }
                              errors++;
                              break;
                            }
                          }
                          if (_errs14 === errors) {
                            if (data4.month !== void 0) {
                              let data5 = data4.month;
                              const _errs15 = errors;
                              if (errors === _errs15) {
                                if (typeof data5 === "string") {
                                  if (func1(data5) > 7) {
                                    const err2 = { instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/maxLength", keyword: "maxLength", params: { limit: 7 }, message: "must NOT have more than 7 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err2];
                                    } else {
                                      vErrors.push(err2);
                                    }
                                    errors++;
                                  } else {
                                    if (!pattern4.test(data5)) {
                                      const err3 = { instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/pattern", keyword: "pattern", params: { pattern: "^[0-9]{4}-(0[1-9]|1[0-2])$" }, message: 'must match pattern "^[0-9]{4}-(0[1-9]|1[0-2])$"' };
                                      if (vErrors === null) {
                                        vErrors = [err3];
                                      } else {
                                        vErrors.push(err3);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err4 = { instancePath: instancePath + "/context/month", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/month/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err4];
                                  } else {
                                    vErrors.push(err4);
                                  }
                                  errors++;
                                }
                              }
                              var valid3 = _errs15 === errors;
                            } else {
                              var valid3 = true;
                            }
                            if (valid3) {
                              if (data4.timeZone !== void 0) {
                                let data6 = data4.timeZone;
                                const _errs17 = errors;
                                if (errors === _errs17) {
                                  if (typeof data6 === "string") {
                                    if (func1(data6) > 255) {
                                      const err5 = { instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/maxLength", keyword: "maxLength", params: { limit: 255 }, message: "must NOT have more than 255 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err5];
                                      } else {
                                        vErrors.push(err5);
                                      }
                                      errors++;
                                    } else {
                                      if (func1(data6) < 1) {
                                        const err6 = { instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err6];
                                        } else {
                                          vErrors.push(err6);
                                        }
                                        errors++;
                                      }
                                    }
                                  } else {
                                    const err7 = { instancePath: instancePath + "/context/timeZone", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/timeZone/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err7];
                                    } else {
                                      vErrors.push(err7);
                                    }
                                    errors++;
                                  }
                                }
                                var valid3 = _errs17 === errors;
                              } else {
                                var valid3 = true;
                              }
                              if (valid3) {
                                if (data4.weekStart !== void 0) {
                                  let data7 = data4.weekStart;
                                  const _errs19 = errors;
                                  if (!(typeof data7 == "number" && (!(data7 % 1) && !isNaN(data7)) && isFinite(data7))) {
                                    const err8 = { instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err8];
                                    } else {
                                      vErrors.push(err8);
                                    }
                                    errors++;
                                  }
                                  if (errors === _errs19) {
                                    if (typeof data7 == "number" && isFinite(data7)) {
                                      if (data7 > 6 || isNaN(data7)) {
                                        const err9 = { instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/maximum", keyword: "maximum", params: { comparison: "<=", limit: 6 }, message: "must be <= 6" };
                                        if (vErrors === null) {
                                          vErrors = [err9];
                                        } else {
                                          vErrors.push(err9);
                                        }
                                        errors++;
                                      } else {
                                        if (data7 < 0 || isNaN(data7)) {
                                          const err10 = { instancePath: instancePath + "/context/weekStart", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/properties/weekStart/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
                                          if (vErrors === null) {
                                            vErrors = [err10];
                                          } else {
                                            vErrors.push(err10);
                                          }
                                          errors++;
                                        }
                                      }
                                    }
                                  }
                                  var valid3 = _errs19 === errors;
                                } else {
                                  var valid3 = true;
                                }
                              }
                            }
                          }
                        }
                      } else {
                        const err11 = { instancePath: instancePath + "/context", schemaPath: "urn:liquid-widgets:snapshot:v1#/$defs/CalendarContext/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err11];
                        } else {
                          vErrors.push(err11);
                        }
                        errors++;
                      }
                    }
                    var _valid0 = _errs11 === errors;
                    valid1 = valid1 || _valid0;
                    const _errs21 = errors;
                    if (data4 !== null) {
                      const err12 = { instancePath: instancePath + "/context", schemaPath: "#/properties/context/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                      if (vErrors === null) {
                        vErrors = [err12];
                      } else {
                        vErrors.push(err12);
                      }
                      errors++;
                    }
                    var _valid0 = _errs21 === errors;
                    valid1 = valid1 || _valid0;
                    if (!valid1) {
                      const err13 = { instancePath: instancePath + "/context", schemaPath: "#/properties/context/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                      if (vErrors === null) {
                        vErrors = [err13];
                      } else {
                        vErrors.push(err13);
                      }
                      errors++;
                      validate52.errors = vErrors;
                      return false;
                    } else {
                      errors = _errs10;
                      if (vErrors !== null) {
                        if (_errs10) {
                          vErrors.length = _errs10;
                        } else {
                          vErrors = null;
                        }
                      }
                    }
                    var valid0 = _errs9 === errors;
                  } else {
                    var valid0 = true;
                  }
                  if (valid0) {
                    if (data.hasData !== void 0) {
                      const _errs23 = errors;
                      if (typeof data.hasData !== "boolean") {
                        validate52.errors = [{ instancePath: instancePath + "/hasData", schemaPath: "#/properties/hasData/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" }];
                        return false;
                      }
                      var valid0 = _errs23 === errors;
                    } else {
                      var valid0 = true;
                    }
                    if (valid0) {
                      if (data.eventCount !== void 0) {
                        let data9 = data.eventCount;
                        const _errs25 = errors;
                        if (!(typeof data9 == "number" && (!(data9 % 1) && !isNaN(data9)) && isFinite(data9))) {
                          validate52.errors = [{ instancePath: instancePath + "/eventCount", schemaPath: "#/properties/eventCount/type", keyword: "type", params: { type: "integer" }, message: "must be integer" }];
                          return false;
                        }
                        if (errors === _errs25) {
                          if (typeof data9 == "number" && isFinite(data9)) {
                            if (data9 > 1e4 || isNaN(data9)) {
                              validate52.errors = [{ instancePath: instancePath + "/eventCount", schemaPath: "#/properties/eventCount/maximum", keyword: "maximum", params: { comparison: "<=", limit: 1e4 }, message: "must be <= 10000" }];
                              return false;
                            } else {
                              if (data9 < 0 || isNaN(data9)) {
                                validate52.errors = [{ instancePath: instancePath + "/eventCount", schemaPath: "#/properties/eventCount/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" }];
                                return false;
                              }
                            }
                          }
                        }
                        var valid0 = _errs25 === errors;
                      } else {
                        var valid0 = true;
                      }
                      if (valid0) {
                        if (data.sourceId !== void 0) {
                          let data10 = data.sourceId;
                          const _errs27 = errors;
                          const _errs28 = errors;
                          let valid4 = false;
                          const _errs29 = errors;
                          if (errors === _errs29) {
                            if (typeof data10 === "string") {
                              if (func1(data10) > 128) {
                                const err14 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 128 }, message: "must NOT have more than 128 characters" };
                                if (vErrors === null) {
                                  vErrors = [err14];
                                } else {
                                  vErrors.push(err14);
                                }
                                errors++;
                              } else {
                                if (func1(data10) < 1) {
                                  const err15 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err15];
                                  } else {
                                    vErrors.push(err15);
                                  }
                                  errors++;
                                } else {
                                  if (!pattern5.test(data10)) {
                                    const err16 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/pattern", keyword: "pattern", params: { pattern: "^[A-Za-z0-9_-]+$" }, message: 'must match pattern "^[A-Za-z0-9_-]+$"' };
                                    if (vErrors === null) {
                                      vErrors = [err16];
                                    } else {
                                      vErrors.push(err16);
                                    }
                                    errors++;
                                  }
                                }
                              }
                            } else {
                              const err17 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err17];
                              } else {
                                vErrors.push(err17);
                              }
                              errors++;
                            }
                          }
                          var _valid1 = _errs29 === errors;
                          valid4 = valid4 || _valid1;
                          const _errs31 = errors;
                          if (data10 !== null) {
                            const err18 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                            if (vErrors === null) {
                              vErrors = [err18];
                            } else {
                              vErrors.push(err18);
                            }
                            errors++;
                          }
                          var _valid1 = _errs31 === errors;
                          valid4 = valid4 || _valid1;
                          if (!valid4) {
                            const err19 = { instancePath: instancePath + "/sourceId", schemaPath: "#/properties/sourceId/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                            if (vErrors === null) {
                              vErrors = [err19];
                            } else {
                              vErrors.push(err19);
                            }
                            errors++;
                            validate52.errors = vErrors;
                            return false;
                          } else {
                            errors = _errs28;
                            if (vErrors !== null) {
                              if (_errs28) {
                                vErrors.length = _errs28;
                              } else {
                                vErrors = null;
                              }
                            }
                          }
                          var valid0 = _errs27 === errors;
                        } else {
                          var valid0 = true;
                        }
                        if (valid0) {
                          if (data.status !== void 0) {
                            let data11 = data.status;
                            const _errs33 = errors;
                            if (!(data11 === "loading" || data11 === "ok" || data11 === "stale" || data11 === "unconfigured" || data11 === "unavailable")) {
                              validate52.errors = [{ instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema76.properties.status.enum }, message: "must be equal to one of the allowed values" }];
                              return false;
                            }
                            var valid0 = _errs33 === errors;
                          } else {
                            var valid0 = true;
                          }
                          if (valid0) {
                            if (data.updatedAt !== void 0) {
                              let data12 = data.updatedAt;
                              const _errs34 = errors;
                              const _errs35 = errors;
                              let valid5 = false;
                              const _errs36 = errors;
                              if (errors === _errs36) {
                                if (errors === _errs36) {
                                  if (typeof data12 === "string") {
                                    if (func1(data12) > 64) {
                                      const err20 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/maxLength", keyword: "maxLength", params: { limit: 64 }, message: "must NOT have more than 64 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err20];
                                      } else {
                                        vErrors.push(err20);
                                      }
                                      errors++;
                                    } else {
                                      if (!formats0.validate(data12)) {
                                        const err21 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
                                        if (vErrors === null) {
                                          vErrors = [err21];
                                        } else {
                                          vErrors.push(err21);
                                        }
                                        errors++;
                                      }
                                    }
                                  } else {
                                    const err22 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/0/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err22];
                                    } else {
                                      vErrors.push(err22);
                                    }
                                    errors++;
                                  }
                                }
                              }
                              var _valid2 = _errs36 === errors;
                              valid5 = valid5 || _valid2;
                              const _errs38 = errors;
                              if (data12 !== null) {
                                const err23 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                if (vErrors === null) {
                                  vErrors = [err23];
                                } else {
                                  vErrors.push(err23);
                                }
                                errors++;
                              }
                              var _valid2 = _errs38 === errors;
                              valid5 = valid5 || _valid2;
                              if (!valid5) {
                                const err24 = { instancePath: instancePath + "/updatedAt", schemaPath: "#/properties/updatedAt/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                if (vErrors === null) {
                                  vErrors = [err24];
                                } else {
                                  vErrors.push(err24);
                                }
                                errors++;
                                validate52.errors = vErrors;
                                return false;
                              } else {
                                errors = _errs35;
                                if (vErrors !== null) {
                                  if (_errs35) {
                                    vErrors.length = _errs35;
                                  } else {
                                    vErrors = null;
                                  }
                                }
                              }
                              var valid0 = _errs34 === errors;
                            } else {
                              var valid0 = true;
                            }
                            if (valid0) {
                              if (data.errorCode !== void 0) {
                                let data13 = data.errorCode;
                                const _errs40 = errors;
                                const _errs41 = errors;
                                let valid6 = false;
                                const _errs42 = errors;
                                if (!(data13 === "NETWORK_ERROR" || data13 === "INVALID_DATA" || data13 === "PAYLOAD_TOO_LARGE" || data13 === "EXPANSION_LIMIT" || data13 === "UNSUPPORTED_CALENDAR" || data13 === "UNKNOWN_TIME_ZONE" || data13 === "KEYRING_LOCKED" || data13 === "SECRET_DELETION_FAILED" || data13 === "AUTH_ERROR" || data13 === "RATE_LIMITED" || data13 === "NO_PLAYER" || data13 === "NO_INTERFACE" || data13 === "SERVICE_UNAVAILABLE" || data13 === "INTERNAL_ERROR")) {
                                  const err25 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/0/enum", keyword: "enum", params: { allowedValues: schema76.properties.errorCode.anyOf[0].enum }, message: "must be equal to one of the allowed values" };
                                  if (vErrors === null) {
                                    vErrors = [err25];
                                  } else {
                                    vErrors.push(err25);
                                  }
                                  errors++;
                                }
                                var _valid3 = _errs42 === errors;
                                valid6 = valid6 || _valid3;
                                const _errs43 = errors;
                                if (data13 !== null) {
                                  const err26 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf/1/type", keyword: "type", params: { type: "null" }, message: "must be null" };
                                  if (vErrors === null) {
                                    vErrors = [err26];
                                  } else {
                                    vErrors.push(err26);
                                  }
                                  errors++;
                                }
                                var _valid3 = _errs43 === errors;
                                valid6 = valid6 || _valid3;
                                if (!valid6) {
                                  const err27 = { instancePath: instancePath + "/errorCode", schemaPath: "#/properties/errorCode/anyOf", keyword: "anyOf", params: {}, message: "must match a schema in anyOf" };
                                  if (vErrors === null) {
                                    vErrors = [err27];
                                  } else {
                                    vErrors.push(err27);
                                  }
                                  errors++;
                                  validate52.errors = vErrors;
                                  return false;
                                } else {
                                  errors = _errs41;
                                  if (vErrors !== null) {
                                    if (_errs41) {
                                      vErrors.length = _errs41;
                                    } else {
                                      vErrors = null;
                                    }
                                  }
                                }
                                var valid0 = _errs40 === errors;
                              } else {
                                var valid0 = true;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      validate52.errors = [{ instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" }];
      return false;
    }
  }
  validate52.errors = vErrors;
  return errors === 0;
}
validate52.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };

// src/shared/validation.ts
var MAX_PAYLOAD_BYTES = 512 * 1024;
var ValidationError = class extends Error {
  constructor() {
    super("Invalid protocol payload");
    this.name = "ValidationError";
  }
};
function parse(input, validate) {
  if (new TextEncoder().encode(input).length > MAX_PAYLOAD_BYTES) throw new ValidationError();
  let value;
  try {
    value = JSON.parse(input);
  } catch {
    throw new ValidationError();
  }
  if (!validate(value)) throw new ValidationError();
  return value;
}
function parseSnapshot(input) {
  return parse(input, snapshot);
}
var providerValidators = { calendar, weather, system, network, media };
function parseProviderState(name, input) {
  if (!Object.hasOwn(providerValidators, name)) throw new ValidationError();
  return parse(input, providerValidators[name]);
}

// src/shared/providerStore.ts
var PROVIDERS = ["calendar", "weather", "system", "network", "media"];

// src/shared/dataClient.ts
var Cancellation = class {
  cancelled = false;
  listeners = /* @__PURE__ */ new Set();
  onCancel(callback) {
    if (this.cancelled) callback();
    else this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }
  cancel() {
    this.cancelled = true;
    for (const callback of this.listeners) callback();
    this.listeners.clear();
  }
};
var DataClient = class {
  constructor(wire, store, changed, connection) {
    this.wire = wire;
    this.store = store;
    this.changed = changed;
    this.connection = connection;
  }
  wire;
  store;
  changed;
  connection;
  desiredContext = null;
  appliedContext = null;
  contextPump = null;
  providers = [];
  resumePending = false;
  resumeRetries = /* @__PURE__ */ new Map();
  generation = 0;
  retryCancel = null;
  retryDelay = 1e3;
  owner = null;
  unwatch = null;
  unsignal = null;
  token = null;
  cancel = new Cancellation();
  setCalendarContext(context, day) {
    const json = JSON.stringify(context);
    this.desiredContext = { json, day, key: json + day };
    void this.syncContext().catch(() => {
    });
  }
  syncContext() {
    if (this.contextPump) return this.contextPump;
    if (!this.owner || !this.desiredContext || this.appliedContext?.key === this.desiredContext.key) return Promise.resolve();
    const owner = this.owner, generation = this.generation;
    const current = () => owner === this.owner && generation === this.generation;
    const pump = (async () => {
      while (current() && this.desiredContext && this.appliedContext?.key !== this.desiredContext.key) {
        const desired = this.desiredContext, previous = this.appliedContext;
        await this.wire.call(owner, "SetCalendarContext", [desired.json], this.cancel);
        if (!current()) return;
        if (previous && previous.day !== desired.day && this.token) {
          await this.wire.call(owner, "Refresh", ["calendar"], this.cancel).catch(() => {
          });
          if (!current()) return;
        }
        this.appliedContext = desired;
      }
    })();
    this.contextPump = pump;
    void pump.finally(() => {
      if (this.contextPump === pump) this.contextPump = null;
    }).catch(() => {
    });
    return pump;
  }
  refreshAfterResume() {
    this.resumePending = true;
    if (!this.owner || !this.token) return;
    this.resumePending = false;
    const owner = this.owner, generation = this.generation;
    const current = () => this.owner === owner && this.generation === generation;
    for (const name of this.providers.filter((p) => (p === "calendar" || p === "weather") && this.store.get(p).status !== "unconfigured")) {
      this.resumeRetries.get(name)?.();
      this.resumeRetries.delete(name);
      this.store.markRefreshing(name);
      this.changed(name);
      const source = this.store.get(name).sourceId;
      const relevant = () => current() && this.store.get(name).sourceId === source && this.store.get(name).status === "loading";
      const refresh = async () => {
        try {
          await this.wire.call(owner, "Refresh", [name], this.cancel);
        } catch {
          if (relevant()) this.resumeRetries.set(name, this.wire.schedule(6e4, () => {
            this.resumeRetries.delete(name);
            if (relevant()) void refresh();
          }));
        }
      };
      void refresh();
    }
  }
  start(providers) {
    this.stop();
    if (!providers.length || providers.some((p) => !PROVIDERS.includes(p))) throw new Error("Invalid providers");
    this.providers = [...new Set(providers)];
    this.unwatch = this.wire.watchOwner((owner) => {
      this.retryDelay = 1e3;
      void this.connect(owner, [...new Set(providers)]);
    });
  }
  release(owner, token) {
    void this.wire.call(owner, "Unsubscribe", [token], null).catch(() => {
    });
  }
  disconnect() {
    this.retryCancel?.();
    this.retryCancel = null;
    for (const cancel of this.resumeRetries.values()) cancel();
    this.resumeRetries.clear();
    this.appliedContext = null;
    this.contextPump = null;
    this.generation++;
    this.cancel.cancel();
    this.cancel = new Cancellation();
    this.unsignal?.();
    this.unsignal = null;
    if (this.owner && this.token) this.release(this.owner, this.token);
    this.token = null;
    this.owner = null;
    this.store.resetOwner();
  }
  stop() {
    this.resumePending = false;
    this.providers = [];
    this.retryDelay = 1e3;
    this.unwatch?.();
    this.unwatch = null;
    this.disconnect();
    this.connection("disconnected");
  }
  async connect(owner, providers) {
    if (owner && owner === this.owner) return;
    this.disconnect();
    this.owner = owner;
    if (!owner) {
      this.connection("disconnected");
      return;
    }
    const generation = this.generation;
    const current = () => generation === this.generation && owner === this.owner;
    this.connection("connecting");
    this.unsignal = this.wire.watchChanges(owner, (name, revision, payload) => {
      if (!current()) return;
      try {
        const provider = name;
        if (this.store.applyChange(provider, revision, parseProviderState(provider, payload))) {
          this.resumeRetries.get(provider)?.();
          this.resumeRetries.delete(provider);
          this.changed(provider);
        }
      } catch {
        this.connection("invalid-data");
      }
    });
    try {
      if (this.desiredContext) {
        await this.syncContext();
        if (!current()) return;
      }
      const [token] = await this.wire.call(owner, "Subscribe", [providers], null);
      if (typeof token !== "string" || !token || token.length > 128) throw new Error("Invalid subscription");
      if (!current()) {
        this.release(owner, token);
        return;
      }
      this.token = token;
      const [raw] = await this.wire.call(owner, "GetSnapshot", [], this.cancel);
      if (!current()) return;
      if (typeof raw !== "string") throw new Error("Invalid snapshot");
      this.store.acceptSnapshot(parseSnapshot(raw));
      this.retryDelay = 1e3;
      this.changed();
      this.connection("connected");
      if (this.resumePending) this.refreshAfterResume();
    } catch {
      if (current()) {
        this.disconnect();
        this.connection("unavailable");
        const retryGeneration = this.generation;
        const delay = this.retryDelay;
        this.retryDelay = Math.min(3e4, delay * 2);
        this.retryCancel = this.wire.schedule(delay, () => {
          this.retryCancel = null;
          if (this.generation === retryGeneration) void this.connect(owner, providers);
        });
      }
    }
  }
};
export {
  Cancellation,
  DataClient
};
