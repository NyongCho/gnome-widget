#!@GJS@ -m
var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/calendar-worker/budget.ts
import GLib from "gi://GLib";
var CalendarFailure = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "CalendarFailure";
  }
  code;
};
function createBudget(deadlineUs) {
  return { check() {
    if (GLib.get_monotonic_time() >= deadlineUs) throw new CalendarFailure("EXPANSION_LIMIT");
  } };
}
function invalid() {
  throw new CalendarFailure("INVALID_DATA");
}

export {
  __export,
  CalendarFailure,
  createBudget,
  invalid
};
